import os
import sys
import webview
from src.api.bridge import VideoNarratorAPI
from src.utils.paths import app_version


def get_asset_path(relative_path: str) -> str:
    """Ruta de un recurso del programa. La interfaz vive siempre junto a main.py (carpeta 'app'),
    también en la app empaquetada: así los parches la pueden actualizar."""
    base_path = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_path, relative_path)


def main():
    from src.utils.inicio import log
    log(f'--- abriendo VideoNarrator v{app_version()}')
    try:   # agrupa la ventana con el acceso directo en la barra de tareas (instalaciones v4.3+)
        from src.utils.winnotify import set_app_id
        set_app_id()
    except Exception:
        pass
    api = VideoNarratorAPI()
    log('motor listo')
    html_file = get_asset_path(os.path.join('src', 'ui', 'index.html'))

    if not os.path.exists(html_file):
        print(f"Error: No se encontró el archivo HTML en {html_file}")
        sys.exit(1)

    window = webview.create_window(
        title=f'VideoNarrator v{app_version()}',
        url=html_file,
        js_api=api,
        width=1440,
        height=900,
        min_size=(1100, 680),
        background_color='#000000'
    )

    try:
        window.events.loaded += lambda *a: log('pantalla cargada')
    except Exception:
        pass
    log('abriendo la ventana')
    webview.start(debug=False)


if __name__ == '__main__':
    main()
