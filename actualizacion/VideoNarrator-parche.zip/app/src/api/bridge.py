import os
import re
import json
import threading
import dataclasses
from typing import Optional, Dict, Any
import webview
from src.core.script_parser import parse_script, ScriptClip
from src.core.silence_trimmer import detect_keep_segments
from src.core.media_scanner import scan_images_folder, list_ignored_files, scan_audio_files
from src.core.timeline import build_timeline, build_story_timeline, split_audio_proportionally, trim_targets, apply_trims
from src.core.render_engine import RenderEngine, RenderOptions, is_video_file, probe_media_dimensions
from src.utils.ffmpeg_locator import get_audio_duration, get_ffmpeg_path
from src.utils.helpers import format_time, format_size, get_image_thumbnail_base64, get_media_thumbnail_base64
try:
    from src.core.audio_aligner import align_script_to_audio
    HAS_WHISPER = True
except ImportError:
    HAS_WHISPER = False
import platform
import subprocess as _sp


def _open_system(path):
    """Abre un archivo o carpeta con el programa por defecto del SO."""
    try:
        system = platform.system()
        if system == 'Darwin':
            _sp.Popen(['open', path])
        elif system == 'Linux':
            _sp.Popen(['xdg-open', path])
        else:
            os.startfile(path)
    except Exception:
        pass


class VideoNarratorAPI:
    def __init__(self):
        self._render_engine = RenderEngine()
        self._current_thread = None
        self._cached_alignment = None  # Reusar datos Whisper entre analyze y render
        self._cached_story_alignment = None  # (audio_path, textos, alineación) del narrador
        self._media_dir = ''       # carpeta del proyecto (imágenes/videos)
        self._audio_dir = ''       # última carpeta de donde se eligió un audio

    def _remember_media(self, images_folder):
        try:
            if isinstance(images_folder, (list, tuple)) and images_folder:
                d = os.path.dirname(images_folder[0])
            else:
                d = images_folder or ''
            if d and os.path.isdir(d):
                self._media_dir = d
        except Exception:
            pass

    def _audio_dialog_dir(self) -> str:
        """Carpeta inicial de los diálogos de audio. Así Windows NO abre 'Descargas' por defecto:
        si esa carpeta tiene muchos videos, el diálogo se queda "No responde" generando miniaturas."""
        for d in (self._audio_dir, self._media_dir):
            if d and os.path.isdir(d):
                return d
        return ''

    def _remember_audio(self, path):
        try:
            d = os.path.dirname(path)
            if d and os.path.isdir(d):
                self._audio_dir = d
        except Exception:
            pass

    # ── Preferencias guardadas (ej: plantilla y color de los subtítulos) ─────
    @staticmethod
    def _settings_paths():
        from src.utils.paths import data_dir
        return [os.path.join(data_dir(), 'vn_settings.json'),
                os.path.join(os.path.expanduser('~'), '.videonarrator_settings.json')]

    def get_settings(self) -> Dict[str, Any]:
        for path in self._settings_paths():
            try:
                with open(path, 'r', encoding='utf-8') as fh:
                    data = json.load(fh)
                if isinstance(data, dict):
                    return data
            except Exception:
                continue
        return {}

    def save_settings(self, data: Dict[str, Any]) -> Dict[str, Any]:
        current = self.get_settings()
        if isinstance(data, dict):
            current.update(data)
        for path in self._settings_paths():
            try:
                with open(path, 'w', encoding='utf-8') as fh:
                    json.dump(current, fh, ensure_ascii=False, indent=2)
                return {'ok': True}
            except Exception:
                continue
        return {'ok': False}

    # ── Mis historias: proyectos guardados (v5.3) ─────────────────────────
    def projects_list(self) -> Dict[str, Any]:
        from src.core import projects
        try:
            return {'items': projects.list_projects()}
        except Exception as e:
            return {'items': [], 'error': str(e)}

    def project_get(self, pid: str) -> Dict[str, Any]:
        from src.core import projects
        data = projects.get_project(pid)
        if not data:
            return {'error': 'No se encontró la historia.'}
        data['faltan'] = projects.missing_files(data.get('contenido') or {})
        return data

    def project_save(self, data: Dict[str, Any]) -> Dict[str, Any]:
        from src.core import projects
        try:
            res = projects.save_project(data)
        except Exception as e:
            return {'error': str(e)}
        if res.get('ok'):
            self.save_settings({'ultima_historia': res['id']})
        return res

    def project_rename(self, pid: str, nombre: str) -> Dict[str, Any]:
        from src.core import projects
        return projects.rename_project(pid, nombre)

    def project_duplicate(self, pid: str) -> Dict[str, Any]:
        from src.core import projects
        return projects.duplicate_project(pid)

    def project_delete(self, pid: str) -> Dict[str, Any]:
        from src.core import projects
        res = projects.delete_project(pid)
        if res.get('ok') and self.get_settings().get('ultima_historia') == pid:
            self.save_settings({'ultima_historia': ''})
        return res

    def project_set_current(self, pid: str) -> Dict[str, Any]:
        """La historia que se abre al recargar la pantalla ('' = empezar una nueva)."""
        self._pending_open = pid or ''
        return self.save_settings({'ultima_historia': pid or ''})

    def project_startup(self) -> Dict[str, Any]:
        """Qué historia mostrar al cargar la pantalla (v6.4):
        - al abrir la app: ninguna (pantalla limpia; las historias están en "Mis historias");
        - al cambiar de historia o recargar dentro de la misma sesión: la elegida / la que estaba abierta."""
        first = not getattr(self, '_ui_started', False)
        self._ui_started = True
        pend = getattr(self, '_pending_open', None)
        self._pending_open = None
        if pend is not None:
            return {'id': pend}
        return {'id': '' if first else (self.get_settings().get('ultima_historia') or '')}

    def project_poster(self, media_path: str) -> Dict[str, Any]:
        """Póster nítido (hasta 360x640) de la primera escena, para la biblioteca de historias."""
        from src.core import projects
        return {'poster': projects.make_poster(media_path) or ''}

    # ── Música de fondo (v5.8) ────────────────────────────────────────────
    def browse_music(self, kind: str = 'file') -> Dict[str, Any]:
        """Elegir una canción (kind='file') o una carpeta de canciones que rotan (kind='folder')."""
        try:
            window = self._get_window()
            if kind == 'folder':
                res = window.create_file_dialog(webview.FOLDER_DIALOG)
            else:
                res = window.create_file_dialog(
                    webview.OPEN_DIALOG, directory=self._audio_dialog_dir(),
                    file_types=('Música (*.mp3;*.wav;*.m4a;*.aac;*.flac;*.ogg)', 'Todos (*.*)'))
            if not res:
                return {}
            return self.describe_music(res[0])
        except Exception as e:
            return {'error': str(e)}

    def describe_music(self, path: str) -> Dict[str, Any]:
        from src.core import music as music_mod
        if not path or not os.path.exists(path):
            return {'missing': True, 'path': path, 'filename': os.path.basename(str(path or '').rstrip('\\/'))}
        if os.path.isdir(path):
            tracks = music_mod.list_tracks(path)
            return {'path': path, 'filename': os.path.basename(path.rstrip('\\/')), 'is_folder': True,
                    'count': len(tracks), 'next': os.path.basename(music_mod.pick_track(path, advance=False) or '')}
        try:
            duration_str = format_time(get_audio_duration(path))
        except Exception:
            duration_str = '--:--'
        return {'path': path, 'filename': os.path.basename(path), 'is_folder': False, 'duration_str': duration_str}

    def music_preview(self, path: str, start: float = 0.0) -> Dict[str, Any]:
        """Fragmento de 25 s de la canción para escucharla dentro de la app."""
        from src.core import music as music_mod
        ff = get_ffmpeg_path()
        try:
            start = max(0.0, float(start or 0))
        except (TypeError, ValueError):
            start = 0.0
        url = music_mod.preview_clip(ff, path, start) if ff else ''
        return {'url': url} if url else {'error': 'No se pudo leer la canción.'}

    # ── Voz del narrador con Fish Audio (v6.1) ───────────────────────────
    def fish_get_config(self) -> Dict[str, Any]:
        from src.core import fish_tts
        return fish_tts.public_config()

    def fish_save_config(self, changes: Dict[str, Any]) -> Dict[str, Any]:
        from src.core import fish_tts
        try:
            return {'ok': True, 'config': fish_tts.save_config(changes or {})}
        except Exception as e:
            return {'ok': False, 'mensaje': str(e)}

    def fish_account(self) -> Dict[str, Any]:
        """Saldo y voces propias (también sirve para comprobar que la clave funciona)."""
        from src.core import fish_tts
        try:
            out = {'ok': True, 'voices': fish_tts.my_voices()}
        except fish_tts.FishError as e:
            return {'ok': False, 'mensaje': str(e)}
        try:
            out.update(fish_tts.balance())
        except Exception:
            out['credit'] = None
        return out

    def fish_check_voice(self, text: str) -> Dict[str, Any]:
        from src.core import fish_tts
        try:
            return {'ok': True, 'voice': fish_tts.voice_info(text)}
        except fish_tts.FishError as e:
            return {'ok': False, 'mensaje': str(e)}

    def fish_generate(self, lines, images=None, audio: str = '', force: bool = False) -> Dict[str, Any]:
        """Genera la voz de las líneas del narrador en segundo plano. Avisa con onFishProgress / onFishDone."""
        from src.core import fish_tts
        if getattr(self, '_fish_running', False):
            return {'ok': False, 'mensaje': 'Ya se está generando la voz.'}
        cfg = fish_tts.load_config()
        if not cfg.get('api_key'):
            return {'ok': False, 'mensaje': 'Falta tu clave de API de Fish Audio.'}
        if not cfg.get('voice_id'):
            return {'ok': False, 'mensaje': 'Elige una voz de Fish Audio.'}
        clean = [{'clip_id': int(l.get('clip_id')), 'text': str(l.get('text') or '')} for l in (lines or []) if l.get('clip_id') is not None]
        if not clean:
            return {'ok': False, 'mensaje': 'No hay líneas del narrador para generar.'}
        folder = fish_tts.output_dir(images, audio)
        self._fish_running = True
        self._fish_cancel = False
        window = self._get_window()

        def emit(fn, data):
            try:
                self._js(f"window.{fn} && window.{fn}({json.dumps(data)})")
            except Exception:
                pass

        def run():
            try:
                res = fish_tts.generate_lines(clean, folder, force=bool(force),
                                              on_progress=lambda d: emit('onFishProgress', d),
                                              cancelled=lambda: self._fish_cancel)
                res['files'] = {str(k): v for k, v in res['files'].items()}
                emit('onFishDone', dict(res, ok=True))
            except Exception as e:
                emit('onFishDone', {'ok': False, 'mensaje': str(e)})
            finally:
                self._fish_running = False
        threading.Thread(target=run, daemon=True).start()
        return {'ok': True, 'started': True, 'folder': folder, 'total': len(clean)}

    def fish_cancel(self) -> Dict[str, Any]:
        self._fish_cancel = True
        return {'ok': True}

    # ── Fish Audio con cuenta gratis: la web + Descargas (v6.2) ─────────────
    def fish_copy_text(self, text: str) -> Dict[str, Any]:
        from src.core import fish_web
        return {'ok': fish_web.copy_text(str(text or ''))}

    def fish_watch_start(self, folder: str = '') -> Dict[str, Any]:
        """Vigila Descargas; cada audio nuevo llega a la página con window.onFishDownload."""
        from src.core import fish_web
        self.fish_watch_stop()
        folder = folder if folder and os.path.isdir(folder) else fish_web.downloads_dir()
        window = self._get_window()

        def on_new(path):
            try:
                data = {'path': path, 'name': os.path.basename(path)}
                self._js(f"window.onFishDownload && window.onFishDownload({json.dumps(data)})")
            except Exception:
                pass
        self._fish_watcher = fish_web.DownloadWatcher(folder, on_new).start()
        return {'ok': True, 'folder': folder}

    def fish_watch_stop(self) -> Dict[str, Any]:
        w = getattr(self, '_fish_watcher', None)
        if w:
            w.stop()
        self._fish_watcher = None
        return {'ok': True}

    def fish_pick_folder(self) -> Dict[str, Any]:
        try:
            res = self._get_window().create_file_dialog(webview.FOLDER_DIALOG)
            return {'folder': res[0]} if res else {}
        except Exception as e:
            return {'error': str(e)}

    def fish_pick_downloads(self, folder: str = '') -> Dict[str, Any]:
        """Elegir audios ya descargados; vuelven ordenados por hora de descarga."""
        from src.core import fish_web
        try:
            start = folder if folder and os.path.isdir(folder) else fish_web.downloads_dir()
            res = self._get_window().create_file_dialog(
                webview.OPEN_DIALOG, directory=start, allow_multiple=True,
                file_types=('Audios (*.mp3;*.wav;*.m4a;*.aac;*.ogg;*.opus;*.flac)', 'Todos (*.*)'))
            return {'files': fish_web.describe_files(list(res or []))}
        except Exception as e:
            return {'error': str(e)}

    def fish_import(self, pairs, images=None, audio: str = '') -> Dict[str, Any]:
        from src.core import fish_tts, fish_web
        try:
            res = fish_web.import_to_project(pairs or [], fish_tts.output_dir(images, audio))
            return dict(res, ok=True)
        except Exception as e:
            return {'ok': False, 'mensaje': str(e)}

    def open_url(self, url: str) -> Dict[str, Any]:
        if isinstance(url, str) and url.startswith('https://'):
            import webbrowser
            webbrowser.open(url)
            return {'ok': True}
        return {'ok': False}

    def describe_audio(self, path: str) -> Dict[str, Any]:
        """Datos de un audio ya elegido (al reabrir una historia)."""
        if not path or not os.path.exists(path):
            return {'missing': True, 'path': path, 'filename': os.path.basename(str(path or ''))}
        self._remember_audio(path)
        try:
            duration = get_audio_duration(path)
            duration_str = format_time(duration)
        except Exception:
            duration, duration_str = 0.0, '--:--'
        return {'path': path, 'filename': os.path.basename(path), 'duration': duration, 'duration_str': duration_str}

    def describe_images_folder(self, folder_path: str) -> Dict[str, Any]:
        """Datos de una carpeta de escenas ya elegida (al reabrir una historia)."""
        if not folder_path or not os.path.isdir(folder_path):
            return {'missing': True, 'path': folder_path}
        try:
            self._remember_media(folder_path)
            media = scan_images_folder(folder_path)
            n_videos = sum(1 for m in media.values() if m.is_video)
            ignored = [m.filename for m in sorted(media.values(), key=lambda x: x.clip_id) if m.auto_assigned]
            return {'path': folder_path, 'count': len(media), 'videos': n_videos,
                    'images': len(media) - n_videos, 'ignored': len(ignored), 'ignored_examples': ignored[:3]}
        except Exception as e:
            return {'error': str(e), 'path': folder_path}

    # ── Acceso con usuario y contraseña (v4.9) ────────────────────────────
    def _auth_allowed(self) -> bool:
        from src.core import auth
        return getattr(self, '_auth_ok', False) or not auth.is_enabled()

    def auth_status(self) -> Dict[str, Any]:
        """Al abrir (y cada cierto tiempo): ¿puede usarse la app en esta PC?"""
        from src.core import auth
        from src.utils.paths import app_version
        from src.utils.inicio import log
        if not auth.is_enabled():
            self._auth_ok = True
            return {'required': False, 'ok': True}
        log('verificando acceso…')
        res = auth.validate(app_version())
        log(f"acceso: {'ok' if res.get('ok') else (res.get('motivo') or '?')}" + (f" · {res.get('detalle')}" if res.get('detalle') else ''))
        if res.get('ok'):
            self._auth_ok = True
            res['es_admin'] = auth.is_admin()
        elif res.get('motivo') not in ('red', 'servidor', 'ssl') or not getattr(self, '_auth_ok', False):
            # sin internet a mitad de la sesión no se interrumpe el trabajo; al abrir, sí se exige
            self._auth_ok = False
        res['required'] = True
        res['device'] = auth.device_name()
        return res

    def auth_login(self, usuario: str, clave: str) -> Dict[str, Any]:
        from src.core import auth
        from src.utils.paths import app_version
        res = auth.login(usuario, clave, app_version())
        self._auth_ok = bool(res.get('ok'))
        if res.get('ok'):
            res['es_admin'] = auth.is_admin()
        return res

    # Panel de usuarios (solo administradores; el servidor lo vuelve a comprobar en cada acción)
    def admin_list(self) -> Dict[str, Any]:
        from src.core import auth
        return auth.admin_list()

    def admin_save(self, datos: Dict[str, Any]) -> Dict[str, Any]:
        from src.core import auth
        return auth.admin_save(datos or {})

    def admin_delete(self, usuario: str) -> Dict[str, Any]:
        from src.core import auth
        return auth.admin_delete(usuario)

    def admin_alerts(self, mark_seen: bool = False) -> Dict[str, Any]:
        from src.core import auth
        return auth.admin_alerts(bool(mark_seen))

    def change_password(self, actual: str, nueva: str) -> Dict[str, Any]:
        from src.core import auth
        return auth.change_password(actual, nueva)

    def auth_logout(self) -> Dict[str, Any]:
        from src.core import auth
        auth.logout()
        self._auth_ok = False
        return {'ok': True}

    # ── Actualizaciones por parche (.zip) ─────────────────────────────────
    def get_app_version(self) -> Dict[str, Any]:
        from src.utils.paths import app_version, is_frozen
        return {'version': app_version(), 'frozen': is_frozen()}

    def apply_update(self) -> Dict[str, Any]:
        """
        Aplica un parche: un .zip con 'parche.json' y una carpeta 'app/' con los archivos que cambian.
        - Copia de seguridad de la carpeta app actual en 'app_respaldo' (junto a la instalación).
        - Solo se escriben archivos dentro de app/ (se rechaza cualquier otra ruta).
        Hay que cerrar y volver a abrir VideoNarrator para usar la versión nueva.
        """
        try:
            window = self._get_window()
            res = window.create_file_dialog(
                webview.OPEN_DIALOG,
                file_types=('Actualización de VideoNarrator (*.zip)', 'Todos (*.*)')
            )
            if not res:
                return {}
            return self._apply_patch_zip(res[0])
        except Exception as e:
            return {'error': str(e)}

    def _apply_patch_zip(self, zpath: str, expected_version: Optional[str] = None) -> Dict[str, Any]:
        """Aplica un parche .zip ya descargado o elegido (lo usan apply_update e install_update)."""
        import zipfile, shutil as _sh
        from src.utils.paths import app_dir, install_dir, app_version
        try:
            with zipfile.ZipFile(zpath) as zf:
                names = zf.namelist()
                if 'parche.json' not in names:
                    return {'error': 'Este archivo no es una actualización de VideoNarrator (falta parche.json).'}
                info = json.loads(zf.read('parche.json').decode('utf-8'))
                new_version = str(info.get('version', '?'))
                base_min = str(info.get('base_min', ''))
                current = app_version()

                def vt(v):
                    try:
                        return tuple(int(x) for x in str(v).split('.'))
                    except Exception:
                        return (0,)
                if expected_version and vt(new_version) != vt(expected_version):
                    return {'error': f'El archivo descargado es la v{new_version}, no la v{expected_version}.'}
                if base_min and vt(current) < vt(base_min):
                    return {'error': f'Esta actualización necesita VideoNarrator v{base_min} o más nuevo '
                                     f'(tienes v{current}). Instala primero la versión completa.'}

                members = [n for n in names if n.startswith('app/') and not n.endswith('/')]
                for n in members:
                    norm = os.path.normpath(n)
                    if norm.startswith('..') or os.path.isabs(n) or not norm.startswith('app' + os.sep):
                        return {'error': f'Ruta no permitida dentro del parche: {n}'}
                if not members:
                    return {'error': 'La actualización no contiene archivos.'}

                target_root = os.path.dirname(app_dir())          # carpeta que contiene 'app'
                backup = os.path.join(install_dir(), 'app_respaldo')
                try:
                    _sh.rmtree(backup, ignore_errors=True)
                    _sh.copytree(app_dir(), backup, ignore=_sh.ignore_patterns('__pycache__'))
                except Exception as e:
                    return {'error': f'No se pudo crear la copia de seguridad: {e}'}

                for n in members:
                    dest = os.path.join(target_root, os.path.normpath(n))
                    os.makedirs(os.path.dirname(dest), exist_ok=True)
                    with zf.open(n) as src_f, open(dest, 'wb') as out_f:
                        _sh.copyfileobj(src_f, out_f)
                # archivos que el parche pide borrar
                for rel in info.get('borrar', []) or []:
                    norm = os.path.normpath(rel)
                    if norm.startswith('app' + os.sep) and '..' not in norm.split(os.sep):
                        try:
                            os.remove(os.path.join(target_root, norm))
                        except Exception:
                            pass
            return {'ok': True, 'version': new_version, 'previous': current,
                    'notes': str(info.get('notas', '')), 'files': len(members)}
        except zipfile.BadZipFile:
            return {'error': 'El archivo no es un .zip válido.'}
        except Exception as e:
            return {'error': str(e)}

    # ── Aviso automático de actualizaciones (GitHub Releases) ──────────────
    def check_for_update(self, force: bool = False) -> Dict[str, Any]:
        """Consulta si hay una versión nueva publicada. No lanza errores: sin internet = sin aviso."""
        from src.core import updater
        from src.utils.paths import app_version
        try:
            cfg = updater.load_config()
            if not force and not cfg.get('comprobar_al_abrir', True):
                return {'available': False, 'disabled': True}
            info = updater.check_latest(app_version(), cfg)
            self._update_info = info if info.get('available') else None
            return info
        except Exception as e:
            return {'available': False, 'error': str(e)}

    def install_update(self) -> Dict[str, Any]:
        """Descarga el parche de la versión nueva (avisando el avance a la interfaz) y lo aplica."""
        from src.core import updater
        from src.utils.paths import data_dir
        info = getattr(self, '_update_info', None) or {}
        local = info.get('local_path')
        if local and os.path.exists(local):            # fuente por enlace: el parche ya se descargó al comprobar
            res = self._apply_patch_zip(local, expected_version=info.get('version'))
            if res.get('ok'):
                self._update_info = None
            return res
        if not info.get('url'):
            return {'error': 'No hay un parche para descargar. Usa "Ver novedades" para bajar el instalador.'}
        window = self._get_window()

        def report(done, total):
            try:
                pct = round(done * 100.0 / total, 1) if total else -1
                self._js(f"window.onUpdateProgress && window.onUpdateProgress({json.dumps({'percent': pct, 'done': done, 'total': total})})")
            except Exception:
                pass
        try:
            folder = os.path.join(data_dir(), 'actualizaciones')
            name = re.sub(r'[^\w.\-]+', '_', info.get('asset_name') or f"parche-v{info.get('version')}.zip")
            dest = updater.download(info['url'], os.path.join(folder, name), on_progress=report)
        except Exception as e:
            return {'error': f'No se pudo descargar la actualización: {e}'}
        res = self._apply_patch_zip(dest, expected_version=info.get('version'))
        if res.get('ok'):
            self._update_info = None
            try:
                os.remove(dest)
            except Exception:
                pass
        return res

    def get_update_source(self) -> Dict[str, Any]:
        from src.core import updater
        cfg = updater.load_config()
        return {'url': cfg.get('url_actualizacion', ''), 'github_repo': cfg.get('github_repo', '')}

    def set_update_source(self, link: str) -> Dict[str, Any]:
        """Guarda el enlace de Google Drive / Dropbox de donde se buscan las actualizaciones."""
        from src.core import updater
        return updater.save_user_link(link)

    def open_release_page(self) -> Dict[str, Any]:
        info = getattr(self, '_update_info', None) or {}
        url = info.get('page') or ''
        if not url:
            from src.core import updater
            repo = updater.load_config().get('github_repo')
            url = f'https://github.com/{repo}/releases/latest' if repo else ''
        if url:
            import webbrowser
            webbrowser.open(url)
            return {'ok': True}
        return {'ok': False}

    def restart_app(self) -> Dict[str, Any]:
        """Cierra VideoNarrator y lo vuelve a abrir (para usar la versión recién instalada)."""
        import sys
        from src.utils.paths import is_frozen, install_dir, app_dir
        try:
            if is_frozen():
                cmd = [sys.executable]
            else:
                launcher = os.path.join(install_dir(), 'launcher.py')
                cmd = [sys.executable, launcher if os.path.exists(launcher) else os.path.join(app_dir(), 'main.py')]
            flags = 0x00000008 | 0x00000200 if os.name == 'nt' else 0   # DETACHED_PROCESS | NEW_PROCESS_GROUP
            _sp.Popen(cmd, cwd=install_dir(), close_fds=True, creationflags=flags,
                      stdin=_sp.DEVNULL, stdout=_sp.DEVNULL, stderr=_sp.DEVNULL)
        except Exception as e:
            return {'error': f'No se pudo reiniciar: {e}. Ciérralo y ábrelo tú mismo.'}

        def _quit():
            import time
            time.sleep(0.4)
            try:
                for w in list(webview.windows):
                    w.destroy()
            except Exception:
                pass
            time.sleep(0.6)
            os._exit(0)
        threading.Thread(target=_quit, daemon=True).start()
        return {'ok': True}

    def get_system_info(self) -> Dict[str, Any]:
        """Devuelve información de los recursos del sistema y GPU."""
        enc_name, enc_args, enc_desc = self._render_engine.probe_encoder()
        ff = get_ffmpeg_path()
        return {
            'encoder': enc_desc,
            'encoder_code': enc_name,
            'cpu_threads': os.cpu_count() or 6,
            'ffmpeg_ready': ff is not None
        }

    # ── v8.9: marca de agua ─────────────────────────────────────────────────
    def watermark_pick(self, chroma: bool = True, similarity: str = 'media') -> Dict[str, Any]:
        """Elegir el logo de la marca de agua (imagen o video) y su vista previa sin fondo."""
        try:
            res = self._get_window().create_file_dialog(
                webview.OPEN_DIALOG,
                file_types=('Logo o video (*.png;*.jpg;*.jpeg;*.webp;*.mp4;*.mov;*.webm;*.gif)', 'Todos (*.*)'))
            if not res:
                return {'cancel': True}
            return self.watermark_preview(res[0] if isinstance(res, (list, tuple)) else res, chroma, similarity)
        except Exception as e:
            return {'error': f'No se pudo abrir la ventana para elegir: {e}'}

    def watermark_preview(self, path: str, chroma: bool = True, similarity: str = 'media') -> Dict[str, Any]:
        from src.core import watermark
        return watermark.preview(get_ffmpeg_path(), path, bool(chroma), similarity)

    # ── v8.7: reemplazar el video (o la imagen) de una escena ─────────────────
    _REPL_EXT = ('.mp4', '.mov', '.webm', '.mkv', '.avi', '.m4v', '.jpg', '.jpeg', '.png', '.webp', '.bmp')

    def scene_media_info(self, path: str) -> Dict[str, Any]:
        """Datos de un video/imagen para la ventana de reemplazo (nombre, duración, miniatura)."""
        try:
            if not path or not os.path.isfile(path):
                return {'error': 'No se encontró el archivo.'}
            ext = os.path.splitext(path)[1].lower()
            if ext not in self._REPL_EXT:
                return {'error': 'Elige un video (.mp4, .mov, .webm…) o una imagen (.jpg, .png…).'}
            is_video = is_video_file(path)
            dur = 0.0
            if is_video:
                try:
                    dur = float(get_audio_duration(path) or 0)
                except Exception:
                    dur = 0.0
            w = h = 0
            try:
                ff = get_ffmpeg_path()
                if ff:
                    w, h = probe_media_dimensions(path, ff)
            except Exception:
                pass
            thumb = get_media_thumbnail_base64(path, is_video)
            if thumb and not thumb.startswith('data:'):
                thumb = f"data:image/jpeg;base64,{thumb}"
            return {'path': os.path.abspath(path), 'name': os.path.basename(path), 'is_video': bool(is_video),
                    'duration': round(dur, 2), 'width': w, 'height': h, 'thumbnail': thumb or '',
                    'size_mb': round(os.path.getsize(path) / 1048576, 1)}
        except Exception as e:
            return {'error': f'No se pudo leer el archivo: {e}'}

    def scene_replace_pick(self, old_path: str = '') -> Dict[str, Any]:
        """Ventana de Windows para elegir el video nuevo (empieza en Descargas)."""
        try:
            start = ''
            try:
                from src.core.fish_web import downloads_dir
                start = downloads_dir()
            except Exception:
                start = ''
            if not start or not os.path.isdir(start):
                start = os.path.dirname(old_path or '') or os.path.expanduser('~')
            res = self._get_window().create_file_dialog(
                webview.OPEN_DIALOG, directory=start,
                file_types=('Videos e imágenes (*.mp4;*.mov;*.webm;*.mkv;*.avi;*.m4v;*.jpg;*.jpeg;*.png;*.webp)',
                            'Todos (*.*)'))
            if not res:
                return {'cancel': True}
            return self.scene_media_info(res[0] if isinstance(res, (list, tuple)) else res)
        except Exception as e:
            return {'error': f'No se pudo abrir la ventana para elegir: {e}'}

    def scene_find_file(self, name: str, size: int = 0, hint_folder: str = '') -> Dict[str, Any]:
        """Busca un archivo soltado sobre la línea de tiempo (cuando la ventana no da su ruta)."""
        try:
            name = os.path.basename(str(name or ''))
            if not name:
                return {'path': ''}
            home = os.path.expanduser('~')
            places = []
            try:
                from src.core.fish_web import downloads_dir
                places.append(downloads_dir())
            except Exception:
                pass
            if hint_folder:
                places.append(hint_folder)
            places += [os.path.join(home, d) for d in ('Downloads', 'Descargas', 'Desktop', 'Escritorio', 'Videos', 'Vídeos', 'Documents', 'Documentos')]
            seen = set()
            for base in places:
                if not base or not os.path.isdir(base) or base in seen:
                    continue
                seen.add(base)
                for root, dirs, files in os.walk(base):
                    if root[len(base):].count(os.sep) >= 2:
                        dirs[:] = []
                    if name in files:
                        cand = os.path.join(root, name)
                        try:
                            if not size or os.path.getsize(cand) == int(size):
                                return {'path': cand}
                        except OSError:
                            pass
            return {'path': ''}
        except Exception:
            return {'path': ''}

    def scene_replace(self, old_path: str, new_path: str, clip_id: Any = 0) -> Dict[str, Any]:
        """
        Pone el video nuevo en lugar del de la escena, en la misma carpeta y con el mismo nombre
        (así conserva su número). El anterior se guarda en la subcarpeta 'reemplazados'.
        """
        import shutil
        import time as _t
        from src.core.media_scanner import extract_clip_number
        try:
            if not old_path or not os.path.isfile(old_path):
                return {'error': 'No se encontró el archivo actual de la escena.'}
            if not new_path or not os.path.isfile(new_path):
                return {'error': 'No se encontró el archivo nuevo.'}
            old_path, new_path = os.path.abspath(old_path), os.path.abspath(new_path)
            if os.path.normcase(old_path) == os.path.normcase(new_path):
                return {'error': 'Elegiste el mismo archivo que ya usa la escena.'}
            ext = os.path.splitext(new_path)[1].lower()
            if ext not in self._REPL_EXT:
                return {'error': 'Elige un video (.mp4, .mov, .webm…) o una imagen (.jpg, .png…).'}
            folder = os.path.dirname(old_path)
            stem, old_ext = os.path.splitext(os.path.basename(old_path))
            if extract_clip_number(stem) is not None:
                dest_name = stem + ext
            else:
                try:
                    dest_name = f"{int(float(clip_id))}_{stem}{ext}"
                except Exception:
                    dest_name = stem + ext
            dest = os.path.join(folder, dest_name)
            bdir = os.path.join(folder, 'reemplazados')
            os.makedirs(bdir, exist_ok=True)
            stamp = _t.strftime('%Y%m%d_%H%M%S')

            def _unique(p):
                b, e = os.path.splitext(p)
                k, out = 2, p
                while os.path.exists(out):
                    out = f"{b}_{k}{e}"
                    k += 1
                return out

            backup = _unique(os.path.join(bdir, f"{stem}_{stamp}{old_ext}"))
            shutil.move(old_path, backup)
            extra = ''
            if os.path.exists(dest) and os.path.normcase(dest) != os.path.normcase(new_path):
                extra = _unique(os.path.join(bdir, f"{os.path.splitext(dest_name)[0]}_{stamp}{ext}"))
                shutil.move(dest, extra)
            moved_from = ''
            try:
                if os.path.normcase(os.path.dirname(new_path)) == os.path.normcase(folder):
                    # el nuevo ya está en la carpeta de la historia: se renombra (si no, quedarían dos con el mismo número)
                    if os.path.normcase(new_path) != os.path.normcase(dest):
                        shutil.move(new_path, dest)
                        moved_from = new_path
                else:
                    shutil.copy(new_path, dest)          # copia con fecha nueva: la vista previa se renueva
            except Exception:
                shutil.move(backup, old_path)           # algo falló: todo como estaba
                if extra:
                    shutil.move(extra, dest)
                raise
            try:
                from src.utils.inicio import log
                log(f'escena {clip_id} reemplazada: {os.path.basename(old_path)} -> {os.path.basename(new_path)}')
            except Exception:
                pass
            return {'ok': True, 'new_path': dest, 'old_path': old_path, 'backup_path': backup,
                    'extra_backup': extra, 'moved_from': moved_from, 'name': os.path.basename(new_path),
                    'dest_name': dest_name}
        except Exception as e:
            return {'error': f'No se pudo reemplazar: {e}'}

    def scene_replace_undo(self, info: Dict[str, Any]) -> Dict[str, Any]:
        """Deshace un reemplazo: vuelve el archivo anterior a su lugar."""
        import shutil
        try:
            info = info or {}
            new_path, old_path, backup = info.get('new_path'), info.get('old_path'), info.get('backup_path')
            if not backup or not os.path.isfile(backup):
                return {'error': 'Ya no está el archivo anterior en "reemplazados".'}
            if new_path and os.path.isfile(new_path):
                if info.get('moved_from') and not os.path.exists(info['moved_from']):
                    shutil.move(new_path, info['moved_from'])
                else:
                    os.remove(new_path)
            if info.get('extra_backup') and os.path.isfile(info['extra_backup']) and new_path and not os.path.exists(new_path):
                shutil.move(info['extra_backup'], new_path)
            shutil.move(backup, old_path)
            return {'ok': True}
        except Exception as e:
            return {'error': f'No se pudo deshacer: {e}'}

    def _js(self, code: str):
        """Aviso de Python a la pantalla: por pywebview o, si se usa, por la conexión de respaldo."""
        from src.utils import http_bridge
        if http_bridge.active():
            http_bridge.push_js(code)
            return None
        return self._get_window().evaluate_js(code)

    def _get_window(self):
        if webview.windows:
            return webview.windows[0]
        return webview.active_window()

    def browse_audio(self) -> Dict[str, Any]:
        """Abre diálogo para seleccionar archivo de audio."""
        try:
            window = self._get_window()
            res = window.create_file_dialog(
                webview.OPEN_DIALOG,
                directory=self._audio_dialog_dir(),
                file_types=('Audio o Video (*.mp3;*.wav;*.m4a;*.aac;*.flac;*.mp4;*.mov;*.webm;*.mkv;*.avi)', 'Todos (*.*)')
            )
            if res and len(res) > 0:
                audio_path = res[0]
                self._remember_audio(audio_path)
                try:
                    duration = get_audio_duration(audio_path)
                    duration_str = format_time(duration)
                except Exception:
                    duration = 0.0
                    duration_str = '--:--'
                return {
                    'path': audio_path,
                    'filename': os.path.basename(audio_path),
                    'duration': duration,
                    'duration_str': duration_str
                }
            return {}
        except Exception as e:
            return {'error': str(e)}

    def browse_audio_files(self) -> Dict[str, Any]:
        """Abre diálogo para elegir VARIOS audios a la vez (se reparten entre las escenas)."""
        try:
            window = self._get_window()
            res = window.create_file_dialog(
                webview.OPEN_DIALOG,
                directory=self._audio_dialog_dir(),
                allow_multiple=True,
                file_types=('Audio (*.mp3;*.wav;*.m4a;*.aac;*.flac;*.ogg)', 'Todos (*.*)')
            )
            if res and len(res) > 0:
                self._remember_audio(res[0])
                return {'files': list(res)}
            return {}
        except Exception as e:
            return {'error': str(e)}

    def list_audio_candidates(self) -> Dict[str, Any]:
        """Audios de la carpeta del proyecto (y de la última carpeta de audios usada), para elegirlos
        desde una lista DENTRO de la app sin abrir el diálogo de Windows."""
        exts = ('.mp3', '.wav', '.m4a', '.aac', '.flac', '.ogg')
        dirs = []
        for d in (self._audio_dir, self._media_dir,
                  os.path.dirname(self._media_dir) if self._media_dir else ''):
            if d and os.path.isdir(d) and os.path.abspath(d) not in [os.path.abspath(x) for x in dirs]:
                dirs.append(d)
        files, seen = [], set()
        for d in dirs:
            try:
                with os.scandir(d) as it:
                    for e in it:
                        if e.is_file() and e.name.lower().endswith(exts):
                            key = os.path.abspath(e.path).lower()
                            if key not in seen:
                                seen.add(key)
                                files.append({'path': e.path, 'name': e.name, 'folder': os.path.basename(d) or d})
            except Exception:
                continue
            if len(files) > 500:
                break

        def natural(f):
            return [int(t) if t.isdigit() else t.lower() for t in re.split(r'(\d+)', f['name'])]
        files.sort(key=natural)
        return {'files': files[:500], 'folders': dirs}

    def pick_clip_audio(self, path: str) -> Dict[str, Any]:
        """Confirma un audio elegido desde la lista interna."""
        if not path or not os.path.isfile(path):
            return {'error': 'El archivo ya no existe.'}
        self._remember_audio(path)
        try:
            duration_str = format_time(get_audio_duration(path))
        except Exception:
            duration_str = '--:--'
        return {'path': path, 'filename': os.path.basename(path), 'duration_str': duration_str}

    def browse_clip_audio(self) -> Dict[str, Any]:
        """Abre diálogo para elegir el audio de UNA escena del narrador."""
        try:
            window = self._get_window()
            res = window.create_file_dialog(
                webview.OPEN_DIALOG,
                directory=self._audio_dialog_dir(),
                file_types=('Audio (*.mp3;*.wav;*.m4a;*.aac;*.flac;*.ogg)', 'Todos (*.*)')
            )
            if res and len(res) > 0:
                path = res[0]
                self._remember_audio(path)
                try:
                    duration_str = format_time(get_audio_duration(path))
                except Exception:
                    duration_str = '--:--'
                return {'path': path, 'filename': os.path.basename(path), 'duration_str': duration_str}
            return {}
        except Exception as e:
            return {'error': str(e)}

    def browse_images(self) -> Dict[str, Any]:
        """Abre diálogo para seleccionar la carpeta de imágenes."""
        try:
            window = self._get_window()
            res = window.create_file_dialog(webview.FOLDER_DIALOG)
            if res and len(res) > 0:
                folder_path = res[0]
                self._remember_media(folder_path)
                media = scan_images_folder(folder_path)
                n_videos = sum(1 for m in media.values() if m.is_video)
                ignored = [m.filename for m in sorted(media.values(), key=lambda x: x.clip_id) if m.auto_assigned]
                return {
                    'path': folder_path,
                    'count': len(media),
                    'videos': n_videos,
                    'images': len(media) - n_videos,
                    'ignored': len(ignored),
                    'ignored_examples': ignored[:3]
                }
            return {}
        except Exception as e:
            return {'error': str(e)}

    def browse_media_files(self) -> Dict[str, Any]:
        """Abre diálogo para elegir imágenes y/o videos sueltos (selección múltiple)."""
        try:
            window = self._get_window()
            res = window.create_file_dialog(
                webview.OPEN_DIALOG,
                allow_multiple=True,
                file_types=('Videos (*.mp4;*.mov;*.webm;*.mkv;*.avi)',
                            'Imágenes y videos (*.png;*.jpg;*.jpeg;*.webp;*.bmp;*.mp4;*.mov;*.webm;*.mkv;*.avi)',
                            'Todos (*.*)')
            )
            if res and len(res) > 0:
                files = list(res)
                media = scan_images_folder(files)
                n_videos = sum(1 for m in media.values() if m.is_video)
                auto = [m.filename for m in sorted(media.values(), key=lambda x: x.clip_id) if m.auto_assigned]
                return {
                    'files': files,
                    'count': len(media),
                    'videos': n_videos,
                    'images': len(media) - n_videos,
                    'ignored': len(auto),
                    'ignored_examples': auto[:3]
                }
            return {}
        except Exception as e:
            return {'error': str(e)}

    def describe_media_selection(self, files) -> Dict[str, Any]:
        """Resumen (cantidad, videos, asignados automáticamente) de una lista de archivos sueltos."""
        try:
            media = scan_images_folder(list(files or []))
            n_videos = sum(1 for m in media.values() if m.is_video)
            auto = [m.filename for m in sorted(media.values(), key=lambda x: x.clip_id) if m.auto_assigned]
            return {'count': len(media), 'videos': n_videos, 'images': len(media) - n_videos,
                    'ignored': len(auto), 'ignored_examples': auto[:3]}
        except Exception as e:
            return {'error': str(e), 'count': 0, 'videos': 0, 'ignored': 0, 'ignored_examples': []}

    def browse_output(self) -> Dict[str, Any]:
        """Abre diálogo para seleccionar la carpeta de salida."""
        try:
            window = self._get_window()
            res = window.create_file_dialog(webview.FOLDER_DIALOG)
            if res and len(res) > 0:
                return {'path': res[0]}
            return {}
        except Exception as e:
            return {'error': str(e)}

    def browse_script(self) -> Dict[str, Any]:
        """Abre diálogo para cargar un archivo de guion .txt."""
        try:
            window = self._get_window()
            res = window.create_file_dialog(
                webview.OPEN_DIALOG,
                file_types=('Archivos de Texto (*.txt)', 'Todos (*.*)')
            )
            if res and len(res) > 0:
                script_path = res[0]
                with open(script_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                return {
                    'path': script_path,
                    'filename': os.path.basename(script_path),
                    'content': content
                }
            return {}
        except Exception as e:
            return {'error': str(e)}

    def browse_overlay(self, slot: str = 'intro') -> Dict[str, Any]:
        """Abre diálogo para seleccionar video o imagen para el overlay (Intro u Outro)."""
        try:
            window = self._get_window()
            res = window.create_file_dialog(
                webview.OPEN_DIALOG,
                file_types=('Archivos Multimedia (*.mp4;*.mov;*.webm;*.png;*.webp;*.jpg;*.jpeg)', 'Videos (*.mp4;*.mov;*.webm)', 'Imágenes (*.png;*.webp;*.jpg;*.jpeg)', 'Todos (*.*)')
            )
            if res and len(res) > 0:
                overlay_path = res[0]
                ff = get_ffmpeg_path()
                is_vid = is_video_file(overlay_path)
                dur = 0.0
                if is_vid:
                    try:
                        dur = get_audio_duration(overlay_path, ff)
                    except Exception:
                        if slot == 'intro':
                            dur = 2.0
                        else:
                            dur = 3.5
                else:
                    if slot == 'intro':
                        dur = 2.0
                    else:
                        dur = 3.5
                w, h = probe_media_dimensions(overlay_path, ff)
                thumb = None
                if not is_vid:
                    thumb = get_image_thumbnail_base64(overlay_path)
                return {
                    'path': overlay_path,
                    'filename': os.path.basename(overlay_path),
                    'is_video': is_vid,
                    'duration': round(dur, 2),
                    'width': w,
                    'height': h,
                    'is_vertical': h > w * 1.4,
                    'thumbnail': thumb,
                    'slot': slot
                }
            return {}
        except Exception as e:
            return {'error': str(e)}

    def _resolve_clips(self, script_text: str, audio_path: str, images_folder, options=None):
        """
        Lista de clips del proyecto. Casos que NO exigen audio ni guion CLIP:
          - Sin guion (vacío): los archivos de la carpeta, en orden de número. Los videos
            suenan con su propio audio y duran lo que duran; las imágenes duran 3 s.
          - Guion CLIP sin audio: cada clip usa su video completo (con su audio);
            las imágenes duran según sus palabras.
        Devuelve (clips, free_mode).
        """
        clips = parse_script(script_text if script_text else "")
        have_audio = bool(audio_path and os.path.exists(audio_path))

        if not clips and not (script_text or "").strip():
            media = scan_images_folder(images_folder if images_folder else "")
            free = [
                ScriptClip(clip_id=k, text=media[k].filename, word_count=0, speaker='', kind='dialogue')
                for k in sorted(media.keys())
            ]
            return free, bool(free)

        has_manual = any(
            v and os.path.exists(v) for v in ((options or {}).get('narrator_audio_map') or {}).values()
        )
        trim_on = bool((options or {}).get('trim_dialogue_silence', True))
        # Con recorte de silencios activado, un guion CLIP con audio único también se trata como escenas
        # narradas (cada escena = su tramo del audio), para poder quitar los silencios de cada una.
        if clips and clips[0].kind == 'clip' and (not have_audio or has_manual or trim_on):
            # Sin audio único: cada clip suena con su video. Con audios asignados a mano: cada clip es
            # una escena narrada (su audio manual; las demás usan el audio único).
            new_kind = 'narrator' if have_audio else 'dialogue'
            return [dataclasses.replace(c, kind=new_kind, speaker='') for c in clips], False

        return clips, False

    # ── Modo historia (master prompt: diálogos + narrador) ─────────────────
    def _build_story_project(self, audio_path: str, images_folder, clips, options=None):
        """
        Construye la línea de tiempo de una historia.
        Devuelve (timeline, sync_method, idioma).
        - Líneas de diálogo: su video (con su audio), dura lo que dura el video.
        - Líneas del narrador: su video/imagen + su voz, que sale de audios numerados
          (03.mp3) o del audio único del narrador alineado con Whisper (plan B: por palabras).
        """
        media = scan_images_folder(images_folder if images_folder else "")
        narrator_files = scan_audio_files(images_folder if images_folder else "")

        opts = options or {}
        narr_clips = [c for c in clips if c.kind == 'narrator']
        have_audio = bool(audio_path and os.path.exists(audio_path))

        # Audios que el usuario asignó a mano a cada escena (mandan sobre todo lo demás)
        overrides = {}
        valid_ids = {c.clip_id for c in clips}
        for k, v in (opts.get('narrator_audio_map') or {}).items():
            try:
                cid = int(k)
            except (TypeError, ValueError):
                continue
            if v and os.path.exists(v) and cid in valid_ids:
                overrides[cid] = v

        # Líneas que todavía necesitan voz del audio único (las demás ya tienen su propio audio)
        pending = [c for c in narr_clips if c.clip_id not in narrator_files and c.clip_id not in overrides]
        covered = not pending

        alignment = None
        language = ''
        sync_method = 'archivos' if (narr_clips and covered) else 'ninguno'

        if pending and have_audio:
            texts = tuple(c.text for c in pending)
            cached = self._cached_story_alignment
            if cached and cached[0] == audio_path and cached[1] == texts:
                alignment = cached[2]
                sync_method = 'whisper' if alignment.get('whisper_available', True) else 'proportional'
                language = alignment.get('language', '')
            else:
                if HAS_WHISPER:
                    try:
                        al = align_script_to_audio(audio_path, list(texts))
                        if al and al.get('clips'):
                            alignment = al
                            alignment['whisper_available'] = True
                            language = al.get('language', '')
                            sync_method = 'whisper'
                    except Exception:
                        alignment = None
                if alignment is None:
                    try:
                        total = get_audio_duration(audio_path)
                    except Exception:
                        total = 0.0
                    if total > 0:
                        alignment = split_audio_proportionally(list(texts), total)
                        sync_method = 'proportional'
                if alignment is not None:
                    self._cached_story_alignment = (audio_path, texts, alignment)

        timeline = build_story_timeline(
            clips, media, narrator_files,
            narrator_audio_path=audio_path if have_audio else '',
            narrator_alignment=alignment,
            dialogue_trims=None,
            audio_overrides=overrides
        )

        # Recorte de silencios en TODAS las escenas con audio: diálogos de Flow (imagen + sonido),
        # audios del narrador (archivo numerado o asignado a mano) y tramos del audio único.
        if opts.get('trim_dialogue_silence', True):
            mode = opts.get('dialogue_pause_mode', 'tight')
            if mode not in ('keep', 'tight'):
                mode = 'tight'
            ff = get_ffmpeg_path()
            targets = trim_targets(timeline)
            if targets:
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
                    results = list(pool.map(
                        lambda t: (t[0], self._detect_cached(t[1], ff, mode, t[2], t[3])),
                        targets))
                apply_trims(timeline, {i: segs for i, segs in results if segs})

        # Edición a mano (v6.8): solo cambia las escenas que el usuario tocó
        from src.core import scene_edits
        edits = scene_edits.clean_edits(opts.get('scene_edits'))
        order = [str(x) for x in (opts.get('scene_order') or []) if isinstance(x, (str, int))][:3000]
        scene_edits.apply(timeline, edits, order, self._src_dur)
        if timeline.missing_images:                 # una escena quitada del video ya no hace falta
            left = {c.clip_id for c in timeline.clips}
            timeline.missing_images = [m for m in timeline.missing_images if m in left]
            timeline.is_valid = bool(timeline.clips) and not timeline.missing_images
        return timeline, sync_method, language

    # Cachés: el análisis se repite con cada cambio y no hace falta volver a escuchar cada archivo
    def _file_sig(self, path):
        try:
            st = os.stat(path)
            return (os.path.abspath(path), st.st_size, int(st.st_mtime))
        except OSError:
            return None

    def _detect_cached(self, path, ff, mode, start, end):
        cache = self.__dict__.setdefault('_trim_cache', {})
        sig = self._file_sig(path)
        key = (sig, mode, None if start is None else round(start, 3), None if end is None else round(end, 3))
        if sig and key in cache:
            return cache[key]
        segs = detect_keep_segments(path, ff, pause_mode=mode, start=start, end=end)
        if sig:
            if len(cache) > 2000:
                cache.clear()
            cache[key] = segs
        return segs

    def _src_dur(self, path) -> float:
        cache = self.__dict__.setdefault('_dur_cache', {})
        sig = self._file_sig(path)
        if sig and sig in cache:
            return cache[sig]
        try:
            d = float(get_audio_duration(path))
        except Exception:
            d = 0.0
        if sig:
            cache[sig] = d
        return d

    # ── Vista previa dentro de la app (v6.7) ─────────────────────────────
    @staticmethod
    def _preview_info(item, global_audio: str = '') -> Dict[str, Any]:
        """Qué reproducir en la vista previa para una escena: el video/imagen, qué tramos del video
        se conservan (recorte de silencios) y de dónde sale el audio. No cambia nada del render."""
        from src.core import media_server
        out: Dict[str, Any] = {'dur': round(float(item.duration), 3)}
        try:
            if item.image and os.path.exists(item.image.full_path):
                is_vid = bool(getattr(item.image, 'is_video', False))
                out['media'] = {'url': media_server.url_for(item.image.full_path), 'type': 'video' if is_vid else 'image'}
            mode = getattr(item, 'audio_mode', 'global') or 'global'
            segs = getattr(item, 'keep_segments', None)
            if segs:
                out['vsegs'] = [[round(a, 3), round(b, 3)] for a, b in segs]
            auto = getattr(item, 'auto_segs', None)
            if auto:
                out['auto'] = {'segs': [[round(a, 3), round(b, 3)] for a, b in auto], 'src': getattr(item, 'src_dur', None),
                               'field': 'keep' if mode == 'video' else 'audio'}
            if mode == 'video':
                out['audio'] = {'mode': 'video'}
            elif mode in ('file', 'slice') and item.audio_path and os.path.exists(item.audio_path):
                asegs = getattr(item, 'audio_segments', None)
                out['audio'] = {'mode': mode, 'url': media_server.url_for(item.audio_path),
                                'start': round(float(getattr(item, 'audio_start', 0) or 0), 3),
                                'segs': [[round(a, 3), round(b, 3)] for a, b in asegs] if asegs else None}
            elif mode == 'global' and global_audio and os.path.exists(global_audio):
                out['audio'] = {'mode': 'slice', 'url': media_server.url_for(global_audio),
                                'start': round(float(item.start_time), 3), 'segs': None}
            else:
                out['audio'] = {'mode': 'none'}
        except Exception:
            out.setdefault('audio', {'mode': 'none'})
        return out

    def preview_peaks(self, urls) -> Dict[str, Any]:
        """Formas de onda (20 valores por segundo) de los audios de la vista previa, por URL."""
        from src.core import media_server
        ff = get_ffmpeg_path()
        if not ff:
            return {}
        items = [(u, media_server.path_for(u)) for u in (urls or [])[:400] if isinstance(u, str)]
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            res = list(pool.map(lambda it: (it[0], media_server.peaks(it[1], ff) if it[1] else []), items))
        return {'rate': media_server.PEAKS_PER_SEC, 'peaks': {u: p for u, p in res}}

    def preview_music(self, path: str) -> Dict[str, Any]:
        """La canción que sonaría en el próximo video (para la vista previa)."""
        from src.core import music as music_mod, media_server
        track = music_mod.pick_track(path or '', advance=False)
        if not track:
            return {}
        return {'url': media_server.url_for(track), 'name': os.path.basename(track),
                'gain': music_mod.VOLUME}

    def _analyze_story(self, audio_path: str, images_folder, clips, options=None) -> Dict[str, Any]:
        timeline, sync_method, language = self._build_story_project(audio_path, images_folder, clips, options)

        manual_ids = set()
        for k, v in ((options or {}).get('narrator_audio_map') or {}).items():
            try:
                if v and os.path.exists(v):
                    manual_ids.add(int(k))
            except (TypeError, ValueError):
                pass

        import concurrent.futures
        def _make_ui_clip(item):
            thumb = None
            img_name = ""
            if item.image:
                img_name = item.image.filename
                thumb = get_media_thumbnail_base64(item.image.full_path, getattr(item.image, 'is_video', False))
            return {
                'clip_id': item.clip_id,
                'text': item.text,
                'word_count': item.word_count,
                'start_time_str': format_time(item.start_time),
                'end_time_str': format_time(item.end_time),
                'duration': round(item.duration, 2),
                'has_image': item.has_image,
                'is_video': bool(item.image and getattr(item.image, 'is_video', False)),
                'image_name': img_name,
                'image_path': item.image.full_path if item.image else '',
                'thumbnail': thumb,
                'kind': item.kind,
                'speaker': item.speaker,
                'audio_mode': item.audio_mode,
                'audio_name': os.path.basename(item.audio_path) if item.audio_mode == 'file' else '',
                'audio_manual': item.clip_id in manual_ids,
                'preview': self._preview_info(item),
                'key': getattr(item, 'key', str(item.clip_id)),
                'part': getattr(item, 'part', 0),
                'parts': getattr(item, 'parts', 1),
                'edited': bool(getattr(item, 'edited', False)),
                'edit': getattr(item, 'edit', None) or {},
                'full_text': getattr(item, 'full_text', item.text),
            }

        cpu_workers = min(8, max(4, os.cpu_count() or 4))
        with concurrent.futures.ThreadPoolExecutor(max_workers=cpu_workers) as pool:
            ui_clips = list(pool.map(_make_ui_clip, timeline.clips))

        removed = []
        for item in getattr(timeline, 'removed', []) or []:
            removed.append({'clip_id': item.clip_id, 'text': item.text,
                            'thumbnail': get_media_thumbnail_base64(item.image.full_path, getattr(item.image, 'is_video', False)) if item.image else None})
        total = timeline.total_audio_duration
        return {
            'story_mode': True,
            'removed_scenes': removed,
            'editable': True,
            'total_clips': len(clips),
            'total_words': timeline.total_words,
            'total_duration': total,
            'total_duration_str': format_time(total),
            'missing_images': timeline.missing_images,
            'missing_narrator_audio': timeline.missing_narrator_audio,
            'unused_images': timeline.unused_images,
            'is_valid': timeline.is_valid,
            'clips': ui_clips,
            'sync_method': sync_method,
            'detected_language': language or ''
        }

    def analyze_project(self, audio_path: str, images_folder: str, script_text: str, options: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Analiza en vivo el guion, el audio y las imágenes.
        Usa IA (faster-whisper) para sincronización precisa cuando está disponible.
        """
        if not self._auth_allowed():
            return {'error': 'Ingresa con tu usuario y contraseña para usar VideoNarrator.'}
        try:
            self._remember_media(images_folder)
            clips, free_mode = self._resolve_clips(script_text, audio_path, images_folder, options)

            # Guion master prompt, guion CLIP sin audio, o sin guion: modo historia
            if clips and clips[0].kind != 'clip':
                result = self._analyze_story(audio_path, images_folder, clips, options)
                result['free_mode'] = free_mode
                return result

            duration = 0.0
            if audio_path and os.path.exists(audio_path):
                try:
                    duration = get_audio_duration(audio_path)
                except Exception:
                    pass
            images = scan_images_folder(images_folder if images_folder else "")

            # Intentar sincronización con IA (Whisper)
            alignment_data = None
            detected_language = None
            sync_method = 'proportional'
            if HAS_WHISPER and audio_path and os.path.exists(audio_path) and clips:
                try:
                    clip_texts = [c.text for c in clips]
                    alignment = align_script_to_audio(audio_path, clip_texts)
                    if alignment and alignment.get('clips'):
                        alignment_data = alignment
                        detected_language = alignment.get('language', '')
                        sync_method = 'whisper'
                        self._cached_alignment = alignment  # Guardar para render
                except Exception:
                    pass  # Fallback a proporcional

            timeline = build_timeline(clips, images, duration, alignment_data=alignment_data)
            
            # Generación paralela ultra veloz de miniaturas
            import concurrent.futures
            def _make_ui_clip(item):
                thumb = None
                img_name = ""
                if item.image:
                    img_name = item.image.filename
                    thumb = get_media_thumbnail_base64(item.image.full_path, getattr(item.image, 'is_video', False))
                    if thumb and not thumb.startswith('data:'):
                        thumb = f"data:image/jpeg;base64,{thumb}"
                return {
                    'clip_id': item.clip_id,
                    'text': item.text,
                    'word_count': item.word_count,
                    'start_time_str': format_time(item.start_time),
                    'end_time_str': format_time(item.end_time),
                    'duration': round(item.duration, 2),
                    'has_image': item.has_image,
                    'is_video': bool(item.image and getattr(item.image, 'is_video', False)),
                    'image_name': img_name,
                'image_path': item.image.full_path if item.image else '',
                    'thumbnail': thumb,
                    'preview': self._preview_info(item, global_audio=audio_path)
                }

            cpu_workers = min(8, max(4, os.cpu_count() or 4))
            with concurrent.futures.ThreadPoolExecutor(max_workers=cpu_workers) as pool:
                ui_clips = list(pool.map(_make_ui_clip, timeline.clips))

            return {
                'total_clips': len(clips),
                'total_words': timeline.total_words,
                'total_duration': duration,
                'total_duration_str': format_time(duration),
                'missing_images': timeline.missing_images,
                'unused_images': timeline.unused_images,
                'is_valid': timeline.is_valid,
                'clips': ui_clips,
                'sync_method': sync_method,
                'detected_language': detected_language or ''
            }
        except Exception as e:
            return {'error': str(e)}

    def start_render(self, audio_path: str, images_folder: str, script_text: str, output_folder: str, options: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Inicia el renderizado en un hilo secundario con callbacks a JS."""
        if not self._auth_allowed():
            return {'error': 'Ingresa con tu usuario y contraseña para usar VideoNarrator.'}
        render_opts = RenderOptions()
        if options:
            if 'enable_camera_motion' in options:
                render_opts.enable_camera_motion = bool(options['enable_camera_motion'])
            if 'camera_motion_type' in options:
                render_opts.camera_motion_type = str(options['camera_motion_type'])
            if 'zoom_intensity' in options:
                render_opts.zoom_intensity = float(options['zoom_intensity'])
            if 'enable_transitions' in options:
                render_opts.enable_transitions = bool(options['enable_transitions'])
            if 'transition_style' in options:
                render_opts.transition_style = str(options['transition_style'])
            if 'transition_pool' in options and isinstance(options['transition_pool'], list):
                render_opts.transition_pool = options['transition_pool']
            if 'transition_frequency' in options:
                render_opts.transition_frequency = int(options['transition_frequency'])
            if 'transition_duration' in options:
                render_opts.transition_duration = float(options['transition_duration'])
            if 'export_timestamps' in options:
                render_opts.export_timestamps = bool(options['export_timestamps'])
            if 'preview_mode' in options:
                render_opts.preview_mode = bool(options['preview_mode'])
            if 'preview_duration' in options:
                render_opts.preview_duration = float(options['preview_duration'])
            if 'enable_intro_overlay' in options:
                render_opts.enable_intro_overlay = bool(options['enable_intro_overlay'])
            if 'intro_overlay_path' in options:
                render_opts.intro_overlay_path = options['intro_overlay_path'] if options['intro_overlay_path'] else None
            if 'intro_overlay_duration' in options:
                render_opts.intro_overlay_duration = float(options['intro_overlay_duration'])
            if 'intro_overlay_position' in options:
                render_opts.intro_overlay_position = str(options['intro_overlay_position'])
            if 'intro_overlay_type' in options:
                render_opts.intro_overlay_type = str(options['intro_overlay_type'])
            if 'intro_chroma_similarity' in options:
                render_opts.intro_chroma_similarity = float(options['intro_chroma_similarity'])
            if 'enable_outro_overlay' in options:
                render_opts.enable_outro_overlay = bool(options['enable_outro_overlay'])
            if 'outro_overlay_path' in options:
                render_opts.outro_overlay_path = options['outro_overlay_path'] if options['outro_overlay_path'] else None
            if 'outro_overlay_duration' in options:
                render_opts.outro_overlay_duration = float(options['outro_overlay_duration'])
            if 'outro_overlay_position' in options:
                render_opts.outro_overlay_position = str(options['outro_overlay_position'])
            if 'outro_overlay_type' in options:
                render_opts.outro_overlay_type = str(options['outro_overlay_type'])
            if 'outro_chroma_similarity' in options:
                render_opts.outro_chroma_similarity = float(options['outro_chroma_similarity'])
            if 'resolution' in options:
                render_opts.resolution = str(options['resolution'])
            if 'normalize_audio' in options:
                render_opts.normalize_audio = bool(options['normalize_audio'])
            if options.get('video_extend_mode') in ('freeze', 'loop', 'slow'):
                render_opts.video_extend_mode = options['video_extend_mode']
            if options.get('video_fit') in ('contain', 'cover'):
                render_opts.video_fit = options['video_fit']
            # Subtítulos automáticos
            render_opts.subtitles_enabled = bool(options.get('subtitles_enabled', False))
            if options.get('subtitle_template') in ('karaoke', 'palabra', 'destacado', 'caja', 'elegante', 'pop', 'cajapal',
                                                  'neon', 'maquina', 'impacto', 'contorno', 'sombra3d', 'documental'):
                render_opts.subtitle_template = options['subtitle_template']
            if isinstance(options.get('subtitle_color'), str) and re.fullmatch(r'#[0-9a-fA-F]{6}', options['subtitle_color']):
                render_opts.subtitle_color = options['subtitle_color']
            if options.get('subtitle_position') in ('auto', 'top', 'center', 'bottom'):
                render_opts.subtitle_position = options['subtitle_position']
            if options.get('subtitle_size') in ('small', 'medium', 'large'):
                render_opts.subtitle_size = options['subtitle_size']
            render_opts.subtitle_export_srt = bool(options.get('subtitle_export_srt', False))

        # Igualar el volumen de las voces (v6.5)
        render_opts.level_voices = bool((options or {}).get('level_voices', True))

        # Música de fondo (v5.8)
        if options and options.get('music_enabled') and options.get('music_path'):
            render_opts.music_enabled = True
            render_opts.music_path = str(options.get('music_path'))
            if options.get('music_volume') in ('suave', 'normal', 'presente'):
                render_opts.music_volume = options['music_volume']
            if options.get('music_duck') in ('poco', 'normal', 'mucho'):
                render_opts.music_duck = options['music_duck']
            render_opts.music_fade = bool(options.get('music_fade', True))
            render_opts.music_loop = bool(options.get('music_loop', True))
            try:
                render_opts.music_start = max(0.0, float(options.get('music_start') or 0))
            except (TypeError, ValueError):
                render_opts.music_start = 0.0

        # Marca de agua (v8.9)
        o = options or {}
        if o.get('wm_enabled') and o.get('wm_path') and os.path.isfile(str(o.get('wm_path'))):
            render_opts.wm_enabled = True
            render_opts.wm_path = str(o.get('wm_path'))
            render_opts.wm_chroma = bool(o.get('wm_chroma', True))
            if o.get('wm_similarity') in ('suave', 'media', 'fuerte'):
                render_opts.wm_similarity = o['wm_similarity']
            if o.get('wm_move') in ('fixed', 'ab', 'pingpong', 'corners'):
                render_opts.wm_move = o['wm_move']
            for k, lo, hi in (('wm_size', 0.03, 0.9), ('wm_opacity', 0.05, 1.0), ('wm_ax', 0, 1), ('wm_ay', 0, 1),
                              ('wm_bx', 0, 1), ('wm_by', 0, 1), ('wm_start', 0, 1e6), ('wm_end', 0, 1e6)):
                try:
                    setattr(render_opts, k, max(lo, min(hi, float(o.get(k, getattr(render_opts, k))))))
                except (TypeError, ValueError):
                    pass

        notify_done = bool((options or {}).get('notify_done', True))

        def run_task():
            from src.utils import winnotify
            from src.utils.paths import app_version
            hwnd = winnotify.find_app_window(f'VideoNarrator v{app_version()}')
            taskbar = winnotify.TaskbarProgress(hwnd)
            winnotify.prevent_sleep(True)        # la PC no se suspende mientras se renderiza
            window = None
            try:
                window = self._get_window()
                clips, _free = self._resolve_clips(script_text, audio_path, images_folder, options)
                story_mode = bool(clips and clips[0].kind != 'clip')

                if story_mode:
                    timeline, _sync, _lang = self._build_story_project(audio_path, images_folder, clips, options)
                    if timeline.missing_images:
                        raise ValueError(f"Faltan imágenes o videos para las líneas: {timeline.missing_images}")
                    if not timeline.is_valid:
                        raise ValueError("El proyecto no es válido para renderizar.")
                else:
                    duration = get_audio_duration(audio_path)
                    images = scan_images_folder(images_folder)

                    # Reusar alineación Whisper del análisis (mismos timestamps que la UI)
                    alignment_data = None
                    if self._cached_alignment and len(self._cached_alignment.get('clips', [])) == len(clips):
                        alignment_data = self._cached_alignment
                    elif HAS_WHISPER:
                        try:
                            clip_texts = [c.text for c in clips]
                            alignment = align_script_to_audio(audio_path, clip_texts)
                            if alignment and alignment.get('clips'):
                                alignment_data = alignment
                        except Exception:
                            pass

                    timeline = build_timeline(clips, images, duration, alignment_data=alignment_data)

                    if not timeline.is_valid:
                        raise ValueError(f"Faltan imágenes o videos para los clips: {timeline.missing_images}")

                if output_folder:
                    out_dir = output_folder
                elif audio_path:
                    out_dir = os.path.dirname(audio_path)
                elif isinstance(images_folder, (list, tuple)) and images_folder:
                    out_dir = os.path.dirname(images_folder[0])
                elif images_folder:
                    out_dir = images_folder
                else:
                    out_dir = "."
                
                if not out_dir:
                    out_dir = "."
                
                def on_progress(pdata):
                    try:
                        if not pdata.get('heartbeat'):
                            taskbar.set(float(pdata.get('percent') or 0))
                    except Exception:
                        pass
                    try:
                        js_code = f"if (window.onRenderProgress) {{ window.onRenderProgress({json.dumps(pdata)}); }}"
                        self._js(js_code)
                    except Exception:
                        pass
                
                result = self._render_engine.render(timeline=timeline, audio_path=audio_path, output_folder=out_dir, options=render_opts, on_progress=on_progress)
                taskbar.clear()
                winnotify.prevent_sleep(False)
                if notify_done and not winnotify.is_foreground(hwnd):
                    name = os.path.basename(str(result.get('video_path') or ''))
                    if result.get('is_preview'):
                        winnotify.toast('Tu vista previa está lista', name or 'VideoNarrator terminó la vista previa.')
                    else:
                        winnotify.toast('🎬 Tu video está listo', name or 'VideoNarrator terminó el render.')
                    winnotify.flash_window(hwnd)
                js_code = f"if (window.onRenderComplete) {{ window.onRenderComplete({json.dumps(result)}); }}"
                self._js(js_code)
            except Exception as e:
                err_msg = str(e)
                cancelled = bool(getattr(self._render_engine, 'is_cancelled', False))
                if cancelled:
                    taskbar.clear()
                else:
                    taskbar.error()
                    if notify_done and not winnotify.is_foreground(hwnd):
                        winnotify.toast('El render no se pudo terminar', err_msg[:180] or 'Abre VideoNarrator para ver el detalle.')
                        winnotify.flash_window(hwnd)
                try:
                    js_code = f"if (window.onRenderError) {{ window.onRenderError({json.dumps(err_msg)}); }}"
                    self._js(js_code)
                except Exception:
                    pass
            finally:
                winnotify.prevent_sleep(False)

        self._current_thread = threading.Thread(target=run_task, daemon=True)
        self._current_thread.start()
        return {'status': 'started'}

    def cancel_render(self) -> Dict[str, Any]:
        """Cancela la exportación activa."""
        self._render_engine.cancel()
        return {'status': 'cancelled'}

    def open_video(self, file_path: str):
        """Abre el archivo de video resultante en el reproductor predeterminado."""
        try:
            if os.path.exists(file_path):
                _open_system(file_path)
        except Exception:
            pass

    def open_folder(self, folder_path: str):
        """Abre la carpeta en el explorador de Windows."""
        try:
            if os.path.isdir(folder_path):
                _open_system(folder_path)
            elif os.path.exists(folder_path):
                _open_system(os.path.dirname(folder_path))
        except Exception:
            pass
