"""
Conexión de respaldo pantalla <-> programa (VideoNarrator v8.5).

Normalmente la pantalla habla con Python por pywebview (window.pywebview.api). En algunas PCs esa
conexión no llega nunca y la app se queda en "no terminó de arrancar". Este pequeño servidor, solo
en 127.0.0.1, ofrece las mismas funciones por HTTP; la pantalla (puente.js) lo usa únicamente si
pywebview no aparece. Los avisos de Python a la pantalla (progreso del render, etc.) se entregan
por una cola que la pantalla consulta.

Seguridad: solo escucha en 127.0.0.1, exige un token que se entrega solo a la pantalla de la app
(origen 127.0.0.1/localhost) y solo permite funciones públicas de VideoNarratorAPI.
"""
import json
import re
import secrets
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PORTS = range(47811, 47831)
_API = None
_TOKEN = secrets.token_hex(16)
_PORT = 0
_ACTIVE = False
_QUEUE = []
_COND = threading.Condition()
_ORIGIN_OK = re.compile(r'^(null|https?://(127\.0\.0\.1|localhost)(:\d+)?)$')


def _log(msg):
    try:
        from src.utils.inicio import log
        log(msg)
    except Exception:
        pass


def active() -> bool:
    return _ACTIVE


def push_js(code: str) -> None:
    with _COND:
        _QUEUE.append(code)
        if len(_QUEUE) > 500:
            del _QUEUE[:-500]
        _COND.notify_all()


class _H(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def log_message(self, *a):
        pass

    def _origin(self):
        o = self.headers.get('Origin') or ''
        return o if _ORIGIN_OK.match(o) else ''

    def _send(self, code, obj=None):
        body = json.dumps(obj if obj is not None else {}, default=str, ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        o = self._origin()
        if o:
            self.send_header('Access-Control-Allow-Origin', o)
            self.send_header('Access-Control-Allow-Headers', 'Content-Type, X-VN-Token')
            self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
            self.send_header('Vary', 'Origin')
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        if not self._origin():
            self._send(403, {'error': 'origen'})
            return
        self._send(204)

    def _authorized(self):
        return secrets.compare_digest(self.headers.get('X-VN-Token') or '', _TOKEN)

    def do_GET(self):
        if self.path.startswith('/ping'):
            if not self._origin():                      # solo la pantalla de la app recibe el token
                self._send(403, {'error': 'origen'})
                return
            self._send(200, {'app': 'VideoNarrator', 'token': _TOKEN})
            return
        if self.path.startswith('/events'):
            if not self._authorized():
                self._send(403, {'error': 'token'})
                return
            with _COND:
                if not _QUEUE:
                    _COND.wait(timeout=20)
                out = list(_QUEUE)
                _QUEUE.clear()
            self._send(200, {'js': out})
            return
        self._send(404, {'error': 'no existe'})

    def do_POST(self):
        global _ACTIVE
        m = re.match(r'^/call/([A-Za-z][A-Za-z0-9_]*)$', self.path)
        if not m or not self._authorized():
            self._send(403, {'error': 'no permitido'})
            return
        name = m.group(1)
        fn = getattr(_API, name, None)
        if name.startswith('_') or not callable(fn):
            self._send(404, {'error': f'función desconocida: {name}'})
            return
        try:
            n = int(self.headers.get('Content-Length') or 0)
            args = json.loads(self.rfile.read(n).decode('utf-8') or '[]') if n else []
            if not isinstance(args, list):
                args = [args]
        except Exception:
            self._send(400, {'error': 'datos inválidos'})
            return
        if not _ACTIVE:
            _ACTIVE = True
            _log('conexión de respaldo en uso (pywebview no conectó la pantalla)')
        try:
            res = fn(*args)
            self._send(200, {'result': res})
        except Exception as e:
            self._send(200, {'error': f'{type(e).__name__}: {e}'})


def start(api) -> int:
    """Arranca el servidor de respaldo. Devuelve el puerto (0 si no se pudo)."""
    global _API, _PORT
    _API = api
    for port in PORTS:
        try:
            srv = ThreadingHTTPServer(('127.0.0.1', port), _H)
        except OSError:
            continue
        srv.daemon_threads = True
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        _PORT = port
        _log(f'conexión de respaldo lista (puerto {port})')
        return port
    _log('conexión de respaldo: no hay puerto libre')
    return 0
