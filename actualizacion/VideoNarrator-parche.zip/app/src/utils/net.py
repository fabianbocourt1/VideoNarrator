"""
Conexiones a internet seguras que funcionan en cualquier Windows (VideoNarrator v5.1).

Algunos Windows no tienen al día sus certificados raíz (Windows los descarga "cuando hace falta",
pero Python no lo provoca) y fallan con CERTIFICATE_VERIFY_FAILED. Por eso, además de los
certificados de Windows, se usa la lista de Mozilla incluida en la app (cacert.pem, de certifi).
La verificación de seguridad sigue activa: solo se amplía la lista de autoridades de confianza.
"""
import os
import ssl
import urllib.request

_CTX = None
CA_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'cacert.pem')


def ssl_context() -> ssl.SSLContext:
    global _CTX
    if _CTX is None:
        ctx = ssl.create_default_context()          # certificados de Windows
        for cafile in (CA_FILE, _certifi_file()):
            if cafile and os.path.exists(cafile):
                try:
                    ctx.load_verify_locations(cafile=cafile)
                except Exception:
                    pass
        _CTX = ctx
    return _CTX


def _certifi_file() -> str:
    try:
        import certifi
        return certifi.where()
    except Exception:
        return ''


def urlopen(req, timeout: float = 15.0):
    return urllib.request.urlopen(req, timeout=timeout, context=ssl_context())


def friendly_error(e) -> str:
    text = str(e)
    if 'CERTIFICATE_VERIFY_FAILED' in text or 'SSL' in text:
        return ('No se pudo verificar la conexión segura. Revisa que la fecha y hora de la PC sean '
                'correctas y que ningún antivirus o proxy esté bloqueando la conexión.')
    if 'getaddrinfo' in text or 'Name or service' in text or 'timed out' in text or 'urlopen error' in text:
        return 'Sin conexión a internet (o el servidor no responde).'
    return text
