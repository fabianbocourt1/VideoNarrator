"""
Registro de arranque (VideoNarrator v8.2): %APPDATA%\\VideoNarrator\\inicio.txt

Si la app se queda en "Verificando tu acceso…", este archivo dice en qué paso se detuvo.
Guarda solo las últimas líneas; nunca contiene contraseñas.
"""
import os
import time
import threading

_LOCK = threading.Lock()
MAX_LINES = 300


def log(msg: str) -> None:
    try:
        from src.utils.paths import data_dir
        path = os.path.join(data_dir(), 'inicio.txt')
        line = time.strftime('%Y-%m-%d %H:%M:%S') + '  ' + str(msg).replace('\n', ' ')[:400] + '\n'
        with _LOCK:
            lines = []
            if os.path.exists(path):
                with open(path, 'r', encoding='utf-8', errors='replace') as fh:
                    lines = fh.readlines()[-(MAX_LINES - 1):]
            lines.append(line)
            with open(path, 'w', encoding='utf-8') as fh:
                fh.writelines(lines)
    except Exception:
        pass


class _ToFile:
    """Pasa los avisos de pywebview (la conexión pantalla <-> Python) a inicio.txt."""
    def __init__(self):
        import logging
        self.h = logging.Handler(level=logging.INFO)
        self.h.emit = self._emit

    def _emit(self, record):
        try:
            text = record.getMessage()
            if record.exc_info:
                import traceback
                text += ' | ' + ' '.join(traceback.format_exception(*record.exc_info)[-3:])
            log(f'pywebview {record.levelname.lower()}: {text}')
        except Exception:
            pass


def capture_pywebview_log() -> None:
    try:
        import logging
        lg = logging.getLogger('pywebview')
        lg.addHandler(_ToFile().h)
        if lg.level == logging.NOTSET or lg.level > logging.INFO:
            lg.setLevel(logging.INFO)
    except Exception:
        pass
