"""
Registro de arranque (VideoNarrator v8.2): %APPDATA%\\VideoNarrator\\inicio.txt

Si la app se queda en "Verificando tu acceso…", este archivo dice en qué paso se detuvo.
Guarda solo las últimas líneas; nunca contiene contraseñas.
"""
import os
import time
import threading

_LOCK = threading.Lock()
MAX_LINES = 300


def log(msg: str) -> None:
    try:
        from src.utils.paths import data_dir
        path = os.path.join(data_dir(), 'inicio.txt')
        line = time.strftime('%Y-%m-%d %H:%M:%S') + '  ' + str(msg).replace('\n', ' ')[:400] + '\n'
        with _LOCK:
            lines = []
            if os.path.exists(path):
                with open(path, 'r', encoding='utf-8', errors='replace') as fh:
                    lines = fh.readlines()[-(MAX_LINES - 1):]
            lines.append(line)
            with open(path, 'w', encoding='utf-8') as fh:
                fh.writelines(lines)
    except Exception:
        pass
