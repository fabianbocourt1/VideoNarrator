"""
"Mis historias": proyectos guardados de VideoNarrator (v5.3).

Cada historia es un .json en %APPDATA%\\VideoNarrator\\historias (data_dir/historias):
  - contenido: audio, carpeta/archivos de escenas, guion, audios por escena, intro/outro, salida...
  - controles: el valor de cada interruptor y menú del panel izquierdo
  - resumen y póster (miniatura de la primera escena) para la biblioteca

Se guarda sola mientras trabajas (escritura atómica: si la PC se apaga a mitad de un guardado,
queda la versión anterior completa, nunca un archivo a medias). Eliminar no borra: mueve a
historias\\papelera (se conservan las 30 más recientes).
"""
import os
import re
import json
import time
import uuid
import shutil
import threading
from datetime import datetime
from typing import Any, Dict, List, Optional

_LOCK = threading.Lock()
MAX_TRASH = 30
MAX_NAME = 80


def _root() -> str:
    from src.utils.paths import data_dir
    d = os.path.join(data_dir(), 'historias')
    os.makedirs(d, exist_ok=True)
    return d


def _trash() -> str:
    d = os.path.join(_root(), 'papelera')
    os.makedirs(d, exist_ok=True)
    return d


def _valid_id(pid: str) -> bool:
    return bool(re.fullmatch(r'h_[0-9a-z_]{6,40}', str(pid or '')))


def _path(pid: str) -> str:
    return os.path.join(_root(), pid + '.json')


def _now() -> str:
    return datetime.now().isoformat(timespec='seconds')


def _new_id() -> str:
    return 'h_' + datetime.now().strftime('%Y%m%d_%H%M%S') + '_' + uuid.uuid4().hex[:6]


def _write_atomic(path: str, data: Dict):
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as fh:
        json.dump(data, fh, ensure_ascii=False)
        fh.flush()
        try:
            os.fsync(fh.fileno())
        except Exception:
            pass
    os.replace(tmp, path)


def _read(path: str) -> Optional[Dict]:
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def _clean_name(name: str) -> str:
    name = re.sub(r'\s+', ' ', str(name or '')).strip()
    return name[:MAX_NAME]


def auto_name(contenido: Dict) -> str:
    """Nombre automático: carpeta de escenas > primeras palabras del guion > audio > fecha."""
    media = contenido.get('imagesFolder')
    if isinstance(media, str) and media.strip():
        base = os.path.basename(media.rstrip('\\/'))
        if base:
            return _clean_name(base.replace('_', ' '))
    if isinstance(media, list) and media:
        parent = os.path.basename(os.path.dirname(str(media[0])))
        if parent:
            return _clean_name(parent.replace('_', ' '))
    script = str(contenido.get('scriptText') or '')
    script = re.sub(r'(?im)^\s*(clip|escena|narrador|narrator)\s*\d*\s*[:\-]\s*', '', script)
    words = re.findall(r'[\wáéíóúüñÁÉÍÓÚÜÑ¿¡\'’,.]+', script)
    if words:
        text = ' '.join(words[:6]).strip(' ,.')
        return _clean_name(text[:1].upper() + text[1:] + ('…' if len(words) > 6 else ''))
    audio = contenido.get('audioPath')
    if audio:
        return _clean_name(os.path.splitext(os.path.basename(str(audio)))[0].replace('_', ' '))
    return 'Historia del ' + datetime.now().strftime('%d/%m/%Y')


def _summary(data: Dict) -> Dict:
    return {
        'id': data.get('id'),
        'nombre': data.get('nombre') or 'Historia sin título',
        'creado': data.get('creado'),
        'modificado': data.get('modificado'),
        'resumen': data.get('resumen') or {},
        'poster': data.get('poster') or '',
    }


# ── API ──────────────────────────────────────────────────────────────────────
def list_projects() -> List[Dict]:
    out = []
    for name in os.listdir(_root()):
        if not name.endswith('.json'):
            continue
        data = _read(os.path.join(_root(), name))
        if data and _valid_id(data.get('id')):
            out.append(_summary(data))
    out.sort(key=lambda d: d.get('modificado') or '', reverse=True)
    return out


def get_project(pid: str) -> Optional[Dict]:
    if not _valid_id(pid):
        return None
    return _read(_path(pid))


def save_project(data: Dict) -> Dict:
    """Crea o actualiza. Si nombre_auto es verdadero, el nombre se deduce del contenido."""
    if not isinstance(data, dict):
        return {'error': 'Datos no válidos.'}
    with _LOCK:
        pid = data.get('id')
        old = get_project(pid) if pid else None
        if not old:
            pid = _new_id()
            old = {'id': pid, 'creado': _now(), 'nombre_auto': True}
        contenido = data.get('contenido') or {}
        project = dict(old)
        project.update({
            'id': pid,
            'formato': 1,
            'contenido': contenido,
            'controles': data.get('controles') or {},
            'resumen': data.get('resumen') or old.get('resumen') or {},
            'modificado': _now(),
        })
        if data.get('poster'):
            project['poster'] = str(data['poster'])[:400000]
        if project.get('nombre_auto', True):
            project['nombre'] = auto_name(contenido)
        _write_atomic(_path(pid), project)
        return {'ok': True, 'id': pid, 'nombre': project['nombre'], 'modificado': project['modificado']}


def rename_project(pid: str, nombre: str) -> Dict:
    nombre = _clean_name(nombre)
    if not nombre:
        return {'error': 'Escribe un nombre.'}
    with _LOCK:
        data = get_project(pid)
        if not data:
            return {'error': 'No se encontró la historia.'}
        data['nombre'] = nombre
        data['nombre_auto'] = False
        _write_atomic(_path(pid), data)
    return {'ok': True, 'id': pid, 'nombre': nombre}


def duplicate_project(pid: str) -> Dict:
    with _LOCK:
        data = get_project(pid)
        if not data:
            return {'error': 'No se encontró la historia.'}
        new = dict(data)
        new['id'] = _new_id()
        new['nombre'] = _clean_name((data.get('nombre') or 'Historia') + ' (copia)')
        new['nombre_auto'] = False
        new['creado'] = new['modificado'] = _now()
        _write_atomic(_path(new['id']), new)
    return {'ok': True, 'id': new['id'], 'nombre': new['nombre']}


def delete_project(pid: str) -> Dict:
    """Mueve la historia a la papelera (no se pierde de inmediato)."""
    with _LOCK:
        if not _valid_id(pid) or not os.path.exists(_path(pid)):
            return {'error': 'No se encontró la historia.'}
        dest = os.path.join(_trash(), f'{pid}__{int(time.time())}.json')
        shutil.move(_path(pid), dest)
        trash = sorted((os.path.join(_trash(), f) for f in os.listdir(_trash()) if f.endswith('.json')),
                       key=os.path.getmtime, reverse=True)
        for old in trash[MAX_TRASH:]:
            try:
                os.remove(old)
            except Exception:
                pass
    return {'ok': True}


def missing_files(contenido: Dict) -> List[str]:
    """Archivos o carpetas de la historia que ya no existen (se movieron o borraron)."""
    paths = []
    if contenido.get('audioPath'):
        paths.append(contenido['audioPath'])
    media = contenido.get('imagesFolder')
    if isinstance(media, str) and media:
        paths.append(media)
    elif isinstance(media, list):
        paths.extend(media)
    for v in (contenido.get('narratorAudios') or {}).values():
        if v:
            paths.append(v)
    if contenido.get('musicPath'):
        paths.append(contenido['musicPath'])
    for slot in ('introOverlay', 'outroOverlay'):
        ov = contenido.get(slot)
        if isinstance(ov, dict) and ov.get('path'):
            paths.append(ov['path'])
    return [p for p in paths if not os.path.exists(str(p))]


def make_poster(media_path: str) -> str:
    """Miniatura nítida (máx. 360x640) de una imagen o del primer segundo de un video, como data URL."""
    import base64
    import subprocess
    from io import BytesIO
    if not media_path or not os.path.exists(media_path):
        return ''
    ext = os.path.splitext(media_path)[1].lower()
    try:
        if ext in ('.mp4', '.mov', '.webm', '.mkv', '.avi', '.m4v'):
            from src.utils.ffmpeg_locator import get_ffmpeg_path
            ff = get_ffmpeg_path()
            if not ff:
                return ''
            si = None
            if os.name == 'nt':
                si = subprocess.STARTUPINFO()
                si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            vf = 'scale=360:640:force_original_aspect_ratio=decrease'
            for seek in (['-ss', '0.6'], []):
                r = subprocess.run([ff, '-nostdin', '-v', 'error'] + seek + ['-i', media_path, '-frames:v', '1',
                                    '-vf', vf, '-pix_fmt', 'yuvj420p', '-f', 'image2pipe', '-c:v', 'mjpeg',
                                    '-q:v', '5', '-'], stdin=subprocess.DEVNULL, capture_output=True,
                                   startupinfo=si, timeout=20)
                if r.returncode == 0 and r.stdout:
                    return 'data:image/jpeg;base64,' + base64.b64encode(r.stdout).decode('ascii')
            return ''
        from PIL import Image
        with Image.open(media_path) as img:
            img.draft('RGB', (720, 1280))
            img = img.convert('RGB')
            img.thumbnail((360, 640), Image.Resampling.LANCZOS)
            buf = BytesIO()
            img.save(buf, format='JPEG', quality=80)
        return 'data:image/jpeg;base64,' + base64.b64encode(buf.getvalue()).decode('ascii')
    except Exception:
        return ''
