"""
Inteligencia artificial para VideoNarrator (v6.5): títulos, descripción y hashtags, y traducción
del guion.

Dos formas de usarla:
  - Automática: con una clave GRATIS de Google AI Studio (Gemini). Se guarda cifrada en la PC.
  - Sin clave: la app arma la instrucción (prompt) para pegarla en ChatGPT, Gemini o Claude
    en el navegador, y luego se pega la respuesta de vuelta.
"""
import os
import re
import json
import base64
import urllib.error
import urllib.request
from typing import Dict, List, Optional

API = 'https://generativelanguage.googleapis.com/v1beta'
FALLBACK_MODELS = ['gemini-2.5-flash', 'gemini-2.0-flash', 'gemini-flash-latest', 'gemini-1.5-flash']
LANGS = {
    'en': 'inglés', 'pt': 'portugués (de Brasil)', 'es': 'español', 'fr': 'francés', 'it': 'italiano',
    'de': 'alemán',
}
MAX_LINES_PER_CALL = 40


class IAError(Exception):
    pass


# ── Configuración (clave cifrada con la cuenta de Windows) ─────────────────
def _cfg_path() -> str:
    from src.utils.paths import data_dir
    return os.path.join(data_dir(), 'ia.json')


def _load_raw() -> Dict:
    try:
        with open(_cfg_path(), 'r', encoding='utf-8') as fh:
            return json.load(fh) or {}
    except Exception:
        return {}


def api_key() -> str:
    data = _load_raw()
    enc = data.get('key_enc') or ''
    if not enc:
        return ''
    try:
        raw = base64.b64decode(enc)
        if data.get('modo') == 'dpapi':
            from src.core.auth import _dpapi
            raw = _dpapi(raw, False) or b''
        return raw.decode('utf-8')
    except Exception:
        return ''


def save_key(key: str) -> Dict:
    from src.core.auth import _dpapi
    key = (key or '').strip()
    data = _load_raw()
    if key:
        enc = _dpapi(key.encode('utf-8'), True)
        data['modo'] = 'dpapi' if enc else 'b64'
        data['key_enc'] = base64.b64encode(enc or key.encode('utf-8')).decode('ascii')
    else:
        data['key_enc'] = ''
    data['model'] = ''
    with open(_cfg_path(), 'w', encoding='utf-8') as fh:
        json.dump(data, fh, indent=1)
    return public_config()


def public_config() -> Dict:
    key = api_key()
    return {'has_key': bool(key), 'key_hint': ('…' + key[-4:]) if len(key) >= 8 else '',
            'model': _load_raw().get('model') or ''}


# ── Llamadas a Gemini ───────────────────────────────────────────────────────
def _http(method: str, path: str, key: str, body: Optional[Dict] = None, timeout: float = 60.0) -> Dict:
    from src.utils.net import urlopen, friendly_error
    headers = {'x-goog-api-key': key, 'User-Agent': 'VideoNarrator'}
    data = None
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    req = urllib.request.Request(API + path, data=data, headers=headers, method=method)
    try:
        with urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode('utf-8') or '{}')
    except urllib.error.HTTPError as e:
        try:
            detail = json.loads(e.read().decode('utf-8', 'replace')).get('error', {}).get('message', '')
        except Exception:
            detail = ''
        if e.code in (400, 401, 403) and ('API key' in detail or 'API_KEY' in detail or e.code in (401, 403)):
            raise IAError('La clave de Gemini no es válida. Revísala en Google AI Studio (aistudio.google.com/apikey).')
        if e.code == 429:
            raise IAError('Llegaste al límite gratis de Gemini por ahora. Espera un minuto (o hasta mañana) y vuelve a intentar.')
        if e.code == 404:
            raise IAError('model404')
        raise IAError(f'Gemini respondió con un error ({e.code}). {detail[:200]}')
    except IAError:
        raise
    except Exception as e:
        raise IAError(friendly_error(e))


def _version_key(name: str):
    nums = [int(x) for x in re.findall(r'\d+', name.split('/')[-1])[:2]]
    return tuple(nums + [0] * (2 - len(nums)))


def pick_model(key: str) -> str:
    """El mejor modelo 'flash' disponible para esta clave (los nombres cambian con el tiempo)."""
    try:
        data = _http('GET', '/models?pageSize=200', key, timeout=20)
    except IAError as e:
        if str(e) == 'model404':
            return FALLBACK_MODELS[0]
        raise
    best = []
    for m in data.get('models') or []:
        name = (m.get('name') or '').split('/')[-1]
        if 'generateContent' not in (m.get('supportedGenerationMethods') or []):
            continue
        if 'flash' not in name or any(w in name for w in ('image', 'tts', 'audio', 'live', 'embedding', 'thinking', 'exp')):
            continue
        rank = (0 if 'preview' in name else 1, 0 if 'lite' in name else 1, _version_key(name))
        best.append((rank, name))
    if not best:
        return FALLBACK_MODELS[0]
    best.sort(reverse=True)
    return best[0][1]


def _model(key: str) -> str:
    data = _load_raw()
    if data.get('model'):
        return data['model']
    model = pick_model(key)
    data['model'] = model
    try:
        with open(_cfg_path(), 'w', encoding='utf-8') as fh:
            json.dump(data, fh, indent=1)
    except Exception:
        pass
    return model


def ask(prompt: str, want_json: bool = True, timeout: float = 90.0) -> str:
    key = api_key()
    if not key:
        raise IAError('Falta tu clave de Gemini.')
    body = {'contents': [{'role': 'user', 'parts': [{'text': prompt}]}],
            'generationConfig': {'temperature': 0.7}}
    if want_json:
        body['generationConfig']['responseMimeType'] = 'application/json'
    tried = []
    for model in [_model(key)] + [m for m in FALLBACK_MODELS]:
        if model in tried:
            continue
        tried.append(model)
        try:
            data = _http('POST', f'/models/{model}:generateContent', key, body, timeout=timeout)
        except IAError as e:
            if str(e) == 'model404':                    # ese modelo ya no existe: probar otro
                raw = _load_raw(); raw['model'] = ''
                try:
                    with open(_cfg_path(), 'w', encoding='utf-8') as fh:
                        json.dump(raw, fh, indent=1)
                except Exception:
                    pass
                continue
            raise
        cands = data.get('candidates') or []
        parts = ((cands[0].get('content') or {}).get('parts') or []) if cands else []
        text = ''.join(p.get('text', '') for p in parts).strip()
        if not text:
            reason = (cands[0].get('finishReason') if cands else '') or (data.get('promptFeedback') or {}).get('blockReason', '')
            raise IAError(f'Gemini no devolvió respuesta ({reason or "vacía"}). Intenta de nuevo.')
        if model != _load_raw().get('model'):
            raw = _load_raw(); raw['model'] = model
            try:
                with open(_cfg_path(), 'w', encoding='utf-8') as fh:
                    json.dump(raw, fh, indent=1)
            except Exception:
                pass
        return text
    raise IAError('No se encontró un modelo de Gemini disponible para tu clave.')


def _json_from(text: str):
    text = text.strip()
    m = re.search(r'```(?:json)?\s*(.+?)```', text, re.S)
    if m:
        text = m.group(1).strip()
    try:
        return json.loads(text)
    except Exception:
        m = re.search(r'(\{.*\}|\[.*\])', text, re.S)
        if m:
            return json.loads(m.group(1))
        raise IAError('La respuesta de Gemini no tenía el formato esperado. Intenta de nuevo.')


# ── Prompts ────────────────────────────────────────────────────────────────
def _story_text(lines: List[Dict], limit: int = 12000) -> str:
    text = '\n'.join(str(l.get('text') or '').strip() for l in lines if str(l.get('text') or '').strip())
    return text[:limit]


def publish_prompt(lines: List[Dict], lang: str = 'es', for_paste: bool = False) -> str:
    idioma = LANGS.get(lang, 'español')
    base = (
        f'Eres experto en YouTube Shorts, TikTok y Reels. Esta es la historia de un video vertical narrado:\n\n'
        f'"""\n{_story_text(lines)}\n"""\n\n'
        f'Escribe en {idioma}:\n'
        '1. Cinco TÍTULOS distintos, de máximo 70 caracteres, que den curiosidad sin revelar el final '
        '(puedes usar un emoji como máximo).\n'
        '2. Una DESCRIPCIÓN de 2 a 3 frases que enganche y termine invitando a comentar o seguir la cuenta.\n'
        '3. Entre 10 y 15 HASHTAGS relevantes (mezcla generales como #historias y específicos del tema), '
        'sin espacios dentro de cada hashtag.\n'
    )
    if for_paste:
        return base + '\nResponde con esas tres secciones, en texto simple, listo para copiar.'
    return base + ('\nResponde SOLO con JSON: {"titulos": ["..."], "descripcion": "...", '
                   '"hashtags": ["#..."]}')


def publish_kit(lines: List[Dict], lang: str = 'es') -> Dict:
    data = _json_from(ask(publish_prompt(lines, lang)))
    titulos = [str(t).strip() for t in (data.get('titulos') or []) if str(t).strip()][:8]
    tags = []
    for t in data.get('hashtags') or []:
        t = re.sub(r'\s+', '', str(t))
        if t and not t.startswith('#'):
            t = '#' + t
        if t and t not in tags:
            tags.append(t)
    return {'titulos': titulos, 'descripcion': str(data.get('descripcion') or '').strip(), 'hashtags': tags[:20]}


def translate_prompt(lines: List[Dict], lang: str, for_paste: bool = False) -> str:
    idioma = LANGS.get(lang, lang)
    numbered = '\n'.join(f'CLIP {l["clip_id"]}: {str(l.get("text") or "").strip()}' for l in lines)
    base = (
        f'Traduce al {idioma} este guion de un video narrado. Reglas:\n'
        '- Traducción natural, como la diría un narrador nativo (no literal), conservando emoción y tono.\n'
        '- Cada línea debe durar más o menos lo mismo al leerla en voz alta que el original.\n'
        '- Conserva los nombres propios de los personajes.\n'
        '- No juntes ni separes líneas: exactamente una traducción por cada CLIP, con su mismo número.\n\n'
        f'{numbered}\n'
    )
    if for_paste:
        return base + '\nResponde SOLO con el guion traducido, una línea por CLIP, en este formato: CLIP 1: …'
    return base + '\nResponde SOLO con JSON: {"lineas": [{"clip": 1, "texto": "..."}]}'


def parse_clip_text(text: str) -> Dict[int, str]:
    """Respuesta pegada en formato 'CLIP 3: texto' -> {3: 'texto'} (acepta líneas partidas)."""
    out, cur = {}, None
    for raw in (text or '').splitlines():
        line = raw.replace('**', '').replace('__', '').strip().lstrip('-•> ').strip()
        m = re.match(r'^(?:clip|escena|línea|linea)\s*(\d{1,4})\s*[:.\-–]\s*(.*)$', line, re.I)
        if m:
            cur = int(m.group(1))
            out[cur] = m.group(2).strip()
        elif cur is not None and line:
            out[cur] = (out[cur] + ' ' + line).strip()
    return out


def translate_lines(lines: List[Dict], lang: str, on_progress=None) -> Dict[int, str]:
    result: Dict[int, str] = {}
    chunks = [lines[i:i + MAX_LINES_PER_CALL] for i in range(0, len(lines), MAX_LINES_PER_CALL)]
    for n, chunk in enumerate(chunks, 1):
        if on_progress:
            on_progress({'done': n - 1, 'total': len(chunks)})
        data = _json_from(ask(translate_prompt(chunk, lang), timeout=180))
        items = data.get('lineas') if isinstance(data, dict) else data
        got = {}
        for it in items or []:
            try:
                got[int(it.get('clip'))] = str(it.get('texto') or '').strip()
            except Exception:
                continue
        missing = [l['clip_id'] for l in chunk if not got.get(int(l['clip_id']))]
        if missing:
            raise IAError(f'Gemini no tradujo todas las líneas (faltan: {", ".join(map(str, missing[:8]))}). Intenta de nuevo.')
        result.update(got)
    if on_progress:
        on_progress({'done': len(chunks), 'total': len(chunks)})
    return result


def build_script(lines: List[Dict], translated: Dict[int, str]) -> str:
    """Guion traducido en formato CLIP (los personajes del master prompt conservan su nombre)."""
    named = any(str(l.get('speaker') or '').strip() for l in lines)
    out = []
    for l in lines:
        cid = int(l['clip_id'])
        text = translated.get(cid, str(l.get('text') or ''))
        if named:                       # guion del master prompt: "Personaje: texto" / "Narrador: texto"
            speaker = str(l.get('speaker') or '').strip() or 'Narrador'
            out.append(f'{speaker}: {text}')
        else:                           # formato CLIP
            out.append(f'CLIP {cid}: {text}')
    return '\n\n'.join(out)
