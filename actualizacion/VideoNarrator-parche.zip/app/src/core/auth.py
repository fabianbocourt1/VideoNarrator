"""
Acceso con usuario y contraseña (VideoNarrator v4.9).

Los usuarios viven en Supabase (tabla 'usuarios', ver herramientas/supabase_usuarios.sql).
La app solo llama a tres funciones del servidor: vn_login, vn_validar y vn_salir.
  - Se necesita internet para abrir la app (si no hay, no deja entrar).
  - Una PC a la vez: al entrar en otra PC, la sesión de la anterior se cierra sola.
  - La sesión se recuerda en esta PC (no hay que escribir la contraseña cada vez); el
    administrador puede bloquearla en cualquier momento (activo = falso, vence, etc.).

Si app/auth_config.json no tiene 'supabase_url' y 'supabase_key', el acceso queda desactivado.
"""
import os
import json
import base64
import hashlib
import platform
import urllib.error
import urllib.request
import uuid
from typing import Dict, Optional

MESSAGES = {
    'credenciales': 'Usuario o contraseña incorrectos.',
    'espera': 'Demasiados intentos fallidos. Espera 10 minutos e inténtalo de nuevo.',
    'inactivo': 'Tu acceso a VideoNarrator está desactivado. Contacta al administrador.',
    'vencido': 'Tu acceso a VideoNarrator venció{fecha}. Contacta al administrador.',
    'otro_equipo': 'Esta cuenta ya está activada en otra PC. Pide al administrador que la libere.',
    'otra_pc': 'Tu cuenta se abrió en otra PC{pc}, así que aquí se cerró la sesión. Ingresa de nuevo para usarla en esta PC.',
    'sesion': 'Tu sesión terminó. Ingresa de nuevo.',
    'red': 'VideoNarrator necesita internet para verificar tu acceso. Revisa tu conexión y pulsa Reintentar.',
    'ssl': ('No se pudo verificar la conexión segura con el servidor de acceso. Revisa que la fecha y la '
            'hora de la PC sean correctas y que ningún antivirus esté bloqueando la conexión.'),
    'servidor': 'El servidor de acceso no responde correctamente. Inténtalo más tarde o contacta al administrador.',
}


class NetworkError(Exception):
    """Sin conexión: no se pudo hablar con el servidor."""


# ── Configuración ──────────────────────────────────────────────────────────
def load_config() -> Dict:
    from src.utils.paths import app_dir
    cfg = {'supabase_url': '', 'supabase_key': ''}
    try:
        with open(os.path.join(app_dir(), 'auth_config.json'), 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        if isinstance(data, dict):
            cfg.update({k: str(v or '').strip() for k, v in data.items() if k in cfg})
    except Exception:
        pass
    cfg['supabase_url'] = cfg['supabase_url'].rstrip('/')
    return cfg


def is_enabled(cfg: Optional[Dict] = None) -> bool:
    cfg = cfg or load_config()
    return bool(cfg.get('supabase_url') and cfg.get('supabase_key'))


# ── Identificador de esta PC ────────────────────────────────────────────────
def device_id() -> str:
    """Huella estable de la PC (no cambia al reinstalar la app)."""
    raw = ''
    if os.name == 'nt':
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Microsoft\Cryptography', 0,
                                winreg.KEY_READ | getattr(winreg, 'KEY_WOW64_64KEY', 0)) as k:
                raw = str(winreg.QueryValueEx(k, 'MachineGuid')[0])
        except Exception:
            raw = ''
    if not raw:
        from src.utils.paths import data_dir
        path = os.path.join(data_dir(), 'equipo.id')
        try:
            with open(path, 'r', encoding='utf-8') as fh:
                raw = fh.read().strip()
        except Exception:
            raw = ''
        if not raw:
            raw = uuid.uuid4().hex
            try:
                with open(path, 'w', encoding='utf-8') as fh:
                    fh.write(raw)
            except Exception:
                pass
    return hashlib.sha256(('videonarrator:' + raw).encode('utf-8')).hexdigest()[:32]


def device_name() -> str:
    return (os.environ.get('COMPUTERNAME') or platform.node() or 'PC')[:60]


# ── Sesión guardada (cifrada con la cuenta de Windows cuando es posible) ────
def _dpapi(data: bytes, protect: bool) -> Optional[bytes]:
    if os.name != 'nt':
        return None
    try:
        import ctypes
        from ctypes import wintypes

        class BLOB(ctypes.Structure):
            _fields_ = [('cbData', wintypes.DWORD), ('pbData', ctypes.POINTER(ctypes.c_char))]
        buf = ctypes.create_string_buffer(data, len(data))
        src = BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char)))
        out = BLOB()
        crypt32 = ctypes.windll.crypt32
        fn = crypt32.CryptProtectData if protect else crypt32.CryptUnprotectData
        ok = fn(ctypes.byref(src), None, None, None, None, 0x1, ctypes.byref(out))   # UI_FORBIDDEN
        if not ok:
            return None
        try:
            return ctypes.string_at(out.pbData, out.cbData)
        finally:
            ctypes.windll.kernel32.LocalFree(out.pbData)
    except Exception:
        return None


def _session_path() -> str:
    from src.utils.paths import data_dir
    return os.path.join(data_dir(), 'sesion.json')


def save_session(usuario: str, token: str):
    raw = token.encode('utf-8')
    enc = _dpapi(raw, True)
    data = {'usuario': usuario, 'modo': 'dpapi' if enc else 'b64',
            'token': base64.b64encode(enc or raw).decode('ascii')}
    try:
        with open(_session_path(), 'w', encoding='utf-8') as fh:
            json.dump(data, fh)
    except Exception:
        pass


def load_session() -> Optional[Dict]:
    try:
        with open(_session_path(), 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        blob = base64.b64decode(data.get('token') or '')
        if data.get('modo') == 'dpapi':
            blob = _dpapi(blob, False)
            if blob is None:
                return None
        return {'usuario': str(data.get('usuario') or ''), 'token': blob.decode('utf-8')}
    except Exception:
        return None


def clear_session():
    try:
        os.remove(_session_path())
    except Exception:
        pass


# ── Llamadas al servidor ────────────────────────────────────────────────────
def _rpc(fn: str, payload: Dict, cfg: Optional[Dict] = None, timeout: float = 12.0) -> Dict:
    cfg = cfg or load_config()
    key = cfg['supabase_key']
    headers = {'apikey': key, 'Content-Type': 'application/json', 'Accept': 'application/json',
               'User-Agent': 'VideoNarrator'}
    if key.startswith('eyJ'):                    # clave "anon" antigua (JWT)
        headers['Authorization'] = 'Bearer ' + key
    req = urllib.request.Request(f"{cfg['supabase_url']}/rest/v1/rpc/{fn}",
                                 data=json.dumps(payload).encode('utf-8'), headers=headers, method='POST')
    try:
        from src.utils.net import urlopen
        with urlopen(req, timeout=timeout) as r:
            data = json.loads(r.read().decode('utf-8') or '{}')
    except urllib.error.HTTPError as e:
        detail = ''
        try:
            detail = e.read().decode('utf-8', 'replace')[:300]
        except Exception:
            pass
        raise RuntimeError(f'HTTP {e.code} {detail}')
    except (urllib.error.URLError, OSError, TimeoutError) as e:
        if 'CERTIFICATE_VERIFY_FAILED' in str(e):
            raise RuntimeError('ssl: ' + str(e))
        raise NetworkError(str(e))
    if isinstance(data, str):                    # algunas versiones devuelven el json como texto
        try:
            data = json.loads(data)
        except Exception:
            data = {}
    return data if isinstance(data, dict) else {}


def message_for(res: Dict) -> str:
    motivo = res.get('motivo') or 'servidor'
    text = MESSAGES.get(motivo, MESSAGES['servidor'])
    if motivo == 'vencido':
        v = res.get('vence')
        fecha = ''
        if v:
            try:
                y, m, d = str(v)[:10].split('-')
                fecha = f' el {d}/{m}/{y}'
            except Exception:
                fecha = f' el {v}'
        text = text.format(fecha=fecha)
    if motivo == 'otra_pc':
        pc = str(res.get('equipo_nombre') or '').strip()
        text = text.format(pc=f' ({pc})' if pc else '')
    return text


def _fail(motivo: str, extra: Optional[Dict] = None) -> Dict:
    res = {'ok': False, 'motivo': motivo}
    res.update(extra or {})
    res['mensaje'] = message_for(res)
    return res


def login(usuario: str, clave: str, version: str) -> Dict:
    usuario = (usuario or '').strip().lower()
    if not usuario or not clave:
        return {'ok': False, 'motivo': 'vacio', 'mensaje': 'Escribe tu usuario y tu contraseña.'}
    try:
        res = _rpc('vn_login', {'p_usuario': usuario, 'p_clave': clave, 'p_equipo': device_id(),
                                'p_equipo_nombre': device_name(), 'p_version': version})
    except NetworkError:
        return _fail('red')
    except Exception as e:
        return _fail('ssl' if str(e).startswith('ssl:') else 'servidor', {'detalle': str(e)})
    if res.get('ok') and res.get('token'):
        save_session(res.get('usuario') or usuario, res['token'])
        return {'ok': True, 'usuario': res.get('usuario') or usuario, 'nombre': res.get('nombre') or '',
                'vence': res.get('vence')}
    return _fail(res.get('motivo') or 'servidor', {k: res[k] for k in ('vence',) if k in res})


def validate(version: str) -> Dict:
    """Comprueba la sesión guardada. {'ok': True, ...} o {'ok': False, 'motivo', 'mensaje', 'login': bool}."""
    ses = load_session()
    if not ses or not ses.get('token'):
        return {'ok': False, 'motivo': 'sin_sesion', 'mensaje': '', 'login': True}
    try:
        res = _rpc('vn_validar', {'p_usuario': ses['usuario'], 'p_token': ses['token'],
                                  'p_equipo': device_id(), 'p_version': version})
    except NetworkError:
        out = _fail('red')
        out.update({'login': False, 'usuario': ses['usuario']})
        return out
    except Exception as e:
        out = _fail('ssl' if str(e).startswith('ssl:') else 'servidor', {'detalle': str(e)})
        out.update({'login': False, 'usuario': ses['usuario']})
        return out
    if res.get('ok'):
        return {'ok': True, 'usuario': res.get('usuario') or ses['usuario'], 'nombre': res.get('nombre') or '',
                'vence': res.get('vence')}
    clear_session()
    out = _fail(res.get('motivo') or 'sesion', {k: res[k] for k in ('vence', 'equipo_nombre') if k in res})
    out.update({'login': True, 'usuario': ses['usuario']})
    return out


def logout():
    ses = load_session()
    clear_session()
    if ses:
        try:
            _rpc('vn_salir', {'p_usuario': ses['usuario'], 'p_token': ses['token']}, timeout=6.0)
        except Exception:
            pass


# ── Panel de usuarios (v6.1): solo cuentas de administrador ─────────────────
ADMIN_MESSAGES = {
    'no_admin': 'Tu cuenta no tiene permiso de administrador.',
    'usuario_invalido': 'El usuario solo puede tener letras minúsculas, números, punto, guion o guion bajo (2 a 40).',
    'falta_clave': 'Escribe una contraseña para el usuario nuevo.',
    'sobre_ti_mismo': 'No puedes bloquearte, quitarte el permiso de administrador ni borrarte a ti mismo.',
}


def _admin_call(fn: str, extra: Dict) -> Dict:
    ses = load_session()
    if not ses:
        return {'ok': False, 'mensaje': 'Ingresa de nuevo para usar el panel de usuarios.'}
    payload = {'p_usuario': ses['usuario'], 'p_token': ses['token']}
    payload.update(extra)
    try:
        res = _rpc(fn, payload)
    except NetworkError:
        return {'ok': False, 'mensaje': MESSAGES['red']}
    except Exception as e:
        txt = str(e)
        if 'HTTP 404' in txt or 'PGRST202' in txt:
            return {'ok': False, 'mensaje': 'Falta preparar el panel en Supabase: ejecuta otra vez '
                                             'herramientas/supabase_usuarios.sql (SQL Editor > Run).'}
        return {'ok': False, 'mensaje': MESSAGES['servidor'], 'detalle': txt}
    if not res.get('ok', True) and res.get('motivo'):
        res['mensaje'] = ADMIN_MESSAGES.get(res['motivo'], MESSAGES.get(res['motivo'], MESSAGES['servidor']))
    return res


def is_admin() -> bool:
    ses = load_session()
    if not ses:
        return False
    try:
        return bool(_rpc('vn_es_admin', {'p_usuario': ses['usuario'], 'p_token': ses['token']}, timeout=8).get('es_admin'))
    except Exception:
        return False                       # sin el SQL nuevo o sin internet: el panel no aparece


def admin_list() -> Dict:
    return _admin_call('vn_admin_listar', {})


def admin_save(datos: Dict) -> Dict:
    clean = {}
    for k in ('usuario', 'clave', 'nombre', 'vence'):
        if k in datos and datos[k] is not None:
            clean[k] = str(datos[k]).strip()
    for k in ('activo', 'es_admin', 'cerrar_sesion', 'desbloquear'):
        if k in datos and datos[k] is not None:
            clean[k] = bool(datos[k])
    clean['usuario'] = clean.get('usuario', '').lower()
    return _admin_call('vn_admin_guardar', {'p_datos': clean})


def admin_delete(objetivo: str) -> Dict:
    return _admin_call('vn_admin_borrar', {'p_objetivo': (objetivo or '').strip().lower()})
