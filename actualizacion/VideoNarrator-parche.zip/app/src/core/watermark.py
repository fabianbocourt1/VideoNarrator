"""
Marca de agua (VideoNarrator v8.9).

Un logo (imagen o video, por ejemplo con fondo verde) encima de todo el video, quieto o
moviéndose. Se aplica al final, sobre el video ya terminado:
  - "Quitar el fondo verde": chromakey con el color de fondo detectado en las esquinas del logo.
  - Tamaño (% del ancho del video) y transparencia.
  - Movimiento: fijo (punto A) · de A a B · ida y vuelta entre A y B · recorriendo las esquinas.
  - Cuándo aparece: todo el video o de un segundo a otro.
Los puntos A y B van de 0 a 1 dentro del espacio libre (0,0 = arriba a la izquierda; 1,1 = abajo
a la derecha), así el logo nunca se sale del cuadro.
"""
import os
import io
import base64
import subprocess
from typing import Dict, Optional, Callable

VIDEO_EXT = ('.mp4', '.mov', '.webm', '.mkv', '.avi', '.m4v', '.gif')
SIMILARITY = {'suave': 0.12, 'media': 0.18, 'fuerte': 0.27}
PINGPONG_HALF = 8.0          # segundos de A a B en "ida y vuelta"
CORNER_STAY = 8.0            # segundos en cada esquina
CORNERS = [(0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)]


def _si():
    if os.name != 'nt':
        return None
    si = subprocess.STARTUPINFO()
    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    return si


def _is_video(path: str) -> bool:
    return os.path.splitext(path or '')[1].lower() in VIDEO_EXT


def _first_frame_png(ff: str, path: str, width: int = 0) -> bytes:
    cmd = [ff, '-hide_banner', '-nostdin', '-v', 'error', '-i', path, '-frames:v', '1']
    if width:
        cmd += ['-vf', f'scale={width}:-2']
    cmd += ['-f', 'image2pipe', '-vcodec', 'png', '-']
    r = subprocess.run(cmd, stdin=subprocess.DEVNULL, capture_output=True, timeout=60, startupinfo=_si())
    return r.stdout if r.returncode == 0 else b''


def key_color(ff: str, path: str) -> str:
    """Color de fondo del logo (el de las esquinas), en formato 0xRRGGBB. Verde si no se puede saber."""
    try:
        from PIL import Image
        data = _first_frame_png(ff, path, 320)
        im = Image.open(io.BytesIO(data)).convert('RGBA')
        w, h = im.size
        pts = [(1, 1), (w - 2, 1), (1, h - 2), (w - 2, h - 2), (w // 2, 1), (1, h // 2)]
        px = [im.getpixel(p) for p in pts]
        px = [p for p in px if p[3] > 200] or px
        # El color de fondo es el más repetido entre las esquinas
        best = max(px, key=lambda p: sum(1 for q in px if abs(p[0] - q[0]) + abs(p[1] - q[1]) + abs(p[2] - q[2]) < 60))
        return '0x%02X%02X%02X' % best[:3]
    except Exception:
        return '0x00FF00'


def _chain(opts, key: str, ww: int) -> str:
    """Filtro para el logo: quitar el fondo, escalar y aplicar la transparencia."""
    f = []
    if getattr(opts, 'wm_chroma', True):
        sim = SIMILARITY.get(getattr(opts, 'wm_similarity', 'media'), 0.18)
        f.append(f"chromakey={key}:{sim:.3f}:0.08")
    f.append(f"scale={ww}:-2:flags=lanczos")
    f.append("format=rgba")
    op = max(0.05, min(1.0, float(getattr(opts, 'wm_opacity', 0.8) or 0.8)))
    if op < 0.999:
        f.append(f"colorchannelmixer=aa={op:.3f}")
    return ",".join(f)


def _clamp01(v) -> float:
    try:
        return max(0.0, min(1.0, float(v)))
    except (TypeError, ValueError):
        return 0.0


def position_exprs(opts, t0: float, t1: float):
    """Expresiones x/y de FFmpeg (overlay) según el movimiento elegido."""
    X, Y = "(main_w-overlay_w)", "(main_h-overlay_h)"
    ax, ay = _clamp01(getattr(opts, 'wm_ax', 0.04)), _clamp01(getattr(opts, 'wm_ay', 0.04))
    bx, by = _clamp01(getattr(opts, 'wm_bx', 0.96)), _clamp01(getattr(opts, 'wm_by', 0.96))
    move = getattr(opts, 'wm_move', 'ab')
    span = max(0.1, t1 - t0)
    if move == 'fixed':
        return f"{X}*{ax:.4f}", f"{Y}*{ay:.4f}"
    if move == 'corners':
        k = f"floor(mod((t-{t0:.3f})/{CORNER_STAY:.1f},4))"
        m = 0.03
        cx = [m if c[0] == 0 else 1 - m for c in CORNERS]
        cy = [m if c[1] == 0 else 1 - m for c in CORNERS]
        ex = f"{X}*if(eq({k},0),{cx[0]},if(eq({k},1),{cx[1]},if(eq({k},2),{cx[2]},{cx[3]})))"
        ey = f"{Y}*if(eq({k},0),{cy[0]},if(eq({k},1),{cy[1]},if(eq({k},2),{cy[2]},{cy[3]})))"
        return ex, ey
    if move == 'pingpong':
        p = f"(1-abs(mod((t-{t0:.3f})/{PINGPONG_HALF:.1f},2)-1))"
    else:   # 'ab'
        p = f"clip((t-{t0:.3f})/{span:.3f},0,1)"
    return (f"{X}*({ax:.4f}+({bx - ax:.4f})*{p})", f"{Y}*({ay:.4f}+({by - ay:.4f})*{p})")


def build_cmd(ff: str, video: str, opts, W: int, H: int, dur: float, out: str, enc_args) -> list:
    path = getattr(opts, 'wm_path', '')
    key = key_color(ff, path) if getattr(opts, 'wm_chroma', True) else '0x00FF00'
    size = max(0.03, min(0.9, float(getattr(opts, 'wm_size', 0.18) or 0.18)))
    ww = max(16, int(round(W * size / 2)) * 2)
    t0 = max(0.0, float(getattr(opts, 'wm_start', 0) or 0))
    t1 = float(getattr(opts, 'wm_end', 0) or 0)
    if t1 <= t0 or t1 > dur:
        t1 = dur
    ex, ey = position_exprs(opts, t0, t1)
    cmd = [ff, '-hide_banner', '-y', '-i', video]
    if _is_video(path):
        cmd += ['-stream_loop', '-1', '-i', path]
    else:
        cmd += ['-loop', '1', '-framerate', '30', '-i', path]
    fc = (f"[1:v]{_chain(opts, key, ww)}[wm];"
          f"[0:v][wm]overlay=x='{ex}':y='{ey}':enable='between(t,{t0:.3f},{t1:.3f})':shortest=1:format=auto,"
          f"format=yuv420p[v]")
    args = list(enc_args or ['-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18'])
    if '-pix_fmt' in args:                      # el formato ya va en el filtro
        i = args.index('-pix_fmt')
        del args[i:i + 2]
    cmd += ['-filter_complex', fc, '-map', '[v]', '-map', '0:a?', '-c:a', 'copy'] + args + \
           ['-movflags', '+faststart', '-t', f'{dur:.3f}', out]
    return cmd


def apply(engine, video_path: str, opts, on_progress: Optional[Callable] = None, log=None) -> Dict:
    """Pone la marca de agua sobre video_path (lo reemplaza). {'watermark': nombre} o {'watermark_error': ...}."""
    path = getattr(opts, 'wm_path', '')
    if not path or not os.path.isfile(path):
        return {'watermark_error': 'No se encontró el archivo de la marca de agua; el video quedó sin ella.'}
    ff = engine.ffmpeg_exe
    dur = engine._probe_duration(video_path) or 0.0
    try:
        from src.core.render_engine import probe_media_dimensions
        W, H = probe_media_dimensions(video_path, ff)
    except Exception:
        W, H = 0, 0
    if not W or not H:
        W, H = {'square': (1080, 1080), 'horizontal': (1920, 1080)}.get(getattr(opts, 'resolution', ''), (1080, 1920))
    try:
        _name, enc_args, _desc = engine.probe_encoder()
    except Exception:
        enc_args = None
    tmp = os.path.splitext(video_path)[0] + '.marca.mp4'
    cmd = build_cmd(ff, video_path, opts, W, H, dur, tmp, enc_args)
    if log:
        log(f"ETAPA: marca de agua ({os.path.basename(path)}, {getattr(opts, 'wm_move', 'ab')})")
        log('  cmd: ' + ' '.join(cmd))
    if on_progress:
        try:
            on_progress({'percent': 99.0, 'current_sec': dur, 'total_sec': dur,
                         'encoder_desc': 'Agregando la marca de agua…'})
        except Exception:
            pass
    try:
        r = engine._run_tracked(cmd, timeout=max(180, dur * 4), startupinfo=_si())
        rc, err = r.returncode, (r.stderr or b'').decode('utf-8', 'replace')
    except subprocess.TimeoutExpired:
        rc, err = -1, 'tiempo agotado'
    if rc != 0 or not os.path.exists(tmp) or os.path.getsize(tmp) < 1000:
        # Si falló con la tarjeta gráfica, se intenta una vez con el procesador
        if enc_args and 'libx264' not in enc_args:
            cmd = build_cmd(ff, video_path, opts, W, H, dur, tmp, None)
            try:
                r = engine._run_tracked(cmd, timeout=max(180, dur * 6), startupinfo=_si())
                rc, err = r.returncode, (r.stderr or b'').decode('utf-8', 'replace')
            except subprocess.TimeoutExpired:
                rc, err = -1, 'tiempo agotado'
    if rc != 0 or not os.path.exists(tmp) or os.path.getsize(tmp) < 1000:
        try:
            os.remove(tmp)
        except Exception:
            pass
        if log:
            log(f"  marca de agua: error {rc}: {(err or '')[-600:]}")
        return {'watermark_error': 'No se pudo poner la marca de agua; el video quedó sin ella.'}
    os.replace(tmp, video_path)
    return {'watermark': os.path.basename(path)}


def preview(ff: str, path: str, chroma: bool = True, similarity: str = 'media') -> Dict:
    """Vista previa del logo ya sin el fondo (PNG con transparencia), igual que en el video final."""
    if not path or not os.path.isfile(path):
        return {'error': 'No se encontró el archivo.'}
    try:
        key = key_color(ff, path) if chroma else ''
        vf = []
        if chroma:
            vf.append(f"chromakey={key}:{SIMILARITY.get(similarity, 0.18):.3f}:0.08")
        vf.append("scale='min(720,iw)':-2")
        vf.append("format=rgba")
        cmd = [ff, '-hide_banner', '-nostdin', '-v', 'error', '-i', path, '-frames:v', '1',
               '-vf', ",".join(vf), '-f', 'image2pipe', '-vcodec', 'png', '-']
        r = subprocess.run(cmd, stdin=subprocess.DEVNULL, capture_output=True, timeout=60, startupinfo=_si())
        if r.returncode != 0 or not r.stdout:
            return {'error': 'No se pudo leer el archivo de la marca.'}
        raw = _first_frame_png(ff, path, 720)
        w = h = 0
        try:
            from PIL import Image
            w, h = Image.open(io.BytesIO(r.stdout)).size
        except Exception:
            pass
        return {'path': os.path.abspath(path), 'name': os.path.basename(path), 'is_video': _is_video(path),
                'key': key, 'width': w, 'height': h,
                'preview': 'data:image/png;base64,' + base64.b64encode(r.stdout).decode('ascii'),
                'original': ('data:image/png;base64,' + base64.b64encode(raw).decode('ascii')) if raw else ''}
    except Exception as e:
        return {'error': f'No se pudo preparar la marca: {e}'}
