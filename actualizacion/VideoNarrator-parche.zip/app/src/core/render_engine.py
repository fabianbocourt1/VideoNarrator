import os
import re
import sys
import time
import math
import shutil
import tempfile
import subprocess
import threading
from datetime import datetime
from typing import Optional, Callable, Dict, Any, Tuple, List
from dataclasses import dataclass, field
import concurrent.futures

from src.core.timeline import TimelineProject, generate_timestamps_file_content
from src.core import subtitles as subs_mod
from src.utils.ffmpeg_locator import get_ffmpeg_path, get_audio_duration

# macOS/Linux: Aumentar límite de file descriptors para soportar muchos clips
# FFmpeg abre todos los inputs simultáneamente y el default (256) es insuficiente
if os.name != 'nt':
    try:
        import resource
        soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
        resource.setrlimit(resource.RLIMIT_NOFILE, (min(hard, 10240), hard))
    except Exception:
        pass

W, H, FPS = 1080, 1920, 30
PRESCALE_W, PRESCALE_H = 1080, 1920

def is_video_file(path: str) -> bool:
    if not path:
        return False
    ext = os.path.splitext(path)[1].lower()
    return ext in ('.mp4', '.mov', '.webm', '.mkv', '.avi')

def probe_media_dimensions(path: str, ffmpeg_exe: str) -> Tuple[int, int]:
    try:
        res = _run(
            [ffmpeg_exe, '-i', path],
            capture_output=True,
            text=True,
            errors='ignore'
        )
        match = re.search(r",\s*(\d{2,5})x(\d{2,5})", res.stderr)
        if match:
            return int(match.group(1)), int(match.group(2))
    except Exception:
        pass
    return W, H


def _with_nostdin(cmd):
    """Agrega -nostdin a los comandos de FFmpeg: así nunca intenta leer el teclado
    (en Windows, sin consola, eso puede dejar a FFmpeg colgado indefinidamente)."""
    try:
        if cmd and 'ffmpeg' in os.path.basename(str(cmd[0])).lower() and '-nostdin' not in cmd:
            extra = ['-nostdin'] + ([] if '-hide_banner' in cmd else ['-hide_banner'])
            return [cmd[0]] + extra + list(cmd[1:])
    except Exception:
        pass
    return cmd


def _run(cmd, **kwargs):
    """subprocess.run sin heredar la entrada estándar: evita que FFmpeg se quede esperando teclado
    cuando la app corre sin consola (ventana pywebview)."""
    kwargs.setdefault('stdin', subprocess.DEVNULL)
    return subprocess.run(_with_nostdin(cmd), **kwargs)


class _RenderLog:
    """Registro de la renderización (render_log.txt, junto a la app) para poder ver qué escena se traba."""
    def __init__(self):
        self._f = None
        self._lock = threading.Lock()
        self.path = ''
        self._t0 = time.time()

    def open(self):
        try:
            from src.utils.paths import data_dir
            base = data_dir()
        except Exception:
            base = tempfile.gettempdir()
        for folder in (base, tempfile.gettempdir()):
            try:
                path = os.path.join(folder, 'render_log.txt')
                self._f = open(path, 'w', encoding='utf-8')
                self.path = path
                break
            except Exception:
                self._f = None
        self._t0 = time.time()
        self.write(f"VideoNarrator v4.0 - registro de renderizado ({datetime.now():%Y-%m-%d %H:%M:%S})")

    def write(self, msg: str):
        with self._lock:
            if not self._f:
                return
            try:
                self._f.write(f"[{time.time() - self._t0:7.1f}s] {msg}\n")
                self._f.flush()
            except Exception:
                pass


_LOG = _RenderLog()

@dataclass
class RenderOptions:
    resolution: str = 'vertical'
    normalize_audio: bool = True
    enable_camera_motion: bool = False
    camera_motion_type: str = "alternate"
    zoom_intensity: float = 1.25
    enable_transitions: bool = False
    transition_style: str = "viral_pack"
    transition_pool: List[str] = field(default_factory=lambda: ['fade', 'slide', 'zoomin', 'flash'])
    transition_frequency: int = 1
    transition_duration: float = 0.35
    export_timestamps: bool = True
    preview_mode: bool = False
    preview_duration: float = 15.0

    # Clips que son videos (en lugar de imágenes)
    # video_extend_mode: qué hacer si el video dura menos que el clip
    #   'freeze' = congela el último frame | 'loop' = repite el video | 'slow' = lo ralentiza para igualar
    # video_fit: 'contain' = cabe completo con barras negras (igual que las imágenes) | 'cover' = llena y recorta
    video_extend_mode: str = "freeze"
    video_fit: str = "contain"
    
    enable_intro_overlay: bool = False
    intro_overlay_path: Optional[str] = None
    intro_overlay_duration: float = 2.0
    intro_overlay_position: str = "center"
    intro_overlay_type: str = "chromakey"
    intro_chroma_similarity: float = 0.46
    
    enable_outro_overlay: bool = False
    outro_overlay_path: Optional[str] = None
    outro_overlay_duration: float = 3.5
    outro_overlay_position: str = "bottom"
    outro_overlay_type: str = "chromakey"
    outro_chroma_similarity: float = 0.46

    # Subtítulos automáticos (estilo CapCut) — un solo color de acento en todo el video
    subtitles_enabled: bool = False
    subtitle_template: str = "karaoke"      # karaoke | palabra | destacado | caja | elegante
    subtitle_color: str = "#FFC845"
    subtitle_position: str = "auto"         # auto | top | center | bottom
    subtitle_size: str = "medium"           # small | medium | large
    subtitle_export_srt: bool = False

    # Música de fondo con ducking (v5.8): se mezcla al final, sobre el video ya terminado
    music_enabled: bool = False
    music_path: str = ""                    # archivo, o carpeta (rota una canción por video)
    music_volume: str = "normal"            # suave | normal | presente
    music_duck: str = "normal"              # poco | normal | mucho (cuánto baja al hablar)
    music_fade: bool = True
    music_loop: bool = True
    music_start: float = 0.0

    # v6.5: igualar el volumen de cada voz (Fish, narrador, audio de los videos de diálogo)
    level_voices: bool = True

    # v8.9: marca de agua (logo encima de todo el video, quieto o moviéndose)
    wm_enabled: bool = False
    wm_path: str = ""
    wm_chroma: bool = True                  # quitar el fondo (verde) del logo
    wm_similarity: str = "media"            # suave | media | fuerte
    wm_size: float = 0.18                   # ancho del logo / ancho del video
    wm_opacity: float = 0.8
    wm_move: str = "ab"                     # fixed | ab | pingpong | corners
    wm_ax: float = 0.04
    wm_ay: float = 0.04
    wm_bx: float = 0.96
    wm_by: float = 0.96
    wm_start: float = 0.0
    wm_end: float = 0.0                     # 0 = hasta el final

class RenderEngine:
    def __init__(self, ffmpeg_exe: Optional[str] = None):
        self.ffmpeg_exe = ffmpeg_exe if ffmpeg_exe else get_ffmpeg_path()
        self.current_process = None
        self.is_cancelled = False
        self._cached_encoder_info = None
        # Procesos FFmpeg de las escenas que corren en paralelo (para poder detenerlos todos)
        self._procs = set()
        self._procs_lock = threading.Lock()
        self._abort = False

    def _kill_all(self):
        """Detiene todos los FFmpeg de escenas que estén corriendo."""
        with self._procs_lock:
            procs = list(self._procs)
        for p in procs:
            try:
                p.kill()
            except Exception:
                pass

    def _run_tracked(self, cmd, timeout=None, startupinfo=None, cwd=None):
        """Como subprocess.run(capture_output=True), pero registra el proceso para que
        Cancelar (o un error en otra escena) lo pueda detener al instante."""
        if self._abort or self.is_cancelled:
            raise RuntimeError("Renderizado detenido.")
        p = subprocess.Popen(_with_nostdin(cmd), stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE, startupinfo=startupinfo, cwd=cwd)
        with self._procs_lock:
            self._procs.add(p)
        try:
            # Si se canceló justo mientras se lanzaba, se detiene ya
            if self._abort or self.is_cancelled:
                p.kill()
            try:
                out, err = p.communicate(timeout=timeout)
            except subprocess.TimeoutExpired:
                p.kill()
                tail = b''
                try:
                    _o, tail = p.communicate(timeout=10)
                except Exception:
                    pass
                # Lo último que FFmpeg alcanzó a escribir (frame=..., time=...) dice dónde se trabó
                try:
                    _LOG.write("FFmpeg trabado. Últimas líneas:\n" +
                               (tail or b'').decode('utf-8', errors='replace').replace('\r', '\n')[-1500:])
                except Exception:
                    pass
                raise
        finally:
            with self._procs_lock:
                self._procs.discard(p)
        return subprocess.CompletedProcess(cmd, p.returncode, out, err)

    def probe_encoder(self) -> Tuple[str, list[str], str]:
        """
        Detecta si hay aceleración por hardware (NVIDIA NVENC, AMD AMF o Intel QSV).
        Si no, usa CPU libx264 optimizado para Still Image con multi-threading.
        """
        if self._cached_encoder_info:
            return self._cached_encoder_info

        if not self.ffmpeg_exe:
            return "libx264", ['-c:v', 'libx264', '-preset', 'faster', '-tune', 'stillimage', '-crf', '18', '-threads', '0'], "CPU libx264"

        startupinfo = None
        if os.name == 'nt':
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW

        # Probar NVENC
        try:
            res = _run(
                [self.ffmpeg_exe, '-y', '-f', 'lavfi', '-i', 'color=c=black:s=256x256:d=0.1', '-c:v', 'h264_nvenc', '-f', 'null', '-'],
                capture_output=True,
                startupinfo=startupinfo,
                timeout=3
            )
            if res.returncode == 0:
                self._cached_encoder_info = ("h264_nvenc", ['-c:v', 'h264_nvenc', '-preset', 'p4', '-cq', '18', '-pix_fmt', 'yuv420p'], "GPU NVIDIA (NVENC Ultra Rápido)")
                return self._cached_encoder_info
        except Exception:
            pass

        # Probar AMF
        try:
            res = _run(
                [self.ffmpeg_exe, '-y', '-f', 'lavfi', '-i', 'color=c=black:s=256x256:d=0.1', '-c:v', 'h264_amf', '-f', 'null', '-'],
                capture_output=True,
                startupinfo=startupinfo,
                timeout=3
            )
            if res.returncode == 0:
                self._cached_encoder_info = ("h264_amf", ['-c:v', 'h264_amf', '-quality', 'speed', '-rc', 'cqp', '-qp_p', '18', '-pix_fmt', 'yuv420p'], "GPU AMD (AMF Acelerado)")
                return self._cached_encoder_info
        except Exception:
            pass

        # Probar QSV
        try:
            res = _run(
                [self.ffmpeg_exe, '-y', '-f', 'lavfi', '-i', 'color=c=black:s=256x256:d=0.1', '-c:v', 'h264_qsv', '-f', 'null', '-'],
                capture_output=True,
                startupinfo=startupinfo,
                timeout=3
            )
            if res.returncode == 0:
                self._cached_encoder_info = ("h264_qsv", ['-c:v', 'h264_qsv', '-preset', 'faster', '-global_quality', '18', '-pix_fmt', 'nv12'], "GPU Intel (QuickSync Activo)")
                return self._cached_encoder_info
        except Exception:
            pass

        # Fallback a libx264
        self._cached_encoder_info = ("libx264", ['-c:v', 'libx264', '-preset', 'faster', '-tune', 'stillimage', '-crf', '18', '-threads', '0', '-pix_fmt', 'yuv420p'], "CPU Ryzen / Multi-Core (libx264 optimizado)")
        return self._cached_encoder_info

    def cancel(self):
        """Cancela el proceso de renderizado en curso."""
        self.is_cancelled = True
        self._abort = True
        self._kill_all()
        if self.current_process:
            try:
                self.current_process.terminate()
            except Exception:
                pass

    def _build_zoompan_filter(self, duration: float, fps: int, motion_type: str, zoom_intensity: float = 1.25) -> str:
        """
        Construye el filtro de Ken Burns con pre-escalado 2X y curva Hermite Smoothstep anti-jitter.
        """
        total_frames = max(2, int(round(duration * fps)))
        n_minus_one = max(1, total_frames - 1)
        delta_z = zoom_intensity - 1.0

        prescale_part = (
            f"scale={PRESCALE_W}:{PRESCALE_H}:force_original_aspect_ratio=decrease:flags=bilinear,"
            f"pad={PRESCALE_W}:{PRESCALE_H}:(ow-iw)/2:(oh-ih)/2:black,setsar=1"
        )

        prog = f"(on/{n_minus_one})"
        smooth_curve = f"({prog}*{prog}*(3.0-2.0*{prog}))"

        if motion_type == 'in':
            z_expr = f"'min({zoom_intensity:.4f}, max(1.0, 1.0 + {delta_z:.6f}*{smooth_curve}))'"
            x_expr = "'iw/2-(iw/zoom/2)'"
            y_expr = "'ih/2-(ih/zoom/2)'"
        elif motion_type == 'out':
            z_expr = f"'max(1.0, min({zoom_intensity:.4f}, {zoom_intensity:.4f} - {delta_z:.6f}*{smooth_curve}))'"
            x_expr = "'iw/2-(iw/zoom/2)'"
            y_expr = "'ih/2-(ih/zoom/2)'"
        elif motion_type == 'pan_right':
            z_expr = f"'{zoom_intensity:.4f}'"
            x_expr = f"'{smooth_curve}*(iw-iw/zoom)'"
            y_expr = "'ih/2-(ih/zoom/2)'"
        elif motion_type == 'pan_left':
            z_expr = f"'{zoom_intensity:.4f}'"
            x_expr = f"'(1.0 - {smooth_curve})*(iw-iw/zoom)'"
            y_expr = "'ih/2-(ih/zoom/2)'"
        else:
            return f"scale={W}:{H}:force_original_aspect_ratio=decrease,pad={W}:{H}:(ow-iw)/2:(oh-ih)/2:black,setsar=1"

        zoompan_part = f"zoompan=z={z_expr}:x={x_expr}:y={y_expr}:d={total_frames}:s={W}x{H}:fps={fps}"

        return f"{prescale_part},{zoompan_part}"

    def _resolve_motion_type(self, motion_mode: str, index: int) -> str:
        if motion_mode == 'alternate':
            return 'in' if index % 2 == 0 else 'out'
        if motion_mode in ('in', 'out'):
            return motion_mode
        if motion_mode == 'random':
            patterns = ['in', 'out', 'pan_right', 'in', 'out', 'pan_left']
            return patterns[index % len(patterns)]
        return 'none'

    def _has_transition(self, index: int, freq: int) -> bool:
        if index == 0:
            return False
        if freq == 1:
            return True
        if freq == 2:
            return index % 2 == 1
        if freq == 3:
            return index % 3 == 0
        return index % freq == 0

    def _expand_transition_pool(self, pool: List[str]) -> List[str]:
        expanded = []
        for item in pool:
            il = item.lower().strip()
            if il == 'slide':
                expanded.extend(['smoothleft', 'smoothright'])
            elif il == 'flash':
                expanded.append('fadewhite')
            elif il in ('fade', 'zoomin', 'dissolve'):
                expanded.append(il)
            elif il:
                expanded.append(il)
        if not expanded:
            return ['fade']
        return expanded

    def _resolve_transition_name(self, style: str, index: int, transition_pool: Optional[List[str]]) -> str:
        if transition_pool and len(transition_pool) > 0:
            concrete = self._expand_transition_pool(transition_pool)
            return concrete[(index - 1) % len(concrete)]
        
        s_low = style.lower().strip() if style else 'viral_pack'
        if s_low == 'viral_pack':
            pool = ['smoothleft', 'fade', 'smoothright', 'zoomin', 'fadewhite']
            return pool[(index - 1) % len(pool)]
        if s_low == 'dynamic':
            pool = ['smoothleft', 'fade', 'smoothright']
            return pool[(index - 1) % len(pool)]
        if s_low == 'cinematic':
            pool = ['fade', 'dissolve']
            return pool[(index - 1) % len(pool)]
        if s_low == 'slide':
            return 'smoothleft' if index % 2 == 1 else 'smoothright'
        if s_low == 'flash':
            return 'fadewhite'
        if s_low in ('fade', 'zoomin', 'dissolve'):
            return s_low
        return 'fade'

    def _probe_duration(self, path: str) -> float:
        """Duración en segundos de un archivo de video (0.0 si no se puede leer)."""
        try:
            return float(get_audio_duration(path, self.ffmpeg_exe))
        except Exception:
            return 0.0

    def _build_video_clip_cmd(self, video_path: str, total_frames: int, threads: int, clip_out: str, opts: RenderOptions, keep_segments=None) -> list:
        """
        Comando FFmpeg que convierte un video de entrada en un clip de EXACTAMENTE total_frames
        cuadros, con la resolución y FPS del proyecto. Ignora el audio del video original.
        - Si el video dura más que el clip: se recorta.
        - Si dura menos: se congela el último frame, se repite en bucle o se ralentiza (video_extend_mode).
        - keep_segments (recorte de silencios): solo se conservan esos tramos (inicio, fin) del video;
          es el mismo recorte que se aplica al audio, así que no se desincronizan.

        IMPORTANTE (FFmpeg 7/8): antes se usaba select='...' + tpad=stop=-1 (clonar sin fin). En FFmpeg 7
        esa combinación se queda colgada para siempre (y select además pierde cuadros). Ahora cada tramo
        es una entrada aparte (-ss/-t), cada tramo tiene su número exacto de cuadros, y el relleno
        con el último cuadro siempre tiene un límite.
        """
        actual_dur = total_frames / FPS
        mode = opts.video_extend_mode if opts.video_extend_mode in ('freeze', 'loop', 'slow') else 'freeze'

        if opts.video_fit == 'cover':
            fit = f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H}"
        else:
            fit = f"scale={W}:{H}:force_original_aspect_ratio=decrease,pad={W}:{H}:(ow-iw)/2:(oh-ih)/2:black"
        fit += ",setsar=1"
        # Relleno finito (nunca stop=-1) y marcas de tiempo renumeradas a 30 fps exactos: FFmpeg 7 pierde
        # la cadencia después de trim/tpad (sacaba el clip a 25 fps y descartaba cuadros).
        tail_pad = f"tpad=stop_mode=clone:stop={total_frames},setpts=N/({FPS}*TB)"
        out_args = [
            '-r', str(FPS),
            '-frames:v', str(total_frames),
            '-c:v', 'libx264', '-preset', 'ultrafast', '-crf', '22',
            '-pix_fmt', 'yuv420p', '-an', clip_out
        ]
        no_extra = ['-an', '-sn', '-dn']

        if keep_segments:
            # Cuadros exactos por tramo (redondeo acumulado: la suma coincide con el audio recortado)
            cmd = [self.ffmpeg_exe, '-y']
            parts, labels = [], []
            acc, prev = 0.0, 0
            for k, (a, b) in enumerate(keep_segments):
                acc += (b - a)
                end_f = round(acc * FPS)
                n_k = max(1, end_f - prev)
                prev = end_f
                cmd += ['-threads', str(threads)] + no_extra + [
                    '-ss', f"{a:.4f}", '-t', f"{(b - a) + 0.25:.4f}", '-i', video_path]
                parts.append(
                    f"[{k}:v:0]setpts=PTS-STARTPTS,fps={FPS},"
                    f"tpad=stop_mode=clone:stop={n_k},trim=end_frame={n_k},setpts=PTS-STARTPTS[s{k}]"
                )
                labels.append(f"[s{k}]")
            if len(labels) > 1:
                parts.append("".join(labels) + f"concat=n={len(labels)}:v=1:a=0,{fit},{tail_pad}[v]")
            else:
                parts[-1] = parts[-1].replace("[s0]", f",{fit},{tail_pad}[v]").replace("PTS-STARTPTS,,", "PTS-STARTPTS,")
            return cmd + ['-filter_complex', ";".join(parts), '-map', '[v]'] + out_args

        src_dur = self._probe_duration(video_path)
        too_short = src_dur > 0 and src_dur < actual_dur - (1.0 / FPS)
        input_args = ['-threads', str(threads)] + no_extra
        filters = []
        if mode == 'loop':
            input_args += ['-stream_loop', '-1']
        elif mode == 'slow' and too_short:
            filters.append(f"setpts={actual_dur / src_dur:.6f}*PTS")
        else:
            # recorte / congelar: no hace falta leer más allá de la duración del clip
            input_args += ['-t', f"{actual_dur + 0.5:.3f}"]
        filters.append(f"fps={FPS}")
        filters.append(fit)
        if mode != 'loop':
            filters.append(tail_pad)   # si el video es más corto, se congela el último cuadro

        return [self.ffmpeg_exe, '-y'] + input_args + [
            '-i', video_path, '-map', '0:v:0', '-vf', ",".join(filters)
        ] + out_args

    def _apply_overlay_to_clip(
        self,
        clip_path: str,
        clip_duration: float,
        overlay_path: str,
        output_path: str,
        overlay_type: str,
        overlay_duration: float,
        overlay_position: str,
        chroma_similarity: float,
        chroma_blend: float = 0.03,
        align: str = 'start',
        threads: int = 2
    ):
        """
        Incrusta un overlay dinámico (video o imagen) con soporte para Chroma Key o Canal Alfa.
        """
        if not overlay_path or not os.path.exists(overlay_path):
            return None
        
        is_vid = is_video_file(overlay_path)
        eff_ov_dur = min(overlay_duration, clip_duration)
        
        if align == 'end':
            start_time = max(0.0, clip_duration - eff_ov_dur)
            end_time = clip_duration
        else:
            start_time = 0.0
            end_time = eff_ov_dur

        ov_w, ov_h = probe_media_dimensions(overlay_path, self.ffmpeg_exe)
        is_vertical = ov_h > (ov_w * 1.4)
        
        ov_filters = []
        if is_vid and start_time > 0:
            ov_filters.append(f"setpts=PTS-STARTPTS+({start_time:.3f}/TB)")
        if is_vid:
            ov_filters.append("crop=w='trunc((iw-4)/2)*2':h='trunc((ih-4)/2)*2':x=2:y=2")
        
        if overlay_type == 'chromakey':
            sim = max(0.15, min(0.65, chroma_similarity))
            bl = max(0.01, min(0.15, chroma_blend))
            ov_filters.append(f"colorkey=0x00FF00:{sim:.2f}:{bl:.2f}")
            ov_filters.append("format=yuva420p")
        
        if is_vertical:
            ov_filters.append(f"scale={W}:{H}")
            pos_x = "0"
            pos_y = "0"
        else:
            ov_filters.append("scale=w='trunc(min(iw,920)/2)*2':h=-2:force_original_aspect_ratio=decrease")
            pos_map = {
                'top': ('trunc((W-w)/4)*2', '220'),
                'center': ('trunc((W-w)/4)*2', 'trunc((H-h)/4)*2'),
                'bottom': ('trunc((W-w)/4)*2', 'trunc((H-h-260)/4)*2')
            }
            pos_x, pos_y = pos_map.get(overlay_position, ('trunc((W-w)/4)*2', 'trunc((H-h)/4)*2'))
            
        if not is_vid:
            if align == 'start' and eff_ov_dur > 0.4:
                fade_st = max(0.0, eff_ov_dur - 0.25)
                ov_filters.append(f"fade=t=out:st={fade_st:.2f}:d=0.25:alpha=1")
            elif align == 'end' and eff_ov_dur > 0.4:
                ov_filters.append(f"fade=t=in:st={start_time:.2f}:d=0.25:alpha=1")
                
        ov_chain = ",".join(ov_filters)
        filter_complex = f"[1:v]{ov_chain}[ov];[0:v][ov]overlay=x={pos_x}:y={pos_y}:repeatlast=1:enable='between(t,{start_time:.2f},{end_time:.2f})'[outv]"
        
        input_args = ['-i', clip_path]
        if not is_vid:
            input_args.extend(['-loop', '1'])
        input_args.extend(['-i', overlay_path])
        
        cmd = [self.ffmpeg_exe, '-y', '-threads', str(threads)] + input_args + [
            '-filter_complex', filter_complex,
            '-map', '[outv]',
            '-t', f"{clip_duration:.3f}",
            '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18',
            '-pix_fmt', 'yuv420p', '-an', output_path
        ]
        
        startupinfo = None
        if os.name == 'nt':
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            
        res = _run(cmd, capture_output=True, startupinfo=startupinfo)
        if res.returncode != 0:
            err_msg = res.stderr.decode('ignore', errors='replace')[:300]
            raise RuntimeError(f"Error aplicando overlay ({align}): {err_msg}")
        return None

    def render(
        self,
        timeline: TimelineProject,
        audio_path: str,
        output_folder: str,
        options: Optional[RenderOptions] = None,
        export_timestamps: bool = True,
        on_progress: Optional[Callable[[Dict[str, Any]], None]] = None
    ) -> Dict[str, Any]:
        """
        Ejecuta el renderizado.
        - Si no hay Ken Burns ni Transiciones: usa Concat Demuxer directo (ultrarrápido, ~3s).
        - Si hay Ken Burns o Transiciones: genera micro-clips en paralelo con zoompan y xfade.
        """
        self.is_cancelled = False
        self._abort = False
        self._subs = None
        opts = options if options else RenderOptions(export_timestamps=export_timestamps)
        
        global W, H, PRESCALE_W, PRESCALE_H
        if opts.resolution == 'square':
            W, H = 1080, 1080
            PRESCALE_W, PRESCALE_H = 1080, 1080
        elif opts.resolution == 'horizontal':
            W, H = 1920, 1080
            PRESCALE_W, PRESCALE_H = 1920, 1080
        else:
            W, H = 1080, 1920
            PRESCALE_W, PRESCALE_H = 1080, 1920
        
        if not self.ffmpeg_exe:
            raise RuntimeError("FFmpeg no está disponible.")
            
        if not timeline.is_valid:
            raise RuntimeError("El proyecto no es válido para renderizar.")
            
        active_timeline = timeline
        prefix = "video"
        
        if opts.preview_mode and len(timeline.clips) > 0:
            prefix = "preview_video"
            preview_clips = []
            cum_time = 0.0
            for clip in timeline.clips:
                preview_clips.append(clip)
                cum_time += clip.duration
                if cum_time >= opts.preview_duration and len(preview_clips) >= 2:
                    break
            
            # Crear copia superficial para preview
            c_clips = []
            for c in preview_clips:
                if not c.has_image:
                    continue
                c_clips.append(c)

            active_timeline = TimelineProject(
                clips=preview_clips,
                total_audio_duration=min(cum_time, timeline.total_audio_duration),
                total_words=sum(c.word_count for c in preview_clips),
                missing_images=[],
                unused_images=[],
                is_valid=all(c.has_image for c in preview_clips),
                story_mode=getattr(timeline, 'story_mode', False)
            )

        output_folder = os.path.abspath(output_folder or '.')
        if audio_path:
            audio_path = os.path.abspath(audio_path)
        os.makedirs(output_folder, exist_ok=True)
        ts_str = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_video = os.path.join(output_folder, f"{prefix}_{ts_str}.mp4")
        
        encoder_name, encoder_args, encoder_desc = self.probe_encoder()
        
        has_intro = bool(opts.enable_intro_overlay and opts.intro_overlay_path and os.path.exists(opts.intro_overlay_path))
        has_outro = bool(opts.enable_outro_overlay and opts.outro_overlay_path and os.path.exists(opts.outro_overlay_path))
        has_overlays = has_intro or has_outro
        
        # El modo directo (concat demuxer) solo sirve para imágenes fijas:
        # si algún clip es video se usa siempre el pipeline dinámico.
        has_video_clips = any(
            c.image and getattr(c.image, 'is_video', False) for c in active_timeline.clips
        )
        
        # Registro de la renderización (render_log.txt)
        _LOG.open()
        try:
            import platform
            try:
                _ver = _run([self.ffmpeg_exe, '-version'], capture_output=True, text=True, errors='ignore',
                            timeout=15).stdout.splitlines()[0]
            except Exception as _ve:
                _ver = f"(no se pudo leer la versión: {_ve})"
            _LOG.write(f"FFmpeg: {_ver}")
            _LOG.write(f"Python {platform.python_version()} · {platform.platform()} · CPU={os.cpu_count()} · ffmpeg={self.ffmpeg_exe}")
            _LOG.write(f"escenas={len(active_timeline.clips)} · duración total={active_timeline.total_audio_duration:.1f}s · "
                       f"modo_historia={getattr(active_timeline, 'story_mode', False)} · encoder={encoder_desc}")
            for _n, _c in enumerate(active_timeline.clips, 1):
                _media = _c.image.filename if _c.image else '-'
                _aud = os.path.basename(getattr(_c, 'audio_path', '') or '') or '-'
                _LOG.write(f"  escena {_n}: tipo={getattr(_c, 'kind', 'clip')} archivo={_media} dur={_c.duration:.2f}s "
                           f"audio={getattr(_c, 'audio_mode', '-')}:{_aud}")
            _LOG.write(f"opciones: {opts}")
        except Exception:
            pass

        story_tmp = None
        subs_tmp = None
        try:
            # Modo historia: el audio final se arma por tramos (audio propio de los videos de
            # diálogo + voz del narrador en sus líneas), en el mismo orden que el video.
            if getattr(active_timeline, 'story_mode', False):
                story_tmp = tempfile.mkdtemp(prefix='vn_story_')
                _LOG.write('ETAPA: armando el audio de la historia')
                audio_path = self._build_story_audio(active_timeline, story_tmp, on_progress,
                                                     level=bool(getattr(opts, 'level_voices', True)))

            # Subtítulos automáticos: se preparan ANTES de generar las escenas (si algo falla, falla rápido)
            if opts.subtitles_enabled:
                subs_tmp = tempfile.mkdtemp(prefix='vn_subs_')
                self._subs = self._prepare_subtitles(active_timeline, audio_path, subs_tmp, opts, on_progress)

            if not opts.enable_camera_motion and not opts.enable_transitions and not has_overlays and not has_video_clips:
                result = self._render_concat_direct(
                    active_timeline, audio_path, output_video, output_folder, ts_str,
                    encoder_args, encoder_desc, encoder_name, opts,
                    opts.export_timestamps if not opts.preview_mode else False,
                    on_progress
                )
            else:
                result = self._render_dynamic_pipeline(
                    active_timeline, audio_path, output_video, opts,
                    encoder_args, encoder_desc, on_progress, encoder_name=encoder_name
                )
            # Música de fondo: último paso, sobre el video terminado (la voz ya va recortada)
            if opts.music_enabled and opts.music_path and result.get('video_path') and os.path.exists(result['video_path']):
                from src.core import music as music_mod
                result.update(music_mod.mix_into(self, result['video_path'], opts, on_progress, log=_LOG.write))
                try:
                    result['size_mb'] = round(os.path.getsize(result['video_path']) / 1048576, 2)
                except Exception:
                    pass
            # Marca de agua (v8.9): sobre el video terminado
            if getattr(opts, 'wm_enabled', False) and opts.wm_path and result.get('video_path') and os.path.exists(result['video_path']):
                from src.core import watermark as wm_mod
                result.update(wm_mod.apply(self, result['video_path'], opts, on_progress, log=_LOG.write))
                try:
                    result['size_mb'] = round(os.path.getsize(result['video_path']) / 1048576, 2)
                except Exception:
                    pass
            if self._subs and result.get('video_path'):
                result['subtitles'] = self._subs.get('source')
                result['subtitles_reason'] = self._subs.get('reason', '')
                if opts.subtitle_export_srt:
                    srt_path = os.path.splitext(result['video_path'])[0] + '.srt'
                    try:
                        with open(srt_path, 'w', encoding='utf-8') as fh:
                            fh.write(self._subs['srt'])
                        result['srt_path'] = srt_path
                    except Exception:
                        pass
            _LOG.write("FIN: renderizado completado")
            return result
        except Exception as _e:
            _LOG.write(f"FIN CON ERROR: {_e}")
            raise
        finally:
            if story_tmp:
                shutil.rmtree(story_tmp, ignore_errors=True)
            if subs_tmp:
                shutil.rmtree(subs_tmp, ignore_errors=True)
            self._subs = None

    def _ffmpeg_has_libass(self) -> bool:
        try:
            r = _run([self.ffmpeg_exe, '-hide_banner', '-filters'], capture_output=True, text=True,
                     errors='ignore', timeout=20)
            return bool(re.search(r"\s(ass|subtitles)\s+V->V", r.stdout))
        except Exception:
            return True   # si no se puede comprobar, se intenta igual

    def _prepare_subtitles(self, timeline, audio_path, work_dir, opts, on_progress):
        if not self._ffmpeg_has_libass():
            raise RuntimeError(
                "Tu FFmpeg no incluye libass, necesario para los subtítulos. Instala una versión completa "
                "(por ejemplo la 'full' o 'essentials' de gyan.dev) o desactiva los subtítulos.")
        if on_progress:
            on_progress({'percent': 1.0, 'current_sec': 0.0, 'total_sec': timeline.total_audio_duration,
                         'encoder_desc': "Escuchando la voz para los subtítulos (Whisper)..."})
        _LOG.write("ETAPA: subtítulos (Whisper + archivo ASS)")
        _wp_last = [0.0]

        def _whisper_progress(frac, desc):
            # v9.0: avance real mientras Whisper escucha (antes el render parecía detenido en 1 %)
            if not on_progress:
                return
            import time as _t
            now = _t.time()
            if now - _wp_last[0] < 1.0 and 0 < frac < 1:
                return
            _wp_last[0] = now
            pct = int(round(frac * 100))
            on_progress({'percent': 1.0 + 1.5 * frac, 'current_sec': 0.0, 'total_sec': timeline.total_audio_duration,
                         'encoder_desc': f"{desc} ({pct}%)" if 0 < frac <= 1 else desc})
        info = subs_mod.prepare_subtitles(
            timeline, audio_path, work_dir, W, H,
            template=opts.subtitle_template, accent=opts.subtitle_color,
            position=opts.subtitle_position, size=opts.subtitle_size, log=_LOG.write,
            progress=_whisper_progress)
        if info['words'] == 0:
            _LOG.write("subtítulos: no hay texto ni voz reconocible; se omiten")
            return None
        return info

    def _subs_encoder_args(self, encoder_name: str, encoder_args: list) -> list:
        """Códec para quemar los subtítulos (el video ya no se puede copiar tal cual)."""
        if encoder_name == 'libx264':
            return ['-c:v', 'libx264', '-preset', 'veryfast', '-crf', '19', '-pix_fmt', 'yuv420p', '-threads', '0']
        return list(encoder_args)

    # Volumen de cada voz: se lleva cada escena a este nivel (luego todo el video se normaliza a -16 LUFS)
    LEVEL_TARGET = -20.0
    LEVEL_MAX_UP = 15.0
    LEVEL_MAX_DOWN = -12.0

    def _measure_loudness(self, path: str, startupinfo=None):
        """(LUFS integrados, pico real dBFS) de un audio, o (None, None)."""
        try:
            r = _run([self.ffmpeg_exe, '-hide_banner', '-nostats', '-i', path,
                      '-af', 'ebur128=peak=true:framelog=quiet', '-f', 'null', '-'],
                     capture_output=True, startupinfo=startupinfo, timeout=60)
            err = (r.stderr or b'').decode('utf-8', 'replace')
            summary = err[err.rfind('Summary:'):] if 'Summary:' in err else err
            mi = re.search(r'I:\s*(-?[\d.]+|-inf)\s*LUFS', summary)
            mp = re.search(r'Peak:\s*(-?[\d.]+|-inf)\s*dBFS', summary)
            if not mi or 'inf' in mi.group(1):
                return None, None
            peak = float(mp.group(1)) if mp and 'inf' not in mp.group(1) else 0.0
            return float(mi.group(1)), peak
        except Exception:
            return None, None

    def _level_segment(self, path: str, startupinfo=None) -> str:
        """Ajusta el volumen de un tramo para que todas las voces suenen parejas. Devuelve un resumen."""
        lufs, peak = self._measure_loudness(path, startupinfo)
        if lufs is None or lufs < -55:
            return 'sin voz'
        gain = self.LEVEL_TARGET - lufs
        gain = max(self.LEVEL_MAX_DOWN, min(self.LEVEL_MAX_UP, gain))
        gain = min(gain, -1.0 - peak)            # nunca saturar
        if abs(gain) < 0.5:
            return f'{lufs:.1f} LUFS (ya parejo)'
        tmp = path + '.lvl.wav'
        r = _run([self.ffmpeg_exe, '-y', '-v', 'error', '-i', path, '-af', f'volume={gain:.2f}dB',
                  '-c:a', 'pcm_s16le', '-ar', '44100', '-ac', '2', tmp],
                 capture_output=True, startupinfo=startupinfo, timeout=60)
        if r.returncode == 0 and os.path.exists(tmp):
            os.replace(tmp, path)
            return f'{lufs:.1f} LUFS → {gain:+.1f} dB'
        return 'no se pudo ajustar'

    def _build_story_audio(self, timeline: TimelineProject, tmpdir: str, on_progress=None, level: bool = False) -> str:
        """
        Arma el audio de una historia: un tramo WAV por clip, de EXACTAMENTE la duración del clip,
        y los une en orden.
          - 'video'  → el audio propio del video de diálogo (Flow).
          - 'file'   → audio numerado del narrador (03.mp3).
          - 'slice'  → trozo del audio único del narrador (inicio audio_start).
          - otro     → silencio.
        """
        startupinfo = None
        if os.name == 'nt':
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW

        def run(cmd):
            try:
                return _run(cmd, capture_output=True, startupinfo=startupinfo, cwd=tmpdir, timeout=120)
            except subprocess.TimeoutExpired:
                _LOG.write("audio: un tramo tardó más de 120 s; se usa silencio en su lugar")
                class _Failed:
                    returncode = 1
                    stderr = b''
                return _Failed()

        seg_names = []
        for i, c in enumerate(timeline.clips):
            dur = max(float(c.duration), 0.05)
            name = f"seg_{i:04d}.wav"
            out = os.path.join(tmpdir, name)
            ok = False

            if c.audio_mode in ('video', 'file', 'slice') and c.audio_path and os.path.exists(c.audio_path):
                tail = f"aresample=44100,aformat=sample_fmts=s16:channel_layouts=stereo,apad=whole_dur={dur:.6f}"
                segs = (getattr(c, 'keep_segments', None) if c.audio_mode == 'video'
                        else getattr(c, 'audio_segments', None))
                if segs:
                    # Recorte de silencios: se conservan solo estos tramos (del audio del video, que son
                    # los mismos que se conservan en la imagen, o del audio del narrador), con
                    # microfundidos en los cortes. Se salta directo al primer tramo (-ss).
                    base = max(0.0, segs[0][0] - 0.5)
                    parts, labels = [], []
                    for k, (a, b) in enumerate(segs):
                        a, b = a - base, b - base
                        ln = b - a
                        fd = min(0.008, ln / 4.0)
                        lab = f"[a{k}]" if len(segs) > 1 else "[ac]"
                        parts.append(
                            f"[0:a]atrim=start={a:.4f}:end={b:.4f},asetpts=PTS-STARTPTS,"
                            f"afade=t=in:st=0:d={fd:.4f},afade=t=out:st={ln - fd:.4f}:d={fd:.4f}{lab}"
                        )
                        labels.append(lab)
                    if len(segs) > 1:
                        parts.append("".join(labels) + f"concat=n={len(segs)}:v=0:a=1[ac]")
                    parts.append(f"[ac]{tail}[aout]")
                    r = run([self.ffmpeg_exe, '-y', '-v', 'error', '-ss', f"{base:.3f}", '-i', c.audio_path,
                             '-filter_complex', ";".join(parts), '-map', '[aout]',
                             '-t', f"{dur:.6f}", '-c:a', 'pcm_s16le', '-ar', '44100', '-ac', '2', out])
                else:
                    seek = ['-ss', f"{c.audio_start:.3f}"] if (c.audio_mode == 'slice' and c.audio_start > 0) else []
                    r = run([self.ffmpeg_exe, '-y', '-v', 'error'] + seek + [
                        '-i', c.audio_path, '-vn', '-map', '0:a:0', '-af', tail,
                        '-t', f"{dur:.6f}", '-c:a', 'pcm_s16le', '-ar', '44100', '-ac', '2', out
                    ])
                ok = (r.returncode == 0 and os.path.exists(out))
                if ok and level:
                    _LOG.write(f"  volumen escena {i+1}: {self._level_segment(out, startupinfo)}")

            if not ok:  # sin audio disponible (ej: video sin pista de sonido) → silencio
                run([self.ffmpeg_exe, '-y', '-v', 'error', '-f', 'lavfi',
                     '-i', 'anullsrc=r=44100:cl=stereo', '-t', f"{dur:.6f}",
                     '-c:a', 'pcm_s16le', out])
            seg_names.append(name)
            _LOG.write(f"audio escena {i+1}/{len(timeline.clips)}: modo={c.audio_mode} dur={dur:.2f}s {'OK' if ok else 'silencio'}")
            if on_progress:
                on_progress({
                    'percent': round(1.0 * (i + 1) / max(1, len(timeline.clips)), 1),
                    'current_sec': 0.0,
                    'total_sec': timeline.total_audio_duration,
                    'encoder_desc': f"Preparando el audio de las escenas ({i + 1}/{len(timeline.clips)})..."
                })

        list_path = os.path.join(tmpdir, 'story_audio_list.txt')
        with open(list_path, 'w', encoding='utf-8') as f:
            for name in seg_names:
                f.write(f"file '{name}'\n")

        final_audio = os.path.join(tmpdir, 'story_audio.wav')
        r = run([self.ffmpeg_exe, '-y', '-v', 'error', '-f', 'concat', '-safe', '0',
                 '-i', 'story_audio_list.txt', '-c', 'copy', final_audio])
        if r.returncode != 0 or not os.path.exists(final_audio):
            raise RuntimeError("No se pudo armar el audio de la historia.")
        return final_audio

    def _render_concat_direct(
        self,
        timeline: TimelineProject,
        audio_path: str,
        output_video: str,
        output_folder: str,
        ts_str: str,
        encoder_args: list,
        encoder_desc: str,
        encoder_name: str,
        opts: Optional[RenderOptions],
        export_timestamps: bool,
        on_progress: Optional[Callable]
    ) -> Dict[str, Any]:
        concat_file = os.path.join(output_folder, f"_concat_{ts_str}.txt")
        try:
            with open(concat_file, 'w', encoding='utf-8') as f:
                for clip in timeline.clips:
                    if not clip.image:
                        continue
                    # BUG-03: Escapar comillas simples
                    path_formatted = os.path.abspath(clip.image.full_path).replace("\\", "/").replace("'", "'\\''")
                    f.write(f"file '{path_formatted}'\n")
                    f.write(f"duration {clip.duration:.4f}\n")
                
                last_clip = timeline.clips[-1]
                if last_clip.image:
                    last_path = os.path.abspath(last_clip.image.full_path).replace("\\", "/").replace("'", "'\\''")
                    f.write(f"file '{last_path}'\n")
        except Exception:
            pass
            
        vf = f"scale={W}:{H}:force_original_aspect_ratio=decrease,pad={W}:{H}:(ow-iw)/2:(oh-ih)/2:black,setsar=1"
        subs = getattr(self, '_subs', None)
        if subs:
            vf += f",fps={FPS},{subs['filter']}"
        
        cmd = [
            self.ffmpeg_exe, '-y',
            '-f', 'concat', '-safe', '0', '-i', concat_file
        ]
        
        if opts and opts.preview_mode:
            cmd.extend(['-t', f"{timeline.total_audio_duration:.3f}"])
            
        cmd.extend([
            '-i', audio_path,
            '-vf', vf,
            '-r', str(FPS)
        ])
        
        cmd.extend(encoder_args)
        
        if opts and getattr(opts, 'normalize_audio', False):
            cmd.extend(['-af', 'loudnorm=I=-16:TP=-1.5:LRA=11'])
            
        cmd.extend([
            '-c:a', 'aac', '-b:a', '320k',
            '-shortest', '-movflags', '+faststart'
        ])
        
        # BUG-02: Asegurar que se incluya -progress pipe:1
        cmd.extend(['-progress', 'pipe:1'])
        cmd.append(output_video)
        
        self._run_ffmpeg_with_progress(cmd, timeline.total_audio_duration, encoder_desc, on_progress,
                                       cwd=subs['dir'] if subs else None)
        
        if not os.path.exists(output_video):
            raise RuntimeError("El archivo de video no se generó correctamente.")
            
        size_mb = round(os.path.getsize(output_video) / 1048576, 1)
        timestamps_path = None
        
        if export_timestamps:
            timestamps_path = output_video.replace('.mp4', '_timestamps.txt')
            try:
                with open(timestamps_path, 'w', encoding='utf-8') as f:
                    f.write(generate_timestamps_file_content(timeline))
            except Exception:
                pass
                
        try:
            if os.path.exists(concat_file):
                os.remove(concat_file)
        except Exception:
            pass
            
        return {
            'success': True,
            'video_path': output_video,
            'size_mb': size_mb,
            'timestamps_path': timestamps_path,
            'encoder_used': encoder_desc,
            'is_preview': opts.preview_mode if opts else False,
            'preview_duration': round(timeline.total_audio_duration, 1)
        }

    def _render_dynamic_pipeline(
        self,
        timeline: TimelineProject,
        audio_path: str,
        output_video: str,
        opts: RenderOptions,
        encoder_args: list,
        encoder_desc: str,
        on_progress: Optional[Callable],
        encoder_name: str = 'libx264'
    ) -> Dict[str, Any]:
        
        # ══ FRAME-ALIGNED TIMING (ACUMULADOR CORRIDO) ══
        # En vez de redondear cada clip individualmente (error se acumula),
        # calculamos el frame final acumulado y restamos el anterior.
        # Así el total de frames SIEMPRE coincide con la duración del audio.
        MAX_BATCH = 80
        total_clips = len(timeline.clips)
        clip_base_frames = []
        clip_has_tr = []
        clip_tr_frames = []
        
        accumulated_dur = 0.0
        prev_end_frame = 0
        
        for i in range(total_clips):
            base_dur = timeline.clips[i].duration
            accumulated_dur += base_dur
            end_frame = round(accumulated_dur * FPS)
            base_f = max(2, end_frame - prev_end_frame)
            prev_end_frame = end_frame
            clip_base_frames.append(base_f)
            
            # El primer clip de cada lote (i % MAX_BATCH == 0) es el input [0:v] de su lote.
            # No puede tener transición entrante dentro de su lote, por lo que debe tener
            # exactamente base_f frames (sin frames extra que inflen el video y desfasen el audio).
            is_batch_start = (i % MAX_BATCH == 0)
            has_tr = opts.enable_transitions and (total_clips > 1) and (not is_batch_start) and self._has_transition(i, opts.transition_frequency)
            clip_has_tr.append(has_tr)
            if has_tr:
                prev_dur = timeline.clips[i - 1].duration
                if base_dur < 2.0 or prev_dur < 2.0:
                    max_tr = min(opts.transition_duration, prev_dur * 0.15, base_dur * 0.15)
                else:
                    max_tr = min(opts.transition_duration, prev_dur * 0.35, base_dur * 0.35)
                tr_sec = max(0.067, max_tr)
                tr_f = max(2, round(tr_sec * FPS))
                tr_f = min(tr_f, base_f - 1)
                clip_tr_frames.append(tr_f)
            else:
                clip_tr_frames.append(0)

        with tempfile.TemporaryDirectory() as tmpdir:
            cpu_count = os.cpu_count() or 4
            max_workers = max(4, min(8, cpu_count))
            threads_per_worker = max(1, (cpu_count) // max_workers)
            running: Dict[int, Tuple[str, float]] = {}   # escena -> (archivo, hora de inicio)
            running_lock = threading.Lock()

            def _process_clip(i: int) -> Tuple[int, str]:
                if self.is_cancelled:
                    raise RuntimeError("Cancelado por el usuario.")
                
                clip_data = timeline.clips[i]
                has_tr = clip_has_tr[i]
                base_f = clip_base_frames[i]
                tr_f = clip_tr_frames[i]
                total_frames = base_f + (tr_f if has_tr else 0)
                actual_dur = total_frames / FPS
                
                clip_out = os.path.join(tmpdir, f"clip_{i:04d}.mp4")
                img_path = clip_data.image.full_path if clip_data.image else ""
                
                if opts.enable_camera_motion and not (clip_data.image and getattr(clip_data.image, 'is_video', False)):
                    motion = self._resolve_motion_type(opts.camera_motion_type, i)
                    vf = self._build_zoompan_filter(actual_dur, FPS, motion, opts.zoom_intensity)
                else:
                    vf = f"scale={W}:{H}:force_original_aspect_ratio=decrease,pad={W}:{H}:(ow-iw)/2:(oh-ih)/2:black,setsar=1"
                
                is_video_clip = bool(clip_data.image and getattr(clip_data.image, 'is_video', False))
                if is_video_clip:
                    cmd = self._build_video_clip_cmd(img_path, total_frames, threads_per_worker, clip_out, opts,
                                                     getattr(clip_data, 'keep_segments', None))
                else:
                    cmd = [
                        self.ffmpeg_exe, '-y',
                        '-threads', str(threads_per_worker),
                        '-loop', '1',
                        '-framerate', str(FPS),
                        '-i', img_path,
                        '-vf', vf,
                        '-frames:v', str(total_frames),
                        '-c:v', 'libx264',
                        '-preset', 'ultrafast',
                        '-crf', '22',
                        '-pix_fmt', 'yuv420p',
                        '-an', clip_out
                    ]
                
                startupinfo = None
                if os.name == 'nt':
                    startupinfo = subprocess.STARTUPINFO()
                    startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                    
                clip_label = clip_data.image.filename if clip_data.image else "(sin archivo)"
                timeout_s = 120 + actual_dur * 8
                t_clip = time.time()
                with running_lock:
                    running[i] = (clip_label, t_clip)
                _LOG.write(f"escena {i+1}/{total_clips} INICIO  archivo={clip_label}  duración={actual_dur:.2f}s  cuadros={total_frames}")
                _LOG.write(f"escena {i+1} comando: {' '.join(str(c) for c in cmd)}")
                try:
                    res = self._run_tracked(cmd, timeout=timeout_s, startupinfo=startupinfo)
                except subprocess.TimeoutExpired:
                    _LOG.write(f"escena {i+1} TIEMPO AGOTADO ({timeout_s:.0f}s)")
                    raise RuntimeError(
                        f"La escena {i+1} ({clip_label}) tardó más de {int(timeout_s)} segundos y se detuvo. "
                        f"Prueba con otro archivo en esa escena. Detalles en render_log.txt (carpeta de la app)."
                    )
                finally:
                    with running_lock:
                        running.pop(i, None)
                if self._abort or self.is_cancelled:
                    raise RuntimeError("Renderizado detenido.")
                if res.returncode != 0:
                    err_tail = res.stderr.decode('utf-8', errors='replace').strip()[-400:]
                    _LOG.write(f"escena {i+1} ERROR código {res.returncode}: {err_tail}")
                    raise RuntimeError(
                        f"Error generando la escena {i+1} ({clip_label}): {err_tail} "
                        f"(Detalles en render_log.txt, carpeta de la app)"
                    )
                _LOG.write(f"escena {i+1}/{total_clips} OK  ({time.time() - t_clip:.1f}s)")

                if i == 0 and opts.enable_intro_overlay and opts.intro_overlay_path and os.path.exists(opts.intro_overlay_path):
                    intro_ov_out = os.path.join(tmpdir, f"clip_{i:04d}_intro.mp4")
                    eff_dur = min(opts.intro_overlay_duration, actual_dur)
                    self._apply_overlay_to_clip(
                        clip_path=clip_out,
                        clip_duration=actual_dur,
                        overlay_path=opts.intro_overlay_path,
                        output_path=intro_ov_out,
                        overlay_type=opts.intro_overlay_type,
                        overlay_duration=eff_dur,
                        overlay_position=opts.intro_overlay_position,
                        chroma_similarity=opts.intro_chroma_similarity,
                        align='start',
                        threads=threads_per_worker
                    )
                    if os.path.exists(intro_ov_out) and os.path.getsize(intro_ov_out) > 0:
                        clip_out = intro_ov_out

                if i == total_clips - 1 and opts.enable_outro_overlay and opts.outro_overlay_path and os.path.exists(opts.outro_overlay_path):
                    outro_ov_out = os.path.join(tmpdir, f"clip_{i:04d}_outro.mp4")
                    eff_dur = min(opts.outro_overlay_duration, actual_dur)
                    self._apply_overlay_to_clip(
                        clip_path=clip_out,
                        clip_duration=actual_dur,
                        overlay_path=opts.outro_overlay_path,
                        output_path=outro_ov_out,
                        overlay_type=opts.outro_overlay_type,
                        overlay_duration=eff_dur,
                        overlay_position=opts.outro_overlay_position,
                        chroma_similarity=opts.outro_chroma_similarity,
                        align='end',
                        threads=threads_per_worker
                    )
                    if os.path.exists(outro_ov_out) and os.path.getsize(outro_ov_out) > 0:
                        clip_out = outro_ov_out

                return i, clip_out

            clip_paths_res = [None] * total_clips
            completed = 0

            # Antes: si una escena fallaba o se colgaba, el error quedaba oculto y el pool seguía
            # procesando TODAS las demás escenas sin avisar (la barra se quedaba congelada).
            # Ahora: al primer error se detienen las demás escenas y el error se muestra de inmediato,
            # y mientras se espera se informa qué escenas se están procesando y desde hace cuánto.
            executor = concurrent.futures.ThreadPoolExecutor(max_workers=max_workers)
            futures = {executor.submit(_process_clip, i): i for i in range(total_clips)}
            pending = set(futures)
            last_beat = time.time()
            try:
                while pending:
                    done, pending = concurrent.futures.wait(
                        pending, timeout=2.0, return_when=concurrent.futures.FIRST_COMPLETED)
                    if self.is_cancelled:
                        raise RuntimeError("Renderizado cancelado por el usuario.")
                    for fut in done:
                        idx, out_p = fut.result()   # si la escena falló, el error sale aquí mismo
                        clip_paths_res[idx] = out_p
                        completed += 1
                    pct = (completed / total_clips) * 70.0
                    now = time.time()
                    if done:
                        last_beat = now
                        if on_progress:
                            on_progress({
                                'percent': round(pct, 1),
                                'current_sec': (pct / 100.0) * timeline.total_audio_duration,
                                'total_sec': timeline.total_audio_duration,
                                'encoder_desc': f"Generando escenas animadas ({completed}/{total_clips})..."
                            })
                    elif on_progress and now - last_beat >= 5.0:
                        last_beat = now
                        with running_lock:
                            busy = sorted(running.items())
                        if busy:
                            slow = max(busy, key=lambda kv: now - kv[1][1])
                            detail = (f" · procesando escenas {', '.join(str(k + 1) for k, _ in busy[:8])}"
                                      f" · la más lenta: escena {slow[0] + 1} ({slow[1][0]}) {int(now - slow[1][1])} s")
                        else:
                            detail = ""
                        on_progress({
                            'percent': round(pct, 1),
                            'current_sec': (pct / 100.0) * timeline.total_audio_duration,
                            'total_sec': timeline.total_audio_duration,
                            'encoder_desc': f"Generando escenas animadas ({completed}/{total_clips}){detail}",
                            'heartbeat': True
                        })
            except BaseException as e:
                self._abort = True
                executor.shutdown(wait=False, cancel_futures=True)
                self._kill_all()
                _LOG.write(f"escenas detenidas por: {e}")
                raise
            executor.shutdown(wait=True)

            clip_paths = [p for p in clip_paths_res if p is not None]
            concatenated = os.path.join(tmpdir, "concatenated.mp4")
            
            use_xfade = opts.enable_transitions and (total_clips > 1) and any(clip_has_tr)
            
            if not use_xfade:
                concat_list = os.path.join(tmpdir, 'concat_list.txt')
                with open(concat_list, 'w', encoding='utf-8') as f:
                    for cp in clip_paths:
                        # BUG-03: Escapar comillas para concat demuxer format
                        safe_cp = cp.replace(chr(92), '/').replace("'", "'\\''")
                        f.write(f"file '{safe_cp}'\n")
                
                cmd_cat = [
                    self.ffmpeg_exe, '-y', '-f', 'concat', '-safe', '0',
                    '-i', concat_list, '-c', 'copy', concatenated
                ]
                res_cat = self._run_tracked(cmd_cat)
                if res_cat.returncode != 0:
                    raise RuntimeError("FFmpeg falló al unir las escenas: " + res_cat.stderr.decode('utf-8', errors='replace')[-400:])
            else:
                # --- ENSAMBLAJE POR LOTES ---
                # FFmpeg no puede abrir cientos de archivos a la vez (límite de decoders).
                # Procesamos en lotes de MAX_BATCH clips, luego concatenamos los lotes.
                MAX_BATCH = 80
                startupinfo = None
                if os.name == 'nt':
                    startupinfo = subprocess.STARTUPINFO()
                    startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW

                if total_clips <= MAX_BATCH:
                    batch_segments = [clip_paths]
                    batch_timelines = [timeline.clips]
                else:
                    batch_segments = []
                    batch_timelines = []
                    for start in range(0, total_clips, MAX_BATCH):
                        end = min(start + MAX_BATCH, total_clips)
                        batch_segments.append(clip_paths[start:end])
                        batch_timelines.append(timeline.clips[start:end])

                batch_outputs = []
                for bi, (b_paths, b_clips) in enumerate(
                    zip(batch_segments, batch_timelines)
                ):
                    if self.is_cancelled:
                        raise RuntimeError("Renderizado cancelado por el usuario.")

                    n = len(b_paths)
                    if n == 1:
                        batch_outputs.append(b_paths[0])
                        continue

                    # Construir inputs
                    inputs_args = []
                    for cp in b_paths:
                        inputs_args.extend(['-i', cp])

                    # ══ CONSTRUIR FILTER GRAPH CON FRAMES EXACTOS ══
                    # Usar aritmética de enteros (frames) para evitar drift flotante
                    filter_lines = []
                    current_label = "[0:v]"
                    
                    # Frames acumulados del clip 0 (entero, sin error)
                    acc_frames = clip_base_frames[bi * MAX_BATCH]

                    for i in range(1, n):
                        global_i = bi * MAX_BATCH + i
                        next_input = f"[{i}:v]"
                        next_label = f"[v{i}]" if i < n - 1 else "[outv]"

                        if clip_has_tr[global_i]:
                            tr_f = clip_tr_frames[global_i]
                            offset_frames = acc_frames - tr_f
                            if offset_frames < 0:
                                offset_frames = 0
                            # Convertir a segundos EXACTOS (múltiplo de 1/FPS)
                            offset_sec = offset_frames / FPS
                            tr_sec = tr_f / FPS
                            trans_name = self._resolve_transition_name(
                                opts.transition_style, global_i, opts.transition_pool
                            )
                            filter_lines.append(
                                f"{current_label}{next_input}xfade=transition={trans_name}:"
                                f"duration={tr_sec:.6f}:offset={offset_sec:.6f}{next_label}"
                            )
                        else:
                            filter_lines.append(
                                f"{current_label}{next_input}concat=n=2:v=1:a=0,"
                                f"settb=1/{FPS}{next_label}"
                            )

                        acc_frames += clip_base_frames[global_i]
                        current_label = next_label

                    # FIX: Usar -filter_complex directamente en vez de -filter_complex_script
                    filter_str = ";".join(filter_lines)
                    batch_out = os.path.join(tmpdir, f'batch_{bi}.mp4')

                    cmd_batch = [
                        self.ffmpeg_exe, '-y',
                        '-threads', '0'
                    ] + inputs_args + [
                        '-filter_complex', filter_str,
                        '-map', '[outv]',
                        '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20',
                        '-pix_fmt', 'yuv420p', '-an'
                    ]
                    batch_sec = sum(clip_base_frames[bi * MAX_BATCH: bi * MAX_BATCH + n]) / FPS
                    b_from = 70.0 + 22.0 * bi / len(batch_segments)
                    b_to = 70.0 + 22.0 * (bi + 1) / len(batch_segments)

                    _LOG.write(f"ETAPA: uniendo escenas con transiciones (lote {bi+1}/{len(batch_segments)}, {n} escenas)")
                    res_batch = self._run_tracked_progress(
                        cmd_batch, batch_out, batch_sec, b_from, b_to,
                        f"Uniendo escenas con transiciones (lote {bi+1}/{len(batch_segments)})",
                        timeline.total_audio_duration, on_progress, startupinfo=startupinfo)
                    if res_batch.returncode != 0:
                        if self.is_cancelled:
                            raise RuntimeError("Renderizado cancelado por el usuario.")
                        stderr_msg = res_batch.stderr.decode('utf-8', errors='replace') if res_batch.stderr else 'Sin detalle'
                        # Guardar error completo en archivo
                        err_log = os.path.join(os.path.expanduser('~'), 'Desktop', 'ffmpeg_error.txt')
                        try:
                            with open(err_log, 'w', encoding='utf-8') as ef:
                                ef.write(f"=== FFMPEG ERROR LOTE {bi+1} ===\n")
                                ef.write(f"Clips en lote: {n}\n")
                                ef.write(f"Filter length: {len(filter_str)} chars\n\n")
                                ef.write(stderr_msg)
                        except Exception:
                            pass
                        # Mostrar solo las últimas 15 líneas (el error real)
                        last_lines = stderr_msg.strip().split('\n')[-15:]
                        short_msg = '\n'.join(last_lines)
                        raise RuntimeError(f"FFmpeg falló en lote {bi+1} (ver ffmpeg_error.txt en Escritorio):\n{short_msg}")

                    batch_outputs.append(batch_out)

                # Si hay múltiples lotes, concatenarlos de forma exacta sin alterar los tiempos
                if len(batch_outputs) == 1:
                    if batch_outputs[0] != concatenated:
                        import shutil
                        shutil.copy2(batch_outputs[0], concatenated)
                else:
                    merge_list = os.path.join(tmpdir, 'merge_batches.txt')
                    with open(merge_list, 'w', encoding='utf-8') as f:
                        for bp in batch_outputs:
                            safe_path = bp.replace(chr(92), '/').replace("'", "'\\''")
                            f.write(f"file '{safe_path}'\n")
                    cmd_merge = [
                        self.ffmpeg_exe, '-y', '-f', 'concat', '-safe', '0',
                        '-i', merge_list, '-c', 'copy', concatenated
                    ]
                    res_merge = self._run_tracked(cmd_merge, startupinfo=startupinfo)
                    if res_merge.returncode != 0:
                        stderr_msg = res_merge.stderr.decode('utf-8', errors='replace') if res_merge.stderr else 'Sin detalle'
                        raise RuntimeError(f"FFmpeg falló al unir lotes:\n{stderr_msg}")
                    
            if on_progress:
                on_progress({
                    'percent': 92.0,
                    'current_sec': 0.92 * timeline.total_audio_duration,
                    'total_sec': timeline.total_audio_duration,
                    'encoder_desc': ("Agregando subtítulos y audio..." if getattr(self, '_subs', None)
                                     else "Mezclando audio de alta fidelidad...")
                })
                
            if self.is_cancelled:
                raise RuntimeError("Renderizado cancelado por el usuario.")
                
            cmd_mux = [
                self.ffmpeg_exe, '-y',
                '-i', concatenated
            ]
            if opts.preview_mode:
                cmd_mux.extend(['-t', f"{timeline.total_audio_duration:.3f}"])
            
            subs = getattr(self, '_subs', None)
            cmd_mux.extend([
                '-i', audio_path,
                '-map', '0:v:0', '-map', '1:a:0',
            ])
            if subs:
                # Se queman los subtítulos: hay que recodificar el video en este paso
                cmd_mux.extend(['-vf', subs['filter']] + self._subs_encoder_args(encoder_name, encoder_args))
            else:
                cmd_mux.extend(['-c:v', 'copy'])
            
            if opts.normalize_audio:
                cmd_mux.extend(['-af', 'loudnorm=I=-16:TP=-1.5:LRA=11'])
                
            cmd_mux.extend([
                '-c:a', 'aac', '-b:a', '320k',
                '-shortest', '-movflags', '+faststart'
            ])
            
            startupinfo = None
            if os.name == 'nt':
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                
            _LOG.write("ETAPA: mezclando el audio")
            res_mux = self._run_tracked_progress(
                cmd_mux, output_video, timeline.total_audio_duration, 92.0, 99.0,
                "Agregando subtítulos y audio" if subs else "Mezclando audio de alta fidelidad",
                timeline.total_audio_duration, on_progress,
                startupinfo=startupinfo, cwd=subs['dir'] if subs else None)
            if res_mux.returncode != 0:
                if self.is_cancelled:
                    raise RuntimeError("Renderizado cancelado por el usuario.")
                raise RuntimeError("FFmpeg falló al mezclar el audio: " + res_mux.stderr.decode('utf-8', errors='replace')[-400:])
            
            if on_progress:
                on_progress({
                    'percent': 100.0,
                    'current_sec': timeline.total_audio_duration,
                    'total_sec': timeline.total_audio_duration,
                    'encoder_desc': "¡Finalizado!"
                })
                
            size_mb = round(os.path.getsize(output_video) / 1048576, 1)
            timestamps_path = None
            
            if opts.export_timestamps and not opts.preview_mode:
                timestamps_path = output_video.replace('.mp4', '_timestamps.txt')
                try:
                    with open(timestamps_path, 'w', encoding='utf-8') as f:
                        f.write(generate_timestamps_file_content(timeline))
                except Exception:
                    pass
                    
            return {
                'success': True,
                'video_path': output_video,
                'size_mb': size_mb,
                'timestamps_path': timestamps_path,
                'encoder_used': encoder_desc + " + Ken Burns / Transiciones",
                'is_preview': opts.preview_mode,
                'preview_duration': round(timeline.total_audio_duration, 1)
            }

    def _run_tracked_progress(self, cmd, out_path, span_sec, pct_from, pct_to, desc, total_sec,
                              on_progress, startupinfo=None, cwd=None):
        """Ejecuta FFmpeg informando el avance real (-progress) entre pct_from y pct_to.
        Devuelve un CompletedProcess con stderr en bytes (igual que _run_tracked)."""
        if self._abort or self.is_cancelled:
            raise RuntimeError("Renderizado detenido.")
        full = _with_nostdin(list(cmd) + ['-progress', 'pipe:1', '-nostats', out_path])
        err_f = tempfile.TemporaryFile()
        p = subprocess.Popen(full, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=err_f,
                             startupinfo=startupinfo, universal_newlines=True, errors='ignore', cwd=cwd)
        with self._procs_lock:
            self._procs.add(p)
        span = span_sec if span_sec > 0 else 1.0
        last = 0.0
        try:
            for line in p.stdout:
                if self.is_cancelled:
                    p.kill()
                    break
                if line.startswith('out_time_us='):
                    try:
                        cur = int(line.split('=', 1)[1]) / 1e6
                    except ValueError:
                        continue
                    now = time.time()
                    if on_progress and now - last >= 1.0:
                        last = now
                        frac = min(1.0, max(0.0, cur / span))
                        pct = pct_from + (pct_to - pct_from) * frac
                        on_progress({
                            'percent': round(pct, 1),
                            'current_sec': pct / 100.0 * total_sec,
                            'total_sec': total_sec,
                            'encoder_desc': f"{desc} ({int(frac * 100)}%)"
                        })
            p.wait()
        finally:
            with self._procs_lock:
                self._procs.discard(p)
        err_f.seek(0)
        err = err_f.read()
        err_f.close()
        return subprocess.CompletedProcess(full, p.returncode, b'', err)

    def _run_ffmpeg_with_progress(
        self,
        cmd: list,
        total_sec: float,
        encoder_desc: str,
        on_progress: Optional[Callable],
        cwd: Optional[str] = None
    ):
        # Asegurar que incluya -progress pipe:1
        if '-progress' not in cmd:
            cmd.extend(['-progress', 'pipe:1'])
            
        startupinfo = None
        if os.name == 'nt':
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            
        stderr_file = tempfile.TemporaryFile(mode="w+", encoding="utf-8", errors="ignore")
        
        self.current_process = subprocess.Popen(
            _with_nostdin(cmd),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=stderr_file,
            universal_newlines=True,
            errors='ignore',
            startupinfo=startupinfo,
            cwd=cwd
        )
        
        safe_total = total_sec if total_sec > 0 else 1.0
        
        while True:
            if self.is_cancelled:
                if self.current_process:
                    try:
                        self.current_process.terminate()
                    except Exception:
                        pass
                raise RuntimeError("Renderizado cancelado por el usuario.")
                
            line = self.current_process.stdout.readline()
            if not line:
                break
                
            line = line.strip()
            if "=" in line:
                k, v = line.split("=", 1)
                if k == "out_time_us":
                    try:
                        cur_us = int(v)
                        cur_sec = cur_us / 1000000.0
                        percent = min(100.0, max(0.0, (cur_sec / safe_total) * 100.0))
                        if on_progress:
                            on_progress({
                                'percent': round(percent, 1),
                                'current_sec': cur_sec,
                                'total_sec': safe_total,
                                'encoder_desc': encoder_desc
                            })
                    except Exception:
                        pass
                elif k == "progress" and v == "end":
                    if on_progress:
                        on_progress({
                            'percent': 100.0,
                            'current_sec': safe_total,
                            'total_sec': safe_total,
                            'encoder_desc': encoder_desc
                        })
                        
        self.current_process.wait()
        
        if self.current_process.returncode != 0 and not self.is_cancelled:
            stderr_file.seek(0)
            err_msg = stderr_file.read()
            stderr_file.close()
            raise RuntimeError(f"Error en FFmpeg: {err_msg[:300]}")
            
        stderr_file.close()
        self.current_process = None
