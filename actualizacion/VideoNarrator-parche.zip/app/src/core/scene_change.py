"""
Cambios de escena (VideoNarrator v9.3).

Para "Fundido solo al cambiar de escena": compara el último cuadro de cada clip con el primero
del siguiente. Si cambian mucho los colores y la luz (otro lugar, de día a noche...), ahí va un
fundido corto; si sigue la misma conversación, corte directo.

Ajustado con un video de referencia (1,7 M de vistas): marca los cambios de lugar y deja en
corte directo los cambios de plano dentro del mismo lugar.
"""
import os
import subprocess
from concurrent.futures import ThreadPoolExecutor
from typing import List, Optional, Set

import numpy as np

_W, _H = 32, 56


def _startupinfo():
    if os.name == 'nt':
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        return si
    return None


def _grab(ff: str, path: str, t: Optional[float], from_end: bool = False) -> Optional[np.ndarray]:
    """Un cuadro diminuto (32x56, RGB). t=None para imágenes."""
    cmd = [ff, '-nostdin', '-v', 'error']
    if t is not None:
        if from_end:
            cmd += ['-sseof', '-0.25']
        else:
            cmd += ['-ss', f'{max(0.0, t):.3f}']
    cmd += ['-i', path, '-frames:v', '1', '-vf', f'scale={_W}:{_H},format=rgb24', '-f', 'rawvideo', '-']
    try:
        r = subprocess.run(cmd, stdin=subprocess.DEVNULL, capture_output=True, timeout=30, startupinfo=_startupinfo())
    except Exception:
        return None
    if r.returncode != 0 or len(r.stdout) < _W * _H * 3:
        return None
    return np.frombuffer(r.stdout[:_W * _H * 3], dtype=np.uint8).reshape(_H, _W, 3).astype(np.float32)


def _hsv(a: np.ndarray):
    a = a / 255.0
    mx, mn = a.max(2), a.min(2)
    d = mx - mn + 1e-6
    r, g, b = a[..., 0], a[..., 1], a[..., 2]
    h = np.where(mx == r, ((g - b) / d) % 6, np.where(mx == g, (b - r) / d + 2, (r - g) / d + 4)) / 6.0
    s = np.where(mx > 0, (mx - mn) / (mx + 1e-6), 0.0)
    return h, s, mx


def measure(a: np.ndarray, b: np.ndarray) -> dict:
    """Diferencias de luz (brillo) y de color entre dos cuadros."""
    ha, sa, va = _hsv(a)
    hb, sb, vb = _hsv(b)
    hh_a = np.histogram(ha, bins=12, range=(0, 1), weights=sa * va)[0]
    hh_b = np.histogram(hb, bins=12, range=(0, 1), weights=sb * vb)[0]
    hue = 0.5 * float(np.abs(hh_a / (hh_a.sum() + 1e-6) - hh_b / (hh_b.sum() + 1e-6)).sum())
    vh_a = np.histogram(va, bins=8, range=(0, 1))[0].astype(np.float32)
    vh_b = np.histogram(vb, bins=8, range=(0, 1))[0].astype(np.float32)
    val = 0.5 * float(np.abs(vh_a / vh_a.sum() - vh_b / vh_b.sum()).sum())
    dv = abs(float(va.mean()) - float(vb.mean()))
    return {'hue': hue, 'val': val, 'dv': dv}


def is_change(a: np.ndarray, b: np.ndarray, sensitivity: float = 1.0) -> bool:
    """Escena nueva: cambia mucho la luz (día/noche, interior/exterior) o cambian a la vez color y luz.
    Ajustado con el video de referencia: los cambios de plano dentro del mismo lugar quedan en corte directo."""
    m = measure(a, b)
    k = 1.0 / max(0.3, sensitivity)
    return m['val'] >= 0.45 * k or m['dv'] >= 0.20 * k or (m['hue'] >= 0.75 * k and m['val'] >= 0.30 * k)


def _ends(clip):
    """(ruta, segundo del primer cuadro, segundo del último cuadro o None = final del archivo)."""
    img = getattr(clip, 'image', None)
    if not img or not getattr(img, 'full_path', '') or not os.path.exists(img.full_path):
        return None
    if not getattr(img, 'is_video', False):
        return img.full_path, None, None
    segs = getattr(clip, 'keep_segments', None)
    if segs:
        return img.full_path, float(segs[0][0]) + 0.05, max(0.0, float(segs[-1][1]) - 0.12)
    return img.full_path, 0.05, max(0.0, float(clip.duration) - 0.12)


def detect(clips, ff: str, sensitivity: float = 1.0) -> Set[int]:
    """Índices i (desde 1) en los que empieza una escena nueva: fundido entre el clip i-1 y el i."""
    if not ff or len(clips) < 2:
        return set()
    ends = [_ends(c) for c in clips]

    def first(i):
        e = ends[i]
        return _grab(ff, e[0], e[1]) if e else None

    def last(i):
        e = ends[i]
        if not e:
            return None
        if e[1] is None:
            return _grab(ff, e[0], None)
        f = _grab(ff, e[0], e[2])
        return f if f is not None else _grab(ff, e[0], 0, from_end=True)

    with ThreadPoolExecutor(max_workers=8) as pool:
        firsts = list(pool.map(first, range(len(clips))))
        lasts = list(pool.map(last, range(len(clips))))
    out = set()
    for i in range(1, len(clips)):
        a, b = lasts[i - 1], firsts[i]
        if a is None or b is None:
            continue
        if ends[i - 1] and ends[i] and ends[i - 1][0] == ends[i][0]:
            continue                                   # partes del mismo video: misma escena
        if is_change(a, b, sensitivity):
            out.add(i)
    return out
