"""
Servidor local de medios para la vista previa (VideoNarrator v6.7).

La pantalla de la app no puede abrir archivos del disco directamente, así que este pequeño
servidor (solo en 127.0.0.1, puerto al azar) entrega los videos, audios e imágenes de la historia
al reproductor. Solo sirve archivos que la app registró antes (nunca cualquier ruta) y admite
"Range", que es lo que necesita el reproductor para saltar a cualquier segundo del video.
"""
import os
import re
import hashlib
import mimetypes
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import quote

_FILES = {}
_LOCK = threading.Lock()
_SERVER = None
_PORT = 0

TYPES = {'.mp4': 'video/mp4', '.m4v': 'video/mp4', '.mov': 'video/quicktime', '.webm': 'video/webm',
         '.mkv': 'video/x-matroska', '.avi': 'video/x-msvideo', '.mp3': 'audio/mpeg', '.wav': 'audio/wav',
         '.m4a': 'audio/mp4', '.aac': 'audio/aac', '.ogg': 'audio/ogg', '.opus': 'audio/ogg',
         '.flac': 'audio/flac', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
         '.webp': 'image/webp', '.gif': 'image/gif', '.bmp': 'image/bmp'}


class _Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def log_message(self, *a):
        pass

    def _path(self):
        m = re.match(r'^/m/([0-9a-f]{24})(?:/[^?]*)?', self.path)
        if not m:
            return None
        with _LOCK:
            return _FILES.get(m.group(1))

    def do_HEAD(self):
        self._serve(head=True)

    def do_GET(self):
        self._serve(head=False)

    def _serve(self, head):
        path = self._path()
        if not path or not os.path.isfile(path):
            self.send_response(404)
            self.send_header('Content-Length', '0')
            self.end_headers()
            return
        size = os.path.getsize(path)
        ctype = TYPES.get(os.path.splitext(path)[1].lower()) or mimetypes.guess_type(path)[0] or 'application/octet-stream'
        start, end = 0, size - 1
        rng = self.headers.get('Range')
        status = 200
        if rng:
            m = re.match(r'bytes=(\d*)-(\d*)', rng)
            if m:
                if m.group(1):
                    start = int(m.group(1))
                    if m.group(2):
                        end = min(int(m.group(2)), size - 1)
                elif m.group(2):                       # últimos N bytes
                    start = max(0, size - int(m.group(2)))
                if start > end or start >= size:
                    self.send_response(416)
                    self.send_header('Content-Range', f'bytes */{size}')
                    self.send_header('Content-Length', '0')
                    self.end_headers()
                    return
                status = 206
        length = end - start + 1
        self.send_response(status)
        self.send_header('Content-Type', ctype)
        self.send_header('Accept-Ranges', 'bytes')
        self.send_header('Content-Length', str(length))
        self.send_header('Cache-Control', 'no-cache')
        self.send_header('Access-Control-Allow-Origin', '*')
        if status == 206:
            self.send_header('Content-Range', f'bytes {start}-{end}/{size}')
        self.end_headers()
        if head:
            return
        try:
            with open(path, 'rb') as fh:
                fh.seek(start)
                left = length
                while left > 0:
                    chunk = fh.read(min(256 * 1024, left))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    left -= len(chunk)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
            pass                                        # el reproductor cortó la descarga (normal al saltar)


def _ensure():
    global _SERVER, _PORT
    if _SERVER is not None:
        return _PORT
    srv = ThreadingHTTPServer(('127.0.0.1', 0), _Handler)
    srv.daemon_threads = True
    _PORT = srv.server_address[1]
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    _SERVER = srv
    return _PORT


def url_for(path: str) -> str:
    """URL local (http://127.0.0.1:puerto/m/…) para un archivo de la historia; '' si no existe."""
    if not path or not os.path.isfile(path):
        return ''
    path = os.path.abspath(path)
    token = hashlib.sha1(path.encode('utf-8', 'surrogatepass')).hexdigest()[:24]
    with _LOCK:
        _FILES[token] = path
    port = _ensure()
    try:   # v8.7: si el archivo cambia (escena reemplazada), cambia la dirección y no se usa la copia vieja
        ver = f"?v={int(os.path.getmtime(path))}-{os.path.getsize(path)}"
    except OSError:
        ver = ''
    return f'http://127.0.0.1:{port}/m/{token}/{quote(os.path.basename(path))}{ver}'


def path_for(url: str) -> str:
    """Ruta del archivo detrás de una URL de url_for() ('' si no es nuestra)."""
    m = re.search(r'/m/([0-9a-f]{24})', url or '')
    if not m:
        return ''
    with _LOCK:
        return _FILES.get(m.group(1), '')


_PEAKS = {}
PEAKS_PER_SEC = 20


def peaks(path: str, ffmpeg_exe: str):
    """Forma de onda del audio de un archivo: 20 valores (0-100) por segundo. Se recuerda por archivo."""
    import subprocess
    import array
    try:
        st = os.stat(path)
    except OSError:
        return []
    key = (path, st.st_size, int(st.st_mtime))
    if key in _PEAKS:
        return _PEAKS[key]
    si = None
    if os.name == 'nt':
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    try:
        r = subprocess.run([ffmpeg_exe, '-nostdin', '-v', 'error', '-i', path, '-vn', '-ac', '1', '-ar', '2000',
                            '-f', 's16le', '-'], stdin=subprocess.DEVNULL, capture_output=True, timeout=60, startupinfo=si)
        data = array.array('h')
        data.frombytes(r.stdout[:len(r.stdout) // 2 * 2])
    except Exception:
        return []
    win = 2000 // PEAKS_PER_SEC
    out = []
    for i in range(0, len(data), win):
        chunk = data[i:i + win]
        if not chunk:
            break
        m = max(abs(min(chunk)), abs(max(chunk)))
        out.append(min(100, int(round((m / 32768.0) ** 0.6 * 100))))
    if len(_PEAKS) > 400:
        _PEAKS.clear()
    _PEAKS[key] = out
    return out
