"""
Subtítulos automáticos estilo CapCut (VideoNarrator v4.0).

Flujo:
  1. Tiempos por palabra: faster-whisper (word_timestamps) sobre el AUDIO FINAL del video.
     Las palabras se toman del GUION (sin errores de transcripción en nombres propios) y Whisper
     solo aporta cuándo se dice cada una. Sin Whisper: reparto proporcional dentro de cada escena.
  2. Las palabras se agrupan en frases cortas según la plantilla.
  3. Se genera un archivo .ass (libass) que FFmpeg "quema" sobre el video.

Todas las plantillas usan UN SOLO color de acento en todo el video (el que elige el usuario).
"""
import os
import re
import shutil
import difflib
import threading
import unicodedata
from dataclasses import dataclass
from typing import List, Optional, Dict, Any, Callable

# Las fuentes viven dentro de src/ui para que la interfaz (servida desde esa carpeta) también las cargue
FONTS_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'ui', 'fonts')


# ─────────────────────────────── Plantillas ───────────────────────────────
# size: tamaño base para un video vertical de 1080 px de ancho.
TEMPLATES: Dict[str, Dict[str, Any]] = {
    'karaoke': dict(
        name='Karaoke viral', font='Poppins', bold=True, italic=False, size=96, upper=True,
        max_words=3, max_chars=20, outline=7, shadow=3, pos='bottom', mode='karaoke', box=False),
    'palabra': dict(
        name='Palabra por palabra', font='Big Shoulders', bold=True, italic=False, size=150, upper=True,
        max_words=1, max_chars=30, outline=8, shadow=4, pos='center', mode='palabra', box=False),
    'destacado': dict(
        name='Destacado', font='Poppins', bold=True, italic=False, size=100, upper=True,
        max_words=4, max_chars=22, outline=7, shadow=3, pos='center', mode='destacado', box=False),
    'caja': dict(
        name='Clásico con caja', font='Poppins', bold=False, italic=False, size=62, upper=False,
        max_words=7, max_chars=34, outline=16, shadow=0, pos='bottom', mode='caja', box=True),
    'elegante': dict(
        name='Elegante (reflexión)', font='Lora', bold=False, italic=True, size=90, upper=False,
        max_words=7, max_chars=34, outline=2, shadow=4, pos='bottom', mode='elegante', box=False),
}

SIZE_FACTORS = {'small': 0.82, 'medium': 1.0, 'large': 1.2}


@dataclass
class Word:
    text: str
    start: float
    end: float
    clip: int


# ─────────────────────────────── Utilidades ───────────────────────────────
def _norm(text: str) -> str:
    t = unicodedata.normalize('NFD', (text or '').lower())
    t = ''.join(c for c in t if unicodedata.category(c) != 'Mn')
    return re.sub(r'[^a-z0-9ñ]', '', t)


def _hex_to_ass(color: str, alpha: int = 0) -> str:
    """'#RRGGBB' -> '&HAABBGGRR' (formato de color de ASS)."""
    c = (color or '#FFC845').strip().lstrip('#')
    if not re.fullmatch(r'[0-9a-fA-F]{6}', c):
        c = 'FFC845'
    r, g, b = c[0:2], c[2:4], c[4:6]
    return f"&H{alpha:02X}{b}{g}{r}".upper()


def _ass_time(t: float) -> str:
    t = max(0.0, t)
    cs = int(round(t * 100))
    h, cs = divmod(cs, 360000)
    m, cs = divmod(cs, 6000)
    s, cs = divmod(cs, 100)
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"


def _srt_time(t: float) -> str:
    ms = int(round(max(0.0, t) * 1000))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def _esc(text: str) -> str:
    # Llaves y barra invertida tienen significado especial en ASS
    return text.replace('\\', '/').replace('{', '(').replace('}', ')')


_STRIP_EDGES = '.,;:"“”«»…—–-\''


def _display(word: str, upper: bool) -> str:
    """Texto de cada palabra en pantalla. En las plantillas en MAYÚSCULAS se quitan
    comas y puntos (estilo CapCut); se conservan ¿? ¡!."""
    w = word.strip()
    if upper:
        w = w.strip(_STRIP_EDGES) or w
        return w.upper()
    return w


def _ends_sentence(word: str) -> bool:
    return bool(re.search(r'[.!?…;:]["”»)]*$', word))


def _ends_clause(word: str) -> bool:
    return bool(re.search(r'[,]["”»)]*$', word))


# ───────────────────────────── Whisper (palabras) ─────────────────────────────
_MODEL = None
_MODEL_LOCK = threading.Lock()


LAST_REASON = ''          # v8.8: por qué no se usó Whisper la última vez ('' = se usó)


def _note(reason: str) -> None:
    global LAST_REASON
    LAST_REASON = reason
    try:
        from src.utils.inicio import log
        log('whisper: ' + reason)
    except Exception:
        pass


def whisper_available() -> bool:
    try:
        import faster_whisper  # noqa: F401
        return True
    except Exception:
        return False


def _prepare_downloads() -> str:
    """Certificados para descargar el modelo y carpeta propia (siempre escribible) para guardarlo."""
    try:
        from src.utils.net import CA_FILE
        if CA_FILE and os.path.exists(CA_FILE):
            os.environ.setdefault('REQUESTS_CA_BUNDLE', CA_FILE)
            os.environ.setdefault('SSL_CERT_FILE', CA_FILE)
            os.environ.setdefault('CURL_CA_BUNDLE', CA_FILE)
    except Exception:
        pass
    os.environ.setdefault('HF_HUB_DISABLE_SYMLINKS_WARNING', '1')
    os.environ.setdefault('HF_HUB_DISABLE_TELEMETRY', '1')
    try:
        from src.utils.paths import data_dir
        d = os.path.join(data_dir(), 'whisper')
        os.makedirs(d, exist_ok=True)
        return d
    except Exception:
        return ''


def load_model():
    """Modelo de Whisper compartido ('small'; si no se puede, 'base'). None si no hay forma."""
    global _MODEL
    try:
        from faster_whisper import WhisperModel
    except Exception as e:
        _note(f'no_instalado: {type(e).__name__}: {e}')
        return None
    with _MODEL_LOCK:
        if _MODEL is not None:
            return _MODEL
        root = _prepare_downloads()
        errors = []
        for size in ('small', 'base'):
            try:
                kw = dict(device='cpu', compute_type='int8')
                if root:
                    kw['download_root'] = root
                _MODEL = WhisperModel(size, **kw)
                _note(f'modelo {size} listo')
                globals()['LAST_REASON'] = ''
                return _MODEL
            except Exception as e:
                errors.append(f'{size}: {type(e).__name__}: {str(e)[:200]}')
        _note('sin_modelo: ' + ' | '.join(errors))
        return None


def transcribe_words(audio_path: str, language: Optional[str] = None) -> Optional[List[Word]]:
    """Palabras con tiempos (en segundos del audio). None si Whisper no está disponible o falla."""
    if not audio_path or not os.path.exists(audio_path):
        _note('sin_audio')
        return None
    try:
        model = load_model()
        if model is None:
            return None
        kwargs = dict(word_timestamps=True)
        if language:
            kwargs['language'] = language
        segments, _info = model.transcribe(audio_path, **kwargs)
        words: List[Word] = []
        for seg in segments:
            for w in (seg.words or []):
                raw = (w.word or '').strip()
                if raw and w.end is not None and w.start is not None:
                    words.append(Word(raw, float(w.start), float(w.end), -1))
        if not words:
            _note('sin_palabras: Whisper no reconoció voz en el audio')
        return words or None
    except Exception as e:
        _note(f'error: {type(e).__name__}: {str(e)[:200]}')
        return None


# ─────────────────────── Alineación guion ↔ tiempos ───────────────────────
def _spread(tokens: List[str], t0: float, t1: float) -> List[tuple]:
    """Reparte palabras entre t0 y t1 proporcionalmente a su largo."""
    if not tokens:
        return []
    t1 = max(t1, t0 + 0.05 * len(tokens))
    weights = [len(_norm(t)) + 2 for t in tokens]
    total = float(sum(weights))
    out, t = [], t0
    for tok, w in zip(tokens, weights):
        d = (t1 - t0) * w / total
        out.append((tok, t, t + d))
        t += d
    return out


def _align_clip(tokens: List[str], heard: List[Word], st: float, en: float) -> List[tuple]:
    """Tiempos para las palabras del guion de UNA escena usando lo que Whisper oyó en esa escena."""
    if not heard:
        # Sin Whisper: toda la escena es voz (las escenas ya están cortadas a la medida de la voz)
        pad = min(0.15, (en - st) * 0.05)
        return _spread(tokens, st + pad, en - pad)

    a = [_norm(t) for t in tokens]
    b = [_norm(w.text) for w in heard]
    anchors: Dict[int, Word] = {}
    for blk in difflib.SequenceMatcher(None, a, b, autojunk=False).get_matching_blocks():
        for k in range(blk.size):
            if blk.size == 1 and len(a[blk.a]) <= 2:
                continue   # una palabrita suelta (de, la, y) no sirve de ancla
            anchors[blk.a + k] = heard[blk.b + k]

    speech_start = heard[0].start
    speech_end = heard[-1].end
    result: List[Optional[tuple]] = [None] * len(tokens)
    for i, w in anchors.items():
        result[i] = (tokens[i], w.start, w.end)

    # Tramos sin ancla: se reparten en el hueco entre las anclas vecinas
    i = 0
    while i < len(tokens):
        if result[i] is not None:
            i += 1
            continue
        j = i
        while j < len(tokens) and result[j] is None:
            j += 1
        t0 = result[i - 1][2] if i > 0 else speech_start
        t1 = result[j][1] if j < len(tokens) else speech_end
        if t1 - t0 < 0.08 * (j - i):          # sin espacio: se toma un poco de cada lado
            t0 = max(st, t0 - 0.04 * (j - i))
            t1 = min(en, t1 + 0.04 * (j - i))
        for k, item in enumerate(_spread(tokens[i:j], t0, t1)):
            result[i + k] = item
        i = j

    # Monótono y dentro de la escena
    fixed, last = [], st
    for tok, s, e in result:
        s = min(max(s, last, st), en)
        e = min(max(e, s + 0.04), en)
        fixed.append((tok, s, e))
        last = s
    return fixed


def collect_words(timeline, heard: Optional[List[Word]]) -> List[Word]:
    """Lista de palabras (texto del guion + tiempos) de todo el video."""
    heard = heard or []
    words: List[Word] = []
    for ci, c in enumerate(timeline.clips):
        st, en = float(c.start_time), float(c.end_time)
        if en <= st:
            continue
        text = (getattr(c, 'text', '') or '').strip()
        # Sin guion (modo libre) el "texto" es el nombre del archivo: no se usa
        if c.image is not None and text in (c.image.filename, os.path.splitext(c.image.filename)[0]):
            text = ''
        in_clip = [w for w in heard if st - 0.08 <= (w.start + w.end) / 2.0 < en + 0.08]
        tokens = text.split()
        if tokens:
            timed = _align_clip(tokens, in_clip, st, en)
        elif in_clip:
            timed = [(w.text, max(st, w.start), min(en, w.end)) for w in in_clip]
        else:
            continue
        words.extend(Word(t, s, e, ci) for t, s, e in timed)
    return words


# ─────────────────────────────── Frases ───────────────────────────────
def build_chunks(words: List[Word], tpl: Dict[str, Any]) -> List[List[Word]]:
    max_w, max_c, upper = tpl['max_words'], tpl['max_chars'], tpl['upper']
    chunks: List[List[Word]] = []
    cur: List[Word] = []
    for w in words:
        if cur:
            prev = cur[-1]
            chars = sum(len(_display(x.text, upper)) + 1 for x in cur) + len(_display(w.text, upper))
            if (w.clip != prev.clip or len(cur) >= max_w or chars > max_c
                    or w.start - prev.end > 0.6 or _ends_sentence(prev.text)
                    or (_ends_clause(prev.text) and len(cur) >= 2)):
                chunks.append(cur)
                cur = []
        cur.append(w)
    if cur:
        chunks.append(cur)
    return chunks


def _chunk_times(chunks: List[List[Word]]) -> List[tuple]:
    """(inicio, fin) de cada frase en pantalla, sin solaparse."""
    times = []
    for k, ch in enumerate(chunks):
        s = ch[0].start
        e = max(ch[-1].end + 0.25, s + 0.3)          # se queda un poco tras la última palabra
        if k + 1 < len(chunks):
            e = min(e, chunks[k + 1][0].start)        # nunca encima de la siguiente frase
        times.append((s, max(e, s + 0.05)))
    return times


# ─────────────────────────────── Archivo ASS ───────────────────────────────
def build_ass(chunks: List[List[Word]], tpl: Dict[str, Any], W: int, H: int, accent: str,
              position: str = 'auto', size: str = 'medium') -> str:
    vertical = H > W
    scale = (min(W, H) / 1080.0) * SIZE_FACTORS.get(size, 1.0)
    fs = int(round(tpl['size'] * scale))
    pos = tpl['pos'] if position in ('', 'auto', None) else position
    if pos == 'top':
        align, mv = 8, int(H * (0.13 if vertical else 0.08))
    elif pos == 'center':
        align, mv = 5, 0
    else:
        align, mv = 2, int(H * (0.22 if vertical else 0.09))
    ml = int(W * 0.08)

    ACC = _hex_to_ass(accent)
    WHITE = '&H00FFFFFF'
    mode = tpl['mode']
    primary = ACC if mode in ('palabra', 'elegante') else WHITE
    if tpl['box']:
        border_style, outline_col, back_col = 3, '&H59000000', '&H00000000'   # caja negra ~65 %
    else:
        border_style, outline_col = 1, ('&H50000000' if mode == 'elegante' else '&H00000000')
        back_col = '&H90000000' if mode == 'elegante' else '&H80000000'
    bold = -1 if tpl['bold'] else 0
    italic = -1 if tpl['italic'] else 0
    outline = max(1, int(round(tpl['outline'] * scale)))
    shadow = int(round(tpl['shadow'] * scale))

    lines = [
        "[Script Info]",
        "; VideoNarrator v4.0 - subtítulos automáticos",
        "ScriptType: v4.00+",
        f"PlayResX: {W}",
        f"PlayResY: {H}",
        "WrapStyle: 0",
        "ScaledBorderAndShadow: yes",
        "YCbCr Matrix: TV.709",
        "",
        "[V4+ Styles]",
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, "
        "Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, "
        "Alignment, MarginL, MarginR, MarginV, Encoding",
        f"Style: VN,{tpl['font']},{fs},{primary},{ACC},{outline_col},{back_col},{bold},{italic},0,0,"
        f"100,100,{1 if tpl['upper'] else 0},0,{border_style},{outline},{shadow},{align},{ml},{ml},{mv},1",
    ]
    if tpl['box']:
        # La caja va en una capa (texto invisible, una sola caja por línea) y el texto encima en otra:
        # así el cambio de color de la palabra no corta la caja en pedazos.
        lines.append(
            f"Style: VNTXT,{tpl['font']},{fs},{WHITE},{ACC},&H00000000,&H00000000,{bold},{italic},0,0,"
            f"100,100,0,0,1,0,0,{align},{ml},{ml},{mv},1")
    lines += [
        "",
        "[Events]",
        "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text",
    ]
    upper = tpl['upper']
    times = _chunk_times(chunks)

    def ev(s, e, text, style='VN', layer=0):
        if e - s >= 0.02:
            lines.append(f"Dialogue: {layer},{_ass_time(s)},{_ass_time(e)},{style},,0,0,0,,{text}")

    for ch, (cs, ce) in zip(chunks, times):
        disp = [_esc(_display(w.text, upper)) for w in ch]
        if mode in ('karaoke', 'caja'):
            # Una línea por palabra: la palabra que se está diciendo va en el color de acento
            for i, w in enumerate(ch):
                s = cs if i == 0 else w.start
                e = ch[i + 1].start if i + 1 < len(ch) else ce
                parts = []
                for k, d in enumerate(disp):
                    if k == i:
                        pop = "\\fscx108\\fscy108" if mode == 'karaoke' else ""
                        parts.append(f"{{\\c{ACC}{pop}}}{d}{{\\c{WHITE}\\fscx100\\fscy100}}")
                    else:
                        parts.append(d)
                intro = "{\\fscx92\\fscy92\\t(0,90,\\fscx100\\fscy100)}" if (i == 0 and mode == 'karaoke') else ""
                if mode == 'caja':
                    ev(s, e, "{\\1a&HFF&}" + " ".join(disp), 'VN', 0)       # solo la caja
                    ev(s, e, " ".join(parts), 'VNTXT', 1)                   # el texto encima
                else:
                    ev(s, e, intro + " ".join(parts))
        elif mode == 'palabra':
            for i, w in enumerate(ch):
                s = cs if i == 0 else w.start
                e = ch[i + 1].start if i + 1 < len(ch) else ce
                ev(s, e, "{\\fscx65\\fscy65\\t(0,80,\\fscx108\\fscy108)\\t(80,150,\\fscx100\\fscy100)}" + disp[i])
        elif mode == 'destacado':
            # La palabra más importante (la más larga) de cada frase va en el color de acento
            key = max(range(len(ch)), key=lambda k: len(_norm(ch[k].text))) if ch else 0
            if len(_norm(ch[key].text)) < 4 and len(ch) > 1:
                key = -1
            parts = [(f"{{\\c{ACC}\\fscx112\\fscy112}}{d}{{\\c{WHITE}\\fscx100\\fscy100}}" if k == key else d)
                     for k, d in enumerate(disp)]
            ev(cs, ce, "{\\fscx85\\fscy85\\t(0,110,\\fscx100\\fscy100)}" + " ".join(parts))
        else:  # elegante
            fin = min(260, int((ce - cs) * 1000 / 3))
            fout = min(200, int((ce - cs) * 1000 / 4))
            ev(cs, ce, f"{{\\fad({fin},{fout})\\blur1.5}}" + " ".join(disp))

    return "\n".join(lines) + "\n"


def build_srt(chunks: List[List[Word]]) -> str:
    out = []
    for n, (ch, (s, e)) in enumerate(zip(chunks, _chunk_times(chunks)), 1):
        out.append(f"{n}\n{_srt_time(s)} --> {_srt_time(e)}\n{' '.join(w.text for w in ch)}\n")
    return "\n".join(out)


# ─────────────────────────────── Preparación ───────────────────────────────
def prepare_subtitles(timeline, audio_path: str, work_dir: str, W: int, H: int,
                      template: str = 'karaoke', accent: str = '#FFC845', position: str = 'auto',
                      size: str = 'medium', heard: Optional[List[Word]] = None,
                      log: Optional[Callable[[str], None]] = None) -> Dict[str, Any]:
    """
    Genera work_dir/subs.ass y copia las fuentes a work_dir/fonts.
    FFmpeg debe ejecutarse con cwd=work_dir y el filtro 'ass=subs.ass:fontsdir=fonts'
    (rutas relativas: evitan los problemas de escapar 'C:\\...' dentro de un filtro en Windows).
    """
    tpl = TEMPLATES.get(template) or TEMPLATES['karaoke']
    source = 'whisper'
    if heard is None:
        heard = transcribe_words(audio_path)
    if not heard:
        source = 'guion'
        heard = []
    words = collect_words(timeline, heard)
    chunks = build_chunks(words, tpl)

    os.makedirs(work_dir, exist_ok=True)
    fonts_dst = os.path.join(work_dir, 'fonts')
    os.makedirs(fonts_dst, exist_ok=True)
    if os.path.isdir(FONTS_DIR):
        for f in os.listdir(FONTS_DIR):
            if f.lower().endswith(('.ttf', '.otf')):
                shutil.copy2(os.path.join(FONTS_DIR, f), os.path.join(fonts_dst, f))

    with open(os.path.join(work_dir, 'subs.ass'), 'w', encoding='utf-8-sig') as fh:
        fh.write(build_ass(chunks, tpl, W, H, accent, position, size))
    if log:
        log(f"subtítulos: plantilla={template} color={accent} palabras={len(words)} frases={len(chunks)} "
            f"tiempos={'Whisper' if source == 'whisper' else 'reparto por escena (sin Whisper: ' + (LAST_REASON or '?') + ')'}")
    return {
        'dir': work_dir,
        'filter': 'ass=subs.ass:fontsdir=fonts',
        'srt': build_srt(build_chunks(words, TEMPLATES['caja'])),   # frases completas para YouTube
        'source': source,
        'reason': '' if source == 'whisper' else (LAST_REASON or 'sin_motivo'),
        'words': len(words),
        'chunks': len(chunks),
    }
