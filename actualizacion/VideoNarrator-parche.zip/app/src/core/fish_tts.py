"""
Voz del narrador generada con Fish Audio (VideoNarrator v6.1).

Usa la cuenta de Fish Audio del propio usuario (su clave de API y su saldo):
  POST https://api.fish.audio/v1/tts            -> audio MP3 de una línea
  GET  https://api.fish.audio/model?self=true    -> sus voces
  GET  https://api.fish.audio/model/{id}         -> datos de una voz (pegando su enlace o ID)
  GET  https://api.fish.audio/wallet/self/api-credit -> saldo

Cada línea del narrador se guarda como NN_fish.mp3 en una carpeta "voz_fish" junto al material
del proyecto, y se asigna a su escena. Si el texto, la voz, el modelo y la velocidad no cambiaron,
no se vuelve a generar (no gasta saldo).
"""
import os
import re
import json
import base64
import hashlib
import urllib.error
import urllib.parse
import urllib.request
from typing import Callable, Dict, List, Optional

API = 'https://api.fish.audio'
MODELS = ('s2.1-pro', 's2-pro', 's1')
DEFAULTS = {'voice_id': '', 'voice_name': '', 'model': 's2.1-pro', 'speed': 1.0}

ERRORS = {
    401: 'La clave de API de Fish Audio no es válida. Revísala en fish.audio > API Keys.',
    402: 'Tu cuenta de Fish Audio no tiene saldo suficiente. Recárgala en fish.audio.',
    404: 'No se encontró esa voz (o es privada de otra persona).',
    422: 'Fish Audio rechazó el texto o una opción. Prueba con otra velocidad o modelo.',
    429: 'Fish Audio está recibiendo demasiadas solicitudes. Espera un momento e inténtalo de nuevo.',
}


class FishError(Exception):
    pass


# ── Configuración (la clave se guarda cifrada con la cuenta de Windows) ─────
def _cfg_path() -> str:
    from src.utils.paths import data_dir
    return os.path.join(data_dir(), 'fish_audio.json')


def load_config() -> Dict:
    from src.core.auth import _dpapi
    cfg = dict(DEFAULTS)
    cfg['api_key'] = ''
    try:
        with open(_cfg_path(), 'r', encoding='utf-8') as fh:
            data = json.load(fh) or {}
    except Exception:
        data = {}
    for k in DEFAULTS:
        if k in data:
            cfg[k] = data[k]
    enc = data.get('api_key_enc') or ''
    if enc:
        try:
            raw = base64.b64decode(enc)
            if data.get('modo') == 'dpapi':
                raw = _dpapi(raw, False) or b''
            cfg['api_key'] = raw.decode('utf-8')
        except Exception:
            cfg['api_key'] = ''
    if cfg.get('model') not in MODELS:
        cfg['model'] = DEFAULTS['model']
    try:
        cfg['speed'] = min(2.0, max(0.5, float(cfg.get('speed') or 1.0)))
    except (TypeError, ValueError):
        cfg['speed'] = 1.0
    return cfg


def save_config(changes: Dict) -> Dict:
    from src.core.auth import _dpapi
    cur = load_config()
    for k in ('voice_id', 'voice_name', 'model', 'speed', 'api_key'):
        if k in changes and changes[k] is not None:
            cur[k] = changes[k]
    key = str(cur.pop('api_key') or '').strip()
    enc = _dpapi(key.encode('utf-8'), True) if key else None
    data = {k: cur[k] for k in DEFAULTS}
    data['modo'] = 'dpapi' if enc else 'b64'
    data['api_key_enc'] = base64.b64encode(enc or key.encode('utf-8')).decode('ascii') if key else ''
    with open(_cfg_path(), 'w', encoding='utf-8') as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
    return public_config()


def public_config() -> Dict:
    cfg = load_config()
    key = cfg.pop('api_key')
    cfg['has_key'] = bool(key)
    cfg['key_hint'] = ('…' + key[-4:]) if len(key) >= 8 else ''
    return cfg


# ── Llamadas a la API ───────────────────────────────────────────────────────
def _request(method: str, path: str, key: str, body: Optional[Dict] = None, headers: Optional[Dict] = None,
             timeout: float = 30.0, raw: bool = False):
    from src.utils.net import urlopen
    h = {'Authorization': 'Bearer ' + key, 'User-Agent': 'VideoNarrator'}
    data = None
    if body is not None:
        data = json.dumps(body).encode('utf-8')
        h['Content-Type'] = 'application/json'
    h.update(headers or {})
    req = urllib.request.Request(API + path, data=data, headers=h, method=method)
    try:
        with urlopen(req, timeout=timeout) as r:
            payload = r.read()
    except urllib.error.HTTPError as e:
        detail = ''
        try:
            detail = e.read().decode('utf-8', 'replace')[:300]
        except Exception:
            pass
        raise FishError(ERRORS.get(e.code, f'Fish Audio respondió con un error ({e.code}). {detail}'))
    except Exception as e:
        from src.utils.net import friendly_error
        raise FishError(friendly_error(e))
    if raw:
        return payload
    try:
        return json.loads(payload.decode('utf-8') or '{}')
    except Exception:
        return {}


def _key_or_error() -> str:
    key = load_config().get('api_key') or ''
    if not key:
        raise FishError('Falta tu clave de API de Fish Audio.')
    return key


def balance() -> Dict:
    data = _request('GET', '/wallet/self/api-credit', _key_or_error(), timeout=15)
    try:
        return {'credit': round(float(data.get('credit')), 2)}
    except (TypeError, ValueError):
        return {'credit': None}


def my_voices() -> List[Dict]:
    data = _request('GET', '/model?self=true&page_size=50&page_number=1', _key_or_error(), timeout=20)
    out = []
    for it in data.get('items') or []:
        if it.get('_id'):
            out.append({'id': it['_id'], 'title': it.get('title') or 'Voz sin nombre', 'state': it.get('state') or ''})
    return out


def voice_id_from(text: str) -> str:
    """Acepta el ID o un enlace como https://fish.audio/es/m/<id>/"""
    text = (text or '').strip()
    m = re.search(r'/m/([0-9a-fA-F]{24,40})', text) or re.fullmatch(r'([0-9a-fA-F]{24,40})', text)
    return m.group(1).lower() if m else ''


def voice_info(text: str) -> Dict:
    vid = voice_id_from(text)
    if not vid:
        raise FishError('Pega el enlace de la voz (ej: https://fish.audio/m/…) o su ID.')
    data = _request('GET', '/model/' + vid, _key_or_error(), timeout=20)
    return {'id': vid, 'title': data.get('title') or 'Voz', 'state': data.get('state') or ''}


def synthesize(text: str, cfg: Optional[Dict] = None, timeout: float = 120.0) -> bytes:
    cfg = cfg or load_config()
    key = cfg.get('api_key') or ''
    if not key:
        raise FishError('Falta tu clave de API de Fish Audio.')
    if not cfg.get('voice_id'):
        raise FishError('Elige una voz de Fish Audio.')
    body = {'text': text, 'reference_id': cfg['voice_id'], 'format': 'mp3', 'mp3_bitrate': 128,
            'latency': 'normal', 'normalize': True}
    if abs(float(cfg.get('speed') or 1.0) - 1.0) > 0.001:
        body['prosody'] = {'speed': float(cfg['speed'])}
    audio = _request('POST', '/v1/tts', key, body=body, headers={'model': cfg.get('model') or DEFAULTS['model']},
                     timeout=timeout, raw=True)
    if not audio or len(audio) < 500:
        raise FishError('Fish Audio no devolvió audio para esta línea.')
    return audio


# ── Generar las líneas de un proyecto ───────────────────────────────────────
def output_dir(images=None, audio: str = '') -> str:
    base = ''
    if isinstance(images, str) and images and os.path.isdir(images):
        base = images
    elif isinstance(images, list) and images:
        base = os.path.dirname(str(images[0]))
    elif audio:
        base = os.path.dirname(audio)
    if not base or not os.path.isdir(base):
        from src.utils.paths import data_dir
        base = data_dir()
    d = os.path.join(base, 'voz_fish')
    os.makedirs(d, exist_ok=True)
    return d


def _fingerprint(text: str, cfg: Dict) -> str:
    raw = '|'.join([text.strip(), cfg.get('voice_id', ''), cfg.get('model', ''), f"{float(cfg.get('speed') or 1):.2f}"])
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()[:20]


def generate_lines(lines: List[Dict], folder: str, force: bool = False,
                   on_progress: Optional[Callable[[Dict], None]] = None,
                   cancelled: Optional[Callable[[], bool]] = None) -> Dict:
    """lines: [{'clip_id': 3, 'text': '...'}]. Devuelve {'files': {clip_id: ruta}, 'generated', 'reused', 'errors'}."""
    cfg = load_config()
    index_path = os.path.join(folder, 'voz_fish.json')
    try:
        with open(index_path, 'r', encoding='utf-8') as fh:
            index = json.load(fh) or {}
    except Exception:
        index = {}
    files, errors = {}, []
    generated = reused = 0
    total = len(lines)
    for n, line in enumerate(lines, 1):
        if cancelled and cancelled():
            break
        cid = int(line['clip_id'])
        text = str(line.get('text') or '').strip()
        name = f'{cid:02d}_fish.mp3'
        path = os.path.join(folder, name)
        fp = _fingerprint(text, cfg)
        if on_progress:
            on_progress({'done': n - 1, 'total': total, 'clip_id': cid, 'text': text[:80]})
        if not text:
            continue
        if not force and index.get(name) == fp and os.path.exists(path) and os.path.getsize(path) > 500:
            files[cid] = path
            reused += 1
            continue
        try:
            audio = synthesize(text, cfg)
        except FishError as e:
            errors.append({'clip_id': cid, 'error': str(e)})
            if any(w in str(e) for w in ('clave de API', 'saldo', 'Elige una voz', 'No se encontró esa voz')):
                break                                  # no tiene sentido seguir con las demás líneas
            continue
        tmp = path + '.part'
        with open(tmp, 'wb') as fh:
            fh.write(audio)
        os.replace(tmp, path)
        index[name] = fp
        files[cid] = path
        generated += 1
        try:
            with open(index_path, 'w', encoding='utf-8') as fh:
                json.dump(index, fh, indent=1)
        except Exception:
            pass
    if on_progress:
        on_progress({'done': total, 'total': total})
    return {'files': files, 'generated': generated, 'reused': reused, 'errors': errors, 'folder': folder,
            'cancelled': bool(cancelled and cancelled())}
