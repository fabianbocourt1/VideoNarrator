"""
Fish Audio con cuenta GRATIS (VideoNarrator v6.2).

La API de Fish Audio exige saldo pagado, pero la web permite generar gratis. Este módulo ayuda a
usar la web sin trabajo manual:
  - copia cada línea del narrador al portapapeles (para pegarla en fish.audio);
  - vigila la carpeta de Descargas: cada audio nuevo que se descarga se avisa a la app, que lo
    pone en su escena y copia la siguiente línea;
  - importa audios ya descargados, ordenados por la hora de descarga.
Los audios se copian a la carpeta "voz_fish" del proyecto (NN_fish.mp3), así no dependen de
que Descargas se limpie.
"""
import os
import time
import shutil
import threading
from typing import Callable, Dict, List, Optional

AUDIO_EXT = ('.mp3', '.wav', '.m4a', '.aac', '.ogg', '.opus', '.flac', '.webm')


# ── Carpeta de Descargas ─────────────────────────────────────────────────────
def downloads_dir() -> str:
    if os.name == 'nt':
        try:
            import ctypes
            from ctypes import wintypes

            class GUID(ctypes.Structure):
                _fields_ = [('Data1', wintypes.DWORD), ('Data2', wintypes.WORD),
                            ('Data3', wintypes.WORD), ('Data4', ctypes.c_ubyte * 8)]
            # FOLDERID_Downloads {374DE290-123F-4565-9164-39C4925E467B}
            fid = GUID(0x374DE290, 0x123F, 0x4565, (ctypes.c_ubyte * 8)(0x91, 0x64, 0x39, 0xC4, 0x92, 0x5E, 0x46, 0x7B))
            out = ctypes.c_wchar_p()
            shell32 = ctypes.WinDLL('shell32')
            shell32.SHGetKnownFolderPath.argtypes = [ctypes.POINTER(GUID), wintypes.DWORD, wintypes.HANDLE,
                                                     ctypes.POINTER(ctypes.c_wchar_p)]
            if shell32.SHGetKnownFolderPath(ctypes.byref(fid), 0, None, ctypes.byref(out)) == 0 and out.value:
                path = out.value
                ctypes.windll.ole32.CoTaskMemFree(out)
                if os.path.isdir(path):
                    return path
        except Exception:
            pass
    for name in ('Downloads', 'Descargas'):
        p = os.path.join(os.path.expanduser('~'), name)
        if os.path.isdir(p):
            return p
    return os.path.expanduser('~')


# ── Portapapeles (Windows) ───────────────────────────────────────────────────
def copy_text(text: str) -> bool:
    if os.name != 'nt':
        return False
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.WinDLL('user32')
        kernel32 = ctypes.WinDLL('kernel32')
        user32.OpenClipboard.argtypes = [wintypes.HWND]
        user32.OpenClipboard.restype = wintypes.BOOL
        user32.EmptyClipboard.restype = wintypes.BOOL
        user32.SetClipboardData.argtypes = [wintypes.UINT, wintypes.HANDLE]
        user32.SetClipboardData.restype = wintypes.HANDLE
        user32.CloseClipboard.restype = wintypes.BOOL
        kernel32.GlobalAlloc.argtypes = [wintypes.UINT, ctypes.c_size_t]
        kernel32.GlobalAlloc.restype = wintypes.HANDLE
        kernel32.GlobalLock.argtypes = [wintypes.HANDLE]
        kernel32.GlobalLock.restype = ctypes.c_void_p
        kernel32.GlobalUnlock.argtypes = [wintypes.HANDLE]
        kernel32.GlobalFree.argtypes = [wintypes.HANDLE]
        data = str(text or '').encode('utf-16-le') + b'\x00\x00'
        for _ in range(20):
            if user32.OpenClipboard(None):
                break
            time.sleep(0.05)
        else:
            return False
        try:
            user32.EmptyClipboard()
            h = kernel32.GlobalAlloc(0x0002, len(data))          # GMEM_MOVEABLE
            if not h:
                return False
            p = kernel32.GlobalLock(h)
            ctypes.memmove(p, data, len(data))
            kernel32.GlobalUnlock(h)
            if not user32.SetClipboardData(13, h):               # CF_UNICODETEXT
                kernel32.GlobalFree(h)
                return False
            return True
        finally:
            user32.CloseClipboard()
    except Exception:
        return False


# ── Vigilar Descargas ────────────────────────────────────────────────────────
def _audio_snapshot(folder: str) -> Dict[str, tuple]:
    out = {}
    try:
        with os.scandir(folder) as it:
            for e in it:
                if e.is_file() and e.name.lower().endswith(AUDIO_EXT):
                    try:
                        st = e.stat()
                        out[e.path] = (st.st_size, st.st_mtime)
                    except OSError:
                        pass
    except OSError:
        pass
    return out


class DownloadWatcher:
    """Avisa (on_new(ruta)) cada vez que aparece un audio nuevo y terminado de descargar."""

    def __init__(self, folder: str, on_new: Callable[[str], None], interval: float = 0.8):
        self.folder = folder
        self.on_new = on_new
        self.interval = interval
        self._stop = threading.Event()
        self._known = _audio_snapshot(folder)       # lo que ya estaba no cuenta
        self._pending: Dict[str, tuple] = {}
        self._thread = threading.Thread(target=self._loop, daemon=True)

    def start(self):
        self._thread.start()
        return self

    def stop(self):
        self._stop.set()

    @property
    def running(self) -> bool:
        return self._thread.is_alive() and not self._stop.is_set()

    def poll(self):
        """Una revisión (separada del bucle para poder probarla)."""
        now = _audio_snapshot(self.folder)
        for path, sig in now.items():
            old = self._known.get(path)
            if old is not None and old == sig:
                continue
            if sig[0] < 1000:                        # todavía vacío / escribiéndose
                self._pending.pop(path, None)
                continue
            if self._pending.get(path) == sig:       # mismo tamaño dos revisiones seguidas: terminado
                self._pending.pop(path, None)
                self._known[path] = sig
                try:
                    self.on_new(path)
                except Exception:
                    pass
            else:
                self._pending[path] = sig
        for gone in [p for p in self._known if p not in now]:
            self._known.pop(gone, None)

    def _loop(self):
        while not self._stop.wait(self.interval):
            self.poll()


# ── Importar ─────────────────────────────────────────────────────────────────
def describe_files(paths: List[str]) -> List[Dict]:
    """Audios elegidos, ordenados por hora de descarga (el más antiguo primero)."""
    out = []
    for p in paths or []:
        if p and os.path.isfile(p) and p.lower().endswith(AUDIO_EXT):
            out.append({'path': p, 'name': os.path.basename(p), 'mtime': os.path.getmtime(p)})
    out.sort(key=lambda d: (d['mtime'], d['name'].lower()))
    return out


def import_to_project(pairs: List[Dict], folder: str) -> Dict:
    """pairs: [{'clip_id': 2, 'path': 'C:/.../Descargas/x.mp3'}] -> copia a folder/02_fish.mp3."""
    files, errors = {}, []
    os.makedirs(folder, exist_ok=True)
    for pr in pairs or []:
        try:
            cid = int(pr.get('clip_id'))
            src = str(pr.get('path') or '')
            if not os.path.isfile(src):
                raise FileNotFoundError(os.path.basename(src) or 'archivo')
            ext = os.path.splitext(src)[1].lower() or '.mp3'
            for old in os.listdir(folder):                 # quita la versión anterior de esa línea
                if old.startswith(f'{cid:02d}_fish.') and old.lower().endswith(AUDIO_EXT):
                    try:
                        os.remove(os.path.join(folder, old))
                    except OSError:
                        pass
            dest = os.path.join(folder, f'{cid:02d}_fish{ext}')
            if os.path.abspath(src) != os.path.abspath(dest):
                shutil.copy2(src, dest)
            files[str(cid)] = dest
        except Exception as e:
            errors.append({'clip_id': pr.get('clip_id'), 'error': f'No se pudo copiar {e}'})
    return {'files': files, 'errors': errors, 'folder': folder}
