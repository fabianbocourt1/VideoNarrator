"""
Edición a mano de escenas (VideoNarrator v6.8).

Se aplica DESPUÉS del recorte automático de silencios y solo a las escenas que el usuario tocó:
  - in / out   : dónde empieza y termina la escena, en segundos del archivo que manda en la escena
                 (el video con su propio audio, o el audio del narrador / Fish). Puede acortar o
                 recuperar partes que el recorte automático había quitado.
  - splits     : puntos (segundos del archivo) donde la escena se divide en partes.
  - extend     : segundos extra al final (se congela la última imagen, el audio queda en silencio).
  - off        : la escena no sale en el video (no se borra nada).
y además `order`: el orden de las escenas/partes ("6", "6.2"...).

Las escenas sin edición quedan exactamente como las deja el recorte automático.
"""
import os
import copy
from typing import Callable, Dict, List, Optional, Tuple

MIN_PART = 0.2
MAX_EXTEND = 30.0


def _num(x) -> Optional[float]:
    try:
        v = float(x)
        return v if v == v else None              # descarta NaN
    except (TypeError, ValueError):
        return None


def clean_edits(raw) -> Dict[str, Dict]:
    """Normaliza lo que manda la pantalla (nunca confía en los tipos)."""
    out = {}
    if not isinstance(raw, dict):
        return out
    for k, e in raw.items():
        if not isinstance(e, dict):
            continue
        try:
            cid = str(int(k))
        except (TypeError, ValueError):
            continue
        d = {}
        for f in ('in', 'out'):
            v = _num(e.get(f))
            if v is not None and v >= 0:
                d[f] = v
        ext = _num(e.get('extend'))
        if ext and ext > 0:
            d['extend'] = min(MAX_EXTEND, ext)
        if e.get('off') is True:
            d['off'] = True
        sp = [v for v in (_num(x) for x in (e.get('splits') or [])) if v is not None and v > 0]
        if sp:
            d['splits'] = sorted(set(round(v, 3) for v in sp))[:20]
        if d:
            out[cid] = d
    return out


def _driver(c, src_dur: Callable[[str], float]):
    """Qué archivo manda en la escena y sus tramos actuales: ('keep'|'audio', segs, duración del archivo)."""
    mode = getattr(c, 'audio_mode', '')
    path = getattr(c, 'audio_path', '') or ''
    if mode == 'video' and path:
        d = src_dur(path)
        segs = getattr(c, 'keep_segments', None) or [(0.0, d or c.duration)]
        return 'keep', [list(s) for s in segs], d
    if mode == 'file' and path:
        d = src_dur(path)
        segs = getattr(c, 'audio_segments', None) or [(0.0, d or c.duration)]
        return 'audio', [list(s) for s in segs], d
    if mode == 'slice' and path:
        d = src_dur(path)
        a = float(getattr(c, 'audio_start', 0) or 0)
        segs = getattr(c, 'audio_segments', None) or [(a, a + c.duration)]
        return 'audio', [list(s) for s in segs], d
    return None, None, 0.0


def _window(segs: List[List[float]], lo: float, hi: float) -> List[List[float]]:
    new = [[max(a, lo), min(b, hi)] for a, b in segs if b > lo and a < hi]
    new = [s for s in new if s[1] - s[0] > 0.01]
    if not new:
        return [[lo, hi]]
    if lo < new[0][0]:
        new[0][0] = lo                            # recupera parte del inicio que se había recortado
    if hi > new[-1][1]:
        new[-1][1] = hi                           # recupera parte del final
    return new


def _cut(segs: List[List[float]], points: List[float]) -> List[List[List[float]]]:
    parts, cur = [], [list(s) for s in segs]
    for p in points:
        left, right = [], []
        for a, b in cur:
            if b <= p:
                left.append([a, b])
            elif a >= p:
                right.append([a, b])
            else:
                left.append([a, p]); right.append([p, b])
        if sum(b - a for a, b in left) >= MIN_PART and sum(b - a for a, b in right) >= MIN_PART:
            parts.append(left)
            cur = right
    parts.append(cur)
    return parts


def _split_text(text: str, weights: List[float]) -> List[str]:
    words = (text or '').split()
    if len(weights) <= 1 or not words:
        return [text] + [''] * (len(weights) - 1)
    total = sum(weights) or 1.0
    out, i = [], 0
    for k, w in enumerate(weights):
        if k == len(weights) - 1:
            n = len(words) - i
        else:
            n = max(0, round(len(words) * w / total))
            n = min(n, len(words) - i - (len(weights) - k - 1))
        out.append(' '.join(words[i:i + n]))
        i += n
    return out


def apply(timeline, edits: Dict[str, Dict], order: Optional[List[str]], src_dur: Callable[[str], float]):
    """Aplica las ediciones a la línea de tiempo (in place) y devuelve las escenas quitadas."""
    edits = edits or {}
    natural, removed = [], []
    for c in timeline.clips:
        cid = str(c.clip_id)
        e = edits.get(cid) or {}
        field, segs, sdur = _driver(c, src_dur)
        c.auto_segs = [list(s) for s in segs] if segs else None
        c.src_dur = round(sdur, 3) if sdur else None
        c.edit = e
        c.edited = bool(e)
        c.full_text = c.text
        c.part, c.parts, c.key = 0, 1, cid
        if e.get('off'):
            removed.append(c)
            continue
        parts_segs = None
        if field and segs:
            lo = e.get('in', segs[0][0])
            hi = e.get('out', segs[-1][1])
            top = sdur if sdur else max(hi, segs[-1][1])
            lo = max(0.0, min(lo, top - MIN_PART))
            hi = max(lo + MIN_PART, min(hi, top))
            new = _window(segs, lo, hi) if ('in' in e or 'out' in e) else segs
            pts = [p for p in e.get('splits', []) if new[0][0] + MIN_PART <= p <= new[-1][1] - MIN_PART]
            parts_segs = _cut(new, pts) if pts else [new]
        if not parts_segs:
            c.duration = max(MIN_PART, c.duration + float(e.get('extend', 0) or 0))
            natural.append(c)
            continue
        lens = [sum(b - a for a, b in p) for p in parts_segs]
        texts = _split_text(c.text, lens)
        for k, (p, ln) in enumerate(zip(parts_segs, lens)):
            part = c if k == 0 else copy.copy(c)
            part.text = texts[k]
            if field == 'keep':
                part.keep_segments = [tuple(s) for s in p]
                part.audio_segments = None
            else:
                part.audio_segments = [tuple(s) for s in p]
            part.duration = max(MIN_PART, ln)
            if len(parts_segs) > 1:
                part.part, part.parts, part.key = k + 1, len(parts_segs), f'{cid}.{k + 1}'
            if k == len(parts_segs) - 1 and e.get('extend'):
                part.duration += float(e['extend'])
            natural.append(part)

    # orden elegido a mano (las escenas que no están en la lista quedan en su lugar natural)
    if order:
        pos = {str(k): i for i, k in enumerate(order)}
        last, keyed = -1.0, []
        for n, c in enumerate(natural):
            if c.key in pos:
                last = float(pos[c.key])
                keyed.append((last, n, c))
            elif c.key.split('.')[0] in pos and '.' in c.key:
                last = float(pos[c.key.split('.')[0]]) + 0.001 * c.part
                keyed.append((last, n, c))
            else:
                last += 0.0001
                keyed.append((last, n, c))
        keyed.sort(key=lambda x: (x[0], x[1]))
        natural = [c for _, _, c in keyed]

    t = 0.0
    for c in natural:
        c.start_time = t
        c.end_time = t + c.duration
        t += c.duration
    timeline.clips = natural
    timeline.total_audio_duration = t
    timeline.removed = removed
    return removed
