"""
Aviso automático de actualizaciones (VideoNarrator v4.3, fuente por enlace desde v4.7).

Dos fuentes posibles (se configuran en update_config.json o desde la propia app):

  1. ENLACE (recomendado, v4.7): "url_actualizacion" = enlace de Google Drive (o Dropbox, o cualquier
     enlace directo) de UN archivo .zip de parche. Para publicar una versión nueva se sube el parche
     nuevo como "nueva versión" de ese mismo archivo: el enlace no cambia.
     La app descarga ese .zip al abrir (pesa pocos KB), lee su parche.json y, si la versión es más
     nueva, muestra el aviso. Al pulsar "Actualizar ahora" se instala el archivo ya descargado.

  2. GITHUB: "github_repo" = "usuario/repositorio" (última Release con un .zip "parche" adjunto).

Solo usa la librería estándar (urllib). Sin internet o sin fuente configurada, no se muestra nada.
"""
import os
import io
import json
import re
import html
import zipfile
import urllib.error
import urllib.parse
import urllib.request
from typing import Callable, Dict, Optional

USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) VideoNarrator-Updater'
DEFAULT_CONFIG = {'url_actualizacion': '', 'github_repo': '', 'comprobar_al_abrir': True,
                  'api_base': 'https://api.github.com'}
MAX_PATCH_BYTES = 300 * 1024 * 1024

NOT_SHARED_MSG = ('El enlace no lleva al archivo: en Google Drive, haz clic derecho en el archivo > '
                  'Compartir > "Acceso general" > "Cualquier persona con el enlace".')


def version_tuple(v) -> tuple:
    nums = re.findall(r'\d+', str(v or ''))
    return tuple(int(n) for n in nums) or (0,)


def is_newer(latest, current) -> bool:
    a, b = list(version_tuple(latest)), list(version_tuple(current))
    n = max(len(a), len(b))
    return a + [0] * (n - len(a)) > b + [0] * (n - len(b))


def _user_config_path() -> str:
    from src.utils.paths import data_dir
    return os.path.join(data_dir(), 'update_config.json')


def load_config() -> Dict:
    """app/update_config.json; el de la carpeta de datos (lo que se guarda desde la app) lo reemplaza."""
    from src.utils.paths import app_dir
    cfg = dict(DEFAULT_CONFIG)
    for path in (os.path.join(app_dir(), 'update_config.json'), _user_config_path()):
        try:
            with open(path, 'r', encoding='utf-8') as fh:
                data = json.load(fh)
            if isinstance(data, dict):
                # un valor vacío guardado por el usuario no borra el enlace que trae la app
                cfg.update({k: v for k, v in data.items() if v not in (None, '')})
        except Exception:
            pass
    repo = str(cfg.get('github_repo') or '').strip()
    m = re.search(r'github\.com/([^/\s]+/[^/\s#?]+)', repo)   # acepta también el enlace completo
    if m:
        repo = m.group(1)
    repo = repo.strip('/')
    if repo.endswith('.git'):
        repo = repo[:-4]
    cfg['github_repo'] = repo
    cfg['url_actualizacion'] = str(cfg.get('url_actualizacion') or '').strip()
    return cfg


def save_user_link(link: str) -> Dict:
    """Guarda el enlace de actualizaciones elegido en la app (carpeta de datos del usuario)."""
    link = (link or '').strip()
    if link and not re.match(r'^https?://', link, re.I):
        return {'error': 'Pega un enlace completo (empieza por https://).'}
    path = _user_config_path()
    data = {}
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            data = json.load(fh) or {}
    except Exception:
        data = {}
    data['url_actualizacion'] = link
    try:
        with open(path, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False, indent=2)
    except Exception as e:
        return {'error': f'No se pudo guardar: {e}'}
    return {'ok': True, 'url': link}


# ── Enlaces ────────────────────────────────────────────────────────────────
def drive_file_id(link: str) -> str:
    for pat in (r'drive\.google\.com/file/d/([\w-]{10,})', r'[?&]id=([\w-]{10,})',
                r'drive\.google\.com/open\?id=([\w-]{10,})', r'docs\.google\.com/\w+/d/([\w-]{10,})'):
        m = re.search(pat, link or '')
        if m:
            return m.group(1)
    return ''


def direct_url(link: str) -> str:
    """Convierte un enlace para compartir en uno de descarga directa."""
    link = (link or '').strip()
    if 'google.com' in link:
        fid = drive_file_id(link)
        if fid:
            return f'https://drive.google.com/uc?export=download&id={fid}'
    if 'dropbox.com' in link:
        if re.search(r'[?&]dl=0', link):
            return re.sub(r'([?&])dl=0', r'\1dl=1', link)
        if 'dl=1' not in link and 'raw=1' not in link:
            return link + ('&' if '?' in link else '?') + 'dl=1'
    if 'raw.githubusercontent.com' in link:
        # GitHub guarda una copia del archivo hasta 5 minutos: así siempre se pide la más nueva
        import time
        return link + ('&' if '?' in link else '?') + f't={int(time.time())}'
    return link


def _open(url: str, timeout: float):
    req = urllib.request.Request(url, headers={'User-Agent': USER_AGENT, 'Accept': '*/*'})
    from src.utils.net import urlopen
    return urlopen(req, timeout=timeout)


def _drive_confirm_url(page: str, base_url: str) -> str:
    """Google Drive a veces muestra una página "no se pudo analizar en busca de virus": se sigue su formulario."""
    m = re.search(r'<form[^>]+id="download-form"[^>]+action="([^"]+)"', page)
    if m:
        action = html.unescape(m.group(1))
        params = dict(re.findall(r'<input[^>]+type="hidden"[^>]+name="([^"]+)"[^>]+value="([^"]*)"', page))
        if params:
            return action + ('&' if '?' in action else '?') + urllib.parse.urlencode(params)
        return action
    m = re.search(r'href="(/uc\?export=download[^"]+confirm=[^"]+)"', page)
    if m:
        return urllib.parse.urljoin(base_url, html.unescape(m.group(1)))
    return ''


def download(url: str, dest: str, on_progress: Optional[Callable[[int, int], None]] = None,
             timeout: float = 30.0, cancel: Optional[Callable[[], bool]] = None) -> str:
    """Descarga url en dest (primero a dest + '.part'). Devuelve dest. Sigue la confirmación de Drive."""
    os.makedirs(os.path.dirname(dest) or '.', exist_ok=True)
    tmp = dest + '.part'
    for _attempt in range(3):
        with _open(url, timeout) as r:
            ctype = (r.headers.get('Content-Type') or '').lower()
            total = int(r.headers.get('Content-Length') or 0)
            if 'text/html' in ctype:
                page = r.read(2 * 1024 * 1024).decode('utf-8', 'replace')
                nxt = _drive_confirm_url(page, r.geturl())
                if nxt:
                    url = nxt
                    continue
                raise RuntimeError(NOT_SHARED_MSG)
            if total and total > MAX_PATCH_BYTES:
                raise RuntimeError('El archivo es demasiado grande para ser un parche.')
            done = 0
            with open(tmp, 'wb') as out:
                while True:
                    if cancel and cancel():
                        raise RuntimeError('Descarga cancelada')
                    chunk = r.read(64 * 1024)
                    if not chunk:
                        break
                    out.write(chunk)
                    done += len(chunk)
                    if done > MAX_PATCH_BYTES:
                        raise RuntimeError('El archivo es demasiado grande para ser un parche.')
                    if on_progress:
                        on_progress(done, total)
        if total and done < total:
            raise RuntimeError('La descarga quedó incompleta. Revisa tu conexión e inténtalo otra vez.')
        os.replace(tmp, dest)
        return dest
    raise RuntimeError(NOT_SHARED_MSG)


def read_patch_info(path: str) -> Dict:
    """Lee parche.json de un .zip. Lanza RuntimeError con un mensaje claro si no es un parche."""
    try:
        with zipfile.ZipFile(path) as zf:
            if 'parche.json' not in zf.namelist():
                raise RuntimeError('El archivo del enlace no es un parche de VideoNarrator (falta parche.json).')
            return json.loads(zf.read('parche.json').decode('utf-8'))
    except zipfile.BadZipFile:
        raise RuntimeError('El archivo del enlace no es un .zip válido. ' + NOT_SHARED_MSG)


# ── Comprobación ───────────────────────────────────────────────────────────
def _check_link(current_version: str, cfg: Dict) -> Dict:
    from src.utils.paths import data_dir
    link = cfg['url_actualizacion']
    folder = os.path.join(data_dir(), 'actualizaciones')
    dest = os.path.join(folder, 'ultima_publicada.zip')
    try:
        download(direct_url(link), dest, timeout=15.0)
        info = read_patch_info(dest)
    except Exception as e:
        from src.utils.net import friendly_error
        return {'available': False, 'configured': True, 'source': 'link', 'error': friendly_error(e)}
    latest = '.'.join(str(n) for n in version_tuple(info.get('version')))
    out = {'configured': True, 'source': 'link', 'version': latest, 'current': current_version,
           'notes': str(info.get('notas') or '').strip(), 'page': link,
           'size': os.path.getsize(dest), 'asset_name': os.path.basename(dest)}
    if not is_newer(latest, current_version):
        out['available'] = False
        return out
    base_min = str(info.get('base_min') or '')
    if base_min and version_tuple(current_version) < version_tuple(base_min):
        out.update({'available': False,
                    'error': f'Hay una v{latest}, pero necesita tener instalada la v{base_min} o más nueva '
                             f'(tienes v{current_version}).'})
        return out
    out.update({'available': True, 'url': link, 'local_path': dest})
    return out


def _check_github(current_version: str, cfg: Dict) -> Dict:
    repo = cfg.get('github_repo')
    api = str(cfg.get('api_base') or DEFAULT_CONFIG['api_base']).rstrip('/')
    try:
        req = urllib.request.Request(f'{api}/repos/{repo}/releases/latest',
                                     headers={'User-Agent': USER_AGENT, 'Accept': 'application/vnd.github+json'})
        from src.utils.net import urlopen
        with urlopen(req, timeout=8.0) as r:
            data = json.loads(r.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        msg = str(e)
        if e.code == 404:
            msg = (f'GitHub responde "no encontrado" para {repo}: el repositorio no es visible para '
                   'otros (privado, cuenta en revisión) o no tiene versiones publicadas.')
        return {'available': False, 'configured': True, 'source': 'github', 'error': msg}
    except Exception as e:
        from src.utils.net import friendly_error
        return {'available': False, 'configured': True, 'source': 'github', 'error': friendly_error(e)}

    tag = str(data.get('tag_name') or data.get('name') or '')
    latest = '.'.join(str(n) for n in version_tuple(tag))
    info = {'configured': True, 'source': 'github', 'version': latest, 'current': current_version,
            'notes': str(data.get('body') or '').strip(), 'page': data.get('html_url') or ''}
    if not is_newer(latest, current_version):
        info['available'] = False
        return info
    asset = None
    for a in data.get('assets') or []:
        name = str(a.get('name') or '')
        if name.lower().endswith('.zip') and 'parche' in name.lower():
            asset = a
            break
    if asset is None:
        info.update({'available': True, 'url': '', 'size': 0, 'asset_name': ''})
        return info
    info.update({'available': True, 'url': asset.get('browser_download_url') or '',
                 'size': int(asset.get('size') or 0), 'asset_name': asset.get('name') or ''})
    return info


def check_latest(current_version: str, cfg: Optional[Dict] = None) -> Dict:
    """
    {'available': True, 'version', 'notes', 'url', ...}  si hay una más nueva,
    {'available': False, ...} si no, o con 'error' si no se pudo consultar.
    """
    cfg = cfg or load_config()
    repo = cfg.get('github_repo')
    if cfg.get('url_actualizacion'):
        res = _check_link(current_version, cfg)
        if not res.get('error') or not (repo and '/' in repo):
            return res
        gh = _check_github(current_version, cfg)          # respaldo: las Releases de GitHub
        return gh if not gh.get('error') else res
    if repo and '/' in repo:
        return _check_github(current_version, cfg)
    return {'available': False, 'configured': False}
