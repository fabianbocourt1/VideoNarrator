"""
Revisión de escenas (VideoNarrator v9.2).

Para cada video de la historia:
  • DIÁLOGO (Whisper): escucha el audio del clip y lo compara con el texto COMPLETO de la escena.
    Da igual si hablan 1, 2 o 3 personajes: entre todos deben decir exactamente el texto.
    Los clips del narrador deben estar en silencio (su voz va aparte).
  • IMAGEN (FFmpeg, una sola pasada rápida): pantalla negra, imagen congelada, salto brusco
    a mitad del clip, destellos de brillo y clip demasiado corto para su diálogo.

Nada de esto cambia los archivos: solo informa. El color de cada escena es el peor de los dos.
"""
import os
import re
import subprocess
import threading
import unicodedata
from difflib import SequenceMatcher
from typing import Any, Callable, Dict, List, Optional

ORDER = {'g': 0, 'n': 0, 'y': 1, 'r': 2}          # n = no se pudo revisar (no cuenta como falla)

# Frases que Whisper "inventa" cuando solo hay silencio o música
_HALLUCINATIONS = ('subtitulos', 'amara', 'suscribete', 'gracias por ver', 'thanks for watching',
                   'subtitles by', 'musica', 'aplausos')

WORDS_PER_SEC = 2.8                                  # ritmo normal de habla en español


# ─────────────────────────────── utilidades ───────────────────────────────
def _norm(w: str) -> str:
    t = unicodedata.normalize('NFD', (w or '').lower())
    t = ''.join(c for c in t if unicodedata.category(c) != 'Mn')
    return re.sub(r'[^a-z0-9ñ]', '', t)


def _tokens(text: str) -> List[Dict[str, str]]:
    out = []
    for raw in re.split(r'\s+', text or ''):
        n = _norm(raw)
        if n:
            out.append({'w': raw, 'n': n})
    return out


def _mmss(t: float) -> str:
    t = max(0.0, float(t or 0))
    m = int(t // 60)
    return f"{m:02d}:{t - m * 60:04.1f}".replace('.', ',')


def _secs(t: float) -> str:
    return f"{float(t):.1f}".replace('.', ',')


def _startupinfo():
    if os.name == 'nt':
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        return si
    return None


def _worst(*codes: str) -> str:
    return max(codes, key=lambda c: ORDER.get(c, 0)) if codes else 'g'


# ─────────────────────────────── DIÁLOGO ───────────────────────────────
def compare_text(expected: str, heard: str) -> Dict[str, Any]:
    """Compara palabra por palabra (sin tildes, mayúsculas ni signos).
    Devuelve el % de parecido y las dos frases marcadas (faltó / sobró)."""
    e, h = _tokens(expected), _tokens(heard)
    en, hn = [x['n'] for x in e], [x['n'] for x in h]
    sm = SequenceMatcher(None, en, hn, autojunk=False)
    exp_m = [{'w': x['w'], 's': 'ok'} for x in e]
    heard_m = [{'w': x['w'], 's': 'ok'} for x in h]
    missing = added = changed = 0
    for op, a0, a1, b0, b1 in sm.get_opcodes():
        if op == 'equal':
            continue
        for k in range(a0, a1):
            exp_m[k]['s'] = 'miss'
        for k in range(b0, b1):
            heard_m[k]['s'] = 'add'
        if op == 'replace':
            changed += max(a1 - a0, b1 - b0)
        elif op == 'delete':
            missing += a1 - a0
        elif op == 'insert':
            added += b1 - b0
    matched = sum(b.size for b in sm.get_matching_blocks())
    pct = round(100.0 * matched / max(1, len(en), len(hn)))
    tail_missing = bool(e) and exp_m[-1]['s'] == 'miss'
    return {'pct': int(pct), 'expected': exp_m, 'heard': heard_m, 'missing': missing, 'added': added,
            'changed': changed, 'diff_words': missing + added + changed, 'tail_missing': tail_missing,
            'n_expected': len(e), 'n_heard': len(h)}


def _audio_levels(audio) -> Dict[str, float]:
    """Volumen (dBFS) de la voz: el máximo en ventanas de 50 ms y el de los últimos 100 ms."""
    import numpy as np
    n = len(audio)
    if n < 1600:
        return {'peak_db': -99.0, 'tail_db': -99.0, 'dur': n / 16000.0}
    win = 800
    k = n // win
    frames = audio[:k * win].reshape(k, win)
    rms = np.sqrt(np.mean(frames.astype(np.float64) ** 2, axis=1) + 1e-12)
    db = 20 * np.log10(rms)
    tail = audio[-1600:].astype(np.float64)
    tail_db = float(20 * np.log10(np.sqrt(np.mean(tail ** 2) + 1e-12)))
    return {'peak_db': float(np.max(db)), 'tail_db': tail_db, 'dur': n / 16000.0}


def _transcribe(model, audio, language: Optional[str]) -> Dict[str, Any]:
    kwargs = dict(word_timestamps=True, beam_size=1, best_of=1, condition_on_previous_text=False)
    if language:
        kwargs['language'] = language
    segments, _info = model.transcribe(audio, **kwargs)
    words, text_parts = [], []
    for seg in segments:
        txt = (seg.text or '').strip()
        nsp = float(getattr(seg, 'no_speech_prob', 0) or 0)
        lp = float(getattr(seg, 'avg_logprob', 0) or 0)
        if nsp > 0.6 and lp < -0.8:
            continue                                     # casi seguro que no es voz
        if any(hh in _norm(txt) for hh in (_norm(x) for x in _HALLUCINATIONS)) and nsp > 0.3:
            continue
        text_parts.append(txt)
        for w in (seg.words or []):
            if w.start is not None and w.end is not None and (w.word or '').strip():
                words.append({'w': w.word.strip(), 'start': float(w.start), 'end': float(w.end)})
    return {'text': ' '.join(text_parts).strip(), 'words': words}


def _speakers(name: str) -> int:
    name = (name or '').strip()
    if not name:
        return 1
    return len([p for p in re.split(r'\s*(?:,|\by\b|&|/)\s*', name) if p.strip()]) or 1


def review_dialogue(path: str, item: Dict[str, Any], model, language: Optional[str]) -> Dict[str, Any]:
    """Revisión del audio de un clip. item: kind, audio_mode, text, speaker."""
    from src.core.subtitles import load_audio_16k
    kind = (item.get('kind') or '').lower()
    mode = (item.get('audio_mode') or '').lower()
    narrator = kind == 'narrator' or mode in ('slice', 'global')
    text = item.get('text') or ''

    if mode == 'file':
        return {'st': 'n', 'skip': True, 'msg': 'La voz viene de un audio aparte: no se revisa la del video'}
    try:
        audio = load_audio_16k(path)
    except Exception:
        audio = None
    if audio is None or len(audio) == 0:
        if narrator:
            return {'st': 'g', 'msg': 'Sin voz (correcto: lo cuenta el narrador)'}
        return {'st': 'r', 'msg': 'Sin voz: el video no tiene audio y esta escena tiene diálogo', 'pct': 0}
    lv = _audio_levels(audio)
    quiet = lv['peak_db'] < -42.0

    if narrator:
        if quiet:
            return {'st': 'g', 'msg': 'Sin voz (correcto: lo cuenta el narrador)'}
        if model is None:
            return {'st': 'n', 'msg': 'Tiene sonido; Whisper no está disponible para saber si es voz'}
        tr = _transcribe(model, audio, language)
        if len(_tokens(tr['text'])) >= 2:
            return {'st': 'y', 'msg': 'Se oye a alguien hablar en un clip del narrador', 'heard_text': tr['text']}
        return {'st': 'g', 'msg': 'Sin voz (solo sonido de fondo; correcto)'}

    # Escena con diálogo
    if quiet:
        return {'st': 'r', 'msg': 'Sin voz: esta escena tiene diálogo', 'pct': 0,
                'cmp': compare_text(text, '')}
    if model is None:
        return {'st': 'n', 'msg': 'Whisper no está disponible: no se pudo escuchar el diálogo'}
    tr = _transcribe(model, audio, language)
    if not _tokens(tr['text']):
        return {'st': 'r', 'msg': 'Sin voz: esta escena tiene diálogo', 'pct': 0,
                'cmp': compare_text(text, '')}
    c = compare_text(text, tr['text'])
    pct = c['pct']
    words = tr['words']
    last_end = words[-1]['end'] if words else 0.0
    speaking_at_end = (lv['dur'] - last_end) < 0.18 and lv['tail_db'] > -32.0
    n_sp = _speakers(item.get('speaker'))
    out = {'pct': pct, 'cmp': c, 'heard_text': tr['text']}

    if c['diff_words'] == 0:
        out.update(st='g', msg=(f'Hablan {n_sp} personajes · dijeron todo el diálogo' if n_sp > 1
                                else 'Dice exactamente su diálogo'))
        return out
    e_last = _norm(c['expected'][-1]['w']) if c['expected'] else ''
    h_last = _norm(c['heard'][-1]['w']) if c['heard'] else ''
    partial = bool(h_last) and h_last != e_last and len(h_last) < len(e_last) and e_last.startswith(h_last)
    if partial or (speaking_at_end and (c['tail_missing'] or (c['heard'] and c['heard'][-1]['s'] == 'add'))):
        last = ' '.join(x['w'] for x in c['heard'][-2:]).strip(' .,;:!?¡¿') if c['heard'] else ''
        out.update(st='r', msg=f'Se corta a mitad de palabra: "…{last}…"' if last else 'Se corta antes de terminar')
        return out
    if c['tail_missing'] and c['added'] == 0 and c['changed'] == 0:
        out.update(st='r', msg='Le falta la última palabra' if c['missing'] == 1
                   else f'Le faltan las últimas {c["missing"]} palabras')
        return out
    if c['diff_words'] == 1 or (c['diff_words'] == 2 and pct >= 85):
        if c['changed']:
            what = 'Cambió una palabra' if c['changed'] == 1 and c['diff_words'] == 1 else f'Cambiaron {c["diff_words"]} palabras'
        elif c['missing']:
            what = 'Falta una palabra' if c['missing'] == 1 else f'Faltan {c["missing"]} palabras'
        else:
            what = 'Dijo una palabra de más' if c['added'] == 1 else f'Dijo {c["added"]} palabras de más'
        out.update(st='y', msg=what)
        return out
    if c['missing'] and not c['added'] and not c['changed']:
        out.update(st='r', msg='Le falta una palabra del diálogo' if c['missing'] == 1
                   else f'Le faltan {c["missing"]} palabras del diálogo')
    else:
        out.update(st='r', msg='Dijo otra frase')
    return out


# ─────────────────────────────── IMAGEN ───────────────────────────────
_RE_DUR = re.compile(r'Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)')
_RE_BLACK = re.compile(r'black_start:\s*([\d.]+)\s+black_end:\s*([\d.]+)\s+black_duration:\s*([\d.]+)')
_RE_FRZ_S = re.compile(r'freezedetect\.freeze_start:\s*([\d.]+)')
_RE_FRZ_D = re.compile(r'freezedetect\.freeze_duration:\s*([\d.]+)')
_RE_FRZ_E = re.compile(r'freezedetect\.freeze_end:\s*([\d.]+)')
_RE_SCD = re.compile(r'lavfi\.scd\.score:\s*([\d.]+),\s*lavfi\.scd\.time:\s*([\d.]+)')
_RE_PTS = re.compile(r'pts_time:\s*([\d.]+)')
_RE_Y = re.compile(r'lavfi\.signalstats\.YAVG=([\d.]+)')


def _run_scan(ff: str, path: str, with_scdet: bool = True) -> str:
    chain = 'fps=10,scale=240:-2,format=yuv420p,blackdetect=d=0.4:pix_th=0.10,freezedetect=n=-70dB:d=1.2'
    if with_scdet:
        chain += ',scdet=t=12'
    chain += ',signalstats,metadata=mode=print:key=lavfi.signalstats.YAVG'
    r = subprocess.run([ff, '-nostdin', '-hide_banner', '-v', 'info', '-i', path, '-an', '-sn', '-dn',
                        '-vf', chain, '-f', 'null', '-'],
                       stdin=subprocess.DEVNULL, capture_output=True, timeout=300, startupinfo=_startupinfo())
    err = (r.stderr or b'').decode('utf-8', 'replace')
    if r.returncode != 0 and with_scdet and 'scdet' in err:
        return _run_scan(ff, path, with_scdet=False)      # FFmpeg viejo sin "scdet"
    return err


def analyze_visual(ff: str, path: str) -> Dict[str, Any]:
    """Una pasada de FFmpeg a 10 cuadros/s en baja resolución: rápido aunque el clip sea 4K."""
    err = _run_scan(ff, path)
    dur = 0.0
    m = _RE_DUR.search(err)
    if m:
        dur = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))
    blacks = [(float(a), float(b), float(d)) for a, b, d in _RE_BLACK.findall(err)]
    fs = [float(x) for x in _RE_FRZ_S.findall(err)]
    fd = [float(x) for x in _RE_FRZ_D.findall(err)]
    fe = [float(x) for x in _RE_FRZ_E.findall(err)]
    freezes = []
    for k, s in enumerate(fs):
        if k < len(fd):
            freezes.append((s, fd[k]))
        elif k < len(fe):
            freezes.append((s, fe[k] - s))
        else:
            freezes.append((s, max(0.0, dur - s)))       # congelado hasta el final
    cuts = [(float(sc), float(t)) for sc, t in _RE_SCD.findall(err)]
    ys, cur_t = [], None
    for line in err.splitlines():
        mp = _RE_PTS.search(line)
        if mp:
            cur_t = float(mp.group(1))
            continue
        my = _RE_Y.search(line)
        if my and cur_t is not None:
            ys.append((cur_t, float(my.group(1))))
    return {'dur': dur, 'blacks': blacks, 'freezes': freezes, 'cuts': cuts, 'ys': ys}


def _flashes(ys: List[tuple]) -> List[float]:
    """Subidas/bajadas bruscas de brillo que vuelven enseguida (un destello, no un cambio de plano)."""
    out = []
    for i in range(1, len(ys) - 1):
        t, y = ys[i]
        prev = ys[i - 1][1]
        if abs(y - prev) < 35:
            continue
        for j in range(i + 1, min(len(ys), i + 6)):
            if abs(ys[j][1] - prev) < 15:
                if not out or t - out[-1] > 0.6:
                    out.append(t)
                break
    return out


def review_visual(ff: str, path: str, item: Dict[str, Any]) -> Dict[str, Any]:
    v = analyze_visual(ff, path)
    dur = v['dur'] or float(item.get('duration') or 0)
    checks, problems = [], []                         # problems: (st, texto, t)

    # Negro
    bad_black = []
    for a, b, d in v['blacks']:
        if a < 0.05 and d < 0.8:
            continue                                  # entrada desde negro (normal)
        if dur and b >= dur - 0.05 and d < 0.35:
            continue
        bad_black.append((a, b, d))
    if bad_black:
        a, b, d = max(bad_black, key=lambda x: x[2])
        if dur and d >= dur - 0.2:
            txt = 'Todo el clip está en negro'
        elif dur and b >= dur - 0.1:
            txt = f'Pantalla negra los últimos {_secs(d)} s'
        elif a < 0.05:
            txt = f'Pantalla negra los primeros {_secs(d)} s'
        else:
            txt = f'Pantalla negra {_secs(d)} s (desde {_mmss(a)})'
        problems.append(('r' if d >= 0.5 else 'y', txt, a))
        checks.append({'ok': False, 't': txt.split(' (')[0]})
    else:
        checks.append({'ok': True, 't': 'Sin negro'})

    # Congelado
    frz = [(s, d) for s, d in v['freezes'] if d >= 1.2]
    if frz and not (bad_black and any(abs(s - a) < 0.3 for s, _ in frz for a, _b, _d in bad_black)):
        s, d = max(frz, key=lambda x: x[1])
        st = 'r' if d >= 2.0 else 'y'
        txt = f'Imagen congelada {_secs(d)} s (desde {_mmss(s)})'
        problems.append((st, txt, s))
        checks.append({'ok': False, 't': f'Congelada {_secs(d)} s'})
    else:
        checks.append({'ok': True, 't': 'Sin congelado'})

    # Destellos y saltos bruscos
    flashes = _flashes(v['ys'])
    jumps = []
    for score, t in v['cuts']:
        if t < 0.25 or (dur and t > dur - 0.25):
            continue
        if any(abs(t - f) < 0.35 for f in flashes):
            continue                                   # era un destello, no un corte
        if bad_black and any(a - 0.2 <= t <= b + 0.2 for a, b, _d in bad_black):
            continue
        jumps.append((score, t))
    if jumps:
        score, t = max(jumps)
        st = 'r' if score >= 20 else 'y'
        txt = (f'Salto brusco a mitad del clip ({_mmss(t)})' if st == 'r'
               else f'Cambio brusco de imagen ({_mmss(t)}): ¿salto?')
        problems.append((st, txt, t))
        checks.append({'ok': False, 't': f'Salto brusco a {_mmss(t)}'})
    else:
        checks.append({'ok': True, 't': 'Sin saltos'})
    if flashes:
        t = flashes[0]
        problems.append(('y', f'Destello de brillo en {_mmss(t)}', t))
        checks.append({'ok': False, 't': f'Destello en {_mmss(t)}'})
    else:
        checks.append({'ok': True, 't': 'Sin destellos'})

    # Duración frente al diálogo
    n_words = len(_tokens(item.get('text') or ''))
    dialog = (item.get('kind') or '').lower() != 'narrator' and (item.get('audio_mode') or '') == 'video'
    if dialog and n_words and dur:
        need = n_words / WORDS_PER_SEC + 0.3
        if dur < need * 0.8:
            problems.append(('y', f'Clip de {_secs(dur)} s: corto para su diálogo (~{_secs(need)} s)', None))
            checks.append({'ok': False, 't': f'Duración {_secs(dur)} s (corta)'})
        else:
            checks.append({'ok': True, 't': f'Duración {_secs(dur)} s'})
    elif dur:
        checks.append({'ok': True, 't': f'Duración {_secs(dur)} s'})

    if problems:
        problems.sort(key=lambda p: -ORDER[p[0]])
        st = problems[0][0]
        msg = problems[0][1] + (f' · y {len(problems) - 1} más' if len(problems) > 1 else '')
        at = problems[0][2]
    else:
        st, msg, at = 'g', 'Imagen correcta', None
    return {'st': st, 'msg': msg, 'at': at, 'checks': checks, 'dur': round(dur, 2),
            'marks': [{'t': p[2], 'st': p[0]} for p in problems if p[2] is not None]}


# ─────────────────────────────── trabajo completo ───────────────────────────────
class Reviewer:
    """Revisa en segundo plano; la pantalla pregunta el avance con status()."""

    def __init__(self):
        self._lock = threading.Lock()
        self._cache: Dict[str, Dict[str, Any]] = {}
        self._state: Dict[str, Any] = {'running': False, 'done': 0, 'total': 0, 'current': '', 'results': {},
                                       'error': '', 'whisper': ''}
        self._cancel = False

    @staticmethod
    def _sig(it: Dict[str, Any]) -> str:
        p = it.get('path') or ''
        try:
            st = os.stat(p)
            f = f'{st.st_size}-{int(st.st_mtime)}'
        except OSError:
            f = 'x'
        return '|'.join([p, f, it.get('text') or '', it.get('kind') or '', it.get('audio_mode') or ''])

    def status(self) -> Dict[str, Any]:
        with self._lock:
            s = dict(self._state)
            s['results'] = dict(self._state['results'])
            return s

    def cancel(self):
        self._cancel = True

    def start(self, items: List[Dict[str, Any]], ff: str, language: Optional[str] = None) -> Dict[str, Any]:
        with self._lock:
            if self._state['running']:
                return {'error': 'Ya se están revisando las escenas.'}
            self._state = {'running': True, 'done': 0, 'total': len(items), 'current': 'Preparando…',
                           'results': {}, 'error': '', 'whisper': ''}
        self._cancel = False
        threading.Thread(target=self._run, args=(items, ff, language), daemon=True).start()
        return {'ok': True, 'total': len(items)}

    def _set(self, **kw):
        with self._lock:
            self._state.update(kw)

    def _run(self, items, ff, language):
        model = None
        need_whisper = any((it.get('audio_mode') or '') != 'file' and it.get('is_video') for it in items)
        try:
            if need_whisper:
                self._set(current='Preparando Whisper (la primera vez descarga su modelo)…')
                from src.core import subtitles
                model = subtitles.load_model()
                if model is None:
                    self._set(whisper=subtitles.LAST_REASON or 'Whisper no está disponible')
            for k, it in enumerate(items):
                if self._cancel:
                    break
                key = it.get('key') or str(k)
                self._set(current=f'Escena {it.get("clip_id", k + 1)} ({k + 1} de {len(items)})')
                sig = self._sig(it)
                res = self._cache.get(sig)
                if res is None:
                    res = self._review_one(it, ff, model, language)
                    if not (model is None and res.get('dialog', {}).get('st') == 'n'):
                        self._cache[sig] = res
                with self._lock:
                    self._state['results'][key] = res
                    self._state['done'] = k + 1
        except Exception as e:
            self._set(error=f'{type(e).__name__}: {e}')
        finally:
            self._set(running=False, current='')

    @staticmethod
    def _review_one(it, ff, model, language) -> Dict[str, Any]:
        path = it.get('path') or ''
        if not path or not os.path.isfile(path):
            return {'st': 'r', 'dialog': {'st': 'r', 'msg': 'No se encontró el archivo de la escena'},
                    'visual': {'st': 'r', 'msg': 'No se encontró el archivo', 'checks': []}}
        if not it.get('is_video'):
            return {'st': 'n', 'dialog': {'st': 'n', 'msg': 'Es una imagen: no tiene audio que revisar'},
                    'visual': {'st': 'n', 'msg': 'Imagen fija: no se revisa', 'checks': []}}
        try:
            dia = review_dialogue(path, it, model, language)
        except Exception as e:
            dia = {'st': 'n', 'msg': f'No se pudo escuchar: {type(e).__name__}'}
        try:
            vis = review_visual(ff, path, it)
        except Exception as e:
            vis = {'st': 'n', 'msg': f'No se pudo revisar la imagen: {type(e).__name__}', 'checks': []}
        st = _worst(dia.get('st', 'g'), vis.get('st', 'g'))
        if ORDER.get(st, 0) == 0:
            st = 'n' if (dia.get('st') == 'n' and not dia.get('skip')) else 'g'
        return {'st': st, 'dialog': dia, 'visual': vis}
