"""
Música de fondo con "ducking" (VideoNarrator v5.8).

Se aplica AL FINAL, sobre el video ya terminado (con los silencios ya recortados):
  - la música va en su propia capa, continua de principio a fin (no se corta en los recortes);
  - cuando hay voz, un compresor guiado por la voz ("sidechain") baja la música; en las pausas
    vuelve a subir suavemente;
  - el video no se vuelve a codificar (se copia tal cual): solo se mezcla el audio, en segundos.

La música nunca entra en el análisis del recorte de silencios.
"""
import os
import re
import json
import base64
import subprocess
from typing import Callable, Dict, List, Optional

AUDIO_EXT = ('.mp3', '.wav', '.m4a', '.aac', '.flac', '.ogg', '.opus', '.wma')

# Volumen de la música ANTES del ducking (la voz queda normalizada a -16 LUFS)
VOLUME = {'suave': 0.12, 'normal': 0.20, 'presente': 0.32}
# Cuánto baja al hablar: (umbral, ratio, realce de la guía) del compresor guiado por la voz.
# Medido con voz a -18 dBFS: poco ≈ -6 dB, normal ≈ -10 dB, mucho ≈ -17 dB mientras hay voz.
DUCK = {'poco': (0.015, 2.5, 3), 'normal': (0.012, 8.0, 3), 'mucho': (0.008, 20.0, 4)}
FADE_IN = 1.5
FADE_OUT = 2.5


def _si():
    if os.name == 'nt':
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        return si
    return None


def list_tracks(folder: str) -> List[str]:
    try:
        names = sorted(f for f in os.listdir(folder) if f.lower().endswith(AUDIO_EXT))
    except Exception:
        return []
    return [os.path.join(folder, f) for f in names]


def pick_track(path: str, advance: bool = True) -> Optional[str]:
    """Una canción: el archivo elegido o, si es una carpeta, la siguiente de la carpeta (rotan por render)."""
    if not path:
        return None
    if os.path.isfile(path):
        return path
    if not os.path.isdir(path):
        return None
    tracks = list_tracks(path)
    if not tracks:
        return None
    from src.utils.paths import data_dir
    state_file = os.path.join(data_dir(), 'musica_rotacion.json')
    try:
        with open(state_file, 'r', encoding='utf-8') as fh:
            state = json.load(fh)
    except Exception:
        state = {}
    key = os.path.abspath(path)
    idx = int(state.get(key, 0)) % len(tracks)
    if advance:
        state[key] = idx + 1
        try:
            with open(state_file, 'w', encoding='utf-8') as fh:
                json.dump(state, fh)
        except Exception:
            pass
    return tracks[idx]


def has_audio_stream(ffmpeg_exe: str, path: str) -> bool:
    try:
        r = subprocess.run([ffmpeg_exe, '-hide_banner', '-nostdin', '-i', path], stdin=subprocess.DEVNULL,
                           capture_output=True, text=True, errors='ignore', timeout=30, startupinfo=_si())
        return bool(re.search(r'Stream #\d+:\d+.*Audio:', r.stderr))
    except Exception:
        return True


def build_mix_cmd(ffmpeg_exe: str, video_path: str, track: str, out_path: str, duration: float,
                  volume: str = 'normal', duck: str = 'normal', fade: bool = True, loop: bool = True,
                  start: float = 0.0, video_has_audio: bool = True) -> List[str]:
    gain = VOLUME.get(volume, VOLUME['normal'])
    thr, ratio, lsc = DUCK.get(duck, DUCK['normal'])
    dur = max(0.5, float(duration or 0))
    cmd = [ffmpeg_exe, '-y', '-hide_banner', '-nostdin', '-i', video_path]
    if loop:
        cmd += ['-stream_loop', '-1']
    if start and start > 0:
        cmd += ['-ss', f'{float(start):.2f}']
    cmd += ['-i', track]

    music = f'[1:a]aformat=sample_fmts=fltp:sample_rates=48000:channel_layouts=stereo,atrim=0:{dur:.3f},asetpts=N/SR/TB,volume={gain}'
    if fade:
        fo = min(FADE_OUT, dur / 3)
        fi = min(FADE_IN, dur / 3)
        music += f',afade=t=in:st=0:d={fi:.2f},afade=t=out:st={max(0.0, dur - fo):.3f}:d={fo:.2f}'
    if video_has_audio:
        fc = (f'{music}[m];'
              '[0:a]aformat=sample_fmts=fltp:sample_rates=48000:channel_layouts=stereo,asplit=2[voz][guia];'
              f'[m][guia]sidechaincompress=threshold={thr}:ratio={ratio}:level_sc={lsc}:attack=15:release=450:makeup=1[mb];'
              '[voz][mb]amix=inputs=2:duration=first:dropout_transition=0,volume=2,alimiter=limit=0.97:level=disabled[a]')
    else:
        fc = f'{music},apad=whole_dur={dur:.3f},alimiter=limit=0.97:level=disabled[a]'
    cmd += ['-filter_complex', fc, '-map', '0:v', '-map', '[a]', '-c:v', 'copy',
            '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', '-t', f'{dur:.3f}',
            '-movflags', '+faststart', out_path]
    return cmd


def mix_into(engine, video_path: str, opts, on_progress: Optional[Callable] = None, log=None) -> Dict:
    """Mezcla la música en video_path (lo reemplaza). Devuelve {'music': nombre} o {'music_error': ...}."""
    track = pick_track(getattr(opts, 'music_path', ''))
    if not track:
        return {'music_error': 'No se encontró la canción elegida (o la carpeta no tiene audios).'}
    ff = engine.ffmpeg_exe
    dur = engine._probe_duration(video_path)
    tmp = os.path.splitext(video_path)[0] + '.musica.mp4'
    cmd = build_mix_cmd(ff, video_path, track, tmp, dur,
                        volume=getattr(opts, 'music_volume', 'normal'),
                        duck=getattr(opts, 'music_duck', 'normal'),
                        fade=bool(getattr(opts, 'music_fade', True)),
                        loop=bool(getattr(opts, 'music_loop', True)),
                        start=float(getattr(opts, 'music_start', 0) or 0),
                        video_has_audio=has_audio_stream(ff, video_path))
    if log:
        log(f"ETAPA: música de fondo ({os.path.basename(track)})")
        log('  cmd: ' + ' '.join(cmd))
    if on_progress:
        try:
            on_progress({'percent': 99.0, 'current_sec': dur, 'total_sec': dur,
                         'desc': 'Agregando la música de fondo…'})
        except Exception:
            pass
    try:
        r = engine._run_tracked(cmd, timeout=max(120, dur * 3), startupinfo=_si())
        rc, err = r.returncode, (r.stderr or b'').decode('utf-8', 'replace')
    except subprocess.TimeoutExpired:
        rc, err = -1, 'tiempo agotado'
    if rc != 0 or not os.path.exists(tmp) or os.path.getsize(tmp) < 1000:
        try:
            os.remove(tmp)
        except Exception:
            pass
        if log:
            log(f"  música: error {rc}: {(err or '')[-600:]}")
        return {'music_error': 'No se pudo agregar la música; el video quedó sin ella.'}
    os.replace(tmp, video_path)
    return {'music': os.path.basename(track)}


def preview_clip(ffmpeg_exe: str, path: str, start: float = 0.0, seconds: float = 25.0) -> str:
    """Un fragmento de la canción en MP3 (data URL) para escucharla dentro de la app."""
    track = pick_track(path, advance=False)
    if not track:
        return ''
    cmd = [ffmpeg_exe, '-hide_banner', '-nostdin', '-v', 'error']
    if start and start > 0:
        cmd += ['-ss', f'{float(start):.2f}']
    cmd += ['-i', track, '-t', f'{seconds:.1f}', '-vn', '-ac', '2', '-ar', '44100', '-b:a', '128k', '-f', 'mp3', '-']
    try:
        r = subprocess.run(cmd, stdin=subprocess.DEVNULL, capture_output=True, timeout=60, startupinfo=_si())
        if r.returncode == 0 and r.stdout:
            return 'data:audio/mpeg;base64,' + base64.b64encode(r.stdout).decode('ascii')
    except Exception:
        pass
    return ''
