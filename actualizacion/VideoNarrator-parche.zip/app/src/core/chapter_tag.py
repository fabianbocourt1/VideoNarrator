"""
Etiqueta de capítulo (VideoNarrator v9.3).

Dibuja la etiqueta "CAPÍTULO N" (+ título y "PARTE N" opcionales) al estilo de las portadas de
historias: letras gruesas blancas/amarillas con borde negro y sombra sobre una franja de brocha.
Se pone encima del primer clip unos segundos, con entrada de golpe (zoom rápido) o suave.
"""
import os
import random
import subprocess
from typing import Optional, Tuple

from PIL import Image, ImageDraw, ImageFilter, ImageFont

FONTS_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'ui', 'fonts')
FONT = os.path.join(FONTS_DIR, 'Montserrat-Variable.ttf')
FONT_IT = os.path.join(FONTS_DIR, 'Montserrat-Italic-Variable.ttf')
FONT_FALLBACK = os.path.join(FONTS_DIR, 'BigShoulders-Bold.ttf')

DESIGN_W = 1080
WHITE = (255, 255, 255, 255)
BLACK = (10, 10, 10, 255)

# Esquemas de color: franja, color de la última línea del título, franja de "PARTE", rayas de velocidad
SCHEMES = {
    'rojo_azul': {'band': ((232, 16, 22), (176, 0, 6)), 'accent': (255, 228, 0, 255),
                  'part': ((0, 240, 255), (0, 196, 222)), 'lines': [(0, 240, 255, 255), (230, 20, 20, 255), (0, 240, 255, 255)]},
    'rojo': {'band': ((232, 16, 22), (176, 0, 6)), 'accent': (255, 228, 0, 255),
             'part': ((255, 236, 40), (255, 205, 0)), 'lines': [(255, 228, 0, 255), (230, 20, 20, 255), (255, 228, 0, 255)]},
    'azul': {'band': ((12, 44, 96), (4, 16, 44)), 'accent': (0, 240, 255, 255),
             'part': ((0, 240, 255), (0, 196, 222)), 'lines': [(0, 240, 255, 255), (255, 255, 255, 255), (0, 240, 255, 255)]},
}


def _font(size: int, italic: bool = False) -> ImageFont.FreeTypeFont:
    path = FONT_IT if italic else FONT
    try:
        f = ImageFont.truetype(path, size)
        f.set_variation_by_axes([900])          # Montserrat Black
        return f
    except Exception:
        return ImageFont.truetype(FONT_FALLBACK, int(size * 1.15))


def _fit(text: str, max_w: int, start: int, italic: bool = False, min_size: int = 40):
    size = start
    while size > min_size:
        f = _font(size, italic)
        b = f.getbbox(text, stroke_width=max(4, size // 11))
        if b[2] - b[0] <= max_w:
            return f
        size -= 4
    return _font(min_size, italic)


def _brush(size, color_a, color_b, seed, jag=22):
    """Franja de brocha: bordes irregulares, puntas deshilachadas y vetas suaves."""
    w, h = size
    rnd = random.Random(seed)
    pad = jag * 2
    img = Image.new('RGBA', (w + pad * 2, h + pad * 2), (0, 0, 0, 0))
    mask = Image.new('L', img.size, 0)
    d = ImageDraw.Draw(mask)
    pts, step = [], 14
    for x in range(0, w + 1, step):
        pts.append((pad + x, pad + rnd.uniform(-jag * .5, jag * .6)))
    for y in range(0, h + 1, step):
        pts.append((pad + w + rnd.uniform(-jag * 1.4, jag * .9), pad + y))
    for x in range(w, -1, -step):
        pts.append((pad + x, pad + h + rnd.uniform(-jag * .6, jag * .5)))
    for y in range(h, -1, -step):
        pts.append((pad + rnd.uniform(-jag * .9, jag * 1.4), pad + y))
    d.polygon(pts, fill=255)
    for _ in range(int(w / 9)):
        side = rnd.choice((0, 1))
        y = pad + rnd.uniform(0, h)
        x0 = pad + (w if side else 0)
        ln = rnd.uniform(jag, jag * 3.2)
        d.line([(x0, y), (x0 + (ln if side else -ln), y + rnd.uniform(-3, 3))], fill=255, width=rnd.randint(2, 6))
    mask = mask.filter(ImageFilter.GaussianBlur(0.8))
    grad = Image.new('RGBA', img.size)
    gd = ImageDraw.Draw(grad)
    for y in range(img.size[1]):
        t = y / max(1, img.size[1] - 1)
        c = tuple(int(color_a[i] + (color_b[i] - color_a[i]) * t) for i in range(3))
        gd.line([(0, y), (img.size[0], y)], fill=c + (255,))
    for _ in range(int(h / 9)):
        y = rnd.uniform(pad, pad + h)
        x0 = rnd.uniform(pad, pad + w * .7)
        x1 = x0 + rnd.uniform(w * .1, w * .5)
        col = (0, 0, 0, rnd.randint(10, 26)) if rnd.random() < .55 else (255, 255, 255, rnd.randint(8, 18))
        gd.line([(x0, y), (x1, y)], fill=col, width=rnd.randint(2, 6))
    img.paste(grad, (0, 0), mask)
    return img, pad


def _text_layer(text, font, fill, stroke):
    b = font.getbbox(text, stroke_width=stroke)
    w, h = b[2] - b[0], b[3] - b[1]
    m = 30
    lay = Image.new('RGBA', (w + m * 2, h + m * 2), (0, 0, 0, 0))
    ImageDraw.Draw(lay).text((m - b[0], m - b[1]), text, font=font, fill=fill, stroke_width=stroke, stroke_fill=BLACK)
    sh = Image.new('RGBA', lay.size, (0, 0, 0, 0))
    sh.paste((0, 0, 0, 170), mask=lay.split()[3])
    sh = sh.filter(ImageFilter.GaussianBlur(4))
    out = Image.new('RGBA', (lay.size[0] + 10, lay.size[1] + 12), (0, 0, 0, 0))
    out.alpha_composite(sh, (9, 11))
    out.alpha_composite(lay, (0, 0))
    return out


def split_title(title: str):
    words = (title or '').upper().split()
    if len(words) <= 2:
        return [' '.join(words)] if words else []
    best, cut = 10 ** 9, 1
    for k in range(1, len(words)):
        a, b = ' '.join(words[:k]), ' '.join(words[k:])
        score = abs(len(a) - len(b)) + (0 if len(a) <= len(b) + 4 else 6)
        if score < best:
            best, cut = score, k
    return [' '.join(words[:cut]), ' '.join(words[cut:])]


def render_block(chapter, title: str = '', part=0, scheme: str = 'rojo_azul', seed: int = 7) -> Image.Image:
    """La etiqueta recortada a su tamaño (diseño a 1080 px de ancho), fondo transparente."""
    sc = SCHEMES.get(scheme) or SCHEMES['rojo_azul']
    canvas = Image.new('RGBA', (DESIGN_W, 1200), (0, 0, 0, 0))
    lines = [(f'CAPÍTULO {chapter}', WHITE)]
    tl = split_title(title)
    for k, t in enumerate(tl):
        lines.append((t, sc['accent'] if (k == len(tl) - 1 and len(tl) > 1) else WHITE))
    f_cap = _fit(lines[0][0], 900, 126)
    f_tit = None
    for txt, _c in lines[1:]:
        f = _fit(txt, 980, 132)
        f_tit = f if f_tit is None or f.size < f_tit.size else f_tit
    layers = [_text_layer(txt, f_cap if k == 0 else f_tit, col, max(6, (f_cap if k == 0 else f_tit).size // 9))
              for k, (txt, col) in enumerate(lines)]
    gap = -22
    block_h = sum(l.size[1] for l in layers) + gap * (len(layers) - 1)
    band_h = block_h - 30
    top = 90
    band, bpad = _brush((DESIGN_W - 60, band_h), sc['band'][0], sc['band'][1], seed, jag=26)
    canvas.alpha_composite(band, (30 - bpad, top - bpad))
    y = top - 18
    for lay in layers:
        canvas.alpha_composite(lay, ((DESIGN_W - lay.size[0]) // 2 + 4, y))
        y += lay.size[1] + gap
    try:
        part = int(part or 0)
    except (TypeError, ValueError):
        part = 0
    if part > 0:
        pt = f'PARTE {part}'
        f = _fit(pt, 560, 92, italic=True)
        b = f.getbbox(pt)
        tw, th = b[2] - b[0], b[3] - b[1]
        strip, spad = _brush((tw + 150, th + 44), sc['part'][0], sc['part'][1], seed + 3, jag=16)
        sy = top + band_h - 6
        sx = (DESIGN_W - strip.size[0]) // 2
        d = ImageDraw.Draw(canvas)
        cy = sy + strip.size[1] // 2
        for (dy, ln), col in zip([(-16, 230), (0, 270), (16, 210)], sc['lines']):
            for side in (-1, 1):
                x_in = sx + spad + 8 if side < 0 else sx + strip.size[0] - spad - 8
                x_out = x_in + side * ln
                d.line([(x_in, cy + dy), (x_out, cy + dy)], fill=col, width=7)
                d.line([(x_in, cy + dy + 4), (x_out, cy + dy + 4)], fill=(0, 0, 0, 120), width=2)
        canvas.alpha_composite(strip, (sx, sy))
        txt = Image.new('RGBA', (tw + 40, th + 40), (0, 0, 0, 0))
        ImageDraw.Draw(txt).text((20 - b[0], 20 - b[1]), pt, font=f, fill=BLACK)
        canvas.alpha_composite(txt, ((DESIGN_W - txt.size[0]) // 2, sy + (strip.size[1] - txt.size[1]) // 2))
    bbox = canvas.getbbox() or (0, 0, DESIGN_W, 10)
    return canvas.crop((0, bbox[1], DESIGN_W, bbox[3]))


RES = {'vertical': (1080, 1920), 'square': (1080, 1080), 'horizontal': (1920, 1080)}


def base_scale(W: int, H: int) -> float:
    """Tamaño normal de la etiqueta en un video W x H (diseño a 1080 px de ancho)."""
    return min(1.0, H / 1920 * 1.6) * (W / DESIGN_W if W < DESIGN_W else 1.0)


def preset_y(W: int, H: int, block_h: int, position: str, scale: float = 1.0) -> float:
    """Centro vertical (0..1) de los atajos Arriba y Centro."""
    if position == 'center':
        return 0.40
    f = base_scale(W, H) * scale
    return (30 * f + block_h * f / 2) / H


def placement(W: int, H: int, block_h: int, position: str, x: Optional[float] = None, y: Optional[float] = None,
              scale: float = 1.0) -> Tuple[float, int, int]:
    """Escala y centro (cx, cy) en píxeles. position 'free' usa x, y (0..1, centro de la etiqueta)."""
    scale = max(0.3, min(2.5, float(scale or 1.0)))
    f = base_scale(W, H) * scale
    if position == 'free' and x is not None and y is not None:
        cx, cy = float(x) * W, float(y) * H
    else:
        cx, cy = W / 2, preset_y(W, H, block_h, position, scale) * H
    return f, int(round(cx)), int(round(cy))


def rotated(img: Image.Image, deg: float) -> Image.Image:
    """Gira la etiqueta (grados, positivo = a la derecha)."""
    deg = max(-180.0, min(180.0, float(deg or 0)))
    if abs(deg) < 0.05:
        return img
    return img.rotate(-deg, resample=Image.BICUBIC, expand=True)


def preview_frame(chapter, title, part, scheme, position, W=540, H=960) -> Image.Image:
    """La etiqueta colocada sobre un cuadro transparente del tamaño de la vista previa."""
    blk = render_block(chapter, title, part, scheme)
    f, cx, cy = placement(W * 2, H * 2, blk.size[1], position)
    k = f / 2
    blk = blk.resize((max(1, int(blk.size[0] * k)), max(1, int(blk.size[1] * k))), Image.LANCZOS)
    out = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    out.alpha_composite(blk, (int(cx / 2 - blk.size[0] / 2), int(cy / 2 - blk.size[1] / 2)))
    return out


def _startupinfo():
    if os.name == 'nt':
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        return si
    return None


def apply(ff: str, clip_path: str, out_path: str, png_path: str, clip_dur: float, W: int, H: int,
          position: str = 'top', duration: float = 2.5, entrance: str = 'golpe', threads: int = 2,
          x: Optional[float] = None, y: Optional[float] = None, scale: float = 1.0, block_h: Optional[int] = None) -> Optional[str]:
    """Pone la etiqueta sobre el primer clip (solo se vuelve a codificar ese clip).
    png_path ya viene girada; block_h es la altura SIN girar (para los atajos Arriba/Centro)."""
    with Image.open(png_path) as im:
        bw, bh = im.size
    f, cx, cy = placement(W, H, block_h or bh, position, x, y, scale)
    d = max(0.6, min(float(duration or 2.5), clip_dur))
    base_w = max(2, int(bw * f) // 2 * 2)
    if entrance == 'suave':
        scale = f"scale={base_w}:-2"
        fin = "fade=t=in:st=0:d=0.30:alpha=1"
    else:                                     # golpe: entra grande y se asienta en 0,2 s
        scale = f"scale=w='trunc({base_w}*(1+0.28*max(0\\,1-t/0.2))/2)*2':h=-2:eval=frame"
        fin = "fade=t=in:st=0:d=0.10:alpha=1"
    fout = f"fade=t=out:st={max(0.0, d - 0.30):.2f}:d=0.30:alpha=1"
    fc = (f"[1:v]format=rgba,{scale},{fin},{fout}[t];"
          f"[0:v][t]overlay=x='{cx}-w/2':y='{cy}-h/2':eval=frame:enable='lte(t,{d:.2f})'[v]")
    cmd = [ff, '-y', '-nostdin', '-threads', str(threads), '-i', clip_path, '-loop', '1', '-t', f'{d:.2f}', '-i', png_path,
           '-filter_complex', fc, '-map', '[v]', '-t', f'{clip_dur:.3f}',
           '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18', '-pix_fmt', 'yuv420p', '-an', out_path]
    r = subprocess.run(cmd, stdin=subprocess.DEVNULL, capture_output=True, timeout=600, startupinfo=_startupinfo())
    if r.returncode != 0 or not os.path.exists(out_path) or os.path.getsize(out_path) == 0:
        raise RuntimeError('No se pudo poner la etiqueta de capítulo: ' + (r.stderr or b'').decode('utf-8', 'replace')[-300:])
    return out_path
