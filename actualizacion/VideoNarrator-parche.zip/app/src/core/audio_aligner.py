"""
AudioAligner — Sincronización precisa audio↔guion con IA (faster-whisper).
Usa word-level timestamps para alinear cada clip al milisegundo.
"""

import os
import re
import difflib
import unicodedata
from typing import List, Optional, Dict, Any


def _normalize_word(text: str) -> str:
    """Normaliza una palabra para comparación fuzzy (sin acentos, minúsculas, solo alfanumérico)."""
    if not text:
        return ""
    t = text.lower()
    t = unicodedata.normalize('NFD', t)
    t = ''.join(c for c in t if unicodedata.category(c) != 'Mn')
    return re.sub(r'[^a-z0-9]', '', t)


def align_script_to_audio(audio_path: str, clip_texts: List[str], on_progress=None) -> Optional[Dict[str, Any]]:
    """
    Transcribe el audio con faster-whisper y alinea las palabras del guion
    con los timestamps detectados.

    Args:
        audio_path: Ruta al archivo de audio
        clip_texts: Lista de textos por clip (ya parseados)
        on_progress: Callback opcional para progreso

    Returns:
        {
            'clips': [{'start': float, 'duration': float, 'end': float}, ...],
            'language': str,
            'whisper_available': True
        }
        o None si faster-whisper no está disponible o falla.
    """
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        return None

    if not audio_path or not os.path.exists(audio_path):
        return None
    if not clip_texts or all(not t.strip() for t in clip_texts):
        return None

    # ── 1. Transcribir con Whisper (priorizar modelo 'small' si está disponible) ──
    try:
        from src.core.subtitles import load_model      # v8.8: mismo modelo y misma descarga que los subtítulos
        model = load_model()
        if model is None:
            return None

        segments, info = model.transcribe(
            audio_path,
            word_timestamps=True,
        )

        detected_language = info.language if info else ''

        # Extraer todas las palabras con timestamps
        whisper_words = []
        for segment in segments:
            if segment.words:
                for w in segment.words:
                    raw = w.word.strip()
                    if raw:
                        whisper_words.append({
                            'word': raw,
                            'norm': _normalize_word(raw),
                            'start': round(w.start, 3),
                            'end': round(w.end, 3)
                        })

        if not whisper_words:
            return None

    except Exception:
        return None

    # ── 2. Construir mapa de palabras del guion ──
    script_words = []
    clip_ranges = []  # (start_idx, end_idx) por clip
    for clip_idx, text in enumerate(clip_texts):
        words = text.split()
        start_idx = len(script_words)
        for word in words:
            script_words.append({
                'word': word,
                'norm': _normalize_word(word),
                'clip_idx': clip_idx
            })
        end_idx = len(script_words) - 1 if words else start_idx
        clip_ranges.append((start_idx, end_idx))

    if not script_words:
        return None

    # ── 3. Alinear con SequenceMatcher (filtrando falsos anclajes de palabras cortas) ──
    whisper_norms = [w['norm'] for w in whisper_words]
    script_norms = [w['norm'] for w in script_words]

    matcher = difflib.SequenceMatcher(None, script_norms, whisper_norms, autojunk=False)
    blocks = matcher.get_matching_blocks()

    # Crear puntos de anclaje: script_idx → whisper_idx
    # Evitar que palabras monosílabas sueltas (<=2 letras como 'de', 'la', 'el', 'y', 'a')
    # creen falsos anclajes saltando a otras partes del audio
    anchor_points = {}
    for block in blocks:
        s_start, w_start, size = block
        if size == 0:
            continue
        for i in range(size):
            s_i = s_start + i
            w_i = w_start + i
            word_str = script_norms[s_i]
            if size == 1 and len(word_str) <= 2:
                continue  # Descartar preposiciones aisladas
            anchor_points[s_i] = w_i

    if not anchor_points:
        return None

    # ── 4. Interpolar palabras no alineadas de forma continua ──
    sorted_anchors = sorted(anchor_points.keys())
    estimated_mapping = {}

    for s_idx in range(len(script_words)):
        if s_idx in anchor_points:
            estimated_mapping[s_idx] = anchor_points[s_idx]
        else:
            prev_anchor = None
            next_anchor = None
            for a in sorted_anchors:
                if a < s_idx:
                    prev_anchor = a
                elif a > s_idx and next_anchor is None:
                    next_anchor = a

            if prev_anchor is not None and next_anchor is not None:
                frac = (s_idx - prev_anchor) / (next_anchor - prev_anchor)
                pw = anchor_points[prev_anchor]
                nw = anchor_points[next_anchor]
                est = max(0, min(int(round(pw + frac * (nw - pw))), len(whisper_words) - 1))
                estimated_mapping[s_idx] = est
            elif prev_anchor is not None:
                offset = s_idx - prev_anchor
                est = min(anchor_points[prev_anchor] + offset, len(whisper_words) - 1)
                estimated_mapping[s_idx] = est
            elif next_anchor is not None:
                offset = next_anchor - s_idx
                est = max(anchor_points[next_anchor] - offset, 0)
                estimated_mapping[s_idx] = est

    # ── 5. Calcular puntos de corte precisos en silencios reales ──
    from src.utils.ffmpeg_locator import get_audio_duration
    try:
        total_audio_duration = get_audio_duration(audio_path)
    except Exception:
        total_audio_duration = whisper_words[-1]['end'] + 0.5

    num_clips = len(clip_texts)
    cut_points = [0.0]  # Inicio del primer clip

    for clip_idx in range(num_clips - 1):
        clip_start, clip_end = clip_ranges[clip_idx]
        next_clip_start, next_clip_end = clip_ranges[clip_idx + 1]

        # Buscar la palabra con timestamp más confiable al final del clip actual
        word_end_time = None
        for s_w in range(clip_end, clip_start - 1, -1):
            if s_w in anchor_points:
                word_end_time = whisper_words[anchor_points[s_w]]['end']
                break
        if word_end_time is None:
            if clip_end in estimated_mapping:
                word_end_time = whisper_words[estimated_mapping[clip_end]]['end']
            else:
                word_end_time = cut_points[-1] + 0.5

        # Buscar la palabra con timestamp más confiable al inicio del siguiente clip
        next_word_start = None
        for s_w in range(next_clip_start, next_clip_end + 1):
            if s_w in anchor_points:
                next_word_start = whisper_words[anchor_points[s_w]]['start']
                break
        if next_word_start is None:
            if next_clip_start in estimated_mapping:
                next_word_start = whisper_words[estimated_mapping[next_clip_start]]['start']
            else:
                next_word_start = word_end_time + 0.1

        # Cortar en el silencio natural entre frases
        if next_word_start > word_end_time:
            gap = next_word_start - word_end_time
            cut = word_end_time + min(0.06, gap * 0.5)
        else:
            cut = word_end_time

        # Protección: evitar cortes que retrocedan
        if cut <= cut_points[-1] + 0.3:
            cut = cut_points[-1] + 0.3

        cut_points.append(round(cut, 3))

    cut_points.append(round(total_audio_duration, 3))

    # ── 6. ANTI-TRABAZÓN: Suavizado Inteligente de Ráfagas y Clips Congelados ──
    # Si Whisper se perdió en un tramo, crea clips al mínimo (pasan volando)
    # seguidos de un clip gigante trabado. Detectamos estos tramos y los suavizamos.
    word_counts = [max(len(t.split()), 1) for t in clip_texts]
    total_words = sum(word_counts)
    avg_spw = total_audio_duration / max(total_words, 1)

    durs = [cut_points[i + 1] - cut_points[i] for i in range(num_clips)]

    # Detectar y suavizar zonas anómalas
    idx = 0
    while idx < num_clips:
        exp_d = word_counts[idx] * avg_spw
        # Clip excesivamente comprimido o clip al mínimo
        if durs[idx] < max(0.75, exp_d * 0.45):
            z_start = idx
            while idx < num_clips and durs[idx] < max(0.85, word_counts[idx] * avg_spw * 0.55):
                idx += 1
            z_end = idx # exclusivo

            # Si hay clips comprimidos seguidos de un clip inflado (trabado)
            if z_end < num_clips and durs[z_end] > max(2.5, word_counts[z_end] * avg_spw * 1.5):
                z_end += 1 # incluir el clip trabado para redistribuir el tiempo

            if (z_end - z_start >= 2) or (z_end > z_start and z_end < num_clips + 1):
                # Redistribuir el tiempo total de la zona en proporción a las palabras de cada clip
                t_total_zone = cut_points[z_end] - cut_points[z_start]
                w_total_zone = sum(word_counts[z_start:z_end])
                if w_total_zone > 0 and t_total_zone > 0:
                    curr_t = cut_points[z_start]
                    for k in range(z_start, z_end):
                        new_d = (word_counts[k] / w_total_zone) * t_total_zone
                        new_d = max(new_d, 0.7)
                        durs[k] = new_d
                        cut_points[k] = round(curr_t, 3)
                        curr_t += new_d
                    # Ajustar último punto del tramo si hubo desfase por mínimos
                    if z_end < len(cut_points):
                        diff = curr_t - cut_points[z_end]
                        if abs(diff) > 0.02 and (z_end - z_start) > 0:
                            adj = diff / (z_end - z_start)
                            curr_t = cut_points[z_start]
                            for k in range(z_start, z_end):
                                durs[k] = max(0.7, durs[k] - adj)
                                cut_points[k] = round(curr_t, 3)
                                curr_t += durs[k]
        else:
            idx += 1

    # Asegurar duración mínima universal de 0.7s para que ninguna imagen sea flash
    for i in range(num_clips):
        if durs[i] < 0.7:
            shortfall = 0.7 - durs[i]
            durs[i] = 0.7
            # Compensar restando al clip más largo vecino
            if i + 1 < num_clips and durs[i + 1] > 0.7 + shortfall + 0.3:
                durs[i + 1] -= shortfall
            elif i > 0 and durs[i - 1] > 0.7 + shortfall + 0.3:
                durs[i - 1] -= shortfall

    # Reconstruir cut_points exactos y continuos
    cur_time = 0.0
    for i in range(num_clips):
        cut_points[i] = round(cur_time, 3)
        cur_time += durs[i]
    cut_points[num_clips] = round(total_audio_duration, 3)

    # ── 7. Construir resultado final exacto ──
    result_clips = []
    for i in range(num_clips):
        start = cut_points[i]
        end = cut_points[i + 1] if i + 1 < len(cut_points) else total_audio_duration
        dur = max(round(end - start, 3), 0.7)
        result_clips.append({
            'start': round(start, 3),
            'duration': round(dur, 3),
            'end': round(start + dur, 3)
        })

    return {
        'clips': result_clips,
        'language': detected_language,
        'whisper_available': True
    }
