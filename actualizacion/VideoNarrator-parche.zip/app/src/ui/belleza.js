/* =====================================================================
   VideoNarrator v8.0 — Embellecimiento
   Se carga después de app.js y ayuda.js. No cambia cómo funciona nada:
   solo agrega luz y movimiento encima de lo que ya existe.
     ① luces del fondo        ④ entrada de las escenas   ⑤ destello al encender
     ⑦ pantalla de render     ⑨ celebración al terminar  ⑪ números que cuentan
   (② ③ ⑥ ⑧ ⑩ ⑫ son estilos en styles.css; ⑧ y ⑥ también en index.html)
   ===================================================================== */
(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const root = document.documentElement;
  const getState = () => { try { return state; } catch (e) { return null; } };   // "state" vive en app.js
  const clipsData = () => { const s = getState(); return (s && Array.isArray(s.clipsData)) ? s.clipsData : []; };
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"]/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[ch]));

  // ── ① Luces del fondo ───────────────────────────────────────────────
  (function aurora() {
    const a = document.createElement("div");
    a.id = "vnAurora";
    a.setAttribute("aria-hidden", "true");
    a.innerHTML = "<i></i><i></i><i></i>";
    const grain = $("vnGrain");
    if (grain) grain.before(a); else document.body.prepend(a);
    // En pausa con la ventana minimizada o en segundo plano (no gasta nada)
    const vis = () => root.classList.toggle("vn-idle", document.hidden);
    document.addEventListener("visibilitychange", vis);
    vis();
  })();

  // ── ④ Entrada escalonada de las escenas ─────────────────────────────
  (function entrance() {
    const list = $("clipsList");
    if (!list) return;
    let prev = new Set();
    let started = 0;
    new MutationObserver(() => {
      const cards = Array.from(list.querySelectorAll(".clip-card"));
      const texts = cards.map(c => (c.querySelector(".clip-text-snippet") || c).textContent.trim().slice(0, 80));
      const known = texts.filter(t => prev.has(t)).length;
      const now = performance.now();
      // Solo cuando llega una historia nueva (no en cada pequeño cambio del editor)
      if (cards.length && (prev.size === 0 || known < texts.length * 0.3)) started = now;
      // Si la lista se vuelve a dibujar mientras entran, la animación sigue donde iba
      const off = now - started;
      if (cards.length && started && off < 1600) {
        cards.forEach((c, i) => {
          c.style.setProperty("--vn-i", Math.min(i, 14));
          c.style.setProperty("--vn-off", Math.round(off) + "ms");
          c.classList.add("vn-enter");
          const done = (e) => { if (e.target !== c || e.animationName !== "vnCardIn") return; c.classList.remove("vn-enter"); c.removeEventListener("animationend", done); };
          c.addEventListener("animationend", done);
        });
      }
      prev = new Set(texts);
    }).observe(list, { childList: true });
  })();

  // ── ⑤ Destello al encender + tarjetas de material con contenido ─────
  document.addEventListener("change", (e) => {
    const t = e.target;
    if (!t || !t.matches || !t.checked || !t.matches(".card-fx .card-header input[type=checkbox]")) return;
    const card = t.closest(".card-fx");
    if (!card) return;
    card.classList.remove("vn-flash");
    void card.offsetWidth;
    card.classList.add("vn-flash");
    setTimeout(() => card.classList.remove("vn-flash"), 900);
  }, true);

  (function materialOn() {
    const audio = $("audioCard"), images = $("imagesCard");
    const script = document.querySelector(".card-input.card-script");
    const area = $("scriptInput");
    const sync = () => {
      const s = getState() || {};
      if (audio) audio.classList.toggle("vn-has", !!s.audioPath);
      if (images) images.classList.toggle("vn-has", !!(s.imagesFolder && (!Array.isArray(s.imagesFolder) || s.imagesFolder.length)));
      if (script) script.classList.toggle("vn-has", !!(area && area.value.trim()));
    };
    if (area) area.addEventListener("input", sync);
    setInterval(sync, 900);
    sync();
  })();

  // ── ⑪ Números que suben contando ────────────────────────────────────
  (function counters() {
    const parse = (txt) => {
      txt = String(txt || "").trim();
      if (/^\d+$/.test(txt)) return { v: parseInt(txt, 10), fmt: (n) => String(Math.round(n)) };
      const m = txt.match(/^(\d+):(\d{2})(?::(\d{2}))?$/);
      if (m) {
        const hms = m[3] !== undefined;
        const v = hms ? (+m[1]) * 3600 + (+m[2]) * 60 + (+m[3]) : (+m[1]) * 60 + (+m[2]);
        const p2 = (n) => String(n).padStart(2, "0");
        return { v, fmt: (n) => { n = Math.round(n); return hms ? `${p2(Math.floor(n / 3600))}:${p2(Math.floor(n / 60) % 60)}:${p2(n % 60)}` : `${p2(Math.floor(n / 60))}:${p2(n % 60)}`; } };
      }
      return null;
    };
    ["metricTotalClips", "metricTotalWords", "metricTotalDuration"].forEach((id) => {
      const el = $(id);
      if (!el) return;
      const pill = el.closest(".metric-pill");
      let shown = parse(el.textContent);
      let last = el.textContent;
      let token = 0;
      const write = (t) => { last = t; el.textContent = t; };
      new MutationObserver(() => {
        if (el.textContent === last) return;          // lo escribimos nosotros
        const target = parse(el.textContent);
        const from = shown ? shown.v : 0;
        if (!target || target.v === from || document.hidden) { shown = target; last = el.textContent; return; }
        const my = ++token, t0 = performance.now(), dur = 900;
        if (pill) pill.classList.add("vn-tick");
        const step = () => {
          if (my !== token) return;
          const k = Math.min(1, (performance.now() - t0) / dur), e = 1 - Math.pow(1 - k, 3);
          write(target.fmt(from + (target.v - from) * e));
          if (k < 1) requestAnimationFrame(step);
          else { shown = target; if (pill) setTimeout(() => pill.classList.remove("vn-tick"), 250); }
        };
        write(target.fmt(from));
        requestAnimationFrame(step);
      }).observe(el, { childList: true, characterData: true, subtree: true });
    });
  })();

  // ── ⑦ Pantalla de render tipo cine ─────────────────────────────────
  const C = 2 * Math.PI * 54;
  const STEPS = ["Audio de las escenas", "Escenas con movimiento", "Uniendo con transiciones", "Subtítulos, música y mezcla final"];
  let isPreview = false;
  const rc = {};
  (function cine() {
    const modal = $("renderModal"), sr = $("stateRendering");
    if (!modal || !sr) return;
    const content = modal.querySelector(".modal-content");
    sr.classList.add("vn-cine");

    rc.bg = document.createElement("div");
    rc.bg.className = "vn-rbg";
    modal.insertBefore(rc.bg, modal.firstChild);

    const grid = document.createElement("div");
    grid.className = "vn-rgrid";
    grid.innerHTML = `<div class="vn-rposter"><span class="vn-rposter-lbl"></span></div><div class="vn-rinfo"></div>`;
    const info = grid.querySelector(".vn-rinfo");
    rc.poster = grid.querySelector(".vn-rposter");
    rc.plabel = grid.querySelector(".vn-rposter-lbl");
    while (sr.firstChild) info.appendChild(sr.firstChild);
    sr.appendChild(grid);

    // Anillo con el porcentaje dentro
    const big = info.querySelector(".render-percent-big");
    const ring = document.createElement("div");
    ring.className = "vn-ringbox";
    ring.innerHTML = `<svg viewBox="0 0 120 120" aria-hidden="true"><circle class="vn-ring-bg" cx="60" cy="60" r="54"/><circle class="vn-ring-fg" cx="60" cy="60" r="54" stroke-dasharray="${C.toFixed(2)}" stroke-dashoffset="${C.toFixed(2)}"/></svg><div class="vn-ring-mid"></div>`;
    if (big) { ring.querySelector(".vn-ring-mid").appendChild(big); }
    const lbl = document.createElement("small");
    lbl.className = "vn-ring-lbl";
    ring.querySelector(".vn-ring-mid").appendChild(lbl);
    info.insertBefore(ring, info.firstChild);
    rc.ring = ring.querySelector(".vn-ring-fg");
    rc.ringLbl = lbl;

    rc.title = document.createElement("div");
    rc.title.className = "vn-rtitle";
    rc.sub = document.createElement("div");
    rc.sub.className = "vn-rsub";
    rc.sub.textContent = "Puedes seguir usando la PC: te aviso cuando esté listo.";
    ring.after(rc.title, rc.sub);

    rc.steps = document.createElement("ol");
    rc.steps.className = "vn-steps";
    rc.steps.innerHTML = STEPS.map(s => `<li><i></i><span>${s}</span></li>`).join("");
    const tag = $("renderEncoderTag");
    (tag || rc.sub).after(rc.steps);

    // Saber si es vista previa
    const pv = $("btnPreview"), hd = $("btnRender");
    if (pv) pv.addEventListener("click", () => { isPreview = true; }, true);
    if (hd) hd.addEventListener("click", () => { isPreview = false; }, true);

    // Al abrir la ventana de render: todo desde cero
    let wasOn = false;
    new MutationObserver(() => {
      const on = modal.classList.contains("active") && !sr.classList.contains("hidden");
      root.classList.toggle("vn-calm", modal.classList.contains("active"));
      if (content) content.classList.toggle("vn-wide", on);
      if (on && !wasOn) resetCine();
      wasOn = on;
    }).observe(modal, { attributes: true, attributeFilter: ["class"], subtree: true });
  })();

  function thumbs() { return clipsData().map(c => c && c.thumbnail).filter(Boolean); }
  function setPoster(i, total) {
    const t = thumbs();
    if (!rc.poster) return;
    if (!t.length) { rc.poster.style.backgroundImage = ""; rc.bg.style.backgroundImage = ""; rc.plabel.textContent = ""; return; }
    const k = Math.max(0, Math.min(t.length - 1, i));
    const url = `url("${t[k].replace(/"/g, "%22")}")`;
    if (rc.poster.style.backgroundImage !== url) { rc.poster.style.backgroundImage = url; rc.bg.style.backgroundImage = url; }
    rc.plabel.textContent = total ? `Escena ${Math.min(i + 1, total)} de ${total}` : "";
  }
  function setStep(n, extra) {
    if (!rc.steps) return;
    rc.steps.querySelectorAll("li").forEach((li, i) => {
      li.className = i < n ? "ok" : i === n ? "now" : "";
      li.querySelector("span").textContent = STEPS[i] + (i === n && extra ? ` ${extra}` : "");
    });
  }
  function setRing(p) { if (rc.ring) rc.ring.setAttribute("stroke-dashoffset", (C * (1 - Math.max(0, Math.min(100, p)) / 100)).toFixed(2)); }
  function resetCine() {
    const s = getState() || {};
    const res = s.resolution || "vertical";
    const land = res === "horizontal", sq = res === "square";
    if (rc.poster) rc.poster.parentElement.classList.toggle("land", land);
    if (rc.poster) rc.poster.style.aspectRatio = land ? "16 / 9" : sq ? "1 / 1" : "9 / 16";
    const name = ($("projName") || {}).textContent || "";
    rc.title.textContent = (name && !/sin t[ií]tulo/i.test(name)) ? name : (isPreview ? "Vista previa" : "Tu video");
    rc.ringLbl.textContent = isPreview ? "VISTA PREVIA" : "CREANDO TU VIDEO";
    setRing(0);
    setStep(0);
    setPoster(0, clipsData().length);
  }

  const origProgress = window.onRenderProgress;
  window.onRenderProgress = function (p) {
    if (typeof origProgress === "function") origProgress(p);
    try {
      const pct = +(p && p.percent) || 0;
      setRing(pct);
      const d = String((p && p.encoder_desc) || "");
      const n = clipsData().length;
      let m;
      if ((m = d.match(/Generando escenas animadas \((\d+)\/(\d+)\)/))) {
        setStep(1, `(${m[1]}/${m[2]})`);
        setPoster(Math.max(0, +m[1] - 1), +m[2]);
      } else if (/Escuchando la voz|Preparando el audio/i.test(d)) {
        setStep(0); setPoster(0, n);
      } else if (/Uniendo escenas/i.test(d)) {
        setStep(2); setPoster(Math.round((n - 1) * Math.min(1, pct / 92)), n);
      } else if (/subtítulos y audio|Mezclando audio/i.test(d)) {
        setStep(3); setPoster(n - 1, n);
      } else if (/Finalizado/i.test(d)) {
        setStep(4); setPoster(n - 1, n);
      } else {
        const st = pct < 3 ? 0 : pct < 70 ? 1 : pct < 92 ? 2 : 3;
        setStep(st);
        if (n) setPoster(Math.floor((n - 1) * Math.min(1, pct / 100)), n);
      }
    } catch (e) {}
  };

  // ── ⑨ Celebración al terminar ───────────────────────────────────────
  const origDone = window.onRenderComplete;
  window.onRenderComplete = function (result) {
    if (typeof origDone === "function") origDone(result);
    try { celebrate(result || {}); } catch (e) {}
  };
  function celebrate(result) {
    const box = $("stateSuccess");
    if (!box) return;
    box.classList.add("vn-party");
    const title = $("successTitle");
    if (title && !result.is_preview) title.textContent = "¡Tu video está listo!";

    // Resumen: miniatura + datos
    let sum = box.querySelector(".vn-sum");
    const meta = $("successMeta");
    if (!sum && meta) {
      sum = document.createElement("div");
      sum.className = "vn-sum";
      sum.innerHTML = `<div class="vn-sum-thumb"></div>`;
      meta.before(sum);
      sum.appendChild(meta);
    }
    let sub = box.querySelector(".vn-sub");
    if (!sub && title) { sub = document.createElement("div"); sub.className = "vn-sub"; title.after(sub); }
    const n = clipsData().length;
    const dur = ($("metricTotalDuration") || {}).textContent || "";
    const name = ($("projName") || {}).textContent || "";
    const bits = [];
    if (name && !/sin t[ií]tulo/i.test(name)) bits.push(name);
    if (result.is_preview) bits.push(`${result.preview_duration || 15} s`);
    else { if (n) bits.push(`${n} escena${n === 1 ? "" : "s"}`); if (dur) bits.push(dur); }
    if (result.size_mb !== undefined) bits.push(`${result.size_mb} MB`);
    if (sub) sub.textContent = bits.join(" · ");
    if (sum) {
      const t = thumbs();
      const th = sum.querySelector(".vn-sum-thumb");
      th.style.backgroundImage = t.length ? `url("${t[0].replace(/"/g, "%22")}")` : "";
      th.classList.toggle("empty", !t.length);
      const s = getState() || {};
      th.style.aspectRatio = s.resolution === "horizontal" ? "16 / 9" : s.resolution === "square" ? "1 / 1" : "9 / 16";
    }

    // Destello de luces (se vuelve a lanzar cada vez)
    let burst = box.querySelector(".vn-burst");
    if (burst) burst.remove();
    if (window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    burst = document.createElement("div");
    burst.className = "vn-burst";
    burst.setAttribute("aria-hidden", "true");
    let html = "";
    for (let i = 0; i < 30; i++) {
      const a = Math.PI * (1.08 + 0.84 * (i / 29)) + (Math.random() - 0.5) * 0.15;   // hacia arriba y a los lados
      const r = 80 + Math.random() * 110;
      const col = i % 5 === 0 ? "#FFC845" : i % 7 === 0 ? "#8b6cff" : "#00F0FF";
      const sz = 4 + Math.round(Math.random() * 4);
      html += `<i style="--dx:${(Math.cos(a) * r * 1.5).toFixed(0)}px;--dy:${(Math.sin(a) * r).toFixed(0)}px;--d:${(Math.random() * 0.15).toFixed(2)}s;--c:${col};width:${sz}px;height:${sz}px"></i>`;
    }
    burst.innerHTML = html;
    const icon = box.querySelector(".success-icon");
    (icon || box.firstChild).after(burst);
    if (icon) burst.style.top = (icon.offsetTop + icon.offsetHeight / 2) + "px";
    if (icon) { icon.classList.remove("vn-pop"); void icon.offsetWidth; icon.classList.add("vn-pop"); }
  }

  // ── v8.1: enlace y .zip de actualizaciones, solo para el administrador ──
  const prevAdmin = window.vnSetAdmin;
  window.vnSetAdmin = function (flag, usuario) {
    if (typeof prevAdmin === "function") prevAdmin(flag, usuario);
    document.body.classList.toggle("vn-is-admin", !!flag);
  };
  // Si la sesión ya se abrió antes de cargar este archivo: el botón "Usuarios" visible = administrador
  const admBtn = $("btnAdmin");
  if (admBtn) document.body.classList.toggle("vn-is-admin", !admBtn.classList.contains("hidden"));
})();
