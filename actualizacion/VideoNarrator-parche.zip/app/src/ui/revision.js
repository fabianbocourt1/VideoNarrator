// ============================================================
// v9.2 — Revisión de escenas
// Escucha cada video (Whisper) y lo compara con el texto COMPLETO de su escena; revisa la imagen
// con FFmpeg (negro, congelado, saltos, destellos, duración). Solo informa: no cambia archivos.
// ============================================================
(function sceneReview() {
  const $ = (id) => document.getElementById(id);
  const side = document.querySelector(".pv-side");
  const acts = $("pvActs"), track = $("pvTrack");
  if (!side || !acts || !track) return;
  const api = () => (window.pywebview && window.pywebview.api) || null;
  const esc = (x) => String(x == null ? "" : x).replace(/[&<>"]/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[ch]));
  const ls = { get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }, set(k, v) { try { localStorage.setItem(k, v); } catch (e) {} } };
  const COLOR = { g: "#6fe3b9", y: "#FFC845", r: "#ff8a95", n: "#8fa3ab" };
  const RANK = { r: 0, y: 1, n: 2, g: 3 };

  const R = { items: [], results: {}, status: null, open: "", pill: "all", dim: "all", timer: 0, listenT: 0,
              replacedAtStart: [], ok: {} };
  try { R.ok = JSON.parse(ls.get("vn_review_ok") || "{}") || {}; } catch (e) { R.ok = {}; }

  // ── Botón en la barra de la línea de tiempo ──
  const sep = document.createElement("span"); sep.className = "pv-tsep";
  const btn = document.createElement("button");
  btn.type = "button"; btn.className = "pv-t pv-rep pv-review"; btn.id = "pvReview";
  btn.title = "Revisar todas las escenas: diálogo (Whisper) e imagen";
  btn.innerHTML = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 11l3 3 8-8"/><path d="M20 12v6a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h9"/></svg><span>Revisar escenas</span>';
  acts.appendChild(sep); acts.appendChild(btn);

  // ── Panel (encima del panel de la escena) ──
  const panel = document.createElement("div");
  panel.className = "rv hidden"; panel.id = "rvPanel";
  side.style.position = "relative";
  side.appendChild(panel);

  // ── Escenas de la historia → videos a revisar (una vez por video, con el texto COMPLETO) ──
  function buildItems() {
    const clips = state.clipsData || [];
    const by = new Map();
    clips.forEach((c, i) => {
      const id = String(c.clip_id);
      let g = by.get(id);
      if (!g) {
        g = { key: id, clip_id: c.clip_id, path: c.image_path || "", kind: c.kind || "", speaker: c.speaker || "",
              audio_mode: c.audio_mode || "", is_video: !!c.is_video, duration: 0, parts: [], idx: i,
              thumb: c.thumbnail || "", full: c.full_text || "" };
        by.set(id, g);
      }
      g.parts.push(String(c.text || ""));
      g.duration += Number(c.duration || 0);
    });
    return [...by.values()].map(g => ({ ...g, text: g.full || g.parts.join(" ") }));
  }

  // ── Revisar ──
  async function start() {
    const a = api();
    if (!a || !a.scene_review_start) { alert("Esta función necesita la app de escritorio."); return; }
    R.items = buildItems();
    if (!R.items.length) { alert("Primero analiza la historia para tener escenas que revisar."); return; }
    R.replacedAtStart = (state.replacedScenes || []).slice();
    R.results = {}; R.status = { running: true, done: 0, total: R.items.length, current: "Preparando…" };
    show(true); paint();
    let r;
    try { r = await a.scene_review_start(R.items.map(({ thumb, parts, full, idx, ...x }) => x)); } catch (e) { r = { error: String(e) }; }
    if (r && r.error && !/Ya se están/.test(r.error)) { R.status = { running: false, error: r.error }; paint(); return; }
    poll();
  }
  async function poll() {
    clearTimeout(R.timer);
    const a = api(); if (!a) return;
    let s;
    try { s = await a.scene_review_status(); } catch (e) { s = null; }
    if (s) { R.status = s; R.results = s.results || {}; paint(); }
    if (!s || s.running) R.timer = setTimeout(poll, 700);
  }
  async function cancel() { const a = api(); try { if (a) await a.scene_review_cancel(); } catch (e) {} }

  // ── Estado de cada video (con aprobaciones y reemplazos) ──
  const sigOf = (res) => res ? `${(res.dialog || {}).msg || ""}|${(res.visual || {}).msg || ""}` : "";
  function info(it) {
    const res = R.results[it.key];
    if (!res) return null;
    const replaced = (state.replacedScenes || []).includes(it.key) && !R.replacedAtStart.includes(it.key);
    const approved = R.ok[it.path + "|" + it.key] === sigOf(res);
    const d = res.dialog || { st: "n", msg: "" }, v = res.visual || { st: "n", msg: "", checks: [] };
    let st = res.st || "g";
    if (approved && (st === "r" || st === "y")) st = "g";
    if (replaced) st = "n";
    return { res, d, v, st, approved, replaced };
  }
  const dimSt = (f) => {
    if (!f) return "n";
    if (f.replaced) return "n";
    if (f.approved) return "g";
    return R.dim === "dialog" ? (f.d.st || "n") : R.dim === "visual" ? (f.v.st || "n") : f.st;
  };

  // ── Pintar ──
  function paint() {
    paintPanel();
    paintMarks();
  }
  function paintMarks() {
    track.querySelectorAll(".rv-mk").forEach(m => m.remove());
    if (!Object.keys(R.results).length) return;
    const P = window.vnPreview && window.vnPreview.scenes ? window.vnPreview.scenes() : [];
    track.querySelectorAll(".pv-blk").forEach(b => {
      const sc = P[+b.dataset.i]; if (!sc) return;
      const it = R.items.find(x => x.key === String(sc.id)); if (!it) return;
      const f = info(it); if (!f) return;
      const m = document.createElement("span");
      m.className = "rv-mk d" + f.st;
      m.title = f.replaced ? "Reemplazada: vuelve a revisar" : f.st === "g" ? "Revisión: bien" : (f.d.st === "r" || f.d.st === "y" ? f.d.msg : f.v.msg);
      b.appendChild(m);
    });
  }
  new MutationObserver(() => { if (!track.querySelector(".rv-mk") && Object.keys(R.results).length) paintMarks(); })
    .observe(track, { childList: true });

  function rowHtml(it, f) {
    const open = R.open === it.key;
    const st = dimSt(f);
    const d = f.d, v = f.v;
    const dMsg = f.replaced ? "Reemplazada después de revisar: toca “Revisar otra vez”" : d.msg;
    const pc = d.pct != null && !f.replaced ? `${d.pct} %<small>parecido</small>` : (d.st === "n" || f.replaced ? "" : "—");
    let body = "";
    if (open) {
      const c = d.cmp;
      if (c && (d.st === "r" || d.st === "y")) {
        const ex = c.expected.map(w => w.s === "miss" ? `<span class="rv-miss">${esc(w.w)}</span>` : esc(w.w)).join(" ");
        const hd = c.heard.length ? c.heard.map(w => w.s === "add" ? `<span class="rv-add">${esc(w.w)}</span>` : esc(w.w)).join(" ") : '<span class="rv-none">(no se oye voz)</span>';
        body += `<div class="rv-diff"><div><small>DEBÍA DECIR</small>${ex}</div><div><small>DIJO</small>${hd}</div></div>`;
      } else if (d.heard_text && d.st === "y") {
        body += `<div class="rv-diff"><div><small>SE OYE</small>${esc(d.heard_text)}</div></div>`;
      }
      const dur = +v.dur || it.duration || 0;
      if ((v.marks || []).length && dur > 0) {
        const marks = v.marks.map(m => {
          const x = Math.max(0, Math.min(100, m.t / dur * 100));
          return `<span class="rv-cut d${m.st}" style="left:${x}%"></span>`;
        }).join("");
        const tag = v.marks[0], tx = Math.max(0, Math.min(72, tag.t / dur * 100 + 1));
        body += `<div class="rv-strip" style="${it.thumb ? `background-image:url('${it.thumb}')` : ""}">${marks}<span class="rv-tg d${tag.st}" style="left:${tx}%">${esc(v.msg.split(" · y ")[0])}</span></div>`;
      }
      if ((v.checks || []).length) body += `<div class="rv-chk">${v.checks.map(k => `<span class="${k.ok ? "" : "bad"}">${k.ok ? "✓" : "✕"} ${esc(k.t)}</span>`).join("")}</div>`;
      const canSee = v.at != null && (v.st === "r" || v.st === "y");
      body += `<div class="rv-acts">
        <button type="button" class="rv-b" data-a="listen">▶ Escuchar</button>
        ${canSee ? '<button type="button" class="rv-b" data-a="see">⌖ Ver la falla</button>' : ""}
        ${it.path ? `<button type="button" class="rv-b${f.st === "r" || f.st === "y" ? " p" : ""}" data-a="replace">⇄ Reemplazar ${it.is_video ? "video" : "imagen"}…</button>` : ""}
        ${f.approved ? '<button type="button" class="rv-b" data-a="unok">↺ Quitar aprobación</button>' : (f.res.st === "r" || f.res.st === "y") && !f.replaced ? '<button type="button" class="rv-b" data-a="ok">✓ Está bien así</button>' : ""}
      </div>`;
    }
    const who = it.kind === "narrator" ? "Narrador" : (it.speaker || "Diálogo");
    return `<div class="rv-row${open ? " open s" + st : ""}" data-k="${esc(it.key)}">
      <i class="rv-dot d${st}"></i>${it.thumb ? `<img src="${it.thumb}" alt="">` : '<span class="rv-noimg"></span>'}
      <div class="rv-t"><b>Escena ${esc(it.clip_id)} <em>· ${esc(who)}</em>${f.approved ? ' <span class="rv-okb">✓ aprobada por ti</span>' : ""}</b>
        <div class="rv-l"><span class="rv-lb">DIÁLOGO</span><span class="rv-w d${f.replaced ? "n" : d.st}">${esc(dMsg)}</span></div>
        <div class="rv-l"><span class="rv-lb">IMAGEN</span><span class="rv-w d${f.replaced ? "n" : v.st}">${esc(f.replaced ? "—" : v.msg)}</span></div></div>
      <div class="rv-pc" style="color:${COLOR[st]}">${pc}</div>${body}</div>`;
  }

  function paintPanel() {
    if (panel.classList.contains("hidden")) return;
    const s = R.status || {};
    const rows = R.items.map(it => ({ it, f: info(it) })).filter(x => x.f);
    const cnt = { g: 0, y: 0, r: 0, n: 0 };
    rows.forEach(x => { cnt[dimSt(x.f)]++; });
    const shown = rows.filter(x => R.pill === "all" || dimSt(x.f) === R.pill)
      .sort((a, b) => (RANK[dimSt(a.f)] - RANK[dimSt(b.f)]) || (a.it.idx - b.it.idx));
    const pill = (k, label) => `<button type="button" class="rv-pill${R.pill === k ? " on" : ""}" data-p="${k}">${k !== "all" ? `<i class="d${k}"></i>` : ""}${label}</button>`;
    const seg = (k, label) => `<span class="${R.dim === k ? "on" : ""}" data-d="${k}">${label}</span>`;
    const running = !!s.running;
    const pct = s.total ? Math.round((s.done || 0) / s.total * 100) : 0;
    const when = running ? `Revisando ${s.done || 0} de ${s.total || 0}…` : (rows.length ? `Revisadas ${rows.length} de ${R.items.length}` : "");
    let warn = "";
    if (s.whisper) warn = `<div class="rv-warn">Whisper no está disponible, así que el diálogo no se pudo escuchar (la imagen sí se revisó). Instala la última versión del instalador para activarlo.</div>`;
    if (s.error) warn += `<div class="rv-warn r">La revisión se detuvo: ${esc(s.error)}</div>`;
    panel.innerHTML = `<div class="rv-h"><h4>REVISIÓN DE ESCENAS</h4><span class="rv-x">${esc(when)}</span>
        <button type="button" class="rv-close" data-a="close" title="Cerrar (las marcas siguen en la línea de tiempo)">✕</button></div>
      ${running ? `<div class="rv-run"><div class="rv-runt"><span>${esc(s.current || "Revisando…")}</span><button type="button" class="rv-b" data-a="cancel">Detener</button></div><div class="rv-bar"><i style="width:${pct}%"></i></div></div>` : ""}
      <div class="rv-sum">${pill("g", `${cnt.g} bien`)}${pill("y", `${cnt.y} dudosa${cnt.y === 1 ? "" : "s"}`)}${pill("r", `${cnt.r} para reemplazar`)}${cnt.n ? pill("n", `${cnt.n} sin revisar`) : ""}${pill("all", "Ver todas")}
        <span class="rv-seg">${seg("all", "Todo")}${seg("dialog", "Diálogo")}${seg("visual", "Imagen")}</span>
        ${running ? "" : '<button type="button" class="rv-re" data-a="again">↻ Revisar otra vez</button>'}</div>
      ${warn}
      <div class="rv-list">${shown.map(x => rowHtml(x.it, x.f)).join("") || `<div class="rv-empty">${running ? "Las escenas aparecen aquí a medida que se revisan…" : R.pill === "r" ? "No hay escenas para reemplazar. 🎉" : "No hay escenas en este grupo."}</div>`}</div>`;
  }

  function show(on) {
    panel.classList.toggle("hidden", !on);
    btn.classList.toggle("on", on);
    if (on) paintPanel();
  }

  // ── Acciones ──
  function sceneIndex(it) {
    const P = window.vnPreview && window.vnPreview.scenes ? window.vnPreview.scenes() : [];
    const i = P.findIndex(sc => String(sc.id) === it.key);
    return i;
  }
  function timelineTime(it, t) {               // segundo del video → segundo de la línea de tiempo
    const P = window.vnPreview.scenes();
    const parts = P.filter(sc => String(sc.id) === it.key);
    for (const sc of parts) {
      if (!sc.vsegs) continue;
      let acc = 0;
      for (const [a, b] of sc.vsegs) {
        if (t >= a - 0.05 && t <= b) return sc.start + acc + Math.max(0, t - a);
        if (t < a) return sc.start + acc;
        acc += b - a;
      }
    }
    const sc = parts[0];
    return sc ? sc.start + Math.min(Math.max(0, t), sc.dur - 0.05) : 0;
  }
  function listen(it) {
    const pv = window.vnPreview; if (!pv || !pv.toScene) return;
    const i = sceneIndex(it); if (i < 0) return;
    const P = pv.scenes();
    const parts = P.filter(sc => String(sc.id) === it.key);
    const end = parts.length ? parts[parts.length - 1].start + parts[parts.length - 1].dur : 0;
    pv.toScene(i); pv.play();
    clearInterval(R.listenT);
    R.listenT = setInterval(() => {
      if (!pv.playing() || pv.time() >= end - 0.03) { clearInterval(R.listenT); if (pv.playing() && pv.time() >= end - 0.03) pv.pause(); }
    }, 60);
  }
  function saveOk() { ls.set("vn_review_ok", JSON.stringify(R.ok)); }

  btn.addEventListener("click", () => {
    if (!panel.classList.contains("hidden") && R.status && R.status.running) { show(false); return; }
    start();
  });
  panel.addEventListener("click", (ev) => {
    const a = ev.target.closest("[data-a]");
    const p = ev.target.closest("[data-p]");
    const d = ev.target.closest("[data-d]");
    if (p) { R.pill = p.dataset.p; paintPanel(); return; }
    if (d) { R.dim = d.dataset.d; paintPanel(); return; }
    if (a && a.dataset.a === "close") { show(false); return; }
    if (a && a.dataset.a === "cancel") { cancel(); return; }
    if (a && a.dataset.a === "again") { start(); return; }
    const row = ev.target.closest(".rv-row"); if (!row) return;
    const it = R.items.find(x => x.key === row.dataset.k); if (!it) return;
    if (a) {
      const f = info(it);
      if (a.dataset.a === "listen") listen(it);
      else if (a.dataset.a === "see" && f) {
        const pv = window.vnPreview; pv.pause(); pv.seek(timelineTime(it, +f.v.at || 0));
      } else if (a.dataset.a === "replace") { if (window.vnReplaceScene) window.vnReplaceScene(it.clip_id); }
      else if (a.dataset.a === "ok" && f) { R.ok[it.path + "|" + it.key] = sigOf(f.res); saveOk(); paint(); }
      else if (a.dataset.a === "unok") { delete R.ok[it.path + "|" + it.key]; saveOk(); paint(); }
      return;
    }
    R.open = R.open === it.key ? "" : it.key;
    const i = sceneIndex(it);
    if (i >= 0 && window.vnPreview) { window.vnPreview.pause(); window.vnPreview.toScene(i); }
    paintPanel();
  });
  document.addEventListener("keydown", (ev) => {
    if (ev.key === "Escape" && !panel.classList.contains("hidden") && !document.getElementById("rpOverlay")) show(false);
  });

  // Si la historia cambia (otra historia, nuevo análisis), las marcas viejas se quitan
  let lastSig = "";
  setInterval(() => {
    const sig = (state.clipsData || []).map(c => c.clip_id + ":" + (c.image_path || "")).join("|");
    if (sig === lastSig) return;
    const firstTime = !lastSig; lastSig = sig;
    if (firstTime) return;
    const paths = new Set((state.clipsData || []).map(c => c.image_path || ""));
    if (R.items.length && !R.items.some(it => paths.has(it.path))) {   // otra historia
      R.items = []; R.results = {}; R.status = null; R.open = "";
      show(false); paintMarks();
    } else if (R.items.length) {
      R.items = buildItems().map(it => it);                              // misma historia: textos o miniaturas nuevas
      paint();
    }
  }, 1500);

  window.vnReview = { start, show, state: R };
})();
