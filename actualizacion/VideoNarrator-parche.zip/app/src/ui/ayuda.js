// ============================================================
// v7.2 — Asistente de VideoNarrator (botón flotante de IA)
// Responde con el manual de la app (sin internet, sin costo): entiende la pregunta aunque
// esté escrita distinto o con errores, mira tu historia y te lleva a la sección correcta.
// ============================================================
(function vnAssistant() {
  "use strict";
  const $ = (s) => document.querySelector(s);
  const esc = (x) => String(x == null ? "" : x).replace(/[&<>"]/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[ch]));
  const ls = { get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }, set(k, v) { try { localStorage.setItem(k, v); } catch (e) {} } };
  const ico = (d, s = 16) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`;
  const SPARK = '<path d="M12 2.5l2.1 5.6 5.6 2.1-5.6 2.1L12 17.9l-2.1-5.6-5.6-2.1 5.6-2.1z" fill="currentColor" stroke="none"/><path d="M19 15.5l.8 2.1 2.1.8-2.1.8-.8 2.1-.8-2.1-2.1-.8 2.1-.8z" fill="currentColor" stroke="none"/>';
  const st = () => (typeof state !== "undefined" ? state : {});
  const subs = () => (typeof subState !== "undefined" ? subState : { enabled: false });
  const checked = (id) => { const el = document.getElementById(id); return !!(el && el.checked); };
  const version = () => { const b = $(".badge-pro"); return b ? b.textContent.trim() : ""; };
  const isAdmin = () => { const b = document.getElementById("btnAdmin"); return !!(b && !b.classList.contains("hidden")); };

  // ── Base de conocimiento ────────────────────────────────────────────
  // q: formas de preguntar · k: palabras clave · a: respuesta (HTML) · steps · act: botones · ctx: revisa tu historia
  const KB = [
    // EMPEZAR
    { id: "empezar", cat: "Empezar", t: "Crear mi primera historia",
      q: ["como empiezo", "por donde empiezo", "como hago un video", "primeros pasos", "como funciona la app", "que hago primero", "como creo una historia"],
      k: ["empezar", "comenzar", "inicio", "nuevo", "historia", "video", "pasos"],
      a: "Una historia se arma con tres cosas: tus <b>videos o imágenes</b>, el <b>guion</b> y, si quieres, la <b>voz del narrador</b>.",
      steps: ["En <b>Carpeta de imágenes y videos</b> pulsa <b>Seleccionar videos</b> (o imágenes) y elige tus escenas numeradas (1.mp4, 2.mp4…).",
              "Pega tu guion en <b>Guion</b> (formato <b>CLIP 1: …</b>) o carga un .txt.",
              "Si tienes voz del narrador, agrégala en <b>Pista de audio</b> o usa <b>Voz con Fish Audio</b>.",
              "Revisa en el <b>Editor</b> y pulsa <b>Generar video HD</b>."],
      act: [{ l: "Elegir mis videos", go: "#imagesCard" }, { l: "Ir al guion", go: ".card-script", focus: "#scriptInput" }] },
    { id: "guion", cat: "Empezar", t: "Formato del guion",
      q: ["como escribo el guion", "formato del guion", "que es clip 1", "como pego mi historia", "el guion no lo reconoce", "cargar txt"],
      k: ["guion", "texto", "clip", "formato", "txt", "historia", "narrador", "personaje", "lineas"],
      a: "Cada escena es una línea del guion. Hay dos formatos y la app reconoce los dos solos:",
      steps: ["<b>Formato CLIP:</b> <code>CLIP 1: Érase una vez…</code> · <code>CLIP 2: Y entonces…</code> (una línea por escena, en orden).",
              "<b>Formato con personajes</b> (master prompt): <code>Narrador: Me llamo Hermelinda…</code> · <code>Ana: ¡Hola!</code>",
              "El número de cada CLIP corresponde al video o imagen con ese número (CLIP 3 → 3.mp4).",
              "Con <b>Cargar .txt</b> puedes traer el guion desde un archivo."],
      act: [{ l: "Ir al guion", go: ".card-script", focus: "#scriptInput" }] },
    { id: "videos", cat: "Empezar", t: "Videos e imágenes de las escenas",
      q: ["como subo mis videos", "como agrego imagenes", "seleccionar videos", "no reconoce mis videos", "faltan videos", "falta imagen", "orden de las escenas"],
      k: ["videos", "imagenes", "carpeta", "escenas", "numerados", "falta", "mp4", "seleccionar"],
      a: "Cada escena usa el video o la imagen <b>con su número en el nombre</b>: 1.mp4 para la escena 1, 2.mp4 para la 2, etc.",
      steps: ["Pulsa <b>Seleccionar videos</b> y elige todos a la vez (Ctrl+A en la carpeta), o <b>Seleccionar imágenes</b> para una carpeta de imágenes.",
              "Si una escena dice <b>Falta</b>, revisa que exista un archivo con ese número.",
              "Los videos de diálogo (con voz) usan <b>su propio audio</b>; la app recorta los silencios sola."],
      act: [{ l: "Llévame ahí", go: "#imagesCard" }],
      ctx: () => { const m = (st().clipsData || []).filter(c => !c.has_image).map(c => c.clip_id); return m.length ? `A tu historia le faltan videos o imágenes para ${m.length === 1 ? "la escena" : "las escenas"} <b>${m.slice(0, 8).join(", ")}${m.length > 8 ? "…" : ""}</b>.` : ""; } },
    // VOZ
    { id: "narrador", cat: "Voz y audio", t: "Voz del narrador (audio)",
      q: ["como pongo la voz", "agregar audio del narrador", "audio por escena", "agregar varios audios", "reemplazar audio de una escena", "quitar audio"],
      k: ["voz", "narrador", "audio", "mp3", "pista", "reemplazar", "agregar", "varios"],
      a: "La voz del narrador puede venir de tres lugares:",
      steps: ["<b>Un audio único</b> para toda la historia: en <b>Pista de audio</b> → <b>Seleccionar audio</b>. La app lo reparte por escenas.",
              "<b>Un audio por escena</b>: en la lista de escenas pulsa <b>Agregar varios audios</b>; se asignan por número (03_voz.mp3 → escena 3).",
              "<b>Una escena suelta</b>: en su tarjeta pulsa <b>Reemplazar audio</b> o <b>Cambiar audio</b>."],
      act: [{ l: "Llévame ahí", go: "#audioCard" }] },
    { id: "fishgratis", cat: "Voz y audio", t: "Fish Audio con cuenta gratis",
      q: ["como uso fish audio gratis", "fish audio sin pagar", "mi cuenta de fish es gratis", "fish no detecta mis descargas", "importar audios de fish", "fish audio"],
      k: ["fish", "gratis", "descargas", "importar", "copiar", "linea", "voz", "web"],
      a: "Con una cuenta gratis usas la pestaña <b>Cuenta gratis</b>: la app copia cada línea y pone sola cada descarga en su escena.",
      steps: ["Abre <b>Voz con Fish Audio</b> (en la tarjeta del audio) → pestaña <b>Cuenta gratis</b>.",
              "La línea 1 ya está copiada: pégala en fish.audio (Ctrl+V), genera y <b>descarga</b>.",
              "La app detecta la descarga, la pone en su escena (la reconoce por su texto) y copia la siguiente.",
              "¿Ya los descargaste antes? Usa <b>Importar audios ya descargados</b> y elígelos todos juntos."],
      act: [{ l: "Abrir Fish Audio", click: "#btnFishOpen" }] },
    { id: "fishapi", cat: "Voz y audio", t: "Fish Audio con clave de API",
      q: ["clave de api de fish", "fish con saldo", "generar voz automatica", "api key fish"],
      k: ["fish", "clave", "api", "saldo", "creditos", "generar", "automatico"],
      a: "Si tu cuenta de Fish Audio tiene <b>saldo pagado</b>, la app genera todas las líneas sola:",
      steps: ["Abre <b>Voz con Fish Audio</b> → pestaña <b>Clave de API</b>.",
              "Pega tu clave (fish.audio → API Keys) y pulsa <b>Guardar</b>.",
              "Elige tu voz, la calidad y la velocidad, y pulsa <b>Generar la voz</b>. Las líneas que no cambian no se vuelven a pagar."],
      act: [{ l: "Abrir Fish Audio", click: "#btnFishOpen" }] },
    { id: "silencios", cat: "Voz y audio", t: "Recorte automático de silencios",
      q: ["quitar silencios", "recortar los silencios", "pausas largas", "se corta la voz", "silencio al inicio"],
      k: ["silencio", "silencios", "pausas", "recorte", "recortar", "automatico", "inicio", "final"],
      a: "La app quita sola el silencio al inicio y al final de cada escena y acorta las pausas largas entre frases.",
      steps: ["Está en <b>Recorte y volumen de voces</b> (panel izquierdo, Estilo).",
              "<b>Silencio al inicio y al final:</b> Recortar / No recortar.",
              "<b>Pausas largas entre frases:</b> Acortarlas (máx. 0,4 s) / Mantenerlas.",
              "Si una escena quedó muy cortada, ajústala a mano en el <b>Editor</b> arrastrando sus bordes."],
      act: [{ l: "Llévame ahí", go: "#selectTrimDialogue" }] },
    { id: "volumen", cat: "Voz y audio", t: "Volumen parejo de las voces",
      q: ["una escena suena mas bajo", "volumen diferente", "igualar volumen", "unas voces mas fuertes"],
      k: ["volumen", "bajo", "alto", "igualar", "parejo", "fuerte", "nivel"],
      a: "Con <b>Volumen de las voces: Igualar entre escenas</b> (activado por defecto) la voz de Fish, el narrador y el audio de los videos suenan al mismo nivel, sin saltos y sin saturar.",
      act: [{ l: "Llévame ahí", go: "#selectLevelVoices" }] },
    { id: "musica", cat: "Voz y audio", t: "Música de fondo",
      q: ["como agrego musica", "poner musica", "musica de fondo", "la musica tapa la voz", "bajar la musica", "cancion de fondo"],
      k: ["musica", "cancion", "fondo", "ducking", "baja", "volumen"],
      a: "La música va en su propia capa y <b>baja sola cuando alguien habla</b>. No afecta el recorte de silencios.",
      steps: ["Activa <b>Música de fondo</b> y elige una canción (o una carpeta: rota una canción por video).",
              "<b>Volumen</b>: Suave / Normal / Presente. <b>Al hablar baja</b>: Poco / Normal / Mucho.",
              "Puedes escucharla antes y elegir desde qué segundo empieza."],
      act: [{ l: "Llévame ahí", go: "#musicCard" }],
      ctx: () => checked("toggleMusic") ? "" : "Ahora mismo la <b>música de fondo está apagada</b>." },
    // ESTILO
    { id: "subtitulos", cat: "Estilo", t: "Subtítulos automáticos",
      q: ["no me salen los subtitulos", "como pongo subtitulos", "subtitulos en el video", "letras en pantalla", "cambiar plantilla de subtitulos", "color de los subtitulos", "tamano de los subtitulos"],
      k: ["subtitulos", "letras", "texto", "plantilla", "karaoke", "destacado", "color", "posicion", "tamano", "srt", "cc"],
      a: "Los subtítulos se sincronizan palabra por palabra con la voz.",
      steps: ["Activa <b>Subtítulos automáticos</b>.",
              "Elige la <b>plantilla</b>: Karaoke viral, Palabra por palabra, Destacado, Clásico con caja o Elegante.",
              "Elige el <b>color de acento</b>, la <b>posición</b> y el <b>tamaño</b>.",
              "En el <b>Editor</b> los ves antes de exportar con el botón <b>CC</b>. Con <b>Guardar también un archivo .srt</b> obtienes el archivo para YouTube."],
      act: [{ l: "Llévame ahí", go: "#subtitlesCard" }],
      ctx: () => subs().enabled ? "" : { warn: "Revisé tu historia: los <b>Subtítulos automáticos están apagados</b>.", act: { l: "Activarlos ahora", toggle: "#toggleSubtitles" } } },
    { id: "transiciones", cat: "Estilo", t: "Transiciones entre escenas",
      q: ["como pongo transiciones", "efecto entre escenas", "fundido", "transiciones"],
      k: ["transiciones", "transicion", "fundido", "fade", "slide", "efecto", "corte"],
      a: "Activa <b>Transiciones xfade</b> y elige un preajuste (Pack viral, Dinámico, Cinemático) o los efectos que quieras en rotación, la frecuencia y la duración (0,35 s es lo óptimo).",
      act: [{ l: "Llévame ahí", go: "#toggleTransitions" }] },
    { id: "kenburns", cat: "Estilo", t: "Movimiento de cámara (Ken Burns)",
      q: ["zoom en las imagenes", "movimiento de camara", "que las imagenes se muevan", "ken burns"],
      k: ["zoom", "movimiento", "camara", "ken", "burns", "imagenes"],
      a: "<b>Movimiento de cámara (Ken Burns)</b> hace un zoom suave sobre las imágenes fijas. Elige el tipo de movimiento y la intensidad.",
      act: [{ l: "Llévame ahí", go: "#toggleCameraMotion" }] },
    { id: "clipsvideo", cat: "Estilo", t: "Video más corto que su escena / barras negras",
      q: ["el video es mas corto", "se congela la imagen", "barras negras", "llenar la pantalla", "el video no llena"],
      k: ["congelar", "congela", "barras", "negras", "llenar", "corto", "ajuste", "formato", "repetir", "lento"],
      a: "En <b>Clips de video</b> decides qué pasa cuando un video dura menos que su escena (<b>congelar el último cuadro</b>, repetirlo o ponerlo más lento) y cómo se ajusta a 9:16: <b>Completo (con barras negras)</b> o <b>Llenar la pantalla</b> (recorta los bordes).",
      act: [{ l: "Llévame ahí", go: "#selectVideoExtend" }] },
    { id: "overlays", cat: "Estilo", t: "Intro y outro (overlays)",
      q: ["poner una intro", "logo al final", "outro", "video al inicio"],
      k: ["intro", "outro", "overlay", "logo", "inicio", "final", "chroma"],
      a: "Con <b>Overlays dinámicos</b> pones un video o imagen al <b>inicio</b> y/o al <b>final</b>, con duración ajustable y fondo verde quitado (chroma) si lo necesitas.",
      act: [{ l: "Llévame ahí", go: "#toggleOverlays" }] },
    // EDITOR
    { id: "editor", cat: "Editor", t: "El editor: reproductor y línea de tiempo",
      q: ["como veo el video antes de exportar", "vista previa", "reproductor", "linea de tiempo", "editor", "no veo el reproductor"],
      k: ["editor", "reproductor", "vista", "previa", "linea", "tiempo", "ver", "pistas"],
      a: "Arriba de tus escenas está el <b>Editor</b>: ves la historia armada sin exportar, con los silencios recortados, las voces, la música y los subtítulos.",
      steps: ["<b>Espacio</b> reproduce o pausa. Clic en una escena de la línea de tiempo para ir a ella.",
              "Pistas: <b>Video</b>, <b>Audio</b> (azul = audio del video, verde = Fish/narrador) y <b>Texto</b>.",
              "Zoom con la barra de la derecha. <b>Mostrar editor</b> lo oculta (tus ediciones no se pierden)."],
      act: [{ l: "Llévame ahí", go: "#pvWrap", show: true }] },
    { id: "recortar", cat: "Editor", t: "Recortar el inicio o el final de una escena",
      q: ["como corto el final de una escena", "recortar una escena", "quitar el principio de un video", "acortar una escena", "la escena empieza tarde"],
      k: ["recortar", "cortar", "final", "inicio", "principio", "acortar", "bordes", "termina", "empieza"],
      a: "En el <b>Editor</b>, haz clic en la escena y:",
      steps: ["<b>Arrastra sus bordes azules</b>: hacia adentro recorta, hacia afuera recupera lo que la app había quitado.",
              "O reproduce, pausa en el punto exacto y pulsa <b>Empieza aquí</b> (tecla <b>I</b>) o <b>Termina aquí</b> (tecla <b>O</b>).",
              "Las escenas editadas quedan con borde amarillo. Con <b>Automático</b> vuelve al recorte normal."],
      act: [{ l: "Ir al editor", go: "#pvWrap", show: true }] },
    { id: "dividir", cat: "Editor", t: "Dividir, mover y quitar escenas",
      q: ["como divido una escena", "partir una escena en dos", "dividir un clip", "cortar un clip en dos", "como quito una escena del video", "sacar una escena del video", "cambiar el orden de las escenas", "mover una escena", "quitar una escena", "restaurar una escena", "deshacer"],
      k: ["dividir", "partir", "mover", "orden", "quitar", "eliminar", "restaurar", "deshacer", "congelar", "alargar"],
      a: "Todo se hace en el <b>Editor</b> sobre la escena elegida:",
      steps: ["<b>Dividir</b> (tecla <b>S</b>): parte la escena donde está el cabezal.",
              "<b>Mover</b>: arrastra la escena a otro lugar, o usa ◀ ▶.",
              "<b>Congelar +1 s</b>: deja la última imagen un segundo más.",
              "<b>Quitar</b> (tecla <b>Supr</b>): no sale en el video; la restauras abajo en <b>Quitadas del video</b>.",
              "<b>Deshacer</b> (Ctrl+Z) quita el último cambio."],
      act: [{ l: "Ir al editor", go: "#pvWrap", show: true }] },
    // EXPORTAR
    { id: "exportar", cat: "Exportar", t: "Exportar el video",
      q: ["como exporto", "generar el video", "renderizar", "descargar el video final", "crear el mp4"],
      k: ["exportar", "generar", "render", "renderizar", "hd", "mp4", "final"],
      a: "Pulsa <b>Generar video HD</b> (abajo del panel izquierdo). Puedes seguir trabajando mientras se crea; la app te avisa al terminar.",
      steps: ["<b>Vista previa (15 s)</b> crea un video corto para probar el estilo.",
              "En <b>Carpeta de salida</b> eliges dónde se guarda.",
              "Mientras se renderiza la PC no se suspende."],
      act: [{ l: "Llévame ahí", go: "#btnRender" }],
      ctx: () => (st().clipsData || []).length ? "" : "Todavía no hay escenas: primero agrega tus videos y el guion." },
    { id: "dondevideos", cat: "Exportar", t: "¿Dónde quedan mis videos?",
      q: ["donde quedan mis videos", "donde se guarda el video", "donde se guardan los videos que exporto", "donde esta mi video exportado", "no encuentro el video", "carpeta de salida"],
      k: ["donde", "guarda", "carpeta", "salida", "encontrar", "video", "quedan"],
      a: "En la <b>Carpeta de salida</b> que aparece en la sección <b>Exportar</b>; si no la cambiaste, junto a tu audio o tu material. Al terminar, la app abre la carpeta sola. Borrar una historia <b>no</b> borra tus videos.",
      act: [{ l: "Llévame ahí", go: "#btnSelectOutput" }] },
    { id: "lento", cat: "Exportar", t: "El render tarda mucho",
      q: ["el video tarda mucho", "render lento", "exportar es lento", "usa la gpu"],
      k: ["lento", "tarda", "demora", "gpu", "rapido", "velocidad"],
      a: "La velocidad depende de la cantidad de escenas y de tu PC. La app usa la tarjeta gráfica cuando la encuentra (arriba a la derecha ves cuál usa). Consejos: cierra otros programas pesados y deja la ventana abierta.",
      ctx: () => { const b = document.getElementById("encoderBadge"); return b ? `Tu PC está usando: <b>${esc(b.textContent.trim())}</b>.` : ""; } },
    // HISTORIAS
    { id: "historias", cat: "Mis historias", t: "Guardar y abrir historias",
      q: ["como guardo mi historia", "abrir una historia", "mis historias", "continuar un proyecto", "se perdio mi proyecto", "por que la app abre vacia"],
      k: ["guardar", "abrir", "historias", "proyecto", "continuar", "biblioteca", "nueva", "vacia"],
      a: "Todo se <b>guarda solo</b> mientras trabajas. La app abre siempre en blanco; para seguir con una historia, ábrela desde <b>Mis historias</b>.",
      steps: ["<b>Nueva</b>: empieza otra historia (la actual queda guardada).",
              "<b>Mis historias</b>: abre, renombra, duplica o elimina.",
              "Eliminar una historia la manda a la papelera de la app; tus videos no se borran."],
      act: [{ l: "Abrir Mis historias", click: "#storyLib" }] },
    // CUENTA
    { id: "contrasena", cat: "Cuenta", t: "Cambiar mi contraseña",
      q: ["como cambio mi contrasena", "olvide mi contrasena", "cambiar clave", "cerrar sesion"],
      k: ["contrasena", "clave", "password", "cambiar", "sesion", "cerrar", "olvide"],
      a: "Haz clic en <b>tu nombre</b> (arriba a la derecha) → <b>Cambiar contraseña…</b>. Escribe la actual y la nueva dos veces. En ese mismo menú está <b>Cerrar sesión</b>. Si olvidaste tu contraseña, pídele una nueva al administrador.",
      act: [{ l: "Abrir mi cuenta", click: "#btnUser" }] },
    { id: "otrapc", cat: "Cuenta", t: "Usar la app en otra PC",
      q: ["puedo usarla en otra pc", "se cerro mi sesion", "dice que la sesion esta en otra pc", "no me deja entrar"],
      k: ["otra", "pc", "computadora", "sesion", "entrar", "cerro", "equipo"],
      a: "Tu cuenta funciona <b>en una PC a la vez</b>. Si entras en otra PC, la sesión de la anterior se cierra sola; para volver, entra otra vez con tu usuario y contraseña. Si dice que tu acceso venció o está bloqueado, habla con el administrador." },
    { id: "internet", cat: "Cuenta", t: "La app pide internet",
      q: ["sin internet no abre", "necesita internet", "no hay conexion"],
      k: ["internet", "conexion", "wifi", "abre", "red"],
      a: "La app necesita internet <b>al abrir</b> para comprobar tu acceso. Si se cae a mitad de trabajo, no se interrumpe lo que estás haciendo." },
    { id: "reemplazar", cat: "Editor", t: "Reemplazar el video de una escena",
      q: ["como reemplazo un video", "cambiar el video de una escena", "un video salio mal", "reemplazar clip", "reemplazar escena", "cambiar imagen de una escena"],
      k: ["reemplazar", "cambiar", "video", "escena", "clip", "flow", "mal", "otro"],
      a: "Selecciona la escena en la línea de tiempo y pulsa <b>Reemplazar</b> (o la tecla <b>R</b>, o clic derecho → Reemplazar video…). Eliges el video nuevo de tu PC, comparas AHORA → NUEVO y confirmas. También puedes arrastrar el video desde tu carpeta y soltarlo sobre la escena.",
      steps: ["El video nuevo se copia a la carpeta de tu historia con el número de la escena.",
              "El anterior no se borra: queda en la subcarpeta <b>reemplazados</b>.",
              "Si te equivocaste, pulsa <b>Deshacer</b> en el aviso de abajo."],
      act: [{ l: "Reemplazar ahora", click: "#pvReplace" }] },
    { id: "marca", cat: "Estilo", t: "Marca de agua (logo con fondo verde que se mueve)",
      q: ["como pongo mi logo", "marca de agua", "poner mi arroba", "logo con fondo verde", "que el logo se mueva", "proteger mi video"],
      k: ["marca", "agua", "logo", "arroba", "verde", "mover", "proteger", "copiar"],
      a: "En <b>Estilo → Marca de agua</b> eliges tu logo (imagen o video). Si tiene fondo verde, <b>Quitar el fondo verde</b> lo borra. Ajusta tamaño y transparencia y elige el movimiento: Fijo, De A a B, Ida y vuelta o Esquinas.",
      steps: ["Los puntos A (inicio) y B (final) se arrastran sobre el reproductor del editor.",
              "En la línea de tiempo aparece el carril <b>Marca</b> con sus rombos.",
              "Si queda borde verde, sube la <b>Intensidad del recorte</b> a Fuerte."],
      act: [{ l: "Ir a Marca de agua", go: "#wmCard" }] },
    { id: "estilossub", cat: "Subtítulos", t: "Estilos de subtítulos",
      q: ["que estilos de subtitulos hay", "subtitulos estilo hormozi", "subtitulos neon", "cambiar estilo de subtitulos"],
      k: ["estilo", "plantilla", "subtitulos", "neon", "pop", "hormozi", "caja", "maquina", "documental", "impacto", "sombra", "contorno"],
      a: "En <b>Subtítulos automáticos → Plantilla</b> hay 13 estilos en 3 grupos: animados (Karaoke, Palabra por palabra, Pop, Caja por palabra, Neón, Máquina de escribir), con impacto (Destacado, Impacto, Contorno de color, Sombra 3D) y sobrios (Clásico con caja, Elegante, Cine documental). El editor los muestra igual que en el video.",
      act: [{ l: "Ir a Subtítulos", go: "#subtitlesCard" }] },
    // ACTUALIZACIONES
    { id: "actualizar", cat: "Actualizaciones", t: "Actualizar VideoNarrator",
      q: ["como actualizo", "no aparece la actualizacion", "hay una version nueva", "buscar actualizaciones", "instalar zip"],
      k: ["actualizar", "actualizacion", "version", "nueva", "parche", "zip", "aviso"],
      a: "La app avisa sola cuando hay una versión nueva. También puedes pulsar <b>Actualizar</b> (arriba) → <b>Buscar actualizaciones</b>.",
      steps: ["Si acabas de enterarte de una versión nueva y no aparece, espera unos minutos y vuelve a buscar.",
              "Si no aparece, pídele ayuda al administrador: él puede instalarla con un archivo .zip.",
              "Al terminar, la app se reinicia sola."],
      act: [{ l: "Buscar ahora", click: "#btnApplyUpdate" }],
      ctx: () => `Tienes la versión <b>${esc(version())}</b>.` },
    // PROBLEMAS
    { id: "sinsonido", cat: "Problemas", t: "Una escena no tiene sonido",
      q: ["una escena no tiene sonido", "no se escucha", "quedo en silencio", "sin audio"],
      k: ["sonido", "silencio", "escucha", "audio", "mudo"],
      a: "Revisa en la lista de escenas qué dice su fila de audio: <b>⚠ Sin audio</b> significa que esa escena no tiene voz asignada. Agrégale una con <b>Agregar audio</b>, o revisa que el video tenga su propio sonido.",
      ctx: () => { const m = (st().clipsData || []).filter(c => c.audio_mode === "missing" || c.audio_mode === "silence").map(c => c.clip_id); return m.length ? `Estas escenas no tienen audio: <b>${[...new Set(m)].slice(0, 10).join(", ")}</b>.` : ""; } },
    { id: "faltan", cat: "Problemas", t: "Archivos que ya no están",
      q: ["dice que faltan archivos", "movi mis videos", "no encuentra mis archivos"],
      k: ["faltan", "movi", "archivos", "encuentra", "ruta", "carpeta"],
      a: "Si moviste o renombraste la carpeta de tus videos o audios, al abrir la historia la app te avisa cuáles faltan. Vuelve a elegirlos en el panel izquierdo y todo se reconecta." },
    { id: "acceso", cat: "Cuenta", t: "Mi acceso, precio o renovación",
      q: ["cuanto cuesta la app", "como renuevo mi acceso", "mi acceso vencio", "cuando vence mi cuenta", "como pago"],
      k: ["cuesta", "precio", "renovar", "vence", "vencio", "acceso", "pago", "cuenta"],
      a: "El acceso a VideoNarrator lo maneja tu <b>administrador</b>: él crea tu usuario, te da la contraseña y renueva tu acceso cuando vence. Escríbele para cualquier tema de precio, renovación o cuentas nuevas." },
    // ADMIN (solo administradores)
    { id: "adminusuarios", cat: "Administrador", admin: true, t: "Panel de usuarios",
      q: ["como creo un usuario", "agregar usuario", "bloquear usuario", "renovar acceso", "panel de usuarios"],
      k: ["usuario", "usuarios", "crear", "bloquear", "vence", "acceso", "admin"],
      a: "En <b>Usuarios</b> (arriba): <b>+ Nuevo usuario</b> con contraseña generada, <b>Editar</b> (nombre, contraseña, vencimiento), <b>Bloquear/Activar</b>, <b>Cerrar sesión</b> en su PC y <b>Borrar</b>.",
      act: [{ l: "Abrir Usuarios", click: "#btnAdmin" }] },
    { id: "adminalertas", cat: "Administrador", admin: true, t: "Alertas de acceso",
      q: ["que son las alertas", "copia de la app", "cuenta compartida", "alertas"],
      k: ["alertas", "copia", "compartida", "pirata", "intentos"],
      a: "En <b>Usuarios → Alertas</b> ves copias de la app abiertas en otra PC, intentos con usuarios que no existen, contraseñas incorrectas desde otra PC, cambios de PC y posibles cuentas compartidas. El número rojo indica las nuevas.",
      act: [{ l: "Abrir Usuarios", click: "#btnAdmin" }] },
  ];

  const NEWS = [
    ["8.9", "8 estilos de subtítulos nuevos (Pop, Neón, Caja por palabra…), Elegante sin cursiva y Marca de agua con fondo verde que se mueve de A a B."],
    ["8.8", "Whisper: descarga su modelo de forma más segura y, si no se usa, la app dice el motivo real."],
    ["8.7", "Reemplaza el video o la imagen de una escena desde el editor (botón Reemplazar, tecla R, clic derecho o arrastrando el archivo)."],
    ["8.6", "Vuelve la entrada automática: con tu sesión guardada entras sin escribir la contraseña."],
    ["8.5", "Conexión de respaldo: la app funciona aunque en tu PC falle la conexión normal entre la ventana y el programa."],
    ["8.4", "Al abrir ya no hay verificación automática: entras directamente con tu usuario y contraseña."],
    ["8.3", "Arranque más seguro en todas las PCs y más datos para soporte si algo falla al abrir."],
    ["8.2", "Al abrir ya no se queda en \"Verificando tu acceso…\": si algo falla, lo dice y te deja reintentar."],
    ["8.1", "El menú de actualizaciones es más simple: el enlace y el .zip solo los ve el administrador."],
    ["8.0", "Nueva imagen: luces de fondo, pantalla de render tipo cine, celebración al terminar, escenas que entran animadas, números que cuentan y más."],
    ["7.9", "Los menús azules del panel también brillan."],
    ["7.8", "Botón de Nara más pequeño."],
    ["7.7", "Todos los menús del panel en azul."],
    ["7.6", "Menús de Clips de video y de Recorte y volumen de voces en azul."],
    ["7.5", "Encabezado de Nara más limpio."],
    ["7.4", "El asistente ahora se llama Nara. Las actualizaciones aparecen apenas se publican."],
    ["7.3", "El asistente es más compacto."],
    ["7.2", "Nara, tu asistente (este botón ✨): pregúntale lo que quieras sobre la app."],
    ["7.1", "El editor cabe completo en la pantalla."],
    ["7.0", "Reproductor vertical a la izquierda."],
    ["6.9", "Editor con pistas de Video, Audio y Texto; subtítulos de la vista previa con tu plantilla."],
    ["6.8", "Edición a mano: recortar, dividir, mover, congelar y quitar escenas."],
    ["6.7", "Vista previa dentro de la app."],
    ["6.5", "Volumen parejo de las voces y cambiar tu contraseña desde la app."],
    ["6.4", "La app abre en blanco; tus historias siguen en Mis historias."],
    ["6.3", "Fish gratis reconoce cada descarga por su texto."],
    ["6.2", "Fish Audio con cuenta gratis."],
  ];

  // ── Búsqueda tolerante (acentos, mayúsculas, errores de escritura, sinónimos) ──
  const SYN = { subs: "subtitulos", subtitulo: "subtitulos", letras: "subtitulos", cortar: "recortar", corto: "recortar", corta: "recortar",
    renderizar: "exportar", render: "exportar", generar: "exportar", descargo: "exportar", clave: "contrasena", password: "contrasena",
    cancion: "musica", canciones: "musica", fondo: "musica", eliminar: "quitar", borrar: "quitar", borro: "quitar", partir: "dividir", divido: "dividir",
    pc: "pc", computadora: "pc", compu: "pc", laptop: "pc", update: "actualizar", actualizo: "actualizar", nueva: "nueva",
    voces: "voz", narradora: "narrador", locutor: "narrador", silencio: "silencios", pausas: "silencios", clips: "escenas", escena: "escenas",
    video: "video", videos: "videos", imagen: "imagenes", fotos: "imagenes", foto: "imagenes", guardo: "guardar", abro: "abrir",
    transicion: "transiciones", efectos: "transiciones", vista: "vista", previa: "previa", lento: "lento", tarda: "lento", demora: "lento",
    empiezo: "empezar", comienzo: "empezar", comenzar: "empezar", iniciar: "empezar", guardan: "guarda", guardo: "guarda", sacar: "quitar", saco: "quitar", quito: "quitar",
    kiero: "quiero", bajito: "bajo", despacio: "bajo", fuerte: "alto", precio: "cuesta", pagar: "cuesta", costo: "cuesta", plan: "cuesta" };
  const STOP = new Set("el la los las un una unos unas de del al a en y o que como por para con sin mi mis tu tus su sus se me te lo le les es son esta este esto hay no si ya mas muy pero cuando donde porque yo quiero puedo hago hacer tengo".split(" "));
  const norm = (s) => String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/ñ/g, "n").replace(/[^a-z0-9\s]/g, " ");
  const toks = (s) => norm(s).split(/\s+/).filter(w => w && !STOP.has(w)).map(w => SYN[w] || w);
  function lev(a, b) {
    if (Math.abs(a.length - b.length) > 2) return 9;
    const v = Array.from({ length: b.length + 1 }, (_, i) => i);
    for (let i = 1; i <= a.length; i++) { let p = v[0]; v[0] = i; for (let j = 1; j <= b.length; j++) { const t = v[j]; v[j] = Math.min(v[j] + 1, v[j - 1] + 1, p + (a[i - 1] === b[j - 1] ? 0 : 1)); p = t; } }
    return v[b.length];
  }
  const like = (a, b) => a === b || (a.length >= 5 && b.length >= 5 && (a.startsWith(b.slice(0, 5)) || b.startsWith(a.slice(0, 5)) || lev(a, b) <= (a.length >= 8 ? 2 : 1)));
  const visible = () => KB.filter(e => !e.admin || isAdmin());
  // Cada palabra pesa según lo rara que es en el manual ("escena" pesa poco; "dividir" pesa mucho)
  const bagOf = (e) => e._bag || (e._bag = [...new Set(toks(e.t + " " + e.k.join(" ") + " " + e.q.join(" ")))]);
  function weight(w, list) { const df = list.filter(e => bagOf(e).some(x => like(w, x))).length; return 1 / (1 + df * 0.6); }
  function score(qt, e, W) {
    if (!qt.length) return 0;
    const tw = qt.reduce((n, w) => n + W[w], 0) || 1;
    let best = 0;
    for (const q of e.q) {
      const et = toks(q); if (!et.length) continue;
      const hit = qt.filter(w => et.some(x => like(w, x)));
      const cover = et.filter(x => qt.some(w => like(w, x))).length / et.length;
      best = Math.max(best, (hit.reduce((n, w) => n + W[w], 0) / tw) * (0.55 + 0.45 * cover));
    }
    const bag = bagOf(e);
    const kw = qt.filter(w => bag.some(x => like(w, x))).reduce((n, w) => n + W[w], 0) / tw;
    return best * 0.7 + kw * 0.45;
  }
  function find(text) {
    const qt = [...new Set(toks(text))];
    const list = visible();
    const W = {}; qt.forEach(w => { W[w] = weight(w, list); });
    return list.map(e => ({ e, s: score(qt, e, W) })).sort((a, b) => b.s - a.s);
  }

  // ── Interfaz ──
  const orb = document.createElement("button");
  orb.type = "button"; orb.className = "ai-orb"; orb.title = "Nara · asistente de VideoNarrator";
  orb.innerHTML = `<span class="ai-spark">${ico(SPARK, 28)}</span><span class="ai-x">${ico('<path d="M6 6l12 12M18 6 6 18"/>', 24)}</span><span class="ai-tag">IA</span>`;
  const tip = document.createElement("div");
  tip.className = "ai-tip hidden";
  tip.innerHTML = `Hola, soy Nara ✨ ¿Tienes una duda?<small>Tu asistente de VideoNarrator</small>`;
  const panel = document.createElement("div");
  panel.className = "ai-panel hidden"; panel.setAttribute("role", "dialog"); panel.setAttribute("aria-label", "Nara, asistente de VideoNarrator");
  panel.innerHTML = `
    <div class="ai-head"><div class="ai-av">${ico(SPARK, 20)}</div>
      <div><div class="ai-t">NARA <span class="ai-t2">· ASISTENTE DE VIDEONARRATOR</span></div></div>
      <button type="button" class="ai-close" aria-label="Cerrar">✕</button></div>
    <div class="ai-tabs"><button type="button" class="ai-tab on" data-tab="chat">Asistente</button><button type="button" class="ai-tab" data-tab="manual">Manual</button><button type="button" class="ai-tab" data-tab="news">Novedades</button></div>
    <div class="ai-view" data-view="chat"><div class="ai-body"></div>
      <div class="ai-sug"></div>
      <form class="ai-in"><input type="text" placeholder="Pregúntale a Nara lo que quieras…" maxlength="200" spellcheck="false" autocomplete="off" /><button type="submit" aria-label="Enviar">${ico('<path d="M5 12h14M13 6l6 6-6 6"/>', 16)}</button></form></div>
    <div class="ai-view hidden" data-view="manual"><div class="ai-msearch"><input type="text" placeholder="Buscar en el manual…" spellcheck="false" /></div><div class="ai-manual"></div></div>
    <div class="ai-view hidden" data-view="news"><div class="ai-news"></div></div>`;
  document.body.append(orb, tip, panel);
  const body = panel.querySelector(".ai-body"), input = panel.querySelector(".ai-in input"), sug = panel.querySelector(".ai-sug");

  function open(v) {
    panel.classList.toggle("hidden", !v); orb.classList.toggle("open", v); tip.classList.add("hidden");
    if (v) {
      if (!body.children.length) greet();
      setTimeout(() => input.focus(), 60);
    }
  }
  orb.addEventListener("click", () => open(panel.classList.contains("hidden")));
  panel.querySelector(".ai-close").addEventListener("click", () => open(false));
  document.addEventListener("keydown", (ev) => { if (ev.key === "Escape" && !panel.classList.contains("hidden")) open(false); });
  tip.addEventListener("click", () => open(true));

  const SUGG = ["¿Cómo recorto una escena?", "¿Cómo uso Fish Audio gratis?", "¿Por qué no salen los subtítulos?", "¿Dónde quedan mis videos?"];
  function paintSug(list) { sug.innerHTML = list.map(s => `<button type="button" class="ai-chip">${esc(s)}</button>`).join(""); }
  sug.addEventListener("click", (ev) => { const b = ev.target.closest(".ai-chip"); if (b) ask(b.textContent); });

  function aiMsg(html) {
    const m = document.createElement("div"); m.className = "ai-m ai-bot";
    m.innerHTML = `<div class="ai-a">${ico(SPARK, 14)}</div><div class="ai-c">${html}</div>`;
    body.appendChild(m); body.scrollTop = body.scrollHeight; return m;
  }
  function meMsg(text) { const m = document.createElement("div"); m.className = "ai-m ai-me"; m.textContent = text; body.appendChild(m); body.scrollTop = body.scrollHeight; }
  function greet() {
    const name = (document.getElementById("btnUserName") || {}).textContent || "";
    aiMsg(`¡Hola${name && name !== "usuario" ? ", " + esc(name.trim()) : ""}! 👋 Soy <b>Nara</b>, tu asistente de VideoNarrator. Pregúntame cómo hacer cualquier cosa en la app: te explico paso a paso y te llevo a la sección.`);
    paintSug(SUGG);
  }

  function answerHtml(e) {
    let h = "";
    const c = e.ctx ? e.ctx() : "";
    let extraAct = null;
    if (c && typeof c === "object") { h += `<div class="ai-ctx">${c.warn}</div>`; extraAct = c.act; }
    else if (c) h += `<div class="ai-ctx">${c}</div>`;
    h += `<div>${e.a}</div>`;
    if (e.steps) h += `<ol>${e.steps.map(s => `<li>${s}</li>`).join("")}</ol>`;
    const acts = (extraAct ? [extraAct] : []).concat(e.act || []);
    h += `<div class="ai-acts">${acts.map((a, i) => `<button type="button" class="ai-act${i === 0 ? " pri" : ""}" data-a="${esc(JSON.stringify(a))}">${i === 0 ? ico('<path d="M5 12h14M13 6l6 6-6 6"/>', 13) : ""}${esc(a.l)}</button>`).join("")}
      <button type="button" class="ai-act" data-man="${e.id}">Ver en el manual</button></div>`;
    h += `<div class="ai-src">${ico('<path d="M4 5a2 2 0 0 1 2-2h12v18H6a2 2 0 0 1-2-2z"/>', 12)} Manual · ${esc(e.t)}</div>`;
    return h;
  }

  function ask(text) {
    text = String(text || "").trim();
    if (!text) return;
    meMsg(text); input.value = "";
    const thinking = aiMsg('<span class="ai-typing"><i></i><i></i><i></i></span>');
    const small = norm(text).trim();
    if (/^(hola|buenas|buenos dias|buenas tardes|buenas noches|hey|que tal)\b/.test(small) && small.split(/\s+/).length <= 3) {
      setTimeout(() => { thinking.querySelector(".ai-c").innerHTML = "¡Hola! 😊 Soy Nara. ¿En qué te ayudo? Puedes preguntarme por la voz, los subtítulos, el editor, cómo exportar… o elegir una de las preguntas de abajo."; paintSug(SUGG); }, 500);
      return;
    }
    if (/(como te llamas|quien eres|tu nombre|que eres)/.test(small)) {
      setTimeout(() => { thinking.querySelector(".ai-c").innerHTML = "Soy <b>Nara</b> ✨, la asistente de Video<b>Nar</b>r<b>a</b>tor. Conozco cada parte de la app y te llevo a donde necesites."; }, 450);
      return;
    }
    if (/^(gracias|muchas gracias|ok|listo|perfecto|genial|excelente)\b/.test(small) && small.split(/\s+/).length <= 3) {
      setTimeout(() => { thinking.querySelector(".ai-c").innerHTML = "¡Con gusto! ✨ Si necesitas algo más, aquí estoy."; }, 450);
      return;
    }
    const r = find(text);
    setTimeout(() => {
      const top = r[0], second = r[1];
      let html;
      if (!top || top.s < 0.3) {
        html = `No estoy seguro de haber entendido 🤔. ¿Te refieres a alguno de estos temas?<div class="ai-acts">${r.slice(0, 4).map(x => `<button type="button" class="ai-act" data-ask="${esc(x.e.t)}">${esc(x.e.t)}</button>`).join("")}</div>
          <div class="ai-src">Si no está aquí, escríbele a tu administrador.</div>`;
      } else {
        html = answerHtml(top.e);
        if (second && second.s > 0.45 && second.s > top.s * 0.85 && second.e.id !== top.e.id) html += `<div class="ai-more">También puede interesarte: <button type="button" class="ai-link" data-ask="${esc(second.e.t)}">${esc(second.e.t)}</button></div>`;
      }
      thinking.querySelector(".ai-c").innerHTML = html;
      thinking.classList.add("in");
      body.scrollTop = body.scrollHeight;
      if (top && top.s >= 0.3) {
        const rel = visible().filter(e => e.cat === top.e.cat && e.id !== top.e.id).slice(0, 3).map(e => e.t.startsWith("¿") ? e.t : e.t);
        paintSug(rel.length ? rel : SUGG);
      }
    }, 450 + Math.min(700, text.length * 12));
  }
  panel.querySelector(".ai-in").addEventListener("submit", (ev) => { ev.preventDefault(); ask(input.value); });

  // ── Acciones: llevar a la sección, abrir, activar ──
  function glow(el) {
    if (!el) return;
    const target = el.closest(".card-input, .pv-wrap, .form-group, .render-bar, .btn-tool, button") || el;
    target.scrollIntoView({ behavior: "smooth", block: "center" });
    target.classList.remove("ai-glow"); void target.offsetWidth; target.classList.add("ai-glow");
    setTimeout(() => target.classList.remove("ai-glow"), 2600);
  }
  function run(a) {
    if (a.show) { const s = document.getElementById("pvShow"); if (s && !s.checked) { s.checked = true; s.dispatchEvent(new Event("change")); } }
    if (a.toggle) {
      const t = $(a.toggle);
      if (t && !t.checked) { t.checked = true; t.dispatchEvent(new Event("change", { bubbles: true })); }
      glow(t); aiMsg("✓ Listo, ya está activado."); return;
    }
    if (a.click) {
      const b = $(a.click);
      if (b && !b.disabled && !b.classList.contains("hidden")) { open(false); setTimeout(() => b.click(), 120); }
      else aiMsg("Esa opción no está disponible ahora mismo en tu pantalla.");
      return;
    }
    if (a.go) {
      const el = $(a.go);
      if (!el || el.offsetParent === null && !el.closest(".pv-wrap")) { aiMsg("Esa sección aparece cuando tu historia tiene escenas. Agrega primero tus videos y el guion."); return; }
      open(false); setTimeout(() => { glow(el); if (a.focus) { const f = $(a.focus); f && f.focus(); } }, 150);
    }
  }
  body.addEventListener("click", (ev) => {
    const a = ev.target.closest("[data-a]"); if (a) { try { run(JSON.parse(a.dataset.a)); } catch (e) {} return; }
    const m = ev.target.closest("[data-man]"); if (m) { showTab("manual"); openArticle(m.dataset.man); return; }
    const q = ev.target.closest("[data-ask]"); if (q) ask(q.dataset.ask);
  });

  // ── Manual y novedades ──
  const man = panel.querySelector(".ai-manual"), msearch = panel.querySelector(".ai-msearch input");
  function paintManual(filter) {
    const list = filter ? find(filter).filter(x => x.s > 0.2).map(x => x.e) : visible();
    const cats = [...new Set(list.map(e => e.cat))];
    man.innerHTML = list.length ? cats.map(c => `<div class="ai-cat">${esc(c)}</div>` + list.filter(e => e.cat === c).map(e =>
      `<button type="button" class="ai-art" data-id="${e.id}">${esc(e.t)}<span>›</span></button>`).join("")).join("")
      : `<div class="ai-empty">No encontré ese tema. Prueba con otras palabras o pregúntale al asistente.</div>`;
  }
  function openArticle(id) {
    const e = KB.find(x => x.id === id); if (!e) return;
    man.innerHTML = `<button type="button" class="ai-back">‹ Todos los temas</button><div class="ai-cat">${esc(e.cat)}</div><h3 class="ai-h">${esc(e.t)}</h3><div class="ai-c ai-artbody">${answerHtml(e)}</div>`;
    man.scrollTop = 0;
  }
  man.addEventListener("click", (ev) => {
    const b = ev.target.closest(".ai-art"); if (b) { openArticle(b.dataset.id); return; }
    if (ev.target.closest(".ai-back")) { paintManual(msearch.value.trim()); return; }
    const a = ev.target.closest("[data-a]"); if (a) { try { run(JSON.parse(a.dataset.a)); } catch (e) {} return; }
    const q = ev.target.closest("[data-ask]"); if (q) { showTab("chat"); ask(q.dataset.ask); }
  });
  msearch.addEventListener("input", () => paintManual(msearch.value.trim()));
  panel.querySelector(".ai-news").innerHTML = NEWS.map(([v, t]) => `<div class="ai-new"><span class="ai-v">v${v}</span><div>${esc(t)}</div></div>`).join("");
  function showTab(tab) {
    panel.querySelectorAll(".ai-tab").forEach(b => b.classList.toggle("on", b.dataset.tab === tab));
    panel.querySelectorAll(".ai-view").forEach(v => v.classList.toggle("hidden", v.dataset.view !== tab));
    if (tab === "manual" && !man.children.length) paintManual("");
  }
  panel.querySelectorAll(".ai-tab").forEach(b => b.addEventListener("click", () => { showTab(b.dataset.tab); if (b.dataset.tab === "manual") { msearch.value = ""; paintManual(""); } }));

  // Saludo pequeño junto al botón (las 3 primeras veces que se abre la app)
  const seen = parseInt(ls.get("vnAiTip") || "0", 10) || 0;
  if (seen < 3) {
    setTimeout(() => {
      if (document.body.classList.contains("auth-locked") || !panel.classList.contains("hidden")) return;
      tip.classList.remove("hidden"); ls.set("vnAiTip", String(seen + 1));
      setTimeout(() => tip.classList.add("hidden"), 7000);
    }, 3500);
  }
  window.vnAssistant = { open: () => open(true), ask, find };
})();

// v7.9 — brillo que cruza en los menús azules del panel izquierdo (un <select> no puede llevarlo solo)
(function selectShine() {
  const wrap = (el, i) => {
    if (!el || (el.parentElement && el.parentElement.classList.contains("vn-sel-shine"))) return;
    const w = document.createElement("span");
    w.className = "vn-sel-shine" + (el.tagName === "INPUT" ? " inl" : "");
    w.style.setProperty("--shine-delay", ((i * 0.37) % 3.4).toFixed(2) + "s");
    if (el.tagName === "INPUT") w.style.width = getComputedStyle(el).width;
    el.parentNode.insertBefore(w, el); w.appendChild(el);
  };
  const run = () => document.querySelectorAll(".panel-left select.select-modern, .panel-left #inpMusicStart").forEach(wrap);
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", run); else run();
})();
