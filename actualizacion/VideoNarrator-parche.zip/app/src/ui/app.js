// ============================================================
// VIDEONARRATOR v4.0 — CLIENT CONTROLLER
// Con soporte completo para Ken Burns y Transiciones xfade (SyncReel Match)
// ============================================================

const PRESETS = {
  viral_pack: ['fade', 'slide', 'zoomin', 'flash'],
  dynamic: ['fade', 'slide'],
  cinematic: ['fade', 'dissolve']
};

const CHIP_LABELS = {
  fade: 'Fade',
  slide: 'Slide',
  zoomin: 'Zoom in',
  flash: 'Flash',
  dissolve: 'Dissolve'
};

const state = {
  audioPath: "",
  audioDuration: 0,
  imagesFolder: "",
  imagesCount: 0,
  outputFolder: "",
  scriptText: "",
  isRendering: false,
  lastResult: null,

  // Efectos Ken Burns
  enableCameraMotion: false,
  cameraMotionType: "alternate",
  zoomIntensity: 1.25,

  // Transiciones
  enableTransitions: false,
  activePreset: "viral_pack",
  transitionPool: ["fade", "slide", "zoomin", "flash"],
  transitionFrequency: 1,
  transitionDuration: 0.35,

  // Overlays Dinámicos (Intro & Outro)
  enableOverlays: false,
  introEnabled: false,
  introOverlay: null,
  introPosition: "center",
  introDuration: 2.0,
  introChroma: true,
  introChromaSimilarity: 0.46,

  outroEnabled: false,
  outroOverlay: null,
  outroPosition: "bottom",
  outroDuration: 3.5,
  outroChroma: true,
  outroChromaSimilarity: 0.46,

  // Resolución y Audio
  resolution: "vertical",
  normalizeAudio: true
};

// Referencias DOM
const dom = {
  encoderBadge: document.getElementById("encoderBadge"),
  audioCard: document.getElementById("audioCard"),
  audioFileName: document.getElementById("audioFileName"),
  audioDurationTag: document.getElementById("audioDurationTag"),
  btnSelectAudio: document.getElementById("btnSelectAudio"),

  imagesCard: document.getElementById("imagesCard"),
  imagesFolderName: document.getElementById("imagesFolderName"),
  imagesCountTag: document.getElementById("imagesCountTag"),
  btnSelectImages: document.getElementById("btnSelectImages"),

  scriptInput: document.getElementById("scriptInput"),
  btnLoadScript: document.getElementById("btnLoadScript"),
  btnClearScript: document.getElementById("btnClearScript"),

  // Ken Burns DOM
  toggleCameraMotion: document.getElementById("toggleCameraMotion"),
  fxMotionOptions: document.getElementById("fxMotionOptions"),
  selectMotionType: document.getElementById("selectMotionType"),
  selectZoomIntensity: document.getElementById("selectZoomIntensity"),

  // Transitions DOM
  toggleTransitions: document.getElementById("toggleTransitions"),
  fxTransitionsOptions: document.getElementById("fxTransitionsOptions"),
  presetBtns: document.querySelectorAll(".preset-btn"),
  chipBtns: document.querySelectorAll(".chip-btn"),
  customChipsCount: document.getElementById("customChipsCount"),
  rotationSummaryText: document.getElementById("rotationSummaryText"),
  selectTrFrequency: document.getElementById("selectTrFrequency"),
  selectTrDuration: document.getElementById("selectTrDuration"),

  // Overlays DOM
  toggleOverlays: document.getElementById("toggleOverlays"),
  fxOverlaysOptions: document.getElementById("fxOverlaysOptions"),

  // Intro
  introOverlayCol: document.getElementById("introOverlayCol"),
  toggleIntroOverlay: document.getElementById("toggleIntroOverlay"),
  introOverlayBody: document.getElementById("introOverlayBody"),
  btnSelectIntroFile: document.getElementById("btnSelectIntroFile"),
  btnChangeIntroFile: document.getElementById("btnChangeIntroFile"),
  btnRemoveIntroFile: document.getElementById("btnRemoveIntroFile"),
  introEmptyState: document.getElementById("introEmptyState"),
  introLoadedState: document.getElementById("introLoadedState"),
  introPreviewThumb: document.getElementById("introPreviewThumb"),
  introFilename: document.getElementById("introFilename"),
  introTypeTag: document.getElementById("introTypeTag"),
  introPosBtns: document.querySelectorAll("#introPosGroup .pos-btn"),
  sliderIntroDuration: document.getElementById("sliderIntroDuration"),
  introDurationVal: document.getElementById("introDurationVal"),
  toggleIntroChroma: document.getElementById("toggleIntroChroma"),
  introChromaControls: document.getElementById("introChromaControls"),
  sliderIntroChroma: document.getElementById("sliderIntroChroma"),
  introChromaVal: document.getElementById("introChromaVal"),

  // Outro
  outroOverlayCol: document.getElementById("outroOverlayCol"),
  toggleOutroOverlay: document.getElementById("toggleOutroOverlay"),
  outroOverlayBody: document.getElementById("outroOverlayBody"),
  btnSelectOutroFile: document.getElementById("btnSelectOutroFile"),
  btnChangeOutroFile: document.getElementById("btnChangeOutroFile"),
  btnRemoveOutroFile: document.getElementById("btnRemoveOutroFile"),
  outroEmptyState: document.getElementById("outroEmptyState"),
  outroLoadedState: document.getElementById("outroLoadedState"),
  outroPreviewThumb: document.getElementById("outroPreviewThumb"),
  outroFilename: document.getElementById("outroFilename"),
  outroTypeTag: document.getElementById("outroTypeTag"),
  outroPosBtns: document.querySelectorAll("#outroPosGroup .pos-btn"),
  sliderOutroDuration: document.getElementById("sliderOutroDuration"),
  outroDurationVal: document.getElementById("outroDurationVal"),
  toggleOutroChroma: document.getElementById("toggleOutroChroma"),
  outroChromaControls: document.getElementById("outroChromaControls"),
  sliderOutroChroma: document.getElementById("sliderOutroChroma"),
  outroChromaVal: document.getElementById("outroChromaVal"),

  outputPathDisplay: document.getElementById("outputPathDisplay"),
  btnSelectOutput: document.getElementById("btnSelectOutput"),
  checkTimestamps: document.getElementById("checkTimestamps"),

  btnPreview: document.getElementById("btnPreview"),
  btnRender: document.getElementById("btnRender"),
  successTitle: document.getElementById("successTitle"),

  // Metrics
  metricTotalClips: document.getElementById("metricTotalClips"),
  metricTotalWords: document.getElementById("metricTotalWords"),
  metricTotalDuration: document.getElementById("metricTotalDuration"),
  timelineMatchStatus: document.getElementById("timelineMatchStatus"),
  clipsList: document.getElementById("clipsList"),

  // Modal
  renderModal: document.getElementById("renderModal"),
  stateRendering: document.getElementById("stateRendering"),
  stateSuccess: document.getElementById("stateSuccess"),
  stateError: document.getElementById("stateError"),
  renderEncoderTag: document.getElementById("renderEncoderTag"),
  renderProgressBar: document.getElementById("renderProgressBar"),
  renderPercent: document.getElementById("renderPercent"),
  renderTime: document.getElementById("renderTime"),
  btnCancelRender: document.getElementById("btnCancelRender"),

  successMeta: document.getElementById("successMeta"),
  btnOpenVideo: document.getElementById("btnOpenVideo"),
  btnOpenFolder: document.getElementById("btnOpenFolder"),
  btnCloseModal: document.getElementById("btnCloseModal"),

  errorBox: document.getElementById("errorBox"),
  btnCloseErrorModal: document.getElementById("btnCloseErrorModal")
};

// Esperar a que pywebview esté listo
// v8.2: una sola vez, y después de cargar todo este archivo (antes podía fallar si
// pywebview estaba listo antes que la pantalla)
let vnInitDone = false;
function initAppOnce() {
  if (vnInitDone) return;
  if (!window.pywebview || !window.pywebview.api || typeof window.pywebview.api.get_system_info !== "function") return;
  vnInitDone = true;
  initApp();
}
window.addEventListener("pywebviewready", () => setTimeout(initAppOnce, 0));
setTimeout(initAppOnce, 0);
(function waitBridge(n) {          // por si el aviso "pywebviewready" llegó antes de escucharlo
  if (vnInitDone || n > 200) return;
  setTimeout(() => { initAppOnce(); waitBridge(n + 1); }, 300);
})(0);

async function initApp() {
  try {
    const sysInfo = await window.pywebview.api.get_system_info();
    if (sysInfo && sysInfo.encoder) {
      dom.encoderBadge.innerText = `⚡ ${sysInfo.encoder}`;
    }
  } catch (e) {
    dom.encoderBadge.innerText = "FFmpeg listo";
  }
  loadSubtitleSettings();
}

// ============================================================
// LISTENERS & FILE PICKERS
// ============================================================

dom.btnSelectAudio.addEventListener("click", async () => {
  if (!window.pywebview) return;
  const res = await window.pywebview.api.browse_audio();
  if (res && res.path) {
    state.audioPath = res.path;
    state.audioDuration = res.duration || 0;
    dom.audioFileName.innerText = `✓ ${res.filename}`;
    dom.audioDurationTag.innerText = res.duration_str || "--:--";
    if (!state.outputFolder) {
      dom.outputPathDisplay.innerText = `Carpeta de salida: junto al audio`;
    }
    triggerAnalyze();
  }
});

document.getElementById("btnSelectMediaFiles").addEventListener("click", async () => {
  if (!window.pywebview) return;
  const res = await window.pywebview.api.browse_media_files();
  if (res && res.error) {
    dom.imagesFolderName.innerText = `⚠ Error: ${res.error}`;
    return;
  }
  if (res && res.files && res.files.length) {
    // Si ya había archivos sueltos elegidos, se añaden a los anteriores (sin repetir)
    const prev = Array.isArray(state.imagesFolder) ? state.imagesFolder : [];
    const merged = prev.concat(res.files.filter(f => !prev.includes(f)));
    state.imagesFolder = merged;
    const info = await window.pywebview.api.describe_media_selection(merged);
    state.imagesCount = info.count || 0;
    dom.imagesFolderName.innerText = `✓ ${merged.length} archivo(s) seleccionado(s)`;
    dom.imagesCountTag.innerText = info.videos > 0
      ? `${info.count} archivos (${info.videos} video${info.videos === 1 ? "" : "s"})`
      : `${info.count} imágenes`;
    if (info.ignored > 0) {
      dom.imagesFolderName.innerText += `\nℹ ${info.ignored} sin número en el nombre: se asignaron a clips libres en el orden elegido (ej: ${info.ignored_examples.join(", ")}). Para controlar el orden, renómbralos como 01_nombre.mp4`;
    }
    triggerAnalyze();
  }
});

dom.btnSelectImages.addEventListener("click", async () => {
  if (!window.pywebview) return;
  const res = await window.pywebview.api.browse_images();
  if (res && res.path) {
    state.imagesFolder = res.path;
    state.imagesCount = res.count || 0;
    dom.imagesFolderName.innerText = `✓ ${res.path}`;
    if (res.ignored > 0) {
      dom.imagesFolderName.innerText += `\nℹ ${res.ignored} archivo(s) sin número en el nombre se asignaron automáticamente a los clips libres, del más antiguo al más nuevo (ej: ${res.ignored_examples.join(", ")}). Para controlar el orden, renómbralos como 01_nombre.mp4`;
    } else if (res.count === 0) {
      dom.imagesFolderName.innerText += `\n⚠ No se encontraron imágenes ni videos en esta carpeta`;
    }
    dom.imagesCountTag.innerText = res.videos > 0
      ? `${res.count} archivos (${res.videos} video${res.videos === 1 ? "" : "s"})`
      : `${res.count} imágenes`;
    triggerAnalyze();
  }
});

dom.btnSelectOutput.addEventListener("click", async () => {
  if (!window.pywebview) return;
  const res = await window.pywebview.api.browse_output();
  if (res && res.path) {
    state.outputFolder = res.path;
    dom.outputPathDisplay.innerText = `Salida: ${res.path}`;
  }
});

dom.btnLoadScript.addEventListener("click", async () => {
  if (!window.pywebview) return;
  const res = await window.pywebview.api.browse_script();
  if (res && res.content !== undefined) {
    dom.scriptInput.value = res.content;
    triggerAnalyze();
  }
});

dom.btnClearScript.addEventListener("click", () => {
  dom.scriptInput.value = "";
  triggerAnalyze();
});

// Auto-analyze con debounce al escribir en el guion
let analyzeTimeout = null;
dom.scriptInput.addEventListener("input", () => {
  clearTimeout(analyzeTimeout);
  analyzeTimeout = setTimeout(triggerAnalyze, 350);
});

// ============================================================
// EFECTOS VISUALES: KEN BURNS & TRANSICIONES CONTROLS
// ============================================================

// Toggle Ken Burns
dom.toggleCameraMotion.addEventListener("change", (e) => {
  state.enableCameraMotion = e.target.checked;
  if (state.enableCameraMotion) {
    dom.fxMotionOptions.classList.remove("hidden");
  } else {
    dom.fxMotionOptions.classList.add("hidden");
  }
});

dom.selectMotionType.addEventListener("change", (e) => {
  state.cameraMotionType = e.target.value;
});

dom.selectZoomIntensity.addEventListener("change", (e) => {
  state.zoomIntensity = parseFloat(e.target.value);
});

// Toggle Transiciones
dom.toggleTransitions.addEventListener("change", (e) => {
  state.enableTransitions = e.target.checked;
  if (state.enableTransitions) {
    dom.fxTransitionsOptions.classList.remove("hidden");
  } else {
    dom.fxTransitionsOptions.classList.add("hidden");
  }
});

// v9.3: "Solo al cambiar de escena": fundido corto donde cambia el lugar o la luz; corte directo en lo demás
function applyTrMode() {
  const v = dom.selectTrFrequency.value;
  state.transitionSceneOnly = v === "scene";
  state.transitionFrequency = state.transitionSceneOnly ? 1 : (parseInt(v) || 1);
  const card = dom.selectTrFrequency.closest("#fxTransitionsOptions");
  if (card) {
    const n = card.querySelector("#trSceneNote"); if (n) n.classList.toggle("hidden", !state.transitionSceneOnly);
  }
}
dom.selectTrFrequency.addEventListener("change", applyTrMode);
applyTrMode();

dom.selectTrDuration.addEventListener("change", (e) => {
  state.transitionDuration = parseFloat(e.target.value);
});

// Presets rápidos
dom.presetBtns.forEach(btn => {
  btn.addEventListener("click", () => {
    const presetId = btn.getAttribute("data-preset");
    applyPreset(presetId);
  });
});

function applyPreset(presetId) {
  state.activePreset = presetId;

  dom.presetBtns.forEach(b => {
    b.classList.toggle("active", b.getAttribute("data-preset") === presetId);
  });

  if (presetId !== "custom" && PRESETS[presetId]) {
    state.transitionPool = [...PRESETS[presetId]];
  }

  updateChipsUI();
  updateRotationSummary();
}

// Chips de efectos
dom.chipBtns.forEach(chipBtn => {
  chipBtn.addEventListener("click", () => {
    const chipId = chipBtn.getAttribute("data-chip");
    const index = state.transitionPool.indexOf(chipId);

    if (index >= 0) {
      if (state.transitionPool.length > 1) {
        state.transitionPool.splice(index, 1);
      } else {
        return; // Al menos 1 efecto debe estar activo
      }
    } else {
      state.transitionPool.push(chipId);
    }

    // Verificar si coincide con algún preset existente
    let matchedPreset = "custom";
    for (const [pid, pool] of Object.entries(PRESETS)) {
      if (pool.length === state.transitionPool.length && pool.every(id => state.transitionPool.includes(id))) {
        matchedPreset = pid;
        break;
      }
    }

    state.activePreset = matchedPreset;
    dom.presetBtns.forEach(b => {
      b.classList.toggle("active", b.getAttribute("data-preset") === matchedPreset);
    });

    updateChipsUI();
    updateRotationSummary();
  });
});

function updateChipsUI() {
  dom.chipBtns.forEach(chipBtn => {
    const id = chipBtn.getAttribute("data-chip");
    const isAct = state.transitionPool.includes(id);
    chipBtn.classList.toggle("active", isAct);
  });

  if (dom.customChipsCount) {
    dom.customChipsCount.innerText = `${state.transitionPool.length} seleccionados`;
  }
}

function updateRotationSummary() {
  const names = state.transitionPool.map(id => CHIP_LABELS[id] || id);
  dom.rotationSummaryText.innerText = names.join(" ➔ ");
}

// ============================================================
// OVERLAYS DINÁMICOS LISTENERS & CONTROLS
// ============================================================

// Master toggle
if (dom.toggleOverlays) {
  dom.toggleOverlays.addEventListener("change", (e) => {
    state.enableOverlays = e.target.checked;
    dom.fxOverlaysOptions.classList.toggle("hidden", !state.enableOverlays);
  });
}

// Intro sub-toggle
if (dom.toggleIntroOverlay) {
  dom.toggleIntroOverlay.addEventListener("change", (e) => {
    state.introEnabled = e.target.checked;
    dom.introOverlayBody.classList.toggle("hidden", !state.introEnabled);
    dom.introOverlayCol.classList.toggle("active", state.introEnabled);
  });
}

// Outro sub-toggle
if (dom.toggleOutroOverlay) {
  dom.toggleOutroOverlay.addEventListener("change", (e) => {
    state.outroEnabled = e.target.checked;
    dom.outroOverlayBody.classList.toggle("hidden", !state.outroEnabled);
    dom.outroOverlayCol.classList.toggle("active", state.outroEnabled);
  });
}

// Helper: Format Chroma Similarity text
function getChromaLabel(val) {
  let text = "Suave";
  if (val >= 0.50) text = "Intenso";
  else if (val >= 0.42) text = "Equilibrado";
  return `${val.toFixed(2)} (${text})`;
}

// Pick Intro File
async function pickIntroFile() {
  if (!window.pywebview) return;
  const res = await window.pywebview.api.browse_overlay("intro");
  if (res && res.path) {
    state.introOverlay = res;
    dom.introFilename.innerText = res.filename;
    dom.introFilename.title = res.path;
    const typeLabel = res.is_video ? `Video (${res.duration}s)` : (res.is_vertical ? 'Imagen 9:16' : 'Imagen');
    dom.introTypeTag.innerText = typeLabel;

    if (res.is_video && res.duration > 0) {
      const dur = Math.min(5.0, Math.max(0.5, res.duration));
      state.introDuration = dur;
      dom.sliderIntroDuration.value = dur;
      dom.introDurationVal.innerText = `${dur}s`;
    }

    if (res.thumbnail) {
      dom.introPreviewThumb.innerHTML = `<img src="data:image/jpeg;base64,${res.thumbnail}" alt="Intro Preview" />`;
    } else {
      dom.introPreviewThumb.innerHTML = `<span class="ov-thumb-icon">${res.is_video ? '🎬' : '🖼️'}</span>`;
    }

    dom.introEmptyState.classList.add("hidden");
    dom.introLoadedState.classList.remove("hidden");
  }
}

if (dom.btnSelectIntroFile) dom.btnSelectIntroFile.addEventListener("click", pickIntroFile);
if (dom.btnChangeIntroFile) dom.btnChangeIntroFile.addEventListener("click", pickIntroFile);

if (dom.btnRemoveIntroFile) {
  dom.btnRemoveIntroFile.addEventListener("click", () => {
    state.introOverlay = null;
    dom.introLoadedState.classList.add("hidden");
    dom.introEmptyState.classList.remove("hidden");
  });
}

// Pick Outro File
async function pickOutroFile() {
  if (!window.pywebview) return;
  const res = await window.pywebview.api.browse_overlay("outro");
  if (res && res.path) {
    state.outroOverlay = res;
    dom.outroFilename.innerText = res.filename;
    dom.outroFilename.title = res.path;
    const typeLabel = res.is_video ? `Video (${res.duration}s)` : (res.is_vertical ? 'Imagen 9:16' : 'Imagen');
    dom.outroTypeTag.innerText = typeLabel;

    if (res.is_video && res.duration > 0) {
      const dur = Math.min(8.0, Math.max(1.0, res.duration));
      state.outroDuration = dur;
      dom.sliderOutroDuration.value = dur;
      dom.outroDurationVal.innerText = `${dur}s`;
    }

    if (res.thumbnail) {
      dom.outroPreviewThumb.innerHTML = `<img src="data:image/jpeg;base64,${res.thumbnail}" alt="Outro Preview" />`;
    } else {
      dom.outroPreviewThumb.innerHTML = `<span class="ov-thumb-icon">${res.is_video ? '🏁' : '🖼️'}</span>`;
    }

    dom.outroEmptyState.classList.add("hidden");
    dom.outroLoadedState.classList.remove("hidden");
  }
}

if (dom.btnSelectOutroFile) dom.btnSelectOutroFile.addEventListener("click", pickOutroFile);
if (dom.btnChangeOutroFile) dom.btnChangeOutroFile.addEventListener("click", pickOutroFile);

if (dom.btnRemoveOutroFile) {
  dom.btnRemoveOutroFile.addEventListener("click", () => {
    state.outroOverlay = null;
    dom.outroLoadedState.classList.add("hidden");
    dom.outroEmptyState.classList.remove("hidden");
  });
}

// Position Buttons Intro
if (dom.introPosBtns) {
  dom.introPosBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      dom.introPosBtns.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      state.introPosition = btn.getAttribute("data-pos");
    });
  });
}

// Position Buttons Outro
if (dom.outroPosBtns) {
  dom.outroPosBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      dom.outroPosBtns.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      state.outroPosition = btn.getAttribute("data-pos");
    });
  });
}

// Duration Sliders
if (dom.sliderIntroDuration) {
  dom.sliderIntroDuration.addEventListener("input", (e) => {
    state.introDuration = parseFloat(e.target.value);
    dom.introDurationVal.innerText = `${state.introDuration}s`;
  });
}

if (dom.sliderOutroDuration) {
  dom.sliderOutroDuration.addEventListener("input", (e) => {
    state.outroDuration = parseFloat(e.target.value);
    dom.outroDurationVal.innerText = `${state.outroDuration}s`;
  });
}

// Chroma Key Controls Intro
if (dom.toggleIntroChroma) {
  dom.toggleIntroChroma.addEventListener("change", (e) => {
    state.introChroma = e.target.checked;
    dom.introChromaControls.classList.toggle("hidden", !state.introChroma);
  });
}

if (dom.sliderIntroChroma) {
  dom.sliderIntroChroma.addEventListener("input", (e) => {
    state.introChromaSimilarity = parseFloat(e.target.value);
    dom.introChromaVal.innerText = getChromaLabel(state.introChromaSimilarity);
  });
}

// Chroma Key Controls Outro
if (dom.toggleOutroChroma) {
  dom.toggleOutroChroma.addEventListener("change", (e) => {
    state.outroChroma = e.target.checked;
    dom.outroChromaControls.classList.toggle("hidden", !state.outroChroma);
  });
}

if (dom.sliderOutroChroma) {
  dom.sliderOutroChroma.addEventListener("input", (e) => {
    state.outroChromaSimilarity = parseFloat(e.target.value);
    dom.outroChromaVal.innerText = getChromaLabel(state.outroChromaSimilarity);
  });
}

// ============================================================
// ANALYZE & RENDER TIMELINE CARDS
// ============================================================

// Opciones que cambian la duración de los clips (se envían al analizar y al renderizar)
function getTrimOptions() {
  const trim = document.getElementById("selectTrimDialogue");
  const pause = document.getElementById("selectPauseMode");
  return {
    trim_dialogue_silence: !trim || trim.value !== "off",
    dialogue_pause_mode: (pause && pause.value) || "tight",
    // Audios asignados a mano a cada escena del narrador: { numero_de_linea: ruta }
    narrator_audio_map: state.narratorAudios || {},
    // v6.8: edición a mano (solo las escenas que tocaste; el resto es automático)
    scene_edits: state.sceneEdits || {},
    scene_order: state.sceneOrder || []
  };
}

["selectTrimDialogue", "selectPauseMode"].forEach(id => {
  const el = document.getElementById(id);
  if (el) el.addEventListener("change", () => { triggerAnalyze(); });
});

async function triggerAnalyze() {
  if (!window.pywebview) return;
  const text = dom.scriptInput.value.trim();
  state.scriptText = text;

  const data = await window.pywebview.api.analyze_project(
    state.audioPath,
    state.imagesFolder,
    state.scriptText,
    getTrimOptions()
  );

  if (!data || data.error) {
    // FIX HIGH-01: Actualizar UI con el error en lugar de fallar silenciosamente
    dom.timelineMatchStatus.className = "timeline-status-badge warning";
    dom.timelineMatchStatus.innerText = data && data.error ? `⚠ Error: ${data.error}` : "⚠ Error al analizar proyecto";
    dom.btnRender.disabled = true;
    if (dom.btnPreview) dom.btnPreview.disabled = true;
    return;
  }

  state.storyMode = !!data.story_mode;

  // Métricas
  dom.metricTotalClips.innerText = data.total_clips;
  dom.metricTotalWords.innerText = data.total_words;
  dom.metricTotalDuration.innerText = data.total_duration_str || "00:00";

  // Estado del match
  if (data.total_clips === 0) {
    dom.timelineMatchStatus.className = "timeline-status-badge";
    dom.timelineMatchStatus.innerText = "Esperando datos...";
    dom.btnRender.disabled = true;
    if (dom.btnPreview) dom.btnPreview.disabled = true;
  } else if (data.missing_images && data.missing_images.length > 0) {
    dom.timelineMatchStatus.className = "timeline-status-badge warning";
    dom.timelineMatchStatus.innerText = `⚠ Faltan imágenes o videos (${data.missing_images.slice(0, 5).join(", ")}${data.missing_images.length > 5 ? '...' : ''})`;
    dom.btnRender.disabled = true;
    if (dom.btnPreview) dom.btnPreview.disabled = true;
  } else if (!data.story_mode && !state.audioPath) {
    dom.timelineMatchStatus.className = "timeline-status-badge warning";
    dom.timelineMatchStatus.innerText = "Falta seleccionar audio";
    dom.btnRender.disabled = true;
    if (dom.btnPreview) dom.btnPreview.disabled = true;
  } else {
    dom.timelineMatchStatus.className = "timeline-status-badge success";
    if (data.story_mode && data.free_mode) {
      dom.timelineMatchStatus.innerText = `✓ ${data.clips.length} archivos en orden — listo para renderizar (sin guion ni audio)`;
    } else if (data.story_mode) {
      const nNarr = data.clips.filter(c => c.kind === "narrator").length;
      let msg = `✓ Historia lista — ${data.clips.length - nNarr} diálogos y ${nNarr} líneas de narrador`;
      const sinVoz = (data.missing_narrator_audio || []).length;
      if (sinVoz > 0) msg += ` · ℹ ${sinVoz} línea(s) del narrador sin voz: quedarán en silencio`;
      dom.timelineMatchStatus.innerText = msg;
    } else {
      dom.timelineMatchStatus.innerText = "✓ Todo coincide, listo para renderizar";
    }
    dom.btnRender.disabled = false;
    if (dom.btnPreview) dom.btnPreview.disabled = false;
  }

  // Lista de Clips
  state.clipsData = data.clips || [];
  state.removedScenes = data.removed_scenes || [];
  state.editable = !!data.editable;
  renderClipsList(data.clips);

  // Mostrar método de sincronización e idioma detectado
  const syncBadge = document.getElementById("syncMethodBadge");
  const langBadge = document.getElementById("detectedLanguage");
  if (syncBadge) {
    if (data.story_mode && data.sync_method === "archivos") {
      syncBadge.innerText = "🎙️ Historia · voz del narrador por archivos numerados";
      syncBadge.style.color = "var(--accent-emerald)";
    } else if (data.story_mode && data.sync_method === "whisper") {
      syncBadge.innerText = "🎙️ Historia · narrador sincronizado con IA (Whisper)";
      syncBadge.style.color = "var(--accent-emerald)";
    } else if (data.story_mode && data.sync_method === "proportional") {
      syncBadge.innerText = "🎙️ Historia · narrador repartido por palabras";
      syncBadge.style.color = "var(--text-muted)";
    } else if (data.story_mode && data.free_mode) {
      syncBadge.innerText = "🎞️ Sin guion · cada video suena con su propio audio";
      syncBadge.style.color = "var(--text-muted)";
    } else if (data.story_mode) {
      syncBadge.innerText = "🎙️ Historia · diálogos con el audio de sus videos";
      syncBadge.style.color = "var(--text-muted)";
    } else if (data.sync_method === "whisper") {
      syncBadge.innerText = "🎯 Sync: IA (Whisper)";
      syncBadge.style.color = "var(--accent-emerald)";
    } else {
      syncBadge.innerText = "🔄 Sync: proporcional";
      syncBadge.style.color = "var(--text-muted)";
    }
  }
  if (langBadge) {
    if (data.detected_language) {
      langBadge.style.display = "inline";
      langBadge.innerText = `🌍 Idioma: ${data.detected_language.toUpperCase()}`;
    } else {
      langBadge.style.display = "none";
    }
  }
}
// Botones "Agregar / Cambiar / Reemplazar / Quitar audio" de cada escena (delegación de eventos)
// Se elige desde una lista DENTRO de la app (audios de la carpeta del proyecto). El diálogo de Windows
// solo se usa en "Buscar en otra carpeta…": en algunas PCs ese diálogo se queda "No responde".
dom.clipsList.addEventListener("click", async (e) => {
  const btn = e.target.closest(".btn-clip-audio");
  if (!btn || !window.pywebview) return;
  const clipId = btn.dataset.clip;
  state.narratorAudios = state.narratorAudios || {};
  if (btn.dataset.action === "remove") {
    delete state.narratorAudios[clipId];
    triggerAnalyze();
    return;
  }
  openAudioPicker(btn, clipId);
});

function assignClipAudio(clipId, path) {
  state.narratorAudios = state.narratorAudios || {};
  state.narratorAudios[clipId] = path;
  closeAudioPicker();
  triggerAnalyze();
}

async function browseClipAudioNative(clipId) {
  closeAudioPicker();
  if (state.audioDialogOpen) return;   // ya hay un selector abierto
  state.audioDialogOpen = true;
  let res;
  try {
    res = await window.pywebview.api.browse_clip_audio();
  } finally {
    state.audioDialogOpen = false;
  }
  if (res && res.error) { alert("No se pudo abrir el selector de audio: " + res.error); return; }
  if (res && res.path) assignClipAudio(clipId, res.path);
}

let audioPickerEl = null;
function closeAudioPicker() {
  if (audioPickerEl) { audioPickerEl.remove(); audioPickerEl = null; }
}
document.addEventListener("keydown", e => { if (e.key === "Escape") closeAudioPicker(); });
document.addEventListener("mousedown", e => {
  if (audioPickerEl && !audioPickerEl.contains(e.target) && !e.target.closest(".btn-clip-audio")) closeAudioPicker();
});

async function openAudioPicker(btn, clipId) {
  closeAudioPicker();
  let data = null;
  try { data = await window.pywebview.api.list_audio_candidates(); } catch (err) { data = null; }
  const files = (data && data.files) || [];
  if (!files.length) { browseClipAudioNative(clipId); return; }   // nada en la carpeta: diálogo normal

  const esc = s => String(s || "").replace(/[&<>"]/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[ch]));
  const numOf = name => {
    const base = name.replace(/\.[^.]+$/, "");
    const m = base.match(/^\s*(\d{1,4})(?!\d)/) || base.match(/(?<!\d)(\d{1,4})(?!\d)/);
    return m ? parseInt(m[1], 10) : null;
  };
  const current = (state.narratorAudios || {})[clipId] || "";
  const id = parseInt(clipId, 10);
  // El audio con el mismo número de la escena va primero
  const sorted = [...files].sort((a, b) => (numOf(b.name) === id) - (numOf(a.name) === id));

  const el = document.createElement("div");
  el.className = "audio-picker";
  el.innerHTML = `
    <div class="ap-head">Audio para la línea ${esc(clipId)}</div>
    <input class="ap-search" type="text" placeholder="Buscar por nombre…" />
    <div class="ap-list"></div>
    <button type="button" class="ap-browse"><svg class="vn-ico" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 7.5A2.5 2.5 0 0 1 5.5 5H9l2 2.5h7.5A2.5 2.5 0 0 1 21 10v7.5A2.5 2.5 0 0 1 18.5 20h-13A2.5 2.5 0 0 1 3 17.5z"/></svg> Buscar en otra carpeta…</button>`;
  const list = el.querySelector(".ap-list");
  const draw = (q) => {
    const qq = (q || "").toLowerCase();
    const shown = sorted.filter(f => !qq || f.name.toLowerCase().includes(qq)).slice(0, 200);
    list.innerHTML = shown.length ? shown.map(f => `
      <button type="button" class="ap-item${f.path === current ? " current" : ""}" data-path="${esc(f.path)}">
        <span class="ap-name"><svg class="vn-ico" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 15v-3a8 8 0 0 1 16 0v3"/><rect x="3" y="14" width="4" height="6" rx="1.5"/><rect x="17" y="14" width="4" height="6" rx="1.5"/></svg> ${esc(f.name)}</span>
        ${numOf(f.name) === id ? '<span class="ap-tag">sugerido</span>' : ""}
        <span class="ap-folder">${esc(f.folder)}</span>
      </button>`).join("") : `<div class="ap-empty">Ningún audio coincide</div>`;
  };
  draw("");
  el.querySelector(".ap-search").addEventListener("input", e => draw(e.target.value));
  list.addEventListener("click", async e => {
    const item = e.target.closest(".ap-item");
    if (!item) return;
    const res = await window.pywebview.api.pick_clip_audio(item.dataset.path);
    if (res && res.error) { alert(res.error); return; }
    if (res && res.path) assignClipAudio(clipId, res.path);
  });
  el.querySelector(".ap-browse").addEventListener("click", () => browseClipAudioNative(clipId));

  document.body.appendChild(el);
  audioPickerEl = el;
  // Posición: debajo del botón (o encima si no cabe)
  const r = btn.getBoundingClientRect();
  const w = el.offsetWidth, h = el.offsetHeight;
  let left = Math.min(r.left, window.innerWidth - w - 12);
  let top = r.bottom + 6;
  if (top + h > window.innerHeight - 12) top = Math.max(12, r.top - h - 6);
  el.style.left = `${Math.max(12, left)}px`;
  el.style.top = `${top}px`;
  el.querySelector(".ap-search").focus();
}

function updateAudioToolbar(clips) {
  const bar = document.getElementById("clipsToolbar");
  if (!bar) return;
  const has = clips && clips.length > 0;
  bar.style.display = has ? "flex" : "none";
  const clear = document.getElementById("btnClearAudios");
  if (clear) clear.style.display = Object.keys(state.narratorAudios || {}).length > 0 ? "inline-block" : "none";
  if (!has) {
    const info = document.getElementById("audioAssignInfo");
    if (info) info.style.display = "none";
  }
}

function showAudioAssignInfo(assigned, leftover) {
  const info = document.getElementById("audioAssignInfo");
  if (!info) return;
  const nameOf = p => p.split(/[\\/]/).pop();
  const esc = s => String(s).replace(/[&<>"]/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[ch]));
  let html = "";
  if (assigned.length) {
    html += `<strong>✓ ${assigned.length} audio(s) asignado(s):</strong> ` +
      assigned.map(([id, p]) => `línea ${id} ← ${esc(nameOf(p))}`).join(" · ");
  }
  if (leftover.length) {
    html += `<br><span class="warn">⚠ ${leftover.length} audio(s) sin escena libre: ${leftover.map(p => esc(nameOf(p))).join(", ")}</span>`;
  }
  info.innerHTML = html + `<span class="audio-assign-close">cerrar</span>`;
  info.style.display = "block";
}

// Reparte varios audios entre las escenas:
//  1) por el número del nombre (02_voz.mp3 -> línea 2)
//  2) los que no tienen número, en orden (A-Z, 2 antes que 10) a las escenas que aún no tienen audio propio
function assignAudiosToScenes(files) {
  const clips = state.clipsData || [];
  if (!clips.length || !files || !files.length) return;
  const narr = clips.filter(c => c.kind === "narrator");
  const eligible = narr.length ? narr : clips;
  // Por NÚMERO el audio va a esa escena sea del tipo que sea (04.mp3 -> escena 4, aunque sea de un
  // personaje). Antes solo se buscaba entre las líneas del narrador y el audio terminaba en otra escena.
  const ids = new Set(clips.map(c => c.clip_id));
  const nameOf = p => p.split(/[\\/]/).pop();
  const numberOf = name => {
    const base = name.replace(/\.[^.]+$/, "");
    const m = base.match(/^\s*(\d{1,4})(?!\d)/) || base.match(/(?<!\d)(\d{1,4})(?!\d)/);
    return m ? parseInt(m[1], 10) : null;
  };
  const sorted = [...files].sort((a, b) =>
    nameOf(a).localeCompare(nameOf(b), undefined, { numeric: true, sensitivity: "base" }));

  state.narratorAudios = state.narratorAudios || {};
  const assigned = [], rest = [], taken = new Set();
  sorted.forEach(p => {
    const n = numberOf(nameOf(p));
    if (n !== null && ids.has(n) && !taken.has(n)) {
      state.narratorAudios[n] = p; taken.add(n); assigned.push([n, p]);
    } else {
      rest.push(p);
    }
  });
  const free = eligible.filter(c => !taken.has(c.clip_id) && !state.narratorAudios[c.clip_id]);
  const leftover = [];
  rest.forEach(p => {
    const c = free.shift();
    if (c) { state.narratorAudios[c.clip_id] = p; assigned.push([c.clip_id, p]); }
    else leftover.push(p);
  });
  assigned.sort((a, b) => a[0] - b[0]);
  showAudioAssignInfo(assigned, leftover);
  triggerAnalyze();
}

document.getElementById("btnBulkAudios").addEventListener("click", async () => {
  if (!window.pywebview) return;
  if (state.audioDialogOpen) return;
  state.audioDialogOpen = true;
  let res;
  try {
    res = await window.pywebview.api.browse_audio_files();
  } finally {
    state.audioDialogOpen = false;
  }
  if (res && res.error) { alert("No se pudo abrir el selector de audios: " + res.error); return; }
  if (res && res.files && res.files.length) assignAudiosToScenes(res.files);
});

document.getElementById("btnClearAudios").addEventListener("click", () => {
  state.narratorAudios = {};
  const info = document.getElementById("audioAssignInfo");
  if (info) info.style.display = "none";
  triggerAnalyze();
});

document.getElementById("audioAssignInfo").addEventListener("click", (e) => {
  if (e.target.classList.contains("audio-assign-close")) e.currentTarget.style.display = "none";
});

function renderClipsList(clips) {
  updateAudioToolbar(clips);
  if (!clips || clips.length === 0) {
    dom.clipsList.innerHTML = WELCOME_HTML;
    markWelcomeSteps();
    return;
  }

  let html = "";
  clips.forEach(clip => {
    const hasImg = clip.has_image;
    const cardClass = hasImg ? "clip-card" : "clip-card missing-image";

    let thumbHtml = "";
    const videoBadge = clip.is_video ? `<span class="clip-video-badge">🎬</span>` : "";
    if (hasImg && clip.thumbnail) {
      thumbHtml = `<img src="${clip.thumbnail}" alt="Clip ${clip.clip_id}" />${videoBadge}`;
    } else if (hasImg) {
      thumbHtml = `<div class="clip-thumb-missing" style="color: #00F0FF;">${clip.is_video ? "🎬" : "🖼️"}</div>`;
    } else {
      thumbHtml = `<div class="clip-thumb-missing">⚠ Falta #${clip.clip_id}</div>`;
    }

    const isStory = !!clip.kind && clip.kind !== "clip";
    const esc = s => String(s || "").replace(/[&<>"]/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[ch]));
    const whoHtml = isStory
      ? `<span class="clip-who ${clip.kind}">${clip.kind === "narrator" ? "🎙️ Narrador" : esc(clip.speaker)}</span>`
      : "";
    const labelText = (isStory ? `LÍNEA ${clip.clip_id}` : `CLIP ${clip.clip_id}`) + (clip.parts > 1 ? ` · PARTE ${clip.part}/${clip.parts}` : "");
    const durText = (isStory && clip.kind === "dialogue")
      ? `${clip.duration}s · audio del video`
      : `${clip.duration}s · ${clip.word_count} palabras`;

    // Fila de audio de la escena: aparece en TODAS las escenas
    const hasOwn = !!clip.audio_name;
    const mode = clip.audio_mode || (state.audioPath ? "slice" : "missing");
    let nameText, nameClass = "", btnText = "＋ Agregar audio";
    if (hasOwn) {
      nameText = "<svg class=\"vn-ico\" width=\"13\" height=\"13\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M4 15v-3a8 8 0 0 1 16 0v3\"/><rect x=\"3\" y=\"14\" width=\"4\" height=\"6\" rx=\"1.5\"/><rect x=\"17\" y=\"14\" width=\"4\" height=\"6\" rx=\"1.5\"/></svg> " + esc(clip.audio_name);
      btnText = "Cambiar audio";
    } else if (mode === "slice") {
      nameText = "<svg class=\"vn-ico\" width=\"13\" height=\"13\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M4 15v-3a8 8 0 0 1 16 0v3\"/><rect x=\"3\" y=\"14\" width=\"4\" height=\"6\" rx=\"1.5\"/><rect x=\"17\" y=\"14\" width=\"4\" height=\"6\" rx=\"1.5\"/></svg> Parte del audio único";
    } else if (mode === "video") {
      nameText = "<svg class=\"vn-ico\" width=\"13\" height=\"13\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M3 12h2M7 8.5v7M11 5v14M15 8v8M19 10.5v3\"/></svg> Audio del propio video";
      btnText = "Reemplazar audio";
    } else {
      nameText = "⚠ Sin audio (quedará en silencio)";
      nameClass = "missing";
    }
    const audioRow = `
          <div class="clip-audio-row">
            <span class="clip-audio-name ${nameClass}">${nameText}</span>
            <button class="btn-clip-audio" data-action="add" data-clip="${clip.clip_id}">${btnText}</button>
            ${clip.audio_manual ? `<button class="btn-clip-audio ghost" data-action="remove" data-clip="${clip.clip_id}">Quitar</button>` : ""}
            ${hasImg && clip.image_path ? `<button class="btn-clip-audio rep-video" data-replace="${clip.clip_id}" title="Cambiar el video o la imagen de esta escena por otro de tu PC"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 8h12l-3-3M20 16H8l3 3"/></svg> Reemplazar ${clip.is_video ? "video" : "imagen"}</button>` : ""}
            ${(state.replacedScenes || []).includes(String(clip.clip_id)) ? '<span class="clip-replaced">↻ Reemplazada</span>' : ""}
          </div>`;

    html += `
      <div class="${cardClass}">
        <div class="clip-thumb-box">
          ${thumbHtml}
        </div>
        <div class="clip-content">
          <div class="clip-meta-row">
            <span class="clip-badge">${labelText}</span>
            ${clip.edited ? '<span class="clip-edited" title="Editada a mano en la línea de tiempo (Vista previa)">✎ Editada a mano</span>' : ""}
            ${whoHtml}
            <span class="clip-time-range">${clip.start_time_str} - ${clip.end_time_str}</span>
            <span class="clip-duration-tag">${durText}</span>
            <span class="clip-img-name">${clip.image_name || "Sin archivo"}</span>
          </div>
          <div class="clip-text-snippet">${clip.text || "<em>(Sin texto)</em>"}</div>
          ${audioRow}
        </div>
      </div>
    `;
  });

  dom.clipsList.innerHTML = html;
}

// ============================================================
// RENDER PROCESS (COMPLETO O VISTA PREVIA 15s)
// ============================================================

async function executeRender(isPreview = false) {
  if (!window.pywebview) return;
  if (!state.imagesFolder) {
    alert("Por favor selecciona la carpeta (o los archivos) de imágenes o videos.");
    return;
  }

  // FIX HIGH-03: Verificar que hay clips válidos (evitar race condition con debounce)
  if (dom.btnRender.disabled) {
    alert("El proyecto aún no está listo. Espera a que se complete el análisis.");
    return;
  }

  // Mostrar modal en estado Rendering
  dom.renderModal.classList.add("active");
  dom.stateRendering.classList.remove("hidden");
  dom.stateSuccess.classList.add("hidden");
  dom.stateError.classList.add("hidden");

  dom.renderProgressBar.style.width = "0%";
  dom.renderPercent.innerText = "0%";
  dom.renderTime.innerText = isPreview ? "Generando vista previa (15s)..." : "Iniciando renderizado...";
  startRenderTimer();

  const renderOptions = {
    enable_camera_motion: state.enableCameraMotion,
    camera_motion_type: state.cameraMotionType,
    zoom_intensity: state.zoomIntensity,
    enable_transitions: state.enableTransitions,
    transition_style: state.activePreset,
    transition_pool: state.transitionPool,
    transition_frequency: state.transitionFrequency,
    transition_duration: state.transitionDuration,
    transition_scene_only: !!state.transitionSceneOnly,
    export_timestamps: dom.checkTimestamps.checked,
    preview_mode: isPreview,
    preview_duration: 15.0,

    // Overlays Dinámicos (Intro & Outro)
    enable_intro_overlay: state.enableOverlays && state.introEnabled && !!(state.introOverlay && state.introOverlay.path),
    intro_overlay_path: state.introOverlay ? state.introOverlay.path : null,
    intro_overlay_duration: state.introDuration,
    intro_overlay_position: state.introPosition,
    intro_overlay_type: state.introChroma ? "chromakey" : "alpha",
    intro_chroma_similarity: state.introChromaSimilarity,

    enable_outro_overlay: state.enableOverlays && state.outroEnabled && !!(state.outroOverlay && state.outroOverlay.path),
    outro_overlay_path: state.outroOverlay ? state.outroOverlay.path : null,
    outro_overlay_duration: state.outroDuration,
    outro_overlay_position: state.outroPosition,
    outro_overlay_type: state.outroChroma ? "chromakey" : "alpha",
    outro_chroma_similarity: state.outroChromaSimilarity,

    // Resolución y Audio
    resolution: state.resolution,
    normalize_audio: state.normalizeAudio,

    // Clips de video
    ...getTrimOptions(),
    video_extend_mode: (document.getElementById("selectVideoExtend") || {}).value || "freeze",
    video_fit: (document.getElementById("selectVideoFit") || {}).value || "contain",

    // Subtítulos automáticos
    subtitles_enabled: subState.enabled,
    subtitle_template: subState.template,
    subtitle_color: subState.color,
    subtitle_position: subState.position,
    subtitle_size: subState.size,
    subtitle_export_srt: subState.srt && !isPreview,

    // v5.8: música de fondo con ducking
    ...(window.vnMusic ? window.vnMusic.options() : {}),

    // v8.9: marca de agua
    ...(window.vnWatermark ? window.vnWatermark.options() : {}),
    ...(window.vnChapter ? window.vnChapter.options() : {}),

    // v6.5: igualar el volumen de las voces
    level_voices: ((document.getElementById("selectLevelVoices") || { value: "on" }).value) !== "off",

    // v4.3: notificación de Windows al terminar (si estás en otra ventana)
    notify_done: (document.getElementById("checkNotifyDone") || { checked: true }).checked
  };

  await window.pywebview.api.start_render(
    state.audioPath,
    state.imagesFolder,
    state.scriptText,
    state.outputFolder,
    renderOptions
  );
}

dom.btnRender.addEventListener("click", () => executeRender(false));
if (dom.btnPreview) {
  dom.btnPreview.addEventListener("click", () => executeRender(true));
}

// Callbacks globales invocados desde Python
// Tiempo transcurrido y restante del renderizado (el "00:15 / 05:44" de arriba es la posición dentro del VIDEO)
let renderTimer = null;
function startRenderTimer() {
  state.renderStartedAt = Date.now();
  state.lastProgressAt = Date.now();
  state.lastPercent = 0;
  const first = document.getElementById("renderEta");
  if (first) first.innerText = "";
  clearInterval(renderTimer);
  renderTimer = setInterval(() => {
    const el = document.getElementById("renderEta");
    if (!el) return;
    const elapsed = (Date.now() - state.renderStartedAt) / 1000;
    const p = state.lastPercent || 0;
    let txt = `Tiempo transcurrido ${formatSeconds(elapsed)}`;
    if (p >= 3 && p < 100) txt += ` · faltan aprox. ${formatSeconds(elapsed * (100 - p) / p)}`;
    const idle = (Date.now() - state.lastProgressAt) / 1000;
    if (idle > 45 && p < 100) txt += ` · sin avance hace ${Math.round(idle)} s (las escenas pesadas tardan; sigue trabajando)`;
    el.innerText = txt;
  }, 1000);
}
function stopRenderTimer() {
  clearInterval(renderTimer);
  renderTimer = null;
}

window.onRenderProgress = function(pdata) {
  const percent = pdata.percent || 0;
  // Un "latido" informa qué escenas se procesan, pero no cuenta como avance real
  if (!pdata.heartbeat) state.lastProgressAt = Date.now();
  state.lastPercent = percent;
  dom.renderProgressBar.style.width = `${percent}%`;
  dom.renderPercent.innerText = `${Math.round(percent)}%`;

  if (pdata.current_sec !== undefined && pdata.total_sec !== undefined) {
    const curStr = formatSeconds(pdata.current_sec);
    const totStr = formatSeconds(pdata.total_sec);
    dom.renderTime.innerText = `${curStr} / ${totStr}`;
  }

  if (pdata.encoder_desc) {
    dom.renderEncoderTag.innerText = pdata.encoder_desc;
  }
};

// v8.8: por qué no se usó Whisper, en palabras simples
function whisperWhy(r) {
  r = String(r || "");
  if (r.startsWith("no_instalado")) return "Whisper no está incluido en esta instalación";
  if (r.startsWith("sin_modelo")) return "Whisper no pudo descargar su modelo de voz: la primera vez necesita internet (unos 500 MB) y luego funciona sin internet" + (r.length > 11 ? ` — detalle: ${r.slice(11, 160)}` : "");
  if (r.startsWith("sin_palabras")) return "Whisper no reconoció voz en el audio";
  if (r.startsWith("sin_audio")) return "no hay un audio de voz que escuchar";
  if (r.startsWith("error")) return "Whisper falló al escuchar el audio" + (r.length > 7 ? ` — detalle: ${r.slice(7, 160)}` : "");
  return "Whisper no estuvo disponible";
}

window.onRenderComplete = function(result) {
  stopRenderTimer();
  state.lastResult = result;
  dom.stateRendering.classList.add("hidden");
  dom.stateSuccess.classList.remove("hidden");

  if (result.is_preview) {
    if (dom.successTitle) dom.successTitle.innerText = `¡Vista previa de ${result.preview_duration} s lista!`;
    dom.btnOpenVideo.innerText = "▶ Reproducir vista previa";
  } else {
    if (dom.successTitle) dom.successTitle.innerText = "¡Video generado con éxito!";
    dom.btnOpenVideo.innerText = "▶ Reproducir video";
  }

  let meta = `Archivo: ${result.video_path}\nTamaño: ${result.size_mb} MB\nCodificador: ${result.encoder_used}`;
  if (result.subtitles) {
    meta += result.subtitles === "whisper"
      ? "\nSubtítulos: sincronizados con Whisper"
      : "\nSubtítulos: repartidos por escena (" + whisperWhy(result.subtitles_reason) + ")";
  }
  if (result.srt_path) meta += `\nSubtítulos .srt: ${result.srt_path}`;
  if (result.music) meta += `\nMúsica de fondo: ${result.music}`;
  if (result.music_error) meta += `\n⚠ ${result.music_error}`;
  if (result.watermark) meta += `\nMarca de agua: ${result.watermark}`;
  if (result.watermark_error) meta += `\n⚠ ${result.watermark_error}`;
  dom.successMeta.innerText = meta;
};

window.onRenderError = function(errMsg) {
  stopRenderTimer();
  dom.stateRendering.classList.add("hidden");
  dom.stateError.classList.remove("hidden");
  dom.errorBox.innerText = errMsg || "Error desconocido durante la exportación.";
};

// Botones del modal
dom.btnCancelRender.addEventListener("click", async () => {
  if (window.pywebview) {
    await window.pywebview.api.cancel_render();
  }
  stopRenderTimer();
  dom.renderModal.classList.remove("active");
});

dom.btnOpenVideo.addEventListener("click", () => {
  if (state.lastResult && state.lastResult.video_path && window.pywebview) {
    window.pywebview.api.open_video(state.lastResult.video_path);
  }
});

dom.btnOpenFolder.addEventListener("click", () => {
  if (state.lastResult && state.lastResult.video_path && window.pywebview) {
    window.pywebview.api.open_folder(state.lastResult.video_path);
  }
});

dom.btnCloseModal.addEventListener("click", () => {
  dom.renderModal.classList.remove("active");
});

dom.btnCloseErrorModal.addEventListener("click", () => {
  dom.renderModal.classList.remove("active");
});

function formatSeconds(sec) {
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}`;
}

// ═══ RESOLUCIÓN DE SALIDA ═══
const selectResolution = document.getElementById("selectResolution");
if (selectResolution) {
  selectResolution.addEventListener("change", (e) => {
    state.resolution = e.target.value;
    // Actualizar la métrica de resolución en el panel
    const resMap = {
      vertical: "1080 × 1920",
      square: "1080 × 1080",
      horizontal: "1920 × 1080"
    };
    const metricRes = document.getElementById("metricRes");
    if (metricRes) metricRes.innerText = resMap[state.resolution] || "1080 × 1920";
  });
}

// ═══ DRAG & DROP ═══
function setupDragDrop(element, accept, handler) {
  if (!element) return;
  element.addEventListener("dragover", (e) => {
    e.preventDefault();
    element.style.borderColor = "var(--accent-emerald)";
    element.style.boxShadow = "0 0 12px rgba(0, 240, 255, 0.15)";
  });
  element.addEventListener("dragleave", (e) => {
    e.preventDefault();
    element.style.borderColor = "";
    element.style.boxShadow = "";
  });
  element.addEventListener("drop", (e) => {
    e.preventDefault();
    element.style.borderColor = "";
    element.style.boxShadow = "";
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      const file = files[0];
      const ext = file.name.split('.').pop().toLowerCase();
      if (accept.includes(ext)) {
        handler(file);
      }
    }
  });
}

// Drop de texto en el script editor
const scriptInput = document.getElementById("scriptInput");
if (scriptInput) {
  setupDragDrop(scriptInput, ["txt"], (file) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      scriptInput.value = e.target.result;
      state.scriptText = e.target.result;
      if (typeof triggerAnalyze === "function") triggerAnalyze();
    };
    reader.readAsText(file);
  });
}


// ============================================================
// SUBTÍTULOS AUTOMÁTICOS (v3.0)
// Un solo color de acento en todo el video. La configuración se guarda y se recuerda.
// ============================================================
const SUB_COLOR_NAMES = {
  "#FFC845": "Dorado", "#00F0FF": "Azul eléctrico", "#FFFFFF": "Blanco",
  "#FF5C8A": "Rosa", "#3DFFB0": "Verde menta", "#FF3B3B": "Rojo"
};
const SUB_TEMPLATE_POS = { karaoke: "bottom", palabra: "center", destacado: "center", caja: "bottom", elegante: "bottom",
  pop: "center", cajapal: "bottom", neon: "bottom", maquina: "bottom", impacto: "center", contorno: "bottom", sombra3d: "center", documental: "bottom" };
const SUB_SCALE = { small: 0.82, medium: 1, large: 1.2 };
const subState = { enabled: false, template: "karaoke", color: "#FFC845", position: "auto", size: "medium", srt: false };

const subDom = {
  toggle: document.getElementById("toggleSubtitles"),
  options: document.getElementById("fxSubtitlesOptions"),
  preview: document.getElementById("subPreview"),
  text: document.getElementById("subPreviewText"),
  tplBtns: document.querySelectorAll(".sub-tpl-btn"),
  swatches: document.querySelectorAll(".sub-swatch[data-color]"),
  custom: document.getElementById("subColorCustom"),
  colorName: document.getElementById("subColorName"),
  position: document.getElementById("selectSubPosition"),
  size: document.getElementById("selectSubSize"),
  srt: document.getElementById("checkSubSrt")
};

function applySubStateToUI() {
  subDom.toggle.checked = subState.enabled;
  subDom.options.classList.toggle("hidden", !subState.enabled);
  subDom.tplBtns.forEach(b => b.classList.toggle("active", b.dataset.tpl === subState.template));
  const c = subState.color.toUpperCase();
  let known = false;
  subDom.swatches.forEach(sw => {
    const on = sw.dataset.color.toUpperCase() === c;
    sw.classList.toggle("active", on);
    if (on) known = true;
  });
  const customLabel = document.querySelector(".sub-swatch-custom");
  if (customLabel) {
    customLabel.classList.toggle("active", !known);
    customLabel.style.setProperty("--sw", c);
  }
  subDom.custom.value = c.toLowerCase();
  subDom.colorName.innerText = SUB_COLOR_NAMES[c] || c;
  subDom.position.value = subState.position;
  subDom.size.value = subState.size;
  subDom.srt.checked = subState.srt;
  subDom.preview.style.setProperty("--sub-accent", c);
  subDom.preview.style.setProperty("--sub-scale", SUB_SCALE[subState.size] || 1);
  restartSubPreview();
}

function saveSubtitleSettings() {
  try { localStorage.setItem("vn_subtitles", JSON.stringify(subState)); } catch (e) {}
  try {
    if (window.pywebview && window.pywebview.api && window.pywebview.api.save_settings) {
      window.pywebview.api.save_settings({ subtitles: { ...subState } });
    }
  } catch (e) {}
}

async function loadSubtitleSettings() {
  let saved = null;
  try {
    if (window.pywebview && window.pywebview.api && window.pywebview.api.get_settings) {
      const all = await window.pywebview.api.get_settings();
      saved = all && all.subtitles;
    }
  } catch (e) {}
  if (!saved) {
    try { saved = JSON.parse(localStorage.getItem("vn_subtitles") || "null"); } catch (e) {}
  }
  if (saved && typeof saved === "object") {
    if (typeof saved.enabled === "boolean") subState.enabled = saved.enabled;
    if (SUB_TEMPLATE_POS[saved.template]) subState.template = saved.template;
    if (/^#[0-9a-fA-F]{6}$/.test(saved.color || "")) subState.color = saved.color.toUpperCase();
    if (["auto", "top", "center", "bottom"].includes(saved.position)) subState.position = saved.position;
    if (SUB_SCALE[saved.size]) subState.size = saved.size;
    if (typeof saved.srt === "boolean") subState.srt = saved.srt;
  }
  applySubStateToUI();
}

function setSub(changes) {
  Object.assign(subState, changes);
  applySubStateToUI();
  saveSubtitleSettings();
}

subDom.toggle.addEventListener("change", e => setSub({ enabled: e.target.checked }));
subDom.tplBtns.forEach(b => b.addEventListener("click", () => setSub({ template: b.dataset.tpl })));
subDom.swatches.forEach(sw => sw.addEventListener("click", () => setSub({ color: sw.dataset.color.toUpperCase() })));
subDom.custom.addEventListener("input", e => setSub({ color: e.target.value.toUpperCase() }));
subDom.position.addEventListener("change", e => setSub({ position: e.target.value }));
subDom.size.addEventListener("change", e => setSub({ size: e.target.value }));
subDom.srt.addEventListener("change", e => setSub({ srt: e.target.checked }));

// ── Vista previa animada (imita lo que se quema en el video) ──
const SUB_SAMPLE = "Todo pasa por algo, confía en el proceso de Dios.".split(" ");
let subTimer = null;
let subIdx = 0;

function subChunks(tpl) {
  const maxW = { karaoke: 3, palabra: 1, destacado: 4, caja: 7, elegante: 7, pop: 2, cajapal: 3, neon: 3, maquina: 6, impacto: 5, contorno: 3, sombra3d: 2, documental: 12 }[tpl] || 3;
  const out = [];
  let cur = [];
  SUB_SAMPLE.forEach(w => {
    if (cur.length && (cur.length >= maxW || /[,.]$/.test(cur[cur.length - 1]))) { out.push(cur); cur = []; }
    cur.push(w);
  });
  if (cur.length) out.push(cur);
  return out;
}

function subEsc(t) { return t.replace(/[&<>"]/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[ch])); }

function subWord(w, upper) {
  return upper ? w.replace(/[.,;:]/g, "").toUpperCase() : w;
}

function renderSubFrame() {
  const tpl = subState.template;
  const chunks = subChunks(tpl);
  const flat = [];
  chunks.forEach((ch, ci) => ch.forEach((w, wi) => flat.push({ ci, wi })));
  const step = flat[subIdx % flat.length];
  const ch = chunks[step.ci];
  const upper = ["karaoke", "palabra", "destacado", "pop", "cajapal", "neon", "impacto", "contorno", "sombra3d"].includes(tpl);
  const el = subDom.text;
  const pos = subState.position === "auto" ? SUB_TEMPLATE_POS[tpl] : subState.position;
  el.className = `sub-preview-text t-${tpl} pos-${pos}`;
  const words = ch.map(w => subEsc(subWord(w, upper)));
  let html = "";
  if (tpl === "karaoke") {
    html = words.map((w, k) => k === step.wi ? `<span class="acc big">${w}</span>` : w).join(" ");
    if (step.wi === 0) html = `<span class="pop">${html}</span>`;
  } else if (tpl === "palabra") {
    html = `<span class="pop">${words[step.wi]}</span>`;
  } else if (tpl === "destacado") {
    let key = 0;
    ch.forEach((w, k) => { if (w.replace(/[^\p{L}]/gu, "").length > ch[key].replace(/[^\p{L}]/gu, "").length) key = k; });
    html = words.map((w, k) => k === key ? `<span class="acc big">${w}</span>` : w).join(" ");
    if (step.wi === 0) html = `<span class="pop">${html}</span>`;
  } else if (tpl === "caja") {
    html = `<span class="box">${words.map((w, k) => k === step.wi ? `<span class="acc">${w}</span>` : w).join(" ")}</span>`;
  } else if (tpl === "pop" || tpl === "cajapal" || tpl === "neon" || tpl === "contorno") {
    const cls = { pop: "acc popw", cajapal: "wbox", neon: "glow", contorno: "big" }[tpl];
    html = words.map((w, k) => k === step.wi ? `<span class="${cls}">${w}</span>` : w).join(" ");
    if (step.wi === 0 && tpl !== "neon") html = `<span class="pop">${html}</span>`;
  } else if (tpl === "maquina") {
    const full = words.join(" ");
    const upto = words.slice(0, step.wi + 1).join(" ");
    html = `<span class="box">${upto}<span class="cur">|</span><span class="ghost">${full.slice(upto.length)}</span></span>`;
  } else if (tpl === "impacto") {
    let key = 0;
    ch.forEach((w, k) => { if (w.replace(/[^\p{L}]/gu, "").length > ch[key].replace(/[^\p{L}]/gu, "").length) key = k; });
    html = `<small>${words.filter((w, k) => k !== key).join(" ")}</small><b class="acc">${words[key]}</b>`;
    if (step.wi === 0) html = `<span class="pop">${html}</span>`;
  } else if (tpl === "sombra3d") {
    html = words.join(" ");
    if (step.wi === 0) html = `<span class="pop">${html}</span>`;
  } else {
    html = words.join(" ");
    if (step.wi === 0) el.classList.add("fade");
  }
  el.innerHTML = html;
  subIdx++;
}

function restartSubPreview() {
  clearInterval(subTimer);
  subIdx = 0;
  if (!subState.enabled) return;
  renderSubFrame();
  subTimer = setInterval(renderSubFrame, ["elegante", "documental"].includes(subState.template) ? 420 : 360);
}

applySubStateToUI();


// ============================================================
// MODO AMBIENTE (v3.1)
// El fondo toma los colores de la escena que tienes delante (o sobre la que pasas el mouse).
// Dos capas se turnan con un fundido suave. Sin escenas: grafito neutro.
// ============================================================
const AMB_DEFAULT = ["58 64 80", "34 40 56", "64 56 52", "40 44 58"];
const ambLayers = [];
let ambActive = 0;
let ambCurrentSrc = "";

(function initAmbient() {
  const grain = document.createElement("div");
  grain.id = "vnGrain";
  document.body.prepend(grain);
  for (let i = 0; i < 2; i++) {
    const layer = document.createElement("div");
    layer.className = "vn-amb";
    document.body.prepend(layer);
    ambLayers.push(layer);
  }
  setAmbientColors(AMB_DEFAULT);
})();

function setAmbientColors(cols) {
  const next = ambLayers[1 - ambActive];
  ["--amb1", "--amb2", "--amb3", "--amb4"].forEach((v, i) => next.style.setProperty(v, cols[i]));
  next.classList.add("on");
  ambLayers[ambActive].classList.remove("on");
  ambActive = 1 - ambActive;
}

function ambientFromThumb(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      try {
        const c = document.createElement("canvas");
        c.width = 3; c.height = 3;
        const ctx = c.getContext("2d");
        ctx.drawImage(img, 0, 0, 3, 3);
        const d = ctx.getImageData(0, 0, 3, 3).data;
        const px = (x, y) => {
          const i = (y * 3 + x) * 4;
          // Aclara un poco y limita: el resplandor debe ser suave, nunca chillón
          return [d[i], d[i + 1], d[i + 2]].map(v => Math.min(235, Math.round(v * 1.25))).join(" ");
        };
        resolve([px(0, 0), px(2, 0), px(1, 2), px(1, 1)]);
      } catch (e) { reject(e); }
    };
    img.onerror = reject;
    img.src = src;
  });
}

function updateAmbient(src) {
  if (!src || src === ambCurrentSrc) return;
  ambCurrentSrc = src;
  ambientFromThumb(src).then(setAmbientColors).catch(() => {});
}

function ambientResetIfEmpty() {
  if (!dom.clipsList.querySelector(".clip-card img")) {
    if (ambCurrentSrc) { ambCurrentSrc = ""; setAmbientColors(AMB_DEFAULT); }
    return true;
  }
  return false;
}

// La escena "que tienes delante": la que está a un tercio de la altura de la lista
function ambientFromScroll() {
  if (ambientResetIfEmpty()) return;
  const box = dom.clipsList.getBoundingClientRect();
  const target = box.top + box.height / 3;
  let best = null, bestDist = Infinity;
  dom.clipsList.querySelectorAll(".clip-card").forEach(card => {
    const r = card.getBoundingClientRect();
    const dist = Math.abs((r.top + r.bottom) / 2 - target);
    if (dist < bestDist) { bestDist = dist; best = card; }
  });
  const img = best && best.querySelector(".clip-thumb-box img");
  if (img) updateAmbient(img.src);
}

let ambScrollTimer = null;
dom.clipsList.addEventListener("scroll", () => {
  clearTimeout(ambScrollTimer);
  ambScrollTimer = setTimeout(ambientFromScroll, 180);
}, { passive: true });

let ambHoverTimer = null;
dom.clipsList.addEventListener("mouseover", e => {
  const card = e.target.closest(".clip-card");
  if (!card) return;
  clearTimeout(ambHoverTimer);
  ambHoverTimer = setTimeout(() => {
    const img = card.querySelector(".clip-thumb-box img");
    if (img) updateAmbient(img.src);
  }, 250);
});

// Cada vez que se redibuja la lista de escenas
new MutationObserver(() => {
  clearTimeout(ambScrollTimer);
  ambScrollTimer = setTimeout(ambientFromScroll, 120);
}).observe(dom.clipsList, { childList: true });


// ============================================================
// v3.3 — Pantalla de inicio y ventana de render
// ============================================================
const WELCOME_HTML = `<div class="empty-state welcome"><div class="welcome-mark vn-hero" aria-hidden="true"><span class="vh-ring"></span><span class="vh-glow"></span><span class="vh-top"></span><span class="vh-clap"><span class="vh-play"></span></span><span class="vh-wave"><i style="--h:10px;--d:0s"></i><i style="--h:18px;--d:0.15s"></i><i style="--h:26px;--d:0.3s"></i><i style="--h:14px;--d:0.45s"></i><i style="--h:30px;--d:0.1s"></i><i style="--h:20px;--d:0.55s"></i><i style="--h:12px;--d:0.25s"></i><i style="--h:24px;--d:0.4s"></i><i style="--h:16px;--d:0.05s"></i><i style="--h:8px;--d:0.35s"></i></span><span class="vh-spark s1">✦</span><span class="vh-spark s2">✦</span><span class="vh-spark s3">✦</span></div><h3 class="welcome-title">Tu próxima historia empieza aquí</h3><p class="welcome-sub">Agrega tu material en el panel de la izquierda y las escenas aparecerán aquí solas.</p><div class="welcome-news"><span>NUEVO</span>Música de fondo que baja sola al hablar · en Estilo</div><ol class="welcome-steps"><li class="ws-item" data-step="audio"><span class="ws-ico"><svg class="vn-ico" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 12h2M7 8.5v7M11 5v14M15 8v8M19 10.5v3"/></svg></span><span class="ws-text"><strong>Voz del narrador</strong><span>Opcional: un audio único o uno por escena</span></span><span class="ws-check"><svg class="vn-ico" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg></span></li><li class="ws-item" data-step="media"><span class="ws-ico"><svg class="vn-ico" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4.5" width="18" height="15" rx="2.5"/><circle cx="8.5" cy="9.5" r="1.5"/><path d="m21 15-4.5-4.5L8 19"/></svg></span><span class="ws-text"><strong>Videos e imágenes</strong><span>La carpeta con tus escenas numeradas</span></span><span class="ws-check"><svg class="vn-ico" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg></span></li><li class="ws-item" data-step="script"><span class="ws-ico"><svg class="vn-ico" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 3h7.5L19 7.5V21H7z"/><path d="M14 3v5h5M10 12.5h6M10 16.5h6"/></svg></span><span class="ws-text"><strong>Guion</strong><span>Pega la historia o carga un archivo .txt</span></span><span class="ws-check"><svg class="vn-ico" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg></span></li></ol></div>`;

// Marca los pasos ya hechos en la pantalla de inicio (solo visual)
function markWelcomeSteps() {
  const box = dom.clipsList.querySelector(".welcome");
  if (!box) return;
  const done = {
    audio: !!state.audioPath,
    media: !!(state.imagesFolder && (state.imagesFolder.length || state.imagesFolder)),
    script: !!(dom.scriptInput && dom.scriptInput.value.trim())
  };
  box.querySelectorAll(".ws-item").forEach(li => li.classList.toggle("done", !!done[li.dataset.step]));
}
setInterval(markWelcomeSteps, 1200);
markWelcomeSteps();



// ============================================================
// v4.0 — Actualizaciones por parche (.zip)
// ============================================================
(function () {
  const btn = document.getElementById("btnApplyUpdate");
  if (!btn) return;
  const $ = (id) => document.getElementById(id);
  const menu = $("updMenu"), status = $("updMenuStatus"), input = $("inpUpdLink");
  const btnCheck = $("btnUpdCheck"), btnSave = $("btnUpdSaveLink"), btnZip = $("btnUpdZip");

  function setStatus(text, kind) {
    status.innerText = text || "";
    status.className = "upd-menu-status" + (kind ? " " + kind : "");
  }
  function closeMenu() { if (menu) menu.classList.add("hidden"); }

  async function openMenu() {
    menu.classList.remove("hidden");
    setStatus("");
    try {
      const v = await window.pywebview.api.get_app_version();
      $("updMenuVer").innerText = "Tienes la v" + (v && v.version || "?");
      const src = await window.pywebview.api.get_update_source();
      input.value = (src && src.url) || "";
    } catch (e) {}
  }

  // Instalar un parche .zip elegido a mano (como antes)
  window.vnApplyZip = async function () {
    if (!window.pywebview || !window.pywebview.api || !window.pywebview.api.apply_update) return;
    const res = await window.pywebview.api.apply_update();
    if (!res || (!res.ok && !res.error)) return;          // se canceló
    if (res.error) { alert("No se pudo actualizar:\n\n" + res.error); return; }
    const again = confirm(`VideoNarrator se actualizó de v${res.previous} a v${res.version} (${res.files} archivo(s)).`
      + (res.notes ? `\n\nNovedades:\n${res.notes}` : "")
      + "\n(La versión anterior quedó guardada en la carpeta app_respaldo.)"
      + "\n\n¿Reiniciar VideoNarrator ahora para usar la versión nueva?");
    if (again && window.pywebview.api.restart_app) {
      await window.pywebview.api.restart_app();
    } else {
      btn.innerText = "Reiniciar para v" + res.version;
      btn.dataset.restart = "1";
    }
  };

  btn.addEventListener("click", (ev) => {
    if (btn.dataset.restart === "1") return;              // ya instalada: este clic reinicia (ver abajo)
    if (!window.pywebview || !menu) { window.vnApplyZip(); return; }
    ev.stopPropagation();
    if (menu.classList.contains("hidden")) openMenu(); else closeMenu();
  });
  if (!menu) return;
  menu.addEventListener("click", (ev) => ev.stopPropagation());
  document.addEventListener("click", closeMenu);
  document.addEventListener("keydown", (ev) => { if (ev.key === "Escape") closeMenu(); });

  btnCheck.addEventListener("click", async () => {
    btnCheck.disabled = true;
    setStatus("Buscando…");
    let res = null;
    try { res = await window.pywebview.api.check_for_update(true); } catch (e) { res = { error: String(e) }; }
    btnCheck.disabled = false;
    if (res && res.available) {
      setStatus(`¡Hay una versión nueva: v${res.version}!`, "ok");
      if (window.vnShowUpdate) window.vnShowUpdate(res);
      closeMenu();
    } else if (res && res.error) {
      setStatus(res.error, "err");
    } else if (res && res.configured === false) {
      setStatus("Todavía no hay un enlace de actualizaciones. Pégalo abajo y pulsa Guardar.", "err");
    } else {
      setStatus(`Tienes la versión más nueva (v${(res && res.current) || "?"}).`, "ok");
    }
  });

  btnSave.addEventListener("click", async () => {
    const r = await window.pywebview.api.set_update_source(input.value.trim());
    if (r && r.error) { setStatus(r.error, "err"); return; }
    setStatus(input.value.trim() ? "Enlace guardado. Pulsa «Buscar actualizaciones» para probarlo." : "Enlace borrado.", "ok");
  });

  btnZip.addEventListener("click", () => { closeMenu(); window.vnApplyZip(); });
})();

(async function showVersion() {
  try {
    if (!window.pywebview || !window.pywebview.api || !window.pywebview.api.get_app_version) { setTimeout(showVersion, 400); return; }
    const v = await window.pywebview.api.get_app_version();
    const badge = document.querySelector(".badge-pro");
    if (badge && v && v.version && v.version !== "?") badge.innerText = "v" + v.version;
  } catch (e) {}
})();


// ============================================================
// v4.3 — "Avisarme cuando termine el render" (se recuerda entre sesiones)
// ============================================================
(function notifyPref() {
  const chk = document.getElementById("checkNotifyDone");
  if (!chk) return;
  chk.addEventListener("change", () => {
    try { window.pywebview && window.pywebview.api.save_settings({ notify_done: chk.checked }); } catch (e) {}
  });
  (async function load() {
    if (!window.pywebview || !window.pywebview.api || !window.pywebview.api.get_settings) { setTimeout(load, 400); return; }
    try {
      const all = await window.pywebview.api.get_settings();
      if (all && typeof all.notify_done === "boolean") chk.checked = all.notify_done;
    } catch (e) {}
  })();
})();


// ============================================================
// v4.3 — Aviso automático de nueva versión (GitHub Releases)
// ============================================================
(function updateBanner() {
  const $ = (id) => document.getElementById(id);
  const banner = $("updBanner");
  if (!banner) return;
  const ui = {
    version: $("updVersion"), sub: $("updSub"), actions: $("updActions"),
    now: $("btnUpdNow"), notesBtn: $("btnUpdNotes"), later: $("btnUpdLater"),
    progress: $("updProgress"), fill: $("updProgressFill"), pct: $("updPct"),
    notes: $("updNotes"), notesText: $("updNotesText"), page: $("btnUpdPage")
  };
  let info = null;
  let phase = "offer";          // offer → downloading → ready (reiniciar) | error

  const isRendering = () => {
    const m = document.getElementById("renderModal");
    const st = document.getElementById("stateRendering");
    return !!(m && m.classList.contains("active") && st && !st.classList.contains("hidden"));
  };

  window.vnShowUpdate = function (data) { show(data); };
  function show(data) {
    info = data;
    phase = "offer";
    ui.version.innerText = "v" + data.version;
    ui.notesText.innerText = data.notes || "Esta versión no trae notas.";
    if (data.url) {
      const mb = !data.size ? "" : data.size < 1048576 ? ` (${Math.max(1, Math.round(data.size / 1024))} KB)` : ` (${(data.size / 1048576).toFixed(1)} MB)`;
      ui.sub.innerText = `Tienes la v${data.current}. Se descarga e instala en segundos${mb}.`;
      ui.now.innerText = "Actualizar ahora";
      ui.now.classList.remove("hidden");
    } else {
      ui.sub.innerText = `Tienes la v${data.current}. Esta versión se instala con el instalador completo.`;
      ui.now.innerText = "Descargar instalador";
    }
    banner.classList.remove("hidden");
  }

  async function check() {
    if (!window.pywebview || !window.pywebview.api || !window.pywebview.api.check_for_update) { setTimeout(check, 500); return; }
    try {
      const res = await window.pywebview.api.check_for_update(false);
      if (res && res.available) show(res);
    } catch (e) {}
  }
  setTimeout(check, 2500);      // espera a que la app termine de abrir

  window.onUpdateProgress = function (p) {
    if (phase !== "downloading") return;
    const pct = p && p.percent >= 0 ? p.percent : null;
    ui.fill.style.width = (pct === null ? 50 : pct) + "%";
    ui.pct.innerText = pct === null ? `${((p.done || 0) / 1048576).toFixed(1)} MB` : `${Math.round(pct)}%`;
  };

  ui.now.addEventListener("click", async () => {
    if (!info) return;
    if (phase === "ready") {                          // reiniciar
      if (isRendering()) { alert("Espera a que termine el render para reiniciar VideoNarrator."); return; }
      ui.now.disabled = true;
      ui.sub.innerText = "Reiniciando VideoNarrator…";
      const r = await window.pywebview.api.restart_app();
      if (r && r.error) { ui.now.disabled = false; ui.sub.innerText = r.error; }
      return;
    }
    if (!info.url) { window.pywebview.api.open_release_page(); return; }
    if (phase === "downloading") return;
    phase = "downloading";
    ui.now.disabled = true; ui.notesBtn.disabled = true; ui.later.disabled = true;
    ui.now.innerText = "Descargando…";
    ui.sub.innerText = `Descargando la v${info.version}…`;
    ui.fill.style.width = "0%"; ui.pct.innerText = "0%";
    ui.progress.classList.remove("hidden");
    let res = null;
    try { res = await window.pywebview.api.install_update(); } catch (e) { res = { error: String(e) }; }
    ui.notesBtn.disabled = false; ui.later.disabled = false; ui.now.disabled = false;
    if (res && res.ok) {
      phase = "ready";
      ui.fill.style.width = "100%"; ui.pct.innerText = "100%";
      ui.sub.innerText = `Listo: v${res.previous} → v${res.version}. Reinicia para usar la versión nueva.`;
      ui.now.innerText = "Reiniciar ahora";
      ui.later.innerText = "Al cerrar";
    } else {
      phase = "offer";
      ui.progress.classList.add("hidden");
      ui.sub.innerText = (res && res.error) || "No se pudo actualizar.";
      ui.now.innerText = "Reintentar";
    }
  });

  ui.notesBtn.addEventListener("click", () => {
    const open = ui.notes.classList.toggle("hidden") === false;
    ui.notesBtn.innerText = open ? "Ocultar novedades" : "Ver novedades";
  });
  ui.page.addEventListener("click", () => { try { window.pywebview.api.open_release_page(); } catch (e) {} });
  ui.later.addEventListener("click", () => {
    banner.classList.add("hidden");
    if (phase === "ready") {
      // El parche ya está instalado: el botón "Actualizar" de la barra recuerda reiniciar
      const b = document.getElementById("btnApplyUpdate");
      if (b) { b.innerText = "Reiniciar para v" + info.version; b.dataset.restart = "1"; }
    }
  });

  // El botón "Actualizar" de la barra: reinicia si ya hay una versión instalada esperando,
  // o vuelve a buscar en internet antes de pedir un .zip a mano.
  const navBtn = document.getElementById("btnApplyUpdate");
  if (navBtn) {
    navBtn.addEventListener("click", async (ev) => {
      if (navBtn.dataset.restart === "1") {
        ev.stopImmediatePropagation();
        if (isRendering()) { alert("Espera a que termine el render para reiniciar VideoNarrator."); return; }
        await window.pywebview.api.restart_app();
      }
    }, true);
  }
})();


// ============================================================
// v4.9 — Acceso con usuario y contraseña
// ============================================================
(function authGate() {
  const $ = (id) => document.getElementById(id);
  const gate = $("authGate");
  if (!gate) return;
  const st = { checking: $("authChecking"), form: $("authForm"), offline: $("authOffline") };
  const user = $("authUser"), pass = $("authPass"), msg = $("authMsg"), submit = $("authSubmit");
  const btnUser = $("btnUser"), btnUserName = $("btnUserName");

  function showState(name) {
    Object.entries(st).forEach(([k, el]) => el.classList.toggle("hidden", k !== name));
  }
  function lock(state) {
    document.body.classList.add("auth-locked");
    gate.classList.remove("hidden");
    showState(state);
    if (state === "form") setTimeout(() => (user.value ? pass : user).focus(), 50);
  }
  function unlock(data) {
    gate.classList.add("hidden");
    document.body.classList.remove("auth-locked");
    if (window.vnSetAdmin) window.vnSetAdmin(!!(data && data.es_admin), data && data.usuario);
    if (data && data.required !== false && data.usuario) {
      btnUserName.innerText = data.nombre || data.usuario;
      btnUser.title = `Sesión de ${data.usuario} · clic para cerrar sesión`;
      btnUser.classList.remove("hidden");
    } else {
      btnUser.classList.add("hidden");
    }
  }
  function rendering() {
    const r = document.getElementById("stateRendering");
    const m = document.getElementById("renderModal");
    return !!(m && m.classList.contains("active") && r && !r.classList.contains("hidden"));
  }
  function handle(res, firstCheck) {
    if (res && !res.ok && !firstCheck && rendering()) {   // no tapar un render en curso: se revisa al terminar
      setTimeout(() => check(false), 60 * 1000);
      return;
    }
    if (!res) { lock("offline"); $("authOfflineMsg").innerText = "No se pudo verificar el acceso."; return; }
    if (res.ok) { unlock(res); return; }
    if (res.motivo === "red" || res.motivo === "servidor" || res.motivo === "ssl") {
      if (!firstCheck && !document.body.classList.contains("auth-locked")) return;   // a mitad del trabajo no se corta
      $("authOfflineMsg").innerText = res.mensaje || "No se pudo verificar el acceso.";
      lock("offline");
      return;
    }
    if (res.usuario) user.value = res.usuario;
    msg.innerText = res.motivo === "sin_sesion" ? "" : (res.mensaje || "");
    btnUser.classList.add("hidden");
    lock("form");
  }

  // v8.2: nunca más "Verificando tu acceso…" para siempre
  let bridgeWait = 0;
  async function check(first) {
    const api = window.pywebview && window.pywebview.api;
    if (!api || typeof api.auth_status !== "function") {
      if (first) {
        lock("checking");
        if (!bridgeWait) bridgeWait = Date.now();
        if (Date.now() - bridgeWait > 30000) {          // la parte de Python no respondió al abrir
          bridgeWait = 0;
          const pw = window.pywebview, fx = pw && pw.api ? Object.keys(pw.api).length : -1;
          const eng = (navigator.userAgent.match(/Edg\/[\d.]+/) || ["sin WebView2"])[0];
          $("authOfflineMsg").innerText = "VideoNarrator no terminó de arrancar. Pulsa Reintentar; si sigue igual, ciérralo por completo y ábrelo de nuevo (o reinicia la PC).\n\nDetalle para soporte: puente " + (pw ? "sí" : "no") + " · funciones " + fx + " · " + eng;
          lock("offline");
          return;
        }
      }
      setTimeout(() => check(first), 300);
      return;
    }
    bridgeWait = 0;
    if (first) lock("checking");
    let res = null, late = false;
    const guard = first ? setTimeout(() => {          // el servidor tarda demasiado
      late = true;
      $("authOfflineMsg").innerText = "El servidor de acceso no respondió a tiempo. Revisa tu internet y pulsa Reintentar.";
      lock("offline");
    }, 35000) : null;
    try { res = await api.auth_status(); } catch (e) { res = null; }
    clearTimeout(guard);
    if (late && !(res && res.ok)) return;
    handle(res, first);
  }
  // v8.6: vuelve la verificación automática al abrir (la sesión guardada entra sola) y la revisión
  // cada 5 minutos. Funciona también por la conexión de respaldo (v8.5).
  try { const last = localStorage.getItem("vnLastUser"); if (last) user.value = last; } catch (e) {}
  check(true);
  setInterval(() => check(false), 5 * 60 * 1000);    // cada 5 min: acceso bloqueado o cuenta abierta en otra PC

  // Espera (hasta 25 s) a que la parte de Python esté conectada con la pantalla
  async function bridge() {
    for (let i = 0; i < 100; i++) {
      const api = window.pywebview && window.pywebview.api;
      if (api && typeof api.auth_login === "function") return { api };   // envuelto: nunca se trata como promesa
      await new Promise(r => setTimeout(r, 250));
    }
    return null;
  }

  st.form.addEventListener("submit", async (ev) => {
    ev.preventDefault();
    if (!user.value.trim() || !pass.value) { msg.innerText = "Escribe tu usuario y tu contraseña."; return; }
    submit.disabled = true;
    submit.innerText = "Entrando…";
    msg.innerText = "";
    let res = null;
    const api = ((await bridge()) || {}).api;
    if (!api) res = { mensaje: "VideoNarrator no terminó de arrancar en esta PC. Ciérralo por completo y ábrelo de nuevo." };
    else {
      try { res = await api.auth_login(user.value.trim(), pass.value); } catch (e) { res = { mensaje: String(e) }; }
      if (res && res.ok) { try { localStorage.setItem("vnLastUser", user.value.trim()); } catch (e) {} }
    }
    submit.disabled = false;
    submit.innerText = "Entrar";
    if (res && res.ok) { pass.value = ""; unlock(res); return; }
    msg.innerText = (res && res.mensaje) || "No se pudo ingresar.";
    pass.select();
  });

  $("authEye").addEventListener("click", () => {
    const show = pass.type === "password";
    pass.type = show ? "text" : "password";
    $("authEye").classList.toggle("on", show);
    pass.focus();
  });

  $("authRetry").addEventListener("click", () => check(true));

  // v6.5: el botón con tu nombre abre un menú (cambiar contraseña / cerrar sesión)
  const userMenu = $("userMenu");
  btnUser.addEventListener("click", (ev) => {
    ev.stopPropagation();
    if (!userMenu) { doLogout(); return; }
    userMenu.classList.toggle("hidden");
  });
  document.addEventListener("click", (ev) => {
    if (userMenu && !userMenu.classList.contains("hidden") && !ev.target.closest(".user-wrap")) userMenu.classList.add("hidden");
  });
  if (userMenu) userMenu.addEventListener("click", (ev) => {
    const b = ev.target.closest("button[data-act]");
    if (!b) return;
    userMenu.classList.add("hidden");
    if (b.dataset.act === "logout") doLogout();
    if (b.dataset.act === "password" && window.vnChangePassword) window.vnChangePassword(btnUserName.innerText);
  });

  async function doLogout() {
    const r = document.getElementById("stateRendering");
    const m = document.getElementById("renderModal");
    if (m && m.classList.contains("active") && r && !r.classList.contains("hidden")) {
      alert("Espera a que termine el render para cerrar sesión.");
      return;
    }
    if (!confirm(`¿Cerrar la sesión de ${btnUserName.innerText}?\n\nPara volver a entrar necesitarás tu usuario y contraseña.`)) return;
    try { await window.pywebview.api.auth_logout(); } catch (e) {}
    pass.value = "";
    msg.innerText = "";
    btnUser.classList.add("hidden");
    if (window.vnSetAdmin) window.vnSetAdmin(false);
    lock("form");
  }
})();


// ============================================================
// v6.5 — Cambiar la contraseña (cualquier usuario)
// ============================================================
(function changePassword() {
  const $ = (id) => document.getElementById(id);
  const ov = $("pwOverlay");
  if (!ov) return;
  const f = { old: $("pwOld"), n1: $("pwNew"), n2: $("pwNew2"), show: $("pwShow"), msg: $("pwMsg"), save: $("pwSave") };
  const close = () => ov.classList.add("hidden");
  const say = (t, ok) => { f.msg.className = "auth-msg" + (ok ? " ok" : ""); f.msg.style.color = ok ? "#00F0FF" : ""; f.msg.innerText = t || ""; };
  window.vnChangePassword = function (name) {
    [f.old, f.n1, f.n2].forEach(i => { i.value = ""; i.type = "password"; });
    f.show.checked = false; say(""); f.save.disabled = false;
    $("pwSub").innerText = `Cuenta: ${name || ""} · tu sesión en esta PC sigue abierta`;
    ov.classList.remove("hidden");
    setTimeout(() => f.old.focus(), 50);
  };
  f.show.addEventListener("change", () => [f.old, f.n1, f.n2].forEach(i => { i.type = f.show.checked ? "text" : "password"; }));
  $("pwClose").addEventListener("click", close);
  $("pwCancel").addEventListener("click", close);
  ov.addEventListener("click", (ev) => { if (ev.target === ov) close(); });
  $("pwForm").addEventListener("submit", async (ev) => {
    ev.preventDefault();
    if (!f.old.value) { say("Escribe tu contraseña actual."); f.old.focus(); return; }
    if (f.n1.value.length < 6) { say("La contraseña nueva debe tener al menos 6 caracteres."); f.n1.focus(); return; }
    if (f.n1.value !== f.n2.value) { say("Las dos contraseñas nuevas no coinciden."); f.n2.focus(); return; }
    if (f.n1.value === f.old.value) { say("La contraseña nueva debe ser distinta de la actual."); f.n1.focus(); return; }
    f.save.disabled = true; say("Guardando…", true);
    let r = null;
    try { r = await window.pywebview.api.change_password(f.old.value, f.n1.value); } catch (e) { r = { ok: false, mensaje: String(e) }; }
    f.save.disabled = false;
    if (r && r.ok) {
      [f.old, f.n1, f.n2].forEach(i => { i.value = ""; });
      say("✓ Contraseña cambiada. Úsala la próxima vez que entres.", true);
      setTimeout(close, 1800);
    } else {
      say((r && r.mensaje) || "No se pudo cambiar la contraseña.");
    }
  });
})();


// ============================================================
// v5.3 — Mis historias: se guardan solas y se reabren donde las dejaste
// ============================================================
(function projectsModule() {
  const $ = (id) => document.getElementById(id);
  const api = () => (window.pywebview && window.pywebview.api) || null;
  const P = {
    id: null, nombre: "", restoring: true, started: false,
    lastSnap: "", timer: null, saving: false,
    poster: "", posterSrc: "", posterDirty: false, resumen: {}, items: []
  };
  const ui = {
    chip: $("projChip"), name: $("projName"), st: $("projState"), menu: $("projMenu"),
    lib: $("libOverlay"), grid: $("libGrid"), search: $("libSearch"), count: $("libCount"),
    pmenu: $("posterMenu")
  };
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"]/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[ch]));
  const rendering = () => {
    const m = document.getElementById("renderModal"), r = document.getElementById("stateRendering");
    return !!(m && m.classList.contains("active") && r && !r.classList.contains("hidden"));
  };

  // ── Lo que se guarda ──────────────────────────────────────
  function controlsSnapshot() {
    const out = {};
    document.querySelectorAll(".panel-left input[id], .panel-left select[id]").forEach(el => {
      if (el.type === "file" || el.closest("#subtitlesCard")) return;   // los subtítulos son una preferencia general
      if (el.id === "checkNotifyDone") return;
      out[el.id] = (el.type === "checkbox" || el.type === "radio") ? el.checked : el.value;
    });
    return out;
  }
  function snapshot() {
    return {
      contenido: {
        audioPath: state.audioPath || "",
        imagesFolder: state.imagesFolder || "",
        outputFolder: state.outputFolder || "",
        scriptText: dom.scriptInput.value || "",
        narratorAudios: state.narratorAudios || {},
        sceneEdits: state.sceneEdits || {},
        sceneOrder: state.sceneOrder || [],
        introOverlay: state.introOverlay || null,
        outroOverlay: state.outroOverlay || null,
        activePreset: state.activePreset || "",
        transitionPool: state.transitionPool || [],
        musicPath: (window.vnMusic && window.vnMusic.path) || ""
      },
      controles: controlsSnapshot()
    };
  }
  function hasContent() {
    const m = state.imagesFolder;
    return !!(state.audioPath || (Array.isArray(m) ? m.length : m) || (dom.scriptInput.value || "").trim());
  }

  // ── Guardado automático ───────────────────────────────────
  function setStatus(kind) {
    ui.st.className = "proj-state" + (kind ? " " + kind : "");
    ui.st.innerText = kind === "saving" ? "Guardando…" : kind === "saved" ? "Guardado" : kind === "err" ? "No se pudo guardar" : "";
  }
  function paintChip() {
    ui.name.innerText = P.id ? (P.nombre || "Sin título") : "Sin título";
    ui.name.title = P.id ? P.nombre : "";
    const hint = document.getElementById("projHint");
    if (hint) hint.innerText = P.id ? "· se guarda sola mientras trabajas" : "Se guardará sola cuando agregues tu material";
    ui.chip.disabled = !P.id;
    ui.menu.querySelectorAll(".needs-proj").forEach(b => b.disabled = !P.id);
  }
  function scheduleSave() {
    if (P.restoring || !P.started) return;
    clearTimeout(P.timer);
    P.timer = setTimeout(save, 800);
  }
  async function save() {
    clearTimeout(P.timer);
    if (P.restoring || !P.started || !api() || P.saving) return;
    const snap = snapshot();
    const key = JSON.stringify(snap);
    if (key === P.lastSnap && !P.posterDirty) return;
    if (!P.id && !hasContent()) return;
    P.saving = true;
    setStatus("saving");
    let res = null;
    try {
      res = await api().project_save(Object.assign({ id: P.id, resumen: P.resumen, poster: P.poster }, snap));
    } catch (e) { res = { error: String(e) }; }
    P.saving = false;
    if (res && res.ok) {
      P.id = res.id; P.nombre = res.nombre; P.lastSnap = key; P.posterDirty = false;
      setStatus("saved");
      paintChip();
    } else {
      setStatus("err");
    }
  }
  window.addEventListener("beforeunload", () => { if (P.timer) save(); });

  // Después de cada análisis: resumen y póster de la historia
  async function afterAnalyze() {
    const clips = state.clipsData || [];
    const first = clips.find(c => c.image_path);
    const src = first ? first.image_path : "";
    if (src && src !== P.posterSrc && api() && api().project_poster) {
      try {
        const r = await api().project_poster(src);
        if (r && r.poster) { P.poster = r.poster; P.posterSrc = src; P.posterDirty = true; }
      } catch (e) {}
    }
    P.resumen = { escenas: clips.length, duracion: (dom.metricTotalDuration && dom.metricTotalDuration.innerText) || "",
                  poster_src: P.posterSrc };
    scheduleSave();
  }

  const _origAnalyze = triggerAnalyze;
  triggerAnalyze = async function () {
    if (P.restoring) return;
    const r = await _origAnalyze.apply(this, arguments);
    afterAnalyze();
    return r;
  };
  const panel = document.querySelector(".panel-left");
  if (panel) ["input", "change", "click"].forEach(t => panel.addEventListener(t, scheduleSave, true));

  // ── Reabrir una historia ──────────────────────────────────
  function showOverlay(slot, res) {
    if (!res || !res.path) return;
    const pre = slot === "intro" ? "intro" : "outro";
    state[pre + "Overlay"] = res;
    dom[pre + "Filename"].innerText = res.filename || "";
    dom[pre + "Filename"].title = res.path;
    dom[pre + "TypeTag"].innerText = res.is_video ? `Video (${res.duration}s)` : (res.is_vertical ? "Imagen 9:16" : "Imagen");
    dom[pre + "PreviewThumb"].innerHTML = res.thumbnail
      ? `<img src="data:image/jpeg;base64,${res.thumbnail}" alt="" />`
      : `<span class="ov-thumb-icon">${res.is_video ? "🎬" : "🖼️"}</span>`;
    dom[pre + "EmptyState"].classList.add("hidden");
    dom[pre + "LoadedState"].classList.remove("hidden");
  }
  function applyControls(ctrls) {
    Object.entries(ctrls || {}).forEach(([id, val]) => {
      const el = document.getElementById(id);
      if (!el || el.closest("#subtitlesCard") || el.type === "file") return;
      if (el.type === "checkbox" || el.type === "radio") {
        if (el.checked !== !!val) { el.checked = !!val; el.dispatchEvent(new Event("change", { bubbles: true })); }
      } else if (el.value !== String(val)) {
        el.value = String(val);
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
      }
    });
  }
  async function restore(pid) {
    const d = await api().project_get(pid);
    if (!d || d.error) return false;
    const c = d.contenido || {};
    const faltan = d.faltan || [];
    P.id = d.id; P.nombre = d.nombre || ""; P.poster = d.poster || ""; P.resumen = d.resumen || {};
    P.posterSrc = P.resumen.poster_src || "";

    applyControls(d.controles);
    if (c.activePreset && typeof applyPreset === "function") {
      applyPreset(c.activePreset);
      if (Array.isArray(c.transitionPool) && c.transitionPool.length) {
        state.transitionPool = [...c.transitionPool];
        state.activePreset = c.activePreset;
        updateChipsUI(); updateRotationSummary();
      }
    }
    if (c.introOverlay && !faltan.includes(c.introOverlay.path)) showOverlay("intro", c.introOverlay);
    if (c.outroOverlay && !faltan.includes(c.outroOverlay.path)) showOverlay("outro", c.outroOverlay);
    if (c.outputFolder) { state.outputFolder = c.outputFolder; dom.outputPathDisplay.innerText = `Salida: ${c.outputFolder}`; }

    if (c.audioPath) {
      const a = await api().describe_audio(c.audioPath);
      if (a && !a.missing) {
        state.audioPath = a.path; state.audioDuration = a.duration || 0;
        dom.audioFileName.innerText = `✓ ${a.filename}`;
        dom.audioDurationTag.innerText = a.duration_str || "--:--";
        if (!state.outputFolder) dom.outputPathDisplay.innerText = "Carpeta de salida: junto al audio";
      } else {
        dom.audioFileName.innerText = `⚠ No se encontró: ${(a && a.filename) || c.audioPath}`;
      }
    }
    const media = c.imagesFolder;
    if (typeof media === "string" && media) {
      const r = await api().describe_images_folder(media);
      if (r && !r.missing && !r.error) {
        state.imagesFolder = media; state.imagesCount = r.count || 0;
        dom.imagesFolderName.innerText = `✓ ${media}`;
        dom.imagesCountTag.innerText = r.videos > 0 ? `${r.count} archivos (${r.videos} video${r.videos === 1 ? "" : "s"})` : `${r.count} imágenes`;
      } else {
        dom.imagesFolderName.innerText = `⚠ No se encontró la carpeta: ${media}`;
      }
    } else if (Array.isArray(media) && media.length) {
      const ok = media.filter(f => !faltan.includes(f));
      if (ok.length) {
        const info = await api().describe_media_selection(ok);
        state.imagesFolder = ok; state.imagesCount = info.count || 0;
        dom.imagesFolderName.innerText = `✓ ${ok.length} archivo(s) seleccionado(s)`;
        dom.imagesCountTag.innerText = info.videos > 0 ? `${info.count} archivos (${info.videos} video${info.videos === 1 ? "" : "s"})` : `${info.count} imágenes`;
      }
    }
    if (c.musicPath && window.vnMusic) await window.vnMusic.set(c.musicPath);
    const na = {};
    Object.entries(c.narratorAudios || {}).forEach(([k, v]) => { if (v && !faltan.includes(v)) na[k] = v; });
    state.narratorAudios = na;
    state.sceneEdits = (c.sceneEdits && typeof c.sceneEdits === "object") ? c.sceneEdits : {};
    state.sceneOrder = Array.isArray(c.sceneOrder) ? c.sceneOrder : [];
    dom.scriptInput.value = c.scriptText || "";
    return { ok: true, faltan };
  }

  // ── Arranque: espera el ingreso; empieza limpia (o con la historia elegida en «Mis historias») ──
  async function start() {
    if (!api() || !api().projects_list || document.body.classList.contains("auth-locked")) { setTimeout(start, 300); return; }
    let res = null;
    try {
      // Al abrir la app empieza limpia; solo al cambiar de historia se abre la elegida
      const st = await api().project_startup();
      if (st && st.id) res = await restore(st.id);
    } catch (e) {}
    P.restoring = false;
    P.lastSnap = JSON.stringify(snapshot());
    P.started = true;
    paintChip();
    if (res && res.ok) {
      setStatus("saved");
      await triggerAnalyze();
      if (res.faltan.length) {
        const list = res.faltan.slice(0, 6).map(f => "• " + f.split(/[\\/]/).pop()).join("\n");
        setTimeout(() => alert(`Algunos archivos de «${P.nombre}» ya no están donde estaban:\n\n${list}${res.faltan.length > 6 ? "\n…" : ""}\n\nVuelve a elegirlos en el panel izquierdo.`), 300);
      }
    }
    refreshShelf();
  }
  start();

  // ── Cambiar de historia (se recarga la pantalla: arranca limpia) ──
  async function switchTo(pid) {
    if (rendering()) { alert("Espera a que termine el render para cambiar de historia."); return; }
    if (pid && pid === P.id) { closeLib(); return; }
    await save();
    await api().project_set_current(pid || "");
    location.reload();
  }

  // ── Menú de la historia actual ────────────────────────────
  function closeMenus() {
    ui.menu.classList.add("hidden"); ui.chip.classList.remove("open");
    ui.pmenu.classList.add("hidden");
    document.querySelectorAll(".poster-more.on").forEach(b => b.classList.remove("on"));
  }
  ui.chip.addEventListener("click", (ev) => {
    ev.stopPropagation();
    const open = ui.menu.classList.contains("hidden");
    closeMenus();
    if (open) { ui.menu.classList.remove("hidden"); ui.chip.classList.add("open"); paintChip(); }
  });
  const btnNew = document.getElementById("storyNew"), btnLib = document.getElementById("storyLib");
  if (btnNew) btnNew.addEventListener("click", (ev) => { ev.stopPropagation(); switchTo(""); });
  if (btnLib) btnLib.addEventListener("click", (ev) => { ev.stopPropagation(); openLib(); });
  ui.menu.addEventListener("click", async (ev) => {
    const b = ev.target.closest("button[data-act]");
    if (!b || b.disabled) return;
    ev.stopPropagation();
    closeMenus();
    const act = b.dataset.act;
    if (act === "new") return switchTo("");
    if (act === "library") return openLib();
    if (P.id) await save();
    return actOn(P.id, P.nombre, act);
  });
  document.addEventListener("click", (ev) => { if (!ev.target.closest(".poster-menu, .proj-menu")) closeMenus(); });
  document.addEventListener("keydown", (ev) => {
    if (ev.key !== "Escape") return;
    if (!ui.pmenu.classList.contains("hidden") || !ui.menu.classList.contains("hidden")) closeMenus();
    else if (!ui.lib.classList.contains("hidden")) closeLib();
  });

  async function actOn(pid, nombre, act) {
    if (!pid) return;
    if (act === "open") return switchTo(pid);
    if (act === "rename") {
      const nuevo = prompt("Nombre de la historia:", nombre || "");
      if (nuevo === null || !nuevo.trim()) return;
      const r = await api().project_rename(pid, nuevo.trim());
      if (r && r.error) { alert(r.error); return; }
      if (pid === P.id) { P.nombre = r.nombre; paintChip(); }
      return refreshAll();
    }
    if (act === "duplicate") {
      const r = await api().project_duplicate(pid);
      if (r && r.error) { alert(r.error); return; }
      await refreshAll();
      if (confirm(`Se creó «${r.nombre}».\n\n¿Abrirla ahora?`)) return switchTo(r.id);
      return;
    }
    if (act === "delete") {
      if (!confirm(`¿Eliminar la historia «${nombre}»?\n\nTus videos, imágenes y audios NO se borran: solo se quita la historia de la lista.`)) return;
      const r = await api().project_delete(pid);
      if (r && r.error) { alert(r.error); return; }
      if (pid === P.id) { await api().project_set_current(""); location.reload(); return; }
      return refreshAll();
    }
  }

  // ── Biblioteca ────────────────────────────────────────────
  function ago(iso) {
    if (!iso) return "";
    const t = new Date(iso).getTime();
    if (isNaN(t)) return "";
    const s = Math.max(0, (Date.now() - t) / 1000);
    if (s < 60) return "Editada hace un momento";
    if (s < 3600) { const m = Math.round(s / 60); return `Editada hace ${m} min`; }
    if (s < 86400) { const h = Math.round(s / 3600); return `Editada hace ${h} h`; }
    const d = Math.round(s / 86400);
    if (d === 1) return "Editada ayer";
    if (d < 30) return `Editada hace ${d} días`;
    return "Editada el " + new Date(t).toLocaleDateString("es", { day: "numeric", month: "short", year: "numeric" });
  }
  function posterHTML(it, compact) {
    const r = it.resumen || {};
    const stats = [r.escenas ? `${r.escenas} escenas` : "", r.duracion && r.duracion !== "00:00" ? r.duracion : ""].filter(Boolean).join(" · ");
    const art = it.poster
      ? `<img src="${it.poster}" alt="" loading="lazy" />`
      : `<div class="poster-initial">${esc((it.nombre || "H").trim().charAt(0).toUpperCase())}</div>`;
    return `<div class="poster" tabindex="0" data-id="${esc(it.id)}">
      <div class="poster-art">${art}
        ${it.id === P.id ? '<span class="poster-badge">ABIERTA</span>' : ""}
        ${compact ? "" : `<button type="button" class="poster-more" title="Opciones" aria-label="Opciones">⋮</button>`}
        ${stats ? `<div class="poster-stats">${esc(stats)}</div>` : ""}
      </div>
      <div class="poster-name">${esc(it.nombre)}</div>
      <div class="poster-meta">${esc(ago(it.modificado))}</div>
    </div>`;
  }
  function drawGrid() {
    const q = (ui.search.value || "").trim().toLowerCase();
    const items = P.items.filter(it => !q || (it.nombre || "").toLowerCase().includes(q));
    ui.count.innerText = P.items.length
      ? `${P.items.length} historia${P.items.length === 1 ? "" : "s"} · se guardan solas mientras trabajas`
      : "Se guardan solas mientras trabajas";
    if (!P.items.length) {
      ui.grid.innerHTML = `<div class="lib-empty"><strong>AÚN NO HAY HISTORIAS</strong>Agrega tu audio, tus escenas o tu guion y la historia se guardará sola.<br>Aparecerá aquí para retomarla cuando quieras.</div>`;
    } else if (!items.length) {
      ui.grid.innerHTML = `<div class="lib-empty">Ninguna historia coincide con «${esc(q)}».</div>`;
    } else {
      ui.grid.innerHTML = items.map(it => posterHTML(it, false)).join("");
    }
  }
  async function loadItems() {
    try { const r = await api().projects_list(); P.items = (r && r.items) || []; } catch (e) { P.items = []; }
  }
  async function openLib() {
    await save();
    await loadItems();
    ui.search.value = "";
    drawGrid();
    ui.lib.classList.remove("hidden");
    setTimeout(() => ui.search.focus(), 60);
  }
  function closeLib() { ui.lib.classList.add("hidden"); closeMenus(); }
  async function refreshAll() {
    await loadItems();
    if (!ui.lib.classList.contains("hidden")) drawGrid();
    refreshShelf(true);
  }
  ui.search.addEventListener("input", drawGrid);
  $("libClose").addEventListener("click", closeLib);
  $("libNew").addEventListener("click", () => switchTo(""));
  ui.lib.addEventListener("click", (ev) => { if (ev.target === ui.lib) closeLib(); });

  function posterClick(ev) {
    const card = ev.target.closest(".poster");
    if (!card) return;
    const it = P.items.find(x => x.id === card.dataset.id);
    if (!it) return;
    const more = ev.target.closest(".poster-more");
    if (more) {
      ev.stopPropagation();
      const was = more.classList.contains("on");
      closeMenus();
      if (was) return;
      more.classList.add("on");
      const r = more.getBoundingClientRect();
      ui.pmenu.dataset.id = it.id;
      ui.pmenu.classList.remove("hidden");
      const w = ui.pmenu.offsetWidth, h = ui.pmenu.offsetHeight;
      ui.pmenu.style.left = Math.max(8, Math.min(window.innerWidth - w - 8, r.right - w)) + "px";
      ui.pmenu.style.top = (r.bottom + 6 + h > window.innerHeight ? r.top - h - 6 : r.bottom + 6) + "px";
      return;
    }
    switchTo(it.id);
  }
  ui.grid.addEventListener("click", posterClick);
  ui.grid.addEventListener("keydown", (ev) => { if (ev.key === "Enter" && ev.target.classList.contains("poster")) switchTo(ev.target.dataset.id); });
  ui.pmenu.addEventListener("click", (ev) => {
    const b = ev.target.closest("button[data-act]");
    if (!b) return;
    ev.stopPropagation();
    const it = P.items.find(x => x.id === ui.pmenu.dataset.id);
    closeMenus();
    if (it) actOn(it.id, it.nombre, b.dataset.act);
  });

  // ── Estante en la pantalla de bienvenida ──────────────────
  async function refreshShelf(skipLoad) {
    const box = dom.clipsList.querySelector(".welcome");
    if (!box) return;
    if (!skipLoad) await loadItems();
    let shelf = box.querySelector(".shelf");
    const items = P.items.filter(it => it.id !== P.id).slice(0, 5);
    if (!items.length) { if (shelf) shelf.remove(); return; }
    if (!shelf) { shelf = document.createElement("div"); shelf.className = "shelf"; box.appendChild(shelf); }
    shelf.innerHTML = `<div class="shelf-head"><span class="shelf-title">CONTINÚA UNA HISTORIA</span>
      <button type="button" class="shelf-all">Ver todas (${P.items.length}) →</button></div>
      <div class="shelf-row">${items.map(it => posterHTML(it, true)).join("")}</div>`;
    shelf.querySelector(".shelf-all").addEventListener("click", openLib);
    shelf.querySelector(".shelf-row").addEventListener("click", posterClick);
  }
  const _origRenderClips = renderClipsList;
  renderClipsList = function (clips) {
    _origRenderClips(clips);
    if ((!clips || !clips.length) && P.started) refreshShelf(true);
  };
})();


// ============================================================
// v5.4 — Pantalla de ingreso: pared de pósters, saludo y Bloq Mayús
// ============================================================
(function authScene() {
  const wall = document.getElementById("authWall");
  const gate = document.getElementById("authGate");
  if (!wall || !gate) return;

  const PH = [
    "radial-gradient(120% 90% at 30% 15%, #1d5866 0%, #0c2730 55%, #071218 100%)",
    "radial-gradient(120% 90% at 70% 10%, #2b2f6b 0%, #141633 55%, #090a17 100%)",
    "radial-gradient(120% 90% at 40% 20%, #0f6b73 0%, #0a2d33 55%, #05141a 100%)",
    "radial-gradient(120% 90% at 60% 15%, #3a2a55 0%, #1a1328 55%, #0b0812 100%)",
    "radial-gradient(120% 90% at 35% 10%, #164a5a 0%, #0b1f29 60%, #060d12 100%)",
    "radial-gradient(120% 90% at 65% 20%, #1f3f7a 0%, #0e1c38 55%, #070c18 100%)"
  ];
  let built = "";

  function build(posters) {
    const key = posters.join("|").length + ":" + posters.length;
    if (key === built) return;
    built = key;
    const cols = Math.max(7, Math.ceil((window.innerWidth * 1.25) / 186) + 1);
    const perCol = Math.max(5, Math.ceil((window.innerHeight * 1.3) / 270) + 1);
    let n = 0;
    const tile = () => {
      const i = n++;
      if (posters.length && (i % 3 !== 2 || posters.length > 4)) {
        return `<div class="wall-tile"><img src="${posters[i % posters.length]}" alt="" /></div>`;
      }
      return `<div class="wall-tile ph" style="--ph:${PH[i % PH.length]}"></div>`;
    };
    let html = "";
    for (let c = 0; c < cols; c++) {
      const tiles = Array.from({ length: perCol }, tile).join("");
      const dur = 80 + ((c * 37) % 50);                   // 80-130 s: movimiento lento y desparejo
      html += `<div class="wall-col${c % 2 ? " down" : ""}" style="--dur:${dur}s">${tiles}${tiles}</div>`;
    }
    wall.innerHTML = html;
  }
  build([]);

  async function loadPosters() {
    const api = window.pywebview && window.pywebview.api;
    if (!api || !api.projects_list) { setTimeout(loadPosters, 400); return; }
    try {
      const r = await api.projects_list();
      const posters = ((r && r.items) || []).map(it => it.poster).filter(Boolean).slice(0, 24);
      if (posters.length) build(posters);
    } catch (e) {}
    try {
      const v = await api.get_app_version();
      const el = document.getElementById("authVersion");
      if (el && v && v.version && v.version !== "?") el.innerText = "v" + v.version;
    } catch (e) {}
  }
  loadPosters();

  // Saludo según la hora
  const h = new Date().getHours();
  const g = document.getElementById("authGreeting");
  if (g) g.innerText = h >= 5 && h < 12 ? "Buenos días" : h >= 12 && h < 19 ? "Buenas tardes" : "Buenas noches";

  // Aviso de Bloq Mayús
  const pass = document.getElementById("authPass");
  const caps = document.getElementById("authCaps");
  if (pass && caps) {
    const check = (ev) => { try { caps.classList.toggle("hidden", !ev.getModifierState("CapsLock")); } catch (e) {} };
    pass.addEventListener("keydown", check);
    pass.addEventListener("keyup", check);
    pass.addEventListener("blur", () => caps.classList.add("hidden"));
  }
})();


// ============================================================
// v5.8 — Música de fondo con ducking
// ============================================================
(function musicCard() {
  const $ = (id) => document.getElementById(id);
  const toggle = $("toggleMusic"), box = $("fxMusicOptions");
  if (!toggle || !box) return;
  const nameEl = $("musicName"), metaEl = $("musicMeta"), play = $("btnMusicPlay"), audio = $("musicAudio");
  const M = { path: "", playing: false };
  const api = () => window.pywebview && window.pywebview.api;

  toggle.addEventListener("change", () => box.classList.toggle("hidden", !toggle.checked));

  function paint(info) {
    if (!info || !info.path) {
      M.path = "";
      nameEl.innerText = "Ninguna canción elegida";
      metaEl.innerText = "Usa música libre de derechos";
      nameEl.classList.remove("missing");
      play.disabled = true;
      return;
    }
    M.path = info.path;
    if (info.missing) {
      nameEl.innerText = "⚠ No se encontró: " + (info.filename || info.path);
      nameEl.classList.add("missing");
      metaEl.innerText = "Vuelve a elegirla";
      play.disabled = true;
      return;
    }
    nameEl.classList.remove("missing");
    if (info.is_folder) {
      nameEl.innerText = "📁 " + info.filename;
      metaEl.innerText = info.count
        ? `${info.count} canciones · el próximo video usará «${info.next}»`
        : "La carpeta no tiene audios";
      play.disabled = !info.count;
    } else {
      nameEl.innerText = "♪ " + info.filename;
      metaEl.innerText = "Duración " + (info.duration_str || "--:--");
      play.disabled = false;
    }
  }

  function stop() {
    try { audio.pause(); } catch (e) {}
    M.playing = false;
    play.classList.remove("on");
  }
  audio.addEventListener("ended", stop);

  async function choose(kind) {
    if (!api()) return;
    stop();
    const res = await api().browse_music(kind);
    if (!res || (!res.path && !res.error)) return;
    if (res.error) { metaEl.innerText = "⚠ " + res.error; return; }
    paint(res);
    if (!toggle.checked) { toggle.checked = true; toggle.dispatchEvent(new Event("change", { bubbles: true })); }
  }
  $("btnMusicFile").addEventListener("click", () => choose("file"));
  $("btnMusicFolder").addEventListener("click", () => choose("folder"));

  play.addEventListener("click", async () => {
    if (M.playing) { stop(); return; }
    if (!M.path || !api()) return;
    play.classList.add("loading");
    const start = parseFloat($("inpMusicStart").value) || 0;
    let r = null;
    try { r = await api().music_preview(M.path, start); } catch (e) { r = null; }
    play.classList.remove("loading");
    if (!r || !r.url) { metaEl.innerText = "⚠ " + ((r && r.error) || "No se pudo reproducir"); return; }
    const vol = { suave: 0.45, normal: 0.7, presente: 1 }[$("selectMusicVolume").value] || 0.7;
    audio.src = r.url;
    audio.volume = vol;
    try { await audio.play(); M.playing = true; play.classList.add("on"); } catch (e) {}
  });

  window.vnMusic = {
    get path() { return M.path; },
    async set(path) {
      if (!path) { paint(null); return; }
      try { paint(await api().describe_music(path)); } catch (e) { paint({ path, missing: true }); }
    },
    options() {
      const on = toggle.checked && !!M.path;
      return {
        music_enabled: on,
        music_path: on ? M.path : "",
        music_volume: $("selectMusicVolume").value,
        music_duck: $("selectMusicDuck").value,
        music_fade: $("checkMusicFade").checked,
        music_loop: $("checkMusicLoop").checked,
        music_start: parseFloat($("inpMusicStart").value) || 0
      };
    }
  };
})();


// ============================================================
// v6.1 — Panel de usuarios (solo administradores)
// ============================================================
(function adminPanel() {
  const $ = (id) => document.getElementById(id);
  const btn = $("btnAdmin"), ov = $("admOverlay");
  if (!btn || !ov) return;
  const list = $("admList"), form = $("admForm"), msg = $("admMsg"), search = $("admSearch");
  const f = { user: $("admUser"), name: $("admName"), pass: $("admPass"), vence: $("admVence"), never: $("admNever"),
              active: $("admActive"), isAdmin: $("admIsAdmin"), title: $("admFormTitle"), passLabel: $("admPassLabel") };
  const A = { me: "", users: [], editing: null };
  const api = () => window.pywebview && window.pywebview.api;
  const esc = (x) => String(x == null ? "" : x).replace(/[&<>"]/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[ch]));

  window.vnSetAdmin = function (flag, usuario) {
    btn.classList.toggle("hidden", !flag);
    if (usuario) A.me = String(usuario).toLowerCase();
    if (!flag) ov.classList.add("hidden");
  };

  function ago(iso) {
    if (!iso) return "nunca";
    const s = Math.max(0, (Date.now() - new Date(iso).getTime()) / 1000);
    if (s < 120) return "hace un momento";
    if (s < 3600) return `hace ${Math.round(s / 60)} min`;
    if (s < 86400) return `hace ${Math.round(s / 3600)} h`;
    const d = Math.round(s / 86400);
    return d === 1 ? "ayer" : d < 30 ? `hace ${d} días` : new Date(iso).toLocaleDateString("es");
  }
  const fmtDate = (d) => { if (!d) return ""; const [y, m, dd] = String(d).slice(0, 10).split("-"); return `${dd}/${m}/${y}`; };
  const today = () => new Date().toISOString().slice(0, 10);

  function chips(u) {
    const out = [];
    if (u.es_admin) out.push('<span class="adm-chip adm">ADMIN</span>');
    const vencido = u.vence && String(u.vence).slice(0, 10) < today();
    if (!u.activo) out.push('<span class="adm-chip bad">Bloqueado</span>');
    else if (vencido) out.push('<span class="adm-chip bad">Vencido</span>');
    else out.push('<span class="adm-chip ok">Activo</span>');
    if (u.bloqueado) out.push('<span class="adm-chip warn">Espera por intentos</span>');
    if (u.vence && !vencido) out.push(`<span class="adm-chip">Hasta ${fmtDate(u.vence)}</span>`);
    return out.join("");
  }

  function draw() {
    const q = (search.value || "").trim().toLowerCase();
    const items = A.users.filter(u => !q || u.usuario.includes(q) || String(u.nombre || "").toLowerCase().includes(q));
    $("admCount").innerText = `${A.users.length} usuario${A.users.length === 1 ? "" : "s"} · ${A.users.filter(u => u.en_uso).length} con sesión abierta`;
    if (!items.length) { list.innerHTML = `<div class="adm-empty">${A.users.length ? "Ningún usuario coincide." : "Todavía no hay usuarios."}</div>`; return; }
    list.innerHTML = items.map(u => {
      const off = !u.activo || (u.vence && String(u.vence).slice(0, 10) < today());
      const me = u.usuario === A.me;
      return `<div class="adm-row${A.editing === u.usuario ? " sel" : ""}" data-u="${esc(u.usuario)}">
        <div class="adm-av${off ? " off" : ""}">${esc((u.nombre || u.usuario).trim().charAt(0).toUpperCase())}</div>
        <div class="adm-who"><b>${esc(u.nombre || u.usuario)}${me ? " (tú)" : ""}</b><span>${esc(u.usuario)}</span></div>
        <div class="adm-chips">${chips(u)}</div>
        <div class="adm-info">${u.en_uso ? `En uso en <b>${esc(u.equipo_nombre || "una PC")}</b>` : "Sin sesión abierta"}<br>Último acceso: ${esc(ago(u.ultimo_acceso))}${u.version_app ? " · v" + esc(u.version_app) : ""}</div>
        <div class="adm-acts">
          <button type="button" class="btn-tool" data-a="edit">Editar</button>
          ${me ? "" : `<button type="button" class="btn-tool" data-a="toggle">${u.activo ? "Bloquear" : "Activar"}</button>`}
          ${u.en_uso && !me ? '<button type="button" class="btn-tool" data-a="kick" title="Cierra su sesión en la PC donde la tiene abierta">Cerrar sesión</button>' : ""}
          ${me ? "" : '<button type="button" class="danger" data-a="del">Borrar</button>'}
        </div>
      </div>`;
    }).join("");
  }

  async function load() {
    list.innerHTML = '<div class="adm-empty">Cargando usuarios…</div>';
    let r = null;
    try { r = await api().admin_list(); } catch (e) { r = { ok: false, mensaje: String(e) }; }
    if (!r || !r.ok) { list.innerHTML = `<div class="adm-empty">⚠ ${esc((r && r.mensaje) || "No se pudo cargar la lista.")}</div>`; return; }
    A.users = r.usuarios || [];
    draw();
  }

  function openForm(u) {
    A.editing = u ? u.usuario : null;
    form.classList.remove("hidden");
    form.parentElement.classList.add("editing");
    msg.innerText = ""; msg.className = "auth-msg";
    f.title.innerText = u ? "EDITAR USUARIO" : "NUEVO USUARIO";
    f.user.value = u ? u.usuario : ""; f.user.readOnly = !!u;
    f.name.value = u ? (u.nombre || "") : "";
    f.pass.value = "";
    f.passLabel.innerText = u ? "Nueva contraseña (déjala vacía para no cambiarla)" : "Contraseña";
    f.never.checked = !(u && u.vence);
    f.vence.value = u && u.vence ? String(u.vence).slice(0, 10) : "";
    f.vence.disabled = f.never.checked;
    f.active.checked = u ? !!u.activo : true;
    f.isAdmin.checked = !!(u && u.es_admin);
    const me = u && u.usuario === A.me;
    f.active.disabled = me; f.isAdmin.disabled = me;
    draw();
    setTimeout(() => (u ? f.name : f.user).focus(), 50);
  }
  function closeForm() { form.classList.add("hidden"); form.parentElement.classList.remove("editing"); A.editing = null; draw(); }

  f.never.addEventListener("change", () => { f.vence.disabled = f.never.checked; if (!f.never.checked && !f.vence.value) { const d = new Date(); d.setMonth(d.getMonth() + 1); f.vence.value = d.toISOString().slice(0, 10); } });
  $("admGen").addEventListener("click", () => {
    const abc = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    let p = ""; const rnd = new Uint32Array(10); crypto.getRandomValues(rnd);
    rnd.forEach(n => p += abc[n % abc.length]);
    f.pass.value = p;
  });

  form.addEventListener("submit", async (ev) => {
    ev.preventDefault();
    msg.className = "auth-msg";
    const usuario = f.user.value.trim().toLowerCase();
    const isNew = !A.editing;
    if (!/^[a-z0-9._-]{2,40}$/.test(usuario)) { msg.innerText = "Usuario: solo minúsculas, números, punto o guion, sin espacios ni tildes."; return; }
    if (isNew && A.users.some(u => u.usuario === usuario)) { msg.innerText = "Ese usuario ya existe."; return; }
    if ((isNew || f.pass.value) && f.pass.value.length < 6) { msg.innerText = "La contraseña debe tener al menos 6 caracteres."; return; }
    if (!f.never.checked && !f.vence.value) { msg.innerText = "Elige la fecha o marca «Sin vencimiento»."; return; }
    const datos = { usuario, nombre: f.name.value.trim(), vence: f.never.checked ? "" : f.vence.value };
    if (f.pass.value) datos.clave = f.pass.value;
    if (!f.active.disabled) datos.activo = f.active.checked;
    if (!f.isAdmin.disabled) datos.es_admin = f.isAdmin.checked;
    $("admSave").disabled = true;
    let r = null;
    try { r = await api().admin_save(datos); } catch (e) { r = { ok: false, mensaje: String(e) }; }
    $("admSave").disabled = false;
    if (!r || !r.ok) { msg.innerText = (r && r.mensaje) || "No se pudo guardar."; return; }
    const pass = f.pass.value;
    await load();
    if (isNew) {
      openForm(A.users.find(u => u.usuario === usuario));
      msg.className = "auth-msg ok";
      msg.innerText = `Usuario creado. Entrégale:\nUsuario: ${usuario}\nContraseña: ${pass}`;
    } else {
      msg.className = "auth-msg ok";
      msg.innerText = pass ? `Guardado. Nueva contraseña: ${pass}` : "Cambios guardados.";
      draw();
    }
  });
  $("admCancel").addEventListener("click", closeForm);

  list.addEventListener("click", async (ev) => {
    const b = ev.target.closest("button[data-a]");
    if (!b) return;
    const u = A.users.find(x => x.usuario === b.closest(".adm-row").dataset.u);
    if (!u) return;
    const a = b.dataset.a;
    if (a === "edit") return openForm(u);
    let r = null;
    if (a === "toggle") {
      if (u.activo && !confirm(`¿Bloquear a «${u.nombre || u.usuario}»?\n\nNo podrá usar VideoNarrator hasta que lo actives de nuevo. Si está usándolo, saldrá en unos minutos.`)) return;
      r = await api().admin_save({ usuario: u.usuario, activo: !u.activo, cerrar_sesion: u.activo });
    } else if (a === "kick") {
      if (!confirm(`¿Cerrar la sesión de «${u.nombre || u.usuario}» en ${u.equipo_nombre || "su PC"}?\n\nPodrá volver a entrar con su usuario y contraseña.`)) return;
      r = await api().admin_save({ usuario: u.usuario, cerrar_sesion: true });
    } else if (a === "del") {
      if (!confirm(`¿Borrar a «${u.nombre || u.usuario}» para siempre?\n\nNo podrá volver a entrar. Si solo quieres pausar su acceso, usa «Bloquear».`)) return;
      r = await api().admin_delete(u.usuario);
      if (r && r.ok && A.editing === u.usuario) closeForm();
    }
    if (r && !r.ok) alert(r.mensaje || "No se pudo completar.");
    await load();
  });

  search.addEventListener("input", draw);
  btn.addEventListener("click", () => { ov.classList.remove("hidden"); search.value = ""; closeForm(); load(); });
  $("admNew").addEventListener("click", () => openForm(null));
  $("admClose").addEventListener("click", () => ov.classList.add("hidden"));
  ov.addEventListener("click", (ev) => { if (ev.target === ov) ov.classList.add("hidden"); });
  document.addEventListener("keydown", (ev) => { if (ev.key === "Escape" && !ov.classList.contains("hidden")) ov.classList.add("hidden"); });
})();


// ============================================================
// v6.5 — Alertas de acceso para el administrador
// ============================================================
(function adminAlerts() {
  const $ = (id) => document.getElementById(id);
  const ov = $("admOverlay"), btn = $("btnAdmin");
  if (!ov || !btn || !$("admAlerts")) return;
  const api = () => window.pywebview && window.pywebview.api;
  const esc = (x) => String(x == null ? "" : x).replace(/[&<>"]/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[ch]));
  const TYPES = {
    copia_app:           { t: "Copia de la app en otra PC", lvl: "alta" },
    bloqueo_intentos:    { t: "Cuenta en espera por contraseñas incorrectas", lvl: "alta" },
    usuario_inexistente: { t: "Intento con un usuario que no existe", lvl: "media" },
    clave_incorrecta:    { t: "Contraseña incorrecta desde otra PC", lvl: "media" },
    acceso_bloqueado:    { t: "Intento con cuenta bloqueada", lvl: "media" },
    acceso_vencido:      { t: "Intento con acceso vencido", lvl: "media" },
    cambio_pc:           { t: "Entró desde otra PC", lvl: "info" },
    clave_cambiada:      { t: "Cambió su contraseña", lvl: "info" },
  };
  const S = { tab: "users", data: null, timer: null, isAdmin: false };

  function ago(iso) {
    const s = Math.max(0, (Date.now() - new Date(iso).getTime()) / 1000);
    if (s < 120) return "hace un momento";
    if (s < 3600) return `hace ${Math.round(s / 60)} min`;
    if (s < 86400) return `hace ${Math.round(s / 3600)} h`;
    const d = Math.round(s / 86400);
    return d === 1 ? "ayer" : d < 30 ? `hace ${d} días` : new Date(iso).toLocaleDateString("es");
  }

  function badge(n) {
    [$("admBtnBadge"), $("admTabBadge")].forEach(b => {
      if (!b) return;
      b.innerText = n > 99 ? "99+" : String(n);
      b.classList.toggle("hidden", !(n > 0));
    });
    btn.title = n > 0 ? `Administrar usuarios · ${n} alerta${n === 1 ? "" : "s"} nueva${n === 1 ? "" : "s"}` : "Administrar usuarios";
  }

  async function fetchAlerts(mark) {
    let r = null;
    try { r = await api().admin_alerts(!!mark); } catch (e) { r = null; }
    if (!r || !r.ok) return r;
    S.data = r;
    badge(mark ? 0 : (r.nuevas || 0));
    return r;
  }

  function draw() {
    const r = S.data;
    const box = $("admAlertsList");
    if (!r) { box.innerHTML = '<div class="adm-empty">Cargando alertas…</div>'; return; }
    if (!r.ok) { box.innerHTML = `<div class="adm-empty">⚠ ${esc(r.mensaje || "No se pudieron cargar las alertas.")}</div>`; return; }
    const ev = r.eventos || [];
    const nuevas = ev.filter(e => !e.visto && e.tipo !== "clave_cambiada").length;
    $("admAlertsSum").innerText = ev.length
      ? `${ev.length} registro${ev.length === 1 ? "" : "s"} de los últimos 90 días · ${nuevas} sin ver`
      : "Sin alertas. Aquí verás intentos de entrada sospechosos y copias de la app.";
    $("admAlertsSeen").disabled = !nuevas;
    const sh = r.compartidas || [];
    const shBox = $("admShare");
    shBox.classList.toggle("hidden", !sh.length);
    shBox.innerHTML = sh.length ? "⚠ Posible cuenta compartida: " + sh.map(x => `<b>${esc(x.usuario)}</b> (${x.cambios} cambios de PC en 7 días)`).join(", ")
      + ". Puedes cambiarle la contraseña o bloquearla en la pestaña Usuarios." : "";
    if (!ev.length) { box.innerHTML = ""; return; }
    box.innerHTML = ev.map(e => {
      const t = TYPES[e.tipo] || { t: e.tipo, lvl: "info" };
      return `<div class="alr ${t.lvl}${e.visto ? "" : " nueva"}">
        <span class="alr-dot"></span>
        <div class="alr-main"><div class="alr-t">${esc(t.t)}${e.usuario ? ` · <b>${esc(e.usuario)}</b>` : ""}</div>
          <div class="alr-d">${esc(e.detalle || "")}</div></div>
        <div class="alr-side"><div>${esc(ago(e.cuando))}</div><div>${esc(e.equipo_nombre || "")}${e.version ? " · v" + esc(e.version) : ""}</div></div>
      </div>`;
    }).join("");
  }

  function showTab(tab) {
    S.tab = tab;
    ov.querySelectorAll(".adm-tab").forEach(b => b.classList.toggle("active", b.dataset.tab === tab));
    ov.querySelector(".adm-body").classList.toggle("hidden", tab !== "users");
    $("admAlerts").classList.toggle("hidden", tab !== "alerts");
    $("admNew").classList.toggle("hidden", tab !== "users");
    const srch = ov.querySelector(".lib-search"); if (srch) srch.classList.toggle("hidden", tab !== "users");
    if (tab === "alerts") { S.data = null; draw(); fetchAlerts(false).then(r => { if (!r || !r.ok) S.data = r || { ok: false }; draw(); }); }
  }
  ov.querySelectorAll(".adm-tab").forEach(b => b.addEventListener("click", () => showTab(b.dataset.tab)));
  btn.addEventListener("click", () => showTab("users"));
  $("admAlertsSeen").addEventListener("click", async () => { await fetchAlerts(true); S.data && S.data.eventos && S.data.eventos.forEach(e => { e.visto = true; }); draw(); });

  // Revisa alertas al entrar como administrador y cada 5 minutos
  const prev = window.vnSetAdmin;
  window.vnSetAdmin = function (flag, usuario) {
    if (prev) prev(flag, usuario);
    S.isAdmin = !!flag;
    clearInterval(S.timer);
    if (flag) {
      setTimeout(() => fetchAlerts(false), 1500);
      S.timer = setInterval(() => { if (S.isAdmin) fetchAlerts(false); }, 5 * 60 * 1000);
    } else {
      badge(0);
    }
  };
})();


// ============================================================
// v6.7 — Vista previa dentro de la app (reproductor + línea de tiempo)
// Solo MIRA: no cambia nada del video exportado.
// ============================================================
(function previewPlayer() {
  const $ = (id) => document.getElementById(id);
  const wrap = $("pvWrap");
  if (!wrap) return;
  const ui = {
    body: $("pvBody"), show: $("pvShow"), stage: $("pvStage"), vA: $("pvVidA"), vB: $("pvVidB"), img: $("pvImg"),
    empty: $("pvEmpty"), sub: $("pvSub"), loading: $("pvLoading"), bar: $("pvBar"), fill: $("pvBarFill"), knob: $("pvBarKnob"),
    play: $("pvPlay"), playIco: $("pvPlayIco"), prev: $("pvPrev"), next: $("pvNext"), time: $("pvTime"), loop: $("pvLoop"),
    cc: $("pvCC"), mute: $("pvMute"), k: $("pvSceneK"), text: $("pvSceneText"), chips: $("pvSceneChips"),
    tlInfo: $("pvTlInfo"), scroll: $("pvScroll"), ruler: $("pvRuler"), track: $("pvTrack"), head: $("pvHead"),
    audio: $("pvAudio"), music: $("pvMusic"), total: $("pvTotal"), canvas: $("pvCanvas"), full: $("pvFull"),
    atrack: $("pvATrack"), ttrack: $("pvTTrack"), zr: $("pvZoomRange"), textHead: $("pvTextHead")
  };
  const P = { scenes: [], total: 0, T: 0, playing: false, cur: -1, active: ui.vA, spare: ui.vB, sig: "", raf: 0, last: 0,
              loop: false, cc: true, muted: false, pps: 0, fit: true, vdur: {}, musicUrl: "", musicGain: 0.2, sel: -1,
              peaks: {}, peakRate: 20, peakAsked: {} };
  // v8.9: la marca de agua (marca.js) sigue al reproductor
  window.vnPreview = { time: () => P.T, total: () => P.total, pps: () => P.pps, playing: () => P.playing, stage: ui.stage, scroll: ui.scroll,
    // v9.2: la revisión de escenas (revision.js) salta a una escena y la reproduce
    scenes: () => P.scenes, seek: (t) => seek(t, true), toScene: (i) => toScene(i), play: () => play(), pause: () => pause() };
  const tc = (t) => { t = Math.max(0, t || 0); const m = Math.floor(t / 60), s = Math.floor(t % 60), f = Math.floor((t % 1) * 30);
    return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}:${String(f).padStart(2, "0")}`; };
  const esc = (x) => String(x == null ? "" : x).replace(/[&<>"]/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[ch]));
  const fmt = (t) => { t = Math.max(0, t || 0); const m = Math.floor(t / 60), s = Math.floor(t % 60); return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`; };
  const val = (id, d) => { const el = $(id); return el ? el.value : d; };
  const on = (id) => { const el = $(id); return !!(el && el.checked); };
  const ls = { get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }, set(k, v) { try { localStorage.setItem(k, v); } catch (e) {} } };

  // ── Mostrar / ocultar (se recuerda; ocultarlo NO cambia ninguna edición) ──
  ui.show.checked = ls.get("vnPreviewShow") !== "0";
  function applyShow() {
    ui.body.classList.toggle("hidden", !ui.show.checked);
    wrap.classList.toggle("collapsed", !ui.show.checked);
    if (!ui.show.checked) pause();
    else layoutTimeline();
  }
  ui.show.addEventListener("change", () => { ls.set("vnPreviewShow", ui.show.checked ? "1" : "0"); applyShow(); });

  // ── Datos de la historia ──
  function rebuild() {
    const clips = state.clipsData || [];
    let t = 0;
    P.scenes = clips.map((c, i) => {
      const pv = c.preview || {};
      const dur = Math.max(0.2, Number(pv.dur || c.duration || 0));
      const sc = { i, id: c.clip_id, text: String(c.text || ""), thumb: c.thumbnail || "", dur, start: t,
                   media: pv.media || null, vsegs: pv.vsegs || null, audio: pv.audio || { mode: "none" },
                   kind: c.kind || "", speaker: c.speaker || "", audioName: c.audio_name || "",
                   key: c.key || String(c.clip_id), part: c.part || 0, parts: c.parts || 1, edited: !!c.edited,
                   edit: c.edit || {}, auto: pv.auto || null };
      t += dur;
      return sc;
    });
    P.total = t;
    wrap.classList.toggle("hidden", !P.scenes.length);
    if (!P.scenes.length) { pause(); return; }
    if (P.T > P.total) P.T = 0;
    P.cur = -1;
    if (P.keepKey) {
      const k = P.scenes.find(x => x.key === P.keepKey) || P.scenes.find(x => String(x.id) === String(P.keepKey).split(".")[0]);
      if (k && (P.T < k.start || P.T >= k.start + k.dur)) P.T = k.start + 0.001;
      P.keepKey = null;
    }
    layoutTimeline();
    seek(P.T, true);
    loadMusic();
  }

  async function loadMusic() {
    const opts = window.vnMusic ? window.vnMusic.options() : null;
    if (!opts || !opts.music_enabled || !opts.music_path) { P.musicUrl = ""; ui.music.pause(); ui.music.removeAttribute("src"); return; }
    try {
      const r = await window.pywebview.api.preview_music(opts.music_path);
      if (r && r.url) {
        const gain = (r.gain || {})[opts.music_volume] || 0.2;
        P.musicGain = gain; P.musicStart = opts.music_start || 0; P.musicDuck = opts.music_duck || "normal";
        if (P.musicUrl !== r.url) { P.musicUrl = r.url; ui.music.src = r.url; }
      }
    } catch (e) {}
  }

  // tramos conservados: tiempo de la escena → segundo del archivo
  function mapSegs(segs, t) {
    let acc = 0;
    for (let k = 0; k < segs.length; k++) {
      const len = segs[k][1] - segs[k][0];
      if (t < acc + len || k === segs.length - 1) return { src: segs[k][0] + Math.min(t - acc, len), k, a: segs[k][0], b: segs[k][1] };
      acc += len;
    }
    return { src: 0, k: 0, a: 0, b: 0 };
  }
  const sceneAt = (T) => { for (let i = P.scenes.length - 1; i >= 0; i--) if (T >= P.scenes[i].start - 1e-6) return i; return 0; };

  // ── Escena actual: video A/B (la siguiente se precarga en el otro) ──
  function prepare(v, sc) {
    if (!sc || !sc.media || sc.media.type !== "video") return;
    if (v.dataset.url !== sc.media.url) {
      v.dataset.url = sc.media.url; v.src = sc.media.url; v.load();
    }
    const first = sc.vsegs ? sc.vsegs[0][0] : 0;
    try { if (v.readyState >= 1 && Math.abs(v.currentTime - first) > 0.1) v.currentTime = first; } catch (e) {}
    v.addEventListener("loadedmetadata", () => {
      P.vdur[sc.media.url] = v.duration;
      if (v !== P.active) { try { v.currentTime = first; } catch (e) {} }
      else sync(true);
      if (P.sel === sc.i) paintScene(sc.i);
    }, { once: true });
  }

  function enterScene(i) {
    const sc = P.scenes[i];
    P.cur = i;
    const isVid = !!(sc.media && sc.media.type === "video");
    if (isVid) {
      if (P.spare.dataset.url === sc.media.url && P.active.dataset.url !== sc.media.url) { const t = P.active; P.active = P.spare; P.spare = t; }
      prepare(P.active, sc);
    }
    [ui.vA, ui.vB].forEach(v => { v.classList.toggle("on", isVid && v === P.active); if (v !== P.active || !isVid) { v.pause(); v.muted = true; } });
    ui.img.classList.toggle("on", !!(sc.media && sc.media.type === "image"));
    if (sc.media && sc.media.type === "image" && ui.img.dataset.url !== sc.media.url) { ui.img.dataset.url = sc.media.url; ui.img.src = sc.media.url; }
    ui.empty.classList.toggle("hidden", !!sc.media);
    // audio aparte (narrador / Fish / tramo del audio único)
    if (sc.audio && sc.audio.url) { if (ui.audio.dataset.url !== sc.audio.url) { ui.audio.dataset.url = sc.audio.url; ui.audio.src = sc.audio.url; } }
    else { ui.audio.pause(); }
    prepare(P.spare, P.scenes[i + 1]);
    P.sel = i; paintScene(i); markBlock(i);
  }

  // ── Reloj: cada cuadro coloca video/audio en el segundo correcto ──
  function sync(force) {
    if (!P.scenes.length) return;
    const i = sceneAt(P.T);
    if (i !== P.cur) enterScene(i);
    const sc = P.scenes[i], t = P.T - sc.start;
    // video
    if (sc.media && sc.media.type === "video") {
      const v = P.active;
      const vd = P.vdur[sc.media.url] || v.duration || 0;
      let want, lo = -1, hi = 1e9;
      const keptLen = sc.vsegs ? sc.vsegs.reduce((n, g) => n + g[1] - g[0], 0) : 0;
      if (sc.vsegs) { const m = mapSegs(sc.vsegs, Math.min(t, keptLen)); want = m.src; lo = m.a - 0.06; hi = m.b + 0.06; }
      else {
        const mode = val("selectVideoExtend", "freeze");
        if (vd && t >= vd - 0.04) want = mode === "loop" ? t % vd : (mode === "slow" ? t * (vd / sc.dur) : vd - 0.04);
        else want = mode === "slow" && vd && vd < sc.dur ? t * (vd / sc.dur) : t;
      }
      const frozen = (sc.vsegs && t >= keptLen - 0.03) || (!sc.vsegs && vd && t >= vd - 0.05 && val("selectVideoExtend", "freeze") === "freeze");
      v.style.objectFit = val("selectVideoFit", "contain") === "cover" ? "cover" : "contain";
      const off = Math.abs((v.currentTime || 0) - want);
      if (v.readyState >= 1 && (force || off > 0.3 || v.currentTime < lo || v.currentTime > hi)) { try { v.currentTime = want; } catch (e) {} }
      const voiceHere = sc.audio && sc.audio.mode === "video";
      v.muted = P.muted || !voiceHere;
      if (P.playing && !frozen) { if (v.paused) v.play().catch(() => {}); } else if (!v.paused) v.pause();
      if (!sc.vsegs && val("selectVideoExtend", "freeze") === "slow" && vd && vd < sc.dur) v.playbackRate = Math.max(0.25, vd / sc.dur); else v.playbackRate = 1;
    } else if (sc.media && sc.media.type === "image") {
      const kb = on("toggleCameraMotion");
      ui.img.style.objectFit = val("selectVideoFit", "contain") === "cover" ? "cover" : "contain";
      ui.img.style.transform = kb ? `scale(${1 + 0.1 * Math.min(1, t / sc.dur)})` : "none";
    }
    // audio aparte
    const A = sc.audio || {};
    if (A.url) {
      const want = A.segs ? mapSegs(A.segs, t).src : (A.start || 0) + t;
      const ad = ui.audio.duration || 1e9;
      const end = A.segs ? A.segs[A.segs.length - 1][1] : ad;
      const off = Math.abs((ui.audio.currentTime || 0) - want);
      if (ui.audio.readyState >= 1 && (force || off > 0.3)) { try { ui.audio.currentTime = Math.min(want, ad); } catch (e) {} }
      ui.audio.muted = P.muted;
      if (P.playing && want < end - 0.02) { if (ui.audio.paused) ui.audio.play().catch(() => {}); } else if (!ui.audio.paused) ui.audio.pause();
    }
    // música (aproximada: baja cuando hay voz)
    if (P.musicUrl) {
      const hasVoice = A.mode && A.mode !== "none";
      const duck = { poco: 0.55, normal: 0.33, mucho: 0.16 }[P.musicDuck] || 0.33;
      ui.music.volume = Math.min(1, P.musicGain * 1.6 * (hasVoice ? duck : 1));
      ui.music.muted = P.muted;
      const md = ui.music.duration;
      if (force && md && ui.music.readyState >= 1) { try { ui.music.currentTime = ((P.musicStart || 0) + P.T) % md; } catch (e) {} }
      if (P.playing) { if (ui.music.paused) ui.music.play().catch(() => {}); } else if (!ui.music.paused) ui.music.pause();
    }
    // subtítulos (aproximados: la frase en trozos cortos)
    paintSub(sc, t);
    // barra, tiempo y cabezal
    const pct = P.total ? (P.T / P.total) * 100 : 0;
    ui.fill.style.width = pct + "%"; ui.knob.style.left = pct + "%";
    ui.time.innerText = tc(P.T); ui.total.innerText = tc(P.total);
    ui.head.style.left = (P.T * P.pps) + "px";
    if (P.playing) {
      const x = P.T * P.pps, sl = ui.scroll.scrollLeft, w = ui.scroll.clientWidth;
      if (x < sl + 30 || x > sl + w - 60) ui.scroll.scrollLeft = Math.max(0, x - w * 0.3);
    }
  }

  // Subtítulos de la vista previa con la MISMA plantilla elegida (frases y palabras repartidas por tiempo)
  const SUBT = {
    karaoke:   { font: '"VN Poppins"', w: 700, size: 96, upper: true, maxW: 3, maxC: 20, pos: "bottom", mode: "karaoke" },
    palabra:   { font: '"VN Shoulders"', w: 700, size: 150, upper: true, maxW: 1, maxC: 30, pos: "center", mode: "palabra" },
    destacado: { font: '"VN Poppins"', w: 700, size: 100, upper: true, maxW: 4, maxC: 22, pos: "center", mode: "destacado" },
    caja:      { font: '"VN Poppins"', w: 500, size: 62, upper: false, maxW: 7, maxC: 34, pos: "bottom", mode: "caja" },
    elegante:  { font: '"VN Lora Text"', w: 400, size: 86, upper: false, maxW: 7, maxC: 34, pos: "bottom", mode: "elegante" },
    pop:       { font: '"VN Poppins"', w: 700, size: 104, upper: true, maxW: 2, maxC: 16, pos: "center", mode: "pop" },
    cajapal:   { font: '"VN Poppins"', w: 700, size: 90, upper: true, maxW: 3, maxC: 20, pos: "bottom", mode: "cajapal" },
    neon:      { font: '"VN Poppins"', w: 700, size: 94, upper: true, maxW: 3, maxC: 20, pos: "bottom", mode: "neon" },
    maquina:   { font: '"VN Mono"', w: 400, size: 58, upper: false, maxW: 6, maxC: 28, pos: "bottom", mode: "maquina" },
    impacto:   { font: '"VN Shoulders"', w: 700, size: 170, upper: true, maxW: 5, maxC: 30, pos: "center", mode: "impacto" },
    contorno:  { font: '"VN Poppins"', w: 700, size: 98, upper: true, maxW: 3, maxC: 20, pos: "bottom", mode: "contorno" },
    sombra3d:  { font: '"VN Shoulders"', w: 700, size: 140, upper: true, maxW: 2, maxC: 16, pos: "center", mode: "sombra3d" },
    documental:{ font: '"VN Inter"', w: 400, size: 50, upper: false, maxW: 12, maxC: 44, pos: "bottom", mode: "documental" }
  };
  const SIZEF = { small: 0.82, medium: 1, large: 1.2 };
  const subCache = { key: "", chunks: [] };
  function subChunks(sc, tpl) {
    const key = sc.key + "|" + sc.dur + "|" + tpl.mode + "|" + sc.text;
    if (subCache.key === key) return subCache.chunks;
    const words = sc.text.replace(/[—–]/g, " ").split(/\s+/).filter(Boolean);
    const chars = words.reduce((n, w) => n + w.length + 1, 0) || 1;
    let acc = 0;
    const W = words.map(w => { const s = acc / chars * sc.dur; acc += w.length + 1; return { t: w, s, e: acc / chars * sc.dur }; });
    const chunks = []; let cur = [];
    W.forEach(w => {
      if (cur.length) {
        const prev = cur[cur.length - 1];
        const len = cur.reduce((n, x) => n + x.t.length + 1, 0) + w.t.length;
        if (cur.length >= tpl.maxW || len > tpl.maxC || /[.!?…]["»”]?$/.test(prev.t) || (/[,;:]$/.test(prev.t) && cur.length >= 2)) { chunks.push(cur); cur = []; }
      }
      cur.push(w);
    });
    if (cur.length) chunks.push(cur);
    subCache.key = key; subCache.chunks = chunks;
    return chunks;
  }
  function paintSub(sc, t) {
    const show = P.cc && typeof subState !== "undefined" && subState.enabled && sc.text.trim();
    ui.sub.classList.toggle("hidden", !show);
    if (!show) return;
    const tpl = SUBT[subState.template] || SUBT.karaoke;
    const chunks = subChunks(sc, tpl);
    let ch = chunks.find(c => t < c[c.length - 1].e) || chunks[chunks.length - 1];
    if (!ch) { ui.sub.innerHTML = ""; return; }
    const acc = subState.color || "#FFC845";
    const disp = (w) => esc(tpl.upper ? w.toUpperCase() : w);
    let html;
    if (tpl.mode === "palabra") {
      const w = ch.find(x => t < x.e) || ch[ch.length - 1];
      html = `<span style="color:${acc}">${disp(w.t)}</span>`;
    } else if (tpl.mode === "destacado") {
      let key = 0; ch.forEach((w, k) => { if (w.t.replace(/[^\p{L}\p{N}]/gu, "").length > ch[key].t.replace(/[^\p{L}\p{N}]/gu, "").length) key = k; });
      if (ch[key].t.replace(/[^\p{L}\p{N}]/gu, "").length < 4 && ch.length > 1) key = -1;
      html = ch.map((w, k) => k === key ? `<span class="hl" style="color:${acc}">${disp(w.t)}</span>` : disp(w.t)).join(" ");
    } else if (tpl.mode === "karaoke" || tpl.mode === "caja") {
      const now = ch.findIndex(x => t < x.e);
      html = ch.map((w, k) => k === (now < 0 ? ch.length - 1 : now) ? `<span class="${tpl.mode === "karaoke" ? "pop" : ""}" style="color:${acc}">${disp(w.t)}</span>` : disp(w.t)).join(" ");
    } else if (["pop", "cajapal", "neon", "contorno"].includes(tpl.mode)) {
      let now = ch.findIndex(x => t < x.e); if (now < 0) now = ch.length - 1;
      const on = { pop: `class="popw" style="color:${acc}"`, cajapal: `class="wbox" style="background:${acc}"`,
                   neon: `class="glow" style="--acc:${acc}"`, contorno: `class="pop"` }[tpl.mode];
      html = ch.map((w, k) => k === now ? `<span ${on}>${disp(w.t)}</span>` : disp(w.t)).join(" ");
    } else if (tpl.mode === "maquina") {
      const tx = ch.map(w => disp(w.t)).join(" ");
      let n = 0;
      ch.forEach((w, k) => { const d = disp(w.t); const f = Math.max(0, Math.min(1, (t - w.s) / Math.max(0.05, w.e - w.s)));
        if (t >= w.s) n = ch.slice(0, k).reduce((a, x) => a + disp(x.t).length + 1, 0) + Math.ceil(d.length * f); });
      html = `<span class="box">${tx.slice(0, n)}<span class="ghost">${tx.slice(n)}</span></span>`;
    } else if (tpl.mode === "impacto") {
      let key = 0; ch.forEach((w, k) => { if (w.t.replace(/[^\p{L}\p{N}]/gu, "").length > ch[key].t.replace(/[^\p{L}\p{N}]/gu, "").length) key = k; });
      const small = ch.filter((w, k) => k !== key).map(w => disp(w.t)).join(" ");
      html = (small ? `<small>${small}</small>` : "") + `<b style="color:${acc}">${disp(ch[key].t)}</b>`;
    } else if (tpl.mode === "sombra3d") {
      html = `<span style="--acc:${acc}">${ch.map(w => disp(w.t)).join(" ")}</span>`;
    } else if (tpl.mode === "documental") {
      html = ch.map(w => disp(w.t)).join(" ");
    } else {
      html = `<span style="color:${acc}">${ch.map(w => disp(w.t)).join(" ")}</span>`;
    }
    const stageW = ui.stage.clientWidth || 270;
    const fs = tpl.size * (stageW / 1080) * (SIZEF[subState.size] || 1);
    const pos = (!subState.position || subState.position === "auto") ? tpl.pos : subState.position;
    ui.sub.dataset.mode = tpl.mode; ui.sub.dataset.pos = pos;
    ui.sub.style.fontFamily = tpl.font + ", sans-serif"; ui.sub.style.fontWeight = tpl.w;
    ui.sub.style.fontStyle = tpl.italic ? "italic" : "normal";
    ui.sub.style.fontSize = fs.toFixed(1) + "px";
    ui.sub.style.setProperty("--ol", Math.max(1, fs * 0.07).toFixed(1) + "px");
    const idKey = sc.key + "|" + chunks.indexOf(ch) + "|" + html;
    ui.sub.style.setProperty("--acc", acc);
    if (ui.sub.dataset.k !== idKey) { ui.sub.dataset.k = idKey; ui.sub.innerHTML = tpl.mode === "caja" ? `<span class="box">${html}</span>` : html; }
  }

  function frame(ts) {
    if (!P.playing) return;
    const dt = Math.min(0.1, (ts - (P.last || ts)) / 1000);
    P.last = ts;
    const i = sceneAt(P.T);
    P.T += dt;
    if (P.loop) { const sc = P.scenes[i]; if (P.T >= sc.start + sc.dur) { P.T = sc.start; sync(true); } }
    if (P.T >= P.total) { P.T = P.total; pause(); sync(true); return; }
    sync(false);
    P.raf = requestAnimationFrame(frame);
  }
  function play() {
    if (!P.scenes.length) return;
    if (P.T >= P.total - 0.05) P.T = 0;
    P.playing = true; P.last = 0;
    ui.playIco.innerHTML = '<path d="M6 4h4v16H6zM14 4h4v16h-4z"/>';
    sync(true);
    P.raf = requestAnimationFrame(frame);
  }
  function pause() {
    P.playing = false;
    cancelAnimationFrame(P.raf);
    ui.playIco.innerHTML = '<path d="M7 4l14 8-14 8z"/>';
    [ui.vA, ui.vB, ui.audio, ui.music].forEach(m => { try { m.pause(); } catch (e) {} });
  }
  function seek(T, force) {
    P.T = Math.max(0, Math.min(P.total, T));
    if (P.cur >= 0 && sceneAt(P.T) !== P.cur) P.cur = -1;
    sync(true);
  }
  const toScene = (i) => { i = Math.max(0, Math.min(P.scenes.length - 1, i)); seek(P.scenes[i].start + 0.001, true); };

  // ── Panel de la escena ──
  function audioLabel(sc) {
    const m = (sc.audio || {}).mode;
    if (m === "video") return "Audio del propio video";
    if (m === "file") return sc.audioName ? `Voz: ${sc.audioName}` : "Voz del narrador";
    if (m === "slice") return "Tramo de la pista del narrador";
    return "Sin audio";
  }
  function paintScene(i) {
    const sc = P.scenes[i]; if (!sc) return;
    ui.k.innerText = `${sc.id}${sc.parts > 1 ? ` · parte ${sc.part}/${sc.parts}` : ""} · ${i + 1} de ${P.scenes.length}${sc.speaker && !/^narrad/i.test(sc.speaker) ? " · " + sc.speaker : ""}`;
    ui.text.innerText = sc.text || "(sin texto)";
    const chips = [`Dura ${sc.dur.toFixed(1).replace(".", ",")} s`, audioLabel(sc)];
    if (sc.vsegs && sc.media) {
      const vd = P.vdur[sc.media.url];
      const head = sc.vsegs[0][0], tail = vd ? Math.max(0, vd - sc.vsegs[sc.vsegs.length - 1][1]) : null;
      let t = `Recorte automático: −${head.toFixed(1).replace(".", ",")} s al inicio`;
      if (tail != null) t += ` · −${tail.toFixed(1).replace(".", ",")} s al final`;
      if (sc.vsegs.length > 1) t += ` · ${sc.vsegs.length - 1} pausa${sc.vsegs.length > 2 ? "s" : ""} acortada${sc.vsegs.length > 2 ? "s" : ""}`;
      chips.unshift(t);
    }
    if (sc.edited) chips.push("✎ Editada a mano");
    ui.chips.innerHTML = chips.map((c, k) => `<span class="pv-chip${k === 0 && sc.vsegs ? " auto" : ""}${c.startsWith("✎") ? " man" : ""}">${esc(c)}</span>`).join("");
    paintFile(sc);
    paintEdit(sc);
  }

  // ── Línea de tiempo ──
  function layoutTimeline() {
    if (!P.scenes.length || !ui.show.checked) return;
    const w = Math.max(300, ui.scroll.clientWidth - 4);
    const fitPps = w / Math.max(1, P.total);
    if (P.fit || !P.pps) P.pps = fitPps;
    P.pps = Math.max(fitPps * 0.999, Math.min(80, P.pps));
    const W = P.total * P.pps;
    [ui.track, ui.ruler, ui.atrack, ui.ttrack].forEach(el => { el.style.width = W + "px"; });
    ui.track.innerHTML = P.scenes.map(sc => {
      const bw = Math.max(2, sc.dur * P.pps - 2);
      const lbl = sc.parts > 1 ? `${sc.id}·${sc.part}` : String(sc.id);
      return `<div class="pv-blk${sc.media ? "" : " nomedia"}${sc.edited ? " man" : ""}" data-i="${sc.i}" style="left:${sc.start * P.pps}px;width:${bw}px;${sc.thumb ? `background-image:url('${sc.thumb}')` : ""}" title="Escena ${lbl} · ${sc.dur.toFixed(1)} s${sc.edited ? " · editada a mano" : ""}">
        ${bw > 22 ? `<span class="pv-n">${lbl}</span>` : ""}${(sc.audio || {}).mode === "file" ? '<span class="pv-fish"></span>' : ""}${bw > 58 && (state.replacedScenes || []).includes(String(sc.id)) ? '<span class="pv-new">↻ NUEVO</span>' : ""}
        <span class="pv-hd l" data-h="l"></span><span class="pv-hd r" data-h="r"></span></div>`;
    }).join("");
    const step = [1, 2, 5, 10, 15, 30, 60, 120].find(s => s * P.pps >= 70) || 300;
    const minor = step / 5;
    let r = "";
    for (let k = 0; k * minor <= P.total + 0.01; k++) {
      const x = k * minor, major = k % 5 === 0;
      r += `<i class="${major ? "mj" : ""}" style="left:${x * P.pps}px"></i>` + (major ? `<span style="left:${x * P.pps}px">${fmt(Math.round(x))}</span>` : "");
    }
    ui.ruler.innerHTML = r;
    paintAudioTrack(); paintTextTrack(); askPeaks();
    const nEd = Object.keys(state.sceneEdits || {}).length;
    ui.tlInfo.innerText = `${P.scenes.length} escena${P.scenes.length === 1 ? "" : "s"} · ${fmt(P.total)}`
      + (nEd ? ` · ${nEd} editada${nEd === 1 ? "" : "s"} a mano` : "") + ((state.sceneOrder || []).length ? " · orden cambiado" : "");
    markBlock(P.sel);
    paintRemoved();
    ui.head.style.left = (P.T * P.pps) + "px";
  }
  // Pista de audio: forma de onda de lo que suena en cada escena
  function sceneAudioSrc(sc) {
    const A = sc.audio || {};
    if (A.mode === "video" && sc.media) return { url: sc.media.url, segs: sc.vsegs || [[0, sc.dur]], cls: "vid" };
    if (A.url) return { url: A.url, segs: A.segs || [[A.start || 0, (A.start || 0) + sc.dur]], cls: "nar" };
    return null;
  }
  function wavePath(sc, src, bw) {
    const pk = P.peaks[src.url];
    if (!pk || !pk.length) return "";
    const n = Math.max(8, Math.min(600, Math.round(bw / 3)));
    const kept = src.segs.reduce((a, g) => a + g[1] - g[0], 0) || sc.dur;
    let d = "";
    for (let k = 0; k < n; k++) {
      const tt = (k / n) * sc.dur;
      let v = 0;
      if (tt <= kept) { const m = mapSegs(src.segs, tt); v = pk[Math.min(pk.length - 1, Math.floor(m.src * P.peakRate))] || 0; }
      const h = Math.max(1.5, v / 100 * 13);
      d += `M${k * 3 + 1} ${15 - h}V${15 + h}`;
    }
    return `<svg viewBox="0 0 ${n * 3} 30" preserveAspectRatio="none"><path d="${d}"/></svg>`;
  }
  function paintAudioTrack() {
    ui.atrack.innerHTML = P.scenes.map(sc => {
      const src = sceneAudioSrc(sc), bw = Math.max(2, sc.dur * P.pps - 2);
      const lbl = src ? (src.cls === "vid" ? "" : esc(sc.audioName || "Voz")) : "";
      return `<div class="pv-ablk ${src ? src.cls : "none"}" style="left:${sc.start * P.pps}px;width:${bw}px">${src ? wavePath(sc, src, bw) : ""}${lbl && bw > 70 ? `<span>${lbl}</span>` : ""}</div>`;
    }).join("");
  }
  async function askPeaks() {
    const want = [...new Set(P.scenes.map(sc => { const s = sceneAudioSrc(sc); return s && s.url; }).filter(u => u && !P.peakAsked[u]))];
    if (!want.length || !window.pywebview || !window.pywebview.api || !window.pywebview.api.preview_peaks) return;
    want.forEach(u => { P.peakAsked[u] = 1; });
    try {
      const r = await window.pywebview.api.preview_peaks(want);
      if (r && r.peaks) { P.peakRate = r.rate || 20; Object.assign(P.peaks, r.peaks); paintAudioTrack(); }
    } catch (e) {}
  }
  // Pista de texto: lo que dice cada escena (como los subtítulos)
  function paintTextTrack() {
    const on = typeof subState !== "undefined" && subState.enabled;
    ui.ttrack.classList.toggle("off", !on); ui.textHead.classList.toggle("off", !on);
    ui.ttrack.innerHTML = P.scenes.map(sc => {
      const bw = Math.max(2, sc.dur * P.pps - 2);
      return `<div class="pv-tblk" style="left:${sc.start * P.pps}px;width:${bw}px" title="${esc(sc.text)}">${bw > 26 ? esc(sc.text) : ""}</div>`;
    }).join("");
  }

  function markBlock(i) {
    ui.track.querySelectorAll(".pv-blk.sel").forEach(b => b.classList.remove("sel"));
    const b = ui.track.querySelector(`.pv-blk[data-i="${i}"]`);
    if (b) b.classList.add("sel");
  }
  ui.scroll.addEventListener("mousedown", (ev) => {
    if (ev.button !== 0) return;
    const rect = ui.track.getBoundingClientRect();
    const blkEl = ev.target.closest(".pv-blk");
    const hd = ev.target.closest(".pv-hd");
    if (hd && blkEl && blkEl.classList.contains("sel") && editable()) { ev.preventDefault(); dragEdge(ev, +blkEl.dataset.i, hd.dataset.h, blkEl); return; }
    if (blkEl && editable()) { ev.preventDefault(); dragBlock(ev, +blkEl.dataset.i, blkEl, rect); return; }
    const go = (e) => seek((e.clientX - rect.left) / P.pps, true);
    go(ev);
    const mv = (e) => go(e), up = () => { document.removeEventListener("mousemove", mv); document.removeEventListener("mouseup", up); };
    document.addEventListener("mousemove", mv); document.addEventListener("mouseup", up);
  });
  const fitPps = () => Math.max(300, ui.scroll.clientWidth - 4) / Math.max(1, P.total);
  function syncZoom() { const f = fitPps(); ui.zr.value = String(Math.round(Math.log(P.pps / f) / Math.log(80 / f) * 100) || 0); }
  $("pvZoomIn").addEventListener("click", () => { P.fit = false; P.pps *= 1.6; layoutTimeline(); syncZoom(); });
  $("pvZoomOut").addEventListener("click", () => { P.fit = false; P.pps /= 1.6; layoutTimeline(); syncZoom(); });
  $("pvZoomFit").addEventListener("click", () => { P.fit = true; layoutTimeline(); syncZoom(); });
  ui.zr.addEventListener("input", () => {
    const f = fitPps(), v = +ui.zr.value / 100;
    const center = (ui.scroll.scrollLeft + ui.scroll.clientWidth / 2) / P.pps;
    P.fit = v === 0; P.pps = f * Math.pow(80 / f, v); layoutTimeline();
    ui.scroll.scrollLeft = Math.max(0, center * P.pps - ui.scroll.clientWidth / 2);
  });
  ui.full.addEventListener("click", () => {
    try { if (document.fullscreenElement) document.exitFullscreen(); else ui.canvas.requestFullscreen(); } catch (e) {}
  });
  window.addEventListener("resize", () => { if (P.fit) layoutTimeline(); });

  // ══ Edición a mano (v6.8) ══════════════════════════════════════════
  if (!state.sceneEdits) state.sceneEdits = {};
  if (!state.sceneOrder) state.sceneOrder = [];
  const ed = { msg: $("pvEdMsg"), acts: $("pvActs"), undo: $("pvUndo"), removed: $("pvRemoved"), hist: [] };
  const editable = () => !!state.editable && P.scenes.length > 0;
  const n1 = (x) => (Math.round(x * 10) / 10).toFixed(1).replace(".", ",");
  function partSegs(sc) {                       // tramos (segundos del archivo que manda) de esta parte
    if (!sc.auto) return null;
    if (sc.auto.field === "keep") return sc.vsegs || sc.auto.segs;
    const A = sc.audio || {};
    if (A.segs) return A.segs;
    if (A.mode === "file") return sc.auto.segs;
    return [[A.start || 0, (A.start || 0) + sc.dur]];
  }
  function srcAt(sc, t) {
    const segs = partSegs(sc);
    if (!segs) return null;
    const len = segs.reduce((n, s) => n + (s[1] - s[0]), 0);
    return mapSegs(segs, Math.min(Math.max(0, t), len)).src;
  }
  const siblings = (sc) => P.scenes.filter(x => x.id === sc.id).sort((a, b) => (a.part || 0) - (b.part || 0));
  function clipBounds(sc) {                     // inicio y fin de la escena completa (todas sus partes)
    const parts = siblings(sc);
    const first = partSegs(parts[0]), last = partSegs(parts[parts.length - 1]);
    return { lo: first ? first[0][0] : 0, hi: last ? last[last.length - 1][1] : 0, src: sc.auto ? sc.auto.src : null };
  }
  function paintEdit(sc) {
    const can = editable();
    ed.acts.classList.toggle("locked", !can);
    if (!can || !sc) { ed.acts.querySelectorAll("button[data-ed]").forEach(b => { b.disabled = true; }); ed.msg.innerHTML = ""; return; }
    const e = (state.sceneEdits || {})[String(sc.id)] || {};
    const trimmable = !!sc.auto;
    const idx = P.scenes.indexOf(sc);
    const dis = { split: !trimmable, in: !trimmable, out: !trimmable, "ext-": !(e.extend > 0),
                  left: idx <= 0, right: idx >= P.scenes.length - 1, reset: !sc.edited && !e.off, undo: !ed.hist.length };
    ed.acts.querySelectorAll("button[data-ed]").forEach(b => { b.disabled = !!dis[b.dataset.ed]; });
    const bits = [];
    if (e.in != null || e.out != null) bits.push("recorte a mano");
    if ((e.splits || []).length) bits.push(`dividida en ${(e.splits || []).length + 1} partes`);
    if (e.extend) bits.push(`alargada ${n1(e.extend)} s`);
    const info = trimmable ? (bits.length ? "Esta escena: " + bits.join(" · ") + "." : "Sin editar: recorte automático.")
      : "Esta escena no tiene audio que la mida: solo se puede alargar, mover o quitar.";
    ed.msg.innerHTML = (ed.last ? `<div class="pv-last">✓ ${esc(ed.last)}</div>` : "") + `<div class="pv-info">${esc(info)}</div>`;
  }
  function paintRemoved() {
    const list = (state.removedScenes || []);
    ed.removed.classList.toggle("hidden", !list.length || !editable());
    ed.removed.innerHTML = list.length ? `<span class="pv-rm-k">Quitadas del video:</span>` + list.map(r =>
      `<button type="button" class="pv-rm" data-id="${r.clip_id}" title="${esc(r.text)}">${r.thumbnail ? `<img src="${r.thumbnail}" alt="">` : ""}Escena ${r.clip_id} <b>↺ Restaurar</b></button>`).join("") : "";
    ed.undo.disabled = !ed.hist.length;
  }
  ed.removed.addEventListener("click", (ev) => {
    const b = ev.target.closest(".pv-rm"); if (!b) return;
    commit(E => { const e = E[b.dataset.id]; if (e) delete e.off; }, `Escena ${b.dataset.id} restaurada.`);
  });

  function snapshotEdits() { return JSON.stringify({ e: state.sceneEdits || {}, o: state.sceneOrder || [] }); }
  function commit(mutate, message, keepKey) {
    const before = snapshotEdits();
    const E = JSON.parse(JSON.stringify(state.sceneEdits || {}));
    let order = (state.sceneOrder || []).slice();
    const r = mutate(E, order);
    if (Array.isArray(r)) order = r;
    Object.keys(E).forEach(k => {           // limpia ediciones vacías
      const e = E[k];
      if (e.splits && !e.splits.length) delete e.splits;
      if (!e.extend) delete e.extend;
      if (!e.off) delete e.off;
      if (!Object.keys(e).length) delete E[k];
    });
    const after = JSON.stringify({ e: E, o: order });
    if (after === before) return;
    ed.hist.push(before); if (ed.hist.length > 60) ed.hist.shift();
    state.sceneEdits = E; state.sceneOrder = order;
    P.keepKey = keepKey || null;
    ed.last = message || "";
    ed.undo.disabled = false;
    triggerAnalyze();
  }
  function undo() {
    const prev = ed.hist.pop(); if (!prev) return;
    const o = JSON.parse(prev);
    state.sceneEdits = o.e; state.sceneOrder = o.o;
    ed.last = "Se deshizo la última edición.";
    ed.undo.disabled = !ed.hist.length;
    triggerAnalyze();
  }
  const currentKeys = () => P.scenes.map(x => x.key);

  function act(kind) {
    if (kind === "undo") { undo(); return; }
    if (!editable()) return;
    const i = P.sel >= 0 ? P.sel : sceneAt(P.T);
    const sc = P.scenes[i]; if (!sc) return;
    const id = String(sc.id);
    const t = Math.max(0, Math.min(sc.dur, P.T - sc.start));
    const s = srcAt(sc, t);
    const b = clipBounds(sc);
    if ((kind === "split" || kind === "in" || kind === "out") && s == null) return;
    if (kind === "split") {
      const segs = partSegs(sc), a = segs[0][0], z = segs[segs.length - 1][1];
      if (s < a + 0.25 || s > z - 0.25) { ed.last = "Pon el cabezal un poco más adentro de la escena para dividirla."; paintEdit(sc); return; }
      commit(E => { const e = E[id] = E[id] || {}; e.splits = (e.splits || []).concat([Math.round(s * 1000) / 1000]).sort((x, y) => x - y); },
             `Escena ${sc.id} dividida en el segundo ${n1(t)}.`, sc.key);
    } else if (kind === "in") {
      commit(E => {
        const e = E[id] = E[id] || {};
        if (sc.part > 1) { const sp = (e.splits || []).slice(); sp[sc.part - 2] = s; e.splits = sp.sort((x, y) => x - y); }
        else e.in = Math.round(s * 1000) / 1000;
      }, `Escena ${sc.id}: ahora empieza ${n1(t)} s más adelante.`, sc.key);
    } else if (kind === "out") {
      commit(E => {
        const e = E[id] = E[id] || {};
        if (sc.part && sc.part < sc.parts) { const sp = (e.splits || []).slice(); sp[sc.part - 1] = s; e.splits = sp.sort((x, y) => x - y); }
        else e.out = Math.round(s * 1000) / 1000;
      }, `Escena ${sc.id}: ahora termina en el segundo ${n1(t)}.`, sc.key);
    } else if (kind === "ext+" || kind === "ext-") {
      commit(E => { const e = E[id] = E[id] || {}; e.extend = Math.max(0, Math.min(30, (e.extend || 0) + (kind === "ext+" ? 1 : -1))); },
             kind === "ext+" ? `Escena ${sc.id}: la última imagen se queda 1 s más.` : `Escena ${sc.id}: 1 s menos de alargue.`, sc.key);
    } else if (kind === "left" || kind === "right") {
      const keys = currentKeys(), j = kind === "left" ? i - 1 : i + 1;
      if (j < 0 || j >= keys.length) return;
      [keys[i], keys[j]] = [keys[j], keys[i]];
      commit(() => keys, `Escena ${sc.id} movida ${kind === "left" ? "a la izquierda" : "a la derecha"}.`, sc.key);
    } else if (kind === "off") {
      commit(E => { (E[id] = E[id] || {}).off = true; }, `Escena ${sc.id} quitada del video (no se borró nada). Puedes restaurarla abajo.`);
    } else if (kind === "reset") {
      commit((E, order) => {
        delete E[id];
        const out = [];
        order.forEach(k => { const base = String(k).split(".")[0]; if (base === id) { if (!out.includes(id)) out.push(id); } else out.push(k); });
        return out;
      }, `Escena ${sc.id}: volvió al recorte automático.`, id);
    }
  }

  // ════ v8.7: REEMPLAZAR EL VIDEO (O LA IMAGEN) DE UNA ESCENA ════
  const RP = { last: null, toastT: 0 };
  const rpFile = { row: $("pvFileRow"), thumb: $("pvFileThumb"), name: $("pvFileName"), info: $("pvFileInfo"), btn: $("pvFileReplace") };
  const clipOf = (id) => (state.clipsData || []).find(c => String(c.clip_id) === String(id)) || null;
  const n1s = (x) => (Math.round((+x || 0) * 10) / 10).toFixed(1).replace(".", ",");
  function paintFile(sc) {
    if (!rpFile.row) return;
    const c = sc && clipOf(sc.id);
    if (!c || !c.image_path) { rpFile.row.classList.add("hidden"); return; }
    rpFile.row.classList.remove("hidden");
    rpFile.thumb.src = c.thumbnail || "";
    rpFile.thumb.classList.toggle("hidden", !c.thumbnail);
    rpFile.name.innerText = c.image_name || "";
    const isNew = (state.replacedScenes || []).includes(String(c.clip_id));
    rpFile.info.innerText = (c.is_video ? "Video de la escena" : "Imagen de la escena") + (isNew ? " · ↻ reemplazado (el anterior está en “reemplazados”)" : " · carpeta de tu historia");
    rpFile.btn.querySelector("span").innerText = c.is_video ? "Reemplazar video…" : "Reemplazar imagen…";
  }
  function replaceSelected() {
    const i = P.sel >= 0 ? P.sel : sceneAt(P.T);
    const sc = P.scenes[i]; if (sc) replaceScene(sc.id);
  }
  async function replaceScene(id, droppedPath) {
    const api = window.pywebview && window.pywebview.api; if (!api) return;
    const c = clipOf(id);
    if (!c || !c.image_path) { alert(`La escena ${id} no tiene un video o imagen que reemplazar. Agrega a la carpeta un archivo con el número ${id}.`); return; }
    pause();
    let pick;
    try { pick = droppedPath ? await api.scene_media_info(droppedPath) : await api.scene_replace_pick(c.image_path); }
    catch (e) { pick = { error: String(e) }; }
    if (!pick || pick.cancel) return;
    if (pick.error) { alert(pick.error); return; }
    showReplace(c, pick);
  }
  window.vnReplaceScene = replaceScene;

  function showReplace(c, pick) {
    const old = document.getElementById("rpOverlay"); if (old) old.remove();
    const sceneDur = +c.duration || 0;
    const hasEdits = !!(state.sceneEdits || {})[String(c.clip_id)];
    let warn = "";
    if (pick.is_video && pick.duration && sceneDur && pick.duration + 0.05 < sceneDur)
      warn = `El video nuevo dura ${n1s(sceneDur - pick.duration)} s menos que esta escena: se congela su última imagen ese tiempo (como siempre).`;
    else if (!pick.is_video && c.is_video) warn = "Vas a poner una imagen fija en lugar de un video: se verá con movimiento de cámara si lo tienes activado.";
    const side = (lbl, th, name, info, cls) => `<div class="rp-side ${cls}">${th ? `<img src="${th}" alt="">` : '<div class="rp-noimg">🎬</div>'}<div><small>${lbl}</small><b>${esc(name)}</b>${info.map(x => `<span>${esc(x)}</span>`).join("")}</div></div>`;
    const ov = document.createElement("div");
    ov.id = "rpOverlay"; ov.className = "rp-ov";
    ov.innerHTML = `<div class="rp-dlg" role="dialog" aria-label="Reemplazar escena ${c.clip_id}">
      <h3>REEMPLAZAR ESCENA ${esc(c.clip_id)}</h3>
      <div class="rp-sub">“${esc((c.text || "").slice(0, 140))}”</div>
      <div class="rp-cmp">
        ${side("AHORA", c.thumbnail, c.image_name, [c.is_video ? `Escena de ${n1s(sceneDur)} s` : "Imagen", hasEdits ? "Tiene ajustes hechos a mano" : "Sin ajustes a mano"], "")}
        <div class="rp-arrow">➜</div>
        ${side("NUEVO", pick.thumbnail, pick.name, [pick.is_video ? `${n1s(pick.duration)} s` : "Imagen", pick.width ? `${pick.width}×${pick.height}` : "", pick.size_mb > 0 ? `${String(pick.size_mb).replace(".", ",")} MB` : ""].filter(Boolean), "new")}
      </div>
      ${warn ? `<div class="rp-warn">${esc(warn)}</div>` : ""}
      ${hasEdits ? `<label class="rp-opt"><input type="radio" name="rpMode" value="fresh" checked><span><b>Empezar de cero con el video nuevo</b><em>Se quitan los recortes que hiciste a mano en esta escena (recomendado: es otro video).</em></span></label>
      <label class="rp-opt"><input type="radio" name="rpMode" value="keep"><span><b>Mantener mis ajustes de esta escena</b><em>Mismo inicio, final y congelado que tenía el video anterior.</em></span></label>` : ""}
      <div class="rp-safe">✓ No se borra nada: el archivo anterior se guarda en la carpeta <b>“reemplazados”</b>, junto a tu historia.</div>
      <div class="rp-foot"><span class="rp-hint">Tus otras escenas no cambian.</span>
        <div class="rp-bts"><button type="button" class="rp-cancel">Cancelar</button><button type="button" class="rp-go"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 8h12l-3-3M20 16H8l3 3"/></svg> Reemplazar</button></div></div>
    </div>`;
    document.body.appendChild(ov);
    const close = () => ov.remove();
    ov.querySelector(".rp-cancel").addEventListener("click", close);
    ov.addEventListener("mousedown", (e) => { if (e.target === ov) close(); });
    ov.addEventListener("keydown", (e) => { if (e.key === "Escape") close(); });
    const go = ov.querySelector(".rp-go");
    go.focus();
    go.addEventListener("click", async () => {
      const m = ov.querySelector('input[name="rpMode"]:checked');
      const fresh = !m || m.value === "fresh";
      go.disabled = true; go.innerText = "Reemplazando…";
      let res;
      try { res = await window.pywebview.api.scene_replace(c.image_path, pick.path, c.clip_id); } catch (e) { res = { error: String(e) }; }
      if (!res || res.error) { go.disabled = false; go.innerText = "Reemplazar"; alert((res && res.error) || "No se pudo reemplazar."); return; }
      close();
      applyReplace(c, res, fresh);
    });
  }

  function applyReplace(c, res, fresh) {
    const id = String(c.clip_id);
    const before = { edits: JSON.stringify(state.sceneEdits || {}), order: JSON.stringify(state.sceneOrder || []),
                     media: Array.isArray(state.imagesFolder) ? state.imagesFolder.slice() : null,
                     replaced: (state.replacedScenes || []).slice() };
    if (Array.isArray(state.imagesFolder)) {
      const norm = (x) => String(x || "").replace(/\//g, "\\").toLowerCase();
      state.imagesFolder = state.imagesFolder.map(f => norm(f) === norm(res.old_path) ? res.new_path : f);
      if (res.moved_from) state.imagesFolder = state.imagesFolder.filter(f => norm(f) !== norm(res.moved_from) || norm(f) === norm(res.new_path));
    }
    if (fresh && (state.sceneEdits || {})[id]) {
      const E = JSON.parse(JSON.stringify(state.sceneEdits || {})); delete E[id];
      const out = [];
      (state.sceneOrder || []).forEach(k => { const base = String(k).split(".")[0]; if (base === id) { if (!out.includes(id)) out.push(id); } else out.push(k); });
      state.sceneEdits = E; state.sceneOrder = out;
    }
    state.replacedScenes = Array.from(new Set((state.replacedScenes || []).concat([id])));
    RP.last = { res, before, id };
    ed.last = `Escena ${id} reemplazada por ${res.name}.`;
    toast(`✓ Escena ${esc(id)} reemplazada por <b>${esc(res.name)}</b>`);
    triggerAnalyze();
  }

  async function undoReplace() {
    const L = RP.last; if (!L) return;
    RP.last = null;
    let r;
    try { r = await window.pywebview.api.scene_replace_undo(L.res); } catch (e) { r = { error: String(e) }; }
    if (!r || r.error) { alert((r && r.error) || "No se pudo deshacer."); return; }
    state.sceneEdits = JSON.parse(L.before.edits); state.sceneOrder = JSON.parse(L.before.order);
    if (L.before.media) state.imagesFolder = L.before.media;
    state.replacedScenes = L.before.replaced;
    ed.last = `Se deshizo el reemplazo de la escena ${L.id}.`;
    toast(`↺ Escena ${esc(L.id)}: volvió el archivo anterior`, true);
    triggerAnalyze();
  }

  function toast(html, noUndo) {
    let t = document.getElementById("rpToast");
    if (!t) { t = document.createElement("div"); t.id = "rpToast"; t.className = "rp-toast"; document.body.appendChild(t); }
    t.innerHTML = `<span>${html}</span>${noUndo ? "" : '<button type="button" class="rp-undo">Deshacer</button>'}`;
    t.classList.add("on");
    const u = t.querySelector(".rp-undo"); if (u) u.addEventListener("click", () => { t.classList.remove("on"); undoReplace(); });
    clearTimeout(RP.toastT); RP.toastT = setTimeout(() => t.classList.remove("on"), noUndo ? 4000 : 12000);
  }

  // Botones: barra del editor, panel de la escena y tarjetas de la lista
  const rpBtn = $("pvReplace"); if (rpBtn) rpBtn.addEventListener("click", replaceSelected);
  if (rpFile.btn) rpFile.btn.addEventListener("click", replaceSelected);
  document.addEventListener("click", (ev) => {
    const b = ev.target.closest("[data-replace]"); if (!b) return;
    ev.preventDefault(); ev.stopPropagation(); replaceScene(b.dataset.replace);
  }, true);

  // Clic derecho sobre una escena de la línea de tiempo
  function closeMenu() { const m = document.getElementById("rpMenu"); if (m) m.remove(); }
  ui.scroll.addEventListener("contextmenu", (ev) => {
    const blk = ev.target.closest(".pv-blk"); if (!blk) return;
    ev.preventDefault(); closeMenu();
    const i = +blk.dataset.i, sc = P.scenes[i]; if (!sc) return;
    const rect = ui.track.getBoundingClientRect();
    seek((ev.clientX - rect.left) / P.pps, true);
    P.sel = i; paintScene(i); markBlock(i);
    const c = clipOf(sc.id), can = editable();
    const items = [
      c && c.image_path ? ["rep", `${c.is_video ? "Reemplazar video…" : "Reemplazar imagen…"}`, "R"] : null,
      can && sc.auto ? ["split", "Dividir aquí", "S"] : null,
      can && sc.auto ? ["in", "Empieza aquí", "I"] : null,
      can && sc.auto ? ["out", "Termina aquí", "O"] : null,
      can ? ["off", "Quitar del video", "Supr"] : null
    ].filter(Boolean);
    if (!items.length) return;
    const m = document.createElement("div"); m.id = "rpMenu"; m.className = "rp-menu";
    m.innerHTML = items.map(([k, l, key]) => `<button type="button" data-k="${k}"${k === "rep" ? ' class="on"' : ""}>${l}<small>${key}</small></button>`).join("");
    document.body.appendChild(m);
    const mw = m.offsetWidth, mh = m.offsetHeight;
    m.style.left = Math.min(ev.clientX, window.innerWidth - mw - 8) + "px";
    m.style.top = Math.max(8, Math.min(ev.clientY, window.innerHeight - mh - 8)) + "px";
    m.addEventListener("click", (e) => { const b = e.target.closest("button[data-k]"); if (!b) return; closeMenu(); if (b.dataset.k === "rep") replaceScene(sc.id); else act(b.dataset.k); });
  });
  document.addEventListener("mousedown", (e) => { if (!e.target.closest("#rpMenu")) closeMenu(); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeMenu(); });
  ui.scroll.addEventListener("scroll", closeMenu);

  // Arrastrar un video desde una carpeta de Windows y soltarlo sobre una escena
  const isFileDrag = (e) => e.dataTransfer && Array.from(e.dataTransfer.types || []).includes("Files");
  let dropBlk = null;
  ui.scroll.addEventListener("dragover", (e) => {
    if (!isFileDrag(e)) return;
    e.preventDefault(); e.dataTransfer.dropEffect = "copy";
    const blk = e.target.closest(".pv-blk");
    if (blk !== dropBlk) {
      if (dropBlk) { dropBlk.classList.remove("rp-drop"); dropBlk.removeAttribute("data-drop"); }
      dropBlk = blk;
      if (blk) { const sc = P.scenes[+blk.dataset.i]; blk.classList.add("rp-drop"); blk.setAttribute("data-drop", `Suelta para reemplazar la escena ${sc ? sc.id : ""}`); }
    }
  });
  ui.scroll.addEventListener("dragleave", (e) => { if (dropBlk && !ui.scroll.contains(e.relatedTarget)) { dropBlk.classList.remove("rp-drop"); dropBlk = null; } });
  ui.scroll.addEventListener("drop", async (e) => {
    if (!isFileDrag(e)) return;
    e.preventDefault();
    const blk = e.target.closest(".pv-blk");
    if (dropBlk) { dropBlk.classList.remove("rp-drop"); dropBlk = null; }
    if (!blk) return;
    const sc = P.scenes[+blk.dataset.i]; const f = e.dataTransfer.files && e.dataTransfer.files[0];
    if (!sc || !f) return;
    let path = f.pywebviewFullPath || f.path || "";
    if (!path) {
      const hint = typeof state.imagesFolder === "string" ? state.imagesFolder : "";
      try { path = ((await window.pywebview.api.scene_find_file(f.name, f.size, hint)) || {}).path || ""; } catch (err) { path = ""; }
    }
    if (path) replaceScene(sc.id, path);
    else { alert(`No encontré “${f.name}” en Descargas, Escritorio, Videos ni Documentos. Usa el botón Reemplazar para elegirlo.`); replaceScene(sc.id); }
  });
  // Soltar un archivo fuera de una zona preparada no debe abrirlo dentro de la app
  window.addEventListener("dragover", (e) => { if (isFileDrag(e)) e.preventDefault(); });
  window.addEventListener("drop", (e) => { if (isFileDrag(e) && !e.defaultPrevented) e.preventDefault(); });

  ed.acts.addEventListener("click", (ev) => { const b = ev.target.closest("button[data-ed]"); if (b && !b.disabled) act(b.dataset.ed); });

  // Arrastrar un borde de la escena elegida: recorta (o recupera) el inicio / final
  function dragEdge(ev, i, side, el) {
    const sc = P.scenes[i]; const segs = partSegs(sc);
    if (!segs) { ed.last = "Esta escena no tiene audio que la mida: usa Alargar."; paintEdit(sc); return; }
    const id = String(sc.id), x0 = ev.clientX, left0 = parseFloat(el.style.left), w0 = parseFloat(el.style.width);
    const a0 = segs[0][0], z0 = segs[segs.length - 1][1], src = (sc.auto && sc.auto.src) || z0;
    const parts = siblings(sc), k = parts.indexOf(sc);
    const prevEnd = k > 0 ? partSegs(parts[k - 1])[0][0] + 0.25 : 0;
    const nextStart = k < parts.length - 1 ? partSegs(parts[k + 1])[partSegs(parts[k + 1]).length - 1][1] - 0.25 : src;
    let d = 0;
    el.classList.add("dragging");
    const tip = document.createElement("div"); tip.className = "pv-tip"; el.appendChild(tip);
    const mv = (e) => {
      d = (e.clientX - x0) / P.pps;
      if (side === "l") d = Math.max(prevEnd - a0, Math.min(d, (z0 - a0) - 0.25));
      else d = Math.min(nextStart - z0, Math.max(d, -((z0 - a0) - 0.25)));
      if (side === "l") { el.style.left = (left0 + d * P.pps) + "px"; el.style.width = Math.max(4, w0 - d * P.pps) + "px"; }
      else el.style.width = Math.max(4, w0 + d * P.pps) + "px";
      tip.innerText = (side === "l" ? (d >= 0 ? "recorta " : "recupera ") : (d <= 0 ? "recorta " : "recupera ")) + n1(Math.abs(d)) + " s";
    };
    const up = () => {
      document.removeEventListener("mousemove", mv); document.removeEventListener("mouseup", up);
      if (Math.abs(d) < 0.05) { layoutTimeline(); return; }
      if (side === "l") {
        const s = Math.round((a0 + d) * 1000) / 1000;
        commit(E => { const e = E[id] = E[id] || {}; if (sc.part > 1) { const sp = (e.splits || []).slice(); sp[sc.part - 2] = s; e.splits = sp.sort((x, y) => x - y); } else e.in = s; },
               `Escena ${sc.id}: ${d >= 0 ? "recortaste" : "recuperaste"} ${n1(Math.abs(d))} s al inicio.`, sc.key);
      } else {
        const s = Math.round((z0 + d) * 1000) / 1000;
        commit(E => { const e = E[id] = E[id] || {}; if (sc.part && sc.part < sc.parts) { const sp = (e.splits || []).slice(); sp[sc.part - 1] = s; e.splits = sp.sort((x, y) => x - y); } else e.out = s; },
               `Escena ${sc.id}: ${d <= 0 ? "recortaste" : "recuperaste"} ${n1(Math.abs(d))} s al final.`, sc.key);
      }
    };
    document.addEventListener("mousemove", mv); document.addEventListener("mouseup", up);
  }

  // Arrastrar una escena: si casi no se mueve es un clic (ver la escena); si se mueve, cambia de lugar
  function dragBlock(ev, i, el, rect) {
    const x0 = ev.clientX; let moving = false, target = i;
    const marker = document.createElement("div"); marker.className = "pv-drop";
    const mv = (e) => {
      const dx = e.clientX - x0;
      if (!moving && Math.abs(dx) > 6) { moving = true; el.classList.add("moving"); ui.track.appendChild(marker); }
      if (!moving) return;
      el.style.transform = `translateX(${dx}px)`;
      const tx = (e.clientX - rect.left) / P.pps;
      let j = P.scenes.findIndex(s => tx < s.start + s.dur / 2);
      if (j < 0) j = P.scenes.length;
      target = j;
      const pos = j < P.scenes.length ? P.scenes[j].start : P.total;
      marker.style.left = (pos * P.pps - 2) + "px";
    };
    const up = (e) => {
      document.removeEventListener("mousemove", mv); document.removeEventListener("mouseup", up);
      marker.remove(); el.classList.remove("moving"); el.style.transform = "";
      if (!moving) { seek((e.clientX - rect.left) / P.pps, true); return; }
      let j = target > i ? target - 1 : target;
      if (j === i) return;
      const keys = currentKeys(); const [k] = keys.splice(i, 1); keys.splice(j, 0, k);
      commit(() => keys, `Escena ${P.scenes[i].id} movida a la posición ${j + 1}.`, k);
    };
    document.addEventListener("mousemove", mv); document.addEventListener("mouseup", up);
  }

  // ── Controles ──
  ui.play.addEventListener("click", () => (P.playing ? pause() : play()));
  ui.prev.addEventListener("click", () => { const i = sceneAt(P.T); toScene(P.T - P.scenes[i].start > 1 ? i : i - 1); });
  ui.next.addEventListener("click", () => toScene(sceneAt(P.T) + 1));
  ui.loop.addEventListener("click", () => { P.loop = !P.loop; ui.loop.classList.toggle("on", P.loop); });
  ui.cc.addEventListener("click", () => { P.cc = !P.cc; ui.cc.classList.toggle("on", P.cc); sync(false); });
  ui.cc.classList.toggle("on", P.cc);
  ui.mute.addEventListener("click", () => { P.muted = !P.muted; ui.mute.classList.toggle("off", P.muted); sync(false); });
  ui.bar.addEventListener("mousedown", (ev) => {
    const go = (e) => { const r = ui.bar.getBoundingClientRect(); seek(((e.clientX - r.left) / r.width) * P.total, true); };
    go(ev);
    const mv = (e) => go(e), up = () => { document.removeEventListener("mousemove", mv); document.removeEventListener("mouseup", up); };
    document.addEventListener("mousemove", mv); document.addEventListener("mouseup", up);
  });
  ui.stage.addEventListener("click", () => (P.playing ? pause() : play()));
  [ui.vA, ui.vB, ui.audio].forEach(m => {
    m.addEventListener("waiting", () => { if (P.playing) ui.loading.classList.remove("hidden"); });
    m.addEventListener("playing", () => ui.loading.classList.add("hidden"));
    m.addEventListener("seeked", () => ui.loading.classList.add("hidden"));
  });
  document.addEventListener("keydown", (ev) => {
    if (wrap.classList.contains("hidden") || !ui.show.checked || !P.scenes.length) return;
    const tag = (document.activeElement && document.activeElement.tagName) || "";
    if (/INPUT|TEXTAREA|SELECT/.test(tag) || document.activeElement.isContentEditable) return;
    if (document.querySelector(".lib-overlay:not(.hidden), .modal-overlay.active")) return;
    if (ev.code === "Space") { ev.preventDefault(); P.playing ? pause() : play(); }
    else if (ev.key === "ArrowRight") { ev.preventDefault(); seek(P.T + 1, true); }
    else if (ev.key === "ArrowLeft") { ev.preventDefault(); seek(P.T - 1, true); }
    else if (ev.key === "PageDown") { ev.preventDefault(); toScene(sceneAt(P.T) + 1); }
    else if (ev.key === "PageUp") { ev.preventDefault(); toScene(sceneAt(P.T) - 1); }
    else if (ev.key === "l" || ev.key === "L") { P.loop = !P.loop; ui.loop.classList.toggle("on", P.loop); }
    else if (editable() && (ev.ctrlKey || ev.metaKey) && (ev.key === "z" || ev.key === "Z")) { ev.preventDefault(); undo(); }
    else if (editable() && !ev.ctrlKey && (ev.key === "s" || ev.key === "S")) { ev.preventDefault(); act("split"); }
    else if (editable() && !ev.ctrlKey && (ev.key === "i" || ev.key === "I")) { ev.preventDefault(); act("in"); }
    else if (editable() && !ev.ctrlKey && (ev.key === "o" || ev.key === "O")) { ev.preventDefault(); act("out"); }
    else if (editable() && (ev.key === "Delete" || ev.key === "Supr")) { ev.preventDefault(); act("off"); }
    else if (!ev.ctrlKey && !ev.metaKey && (ev.key === "r" || ev.key === "R")) { ev.preventDefault(); replaceSelected(); }
  });
  // al exportar se pausa la vista previa
  const btnR = document.getElementById("btnRender");
  if (btnR) btnR.addEventListener("click", pause, true);

  // ── Se actualiza solo cuando cambia el análisis de la historia ──
  setInterval(() => {
    const clips = state.clipsData || [];
    const sig = clips.length + "|" + (state.removedScenes || []).length + "|" + clips.map(c => (c.key || c.clip_id) + ":" + (c.edited ? "e" : "") + (c.preview ? c.preview.dur + (c.preview.media ? c.preview.media.url : "") + ((c.preview.audio || {}).url || "") + JSON.stringify(c.preview.vsegs || "") : c.duration)).join(",");
    if (sig !== P.sig) { P.sig = sig; const was = P.playing; pause(); rebuild(); if (was && P.scenes.length) play(); }
  }, 700);
  const subT = document.getElementById("toggleSubtitles");
  if (subT) subT.addEventListener("change", () => setTimeout(() => { paintTextTrack(); sync(false); }, 50));
  document.addEventListener("click", (ev) => { if (ev.target.closest("#subtitlesCard")) setTimeout(() => sync(false), 60); });
  const musicToggle = document.getElementById("toggleMusic");
  if (musicToggle) musicToggle.addEventListener("change", () => setTimeout(loadMusic, 300));
  applyShow();
})();


// ============================================================
// v6.1 — Voz del narrador con Fish Audio
// ============================================================
(function fishVoice() {
  const $ = (id) => document.getElementById(id);
  const ov = $("fishOverlay"), openBtn = $("btnFishOpen");
  if (!ov || !openBtn) return;
  const api = () => window.pywebview && window.pywebview.api;
  const ui = { key: $("fishKey"), keyState: $("fishKeyState"), voice: $("fishVoice"), link: $("fishVoiceLink"),
               voiceState: $("fishVoiceState"), model: $("fishModel"), speed: $("fishSpeed"), summary: $("fishSummary"),
               force: $("fishForce"), prog: $("fishProg"), fill: $("fishProgFill"), pct: $("fishProgPct"),
               progText: $("fishProgText"), msg: $("fishMsg"), go: $("fishGo"), cancel: $("fishCancel") };
  const F = { cfg: null, voices: [], credit: null, running: false };
  const note = (el, text, kind) => { el.innerText = text || ""; el.className = "fish-note" + (kind ? " " + kind : ""); };

  function narratorLines() {
    return (state.clipsData || [])
      .filter(c => (c.kind === "narrator" || c.kind === "clip" || !c.kind || !String(c.speaker || "").trim()
                    || /^narrad/i.test(String(c.speaker || ""))) && String(c.full_text || c.text || "").trim())
      .filter((c, i, all) => all.findIndex(x => x.clip_id === c.clip_id) === i)
      .sort((a, b) => a.clip_id - b.clip_id)
      .map(c => ({ clip_id: c.clip_id, text: String(c.full_text || c.text).trim() }));
  }

  function paintSummary() {
    const lines = narratorLines();
    const dialogs = (state.clipsData || []).filter(c => c.kind === "dialogue").length;
    if (!lines.length) {
      ui.summary.innerHTML = "Primero pega tu guion: aquí aparecerán las líneas del narrador.";
      ui.go.disabled = true;
      return;
    }
    const chars = lines.reduce((n, l) => n + l.text.length, 0);
    ui.summary.innerHTML = `Se creará la voz de <b>${lines.length} línea${lines.length === 1 ? "" : "s"} del narrador</b> (${chars.toLocaleString("es")} caracteres)`
      + (dialogs ? (dialogs === 1 ? ". El diálogo conserva el audio de su video." : `. Los ${dialogs} diálogos conservan el audio de su video.`) : ".")
      + (F.credit != null ? `<br>Saldo de tu cuenta: <b>${F.credit}</b> créditos.` : "")
      + "<br>Las líneas que ya se crearon y no cambiaron no se vuelven a pagar.";
    ui.go.disabled = F.running;
  }

  function paintVoices() {
    const cur = F.cfg && F.cfg.voice_id;
    const opts = ['<option value="">— Elige una de tus voces —</option>'];
    const known = new Set();
    F.voices.forEach(v => { known.add(v.id); opts.push(`<option value="${v.id}">${v.title.replace(/</g, "&lt;")}</option>`); });
    if (cur && !known.has(cur)) opts.push(`<option value="${cur}">${String(F.cfg.voice_name || "Voz elegida").replace(/</g, "&lt;")}</option>`);
    ui.voice.innerHTML = opts.join("");
    ui.voice.value = cur || "";
    note(ui.voiceState, cur ? `Voz elegida: ${F.cfg.voice_name || cur}` : "Ninguna voz elegida.", cur ? "ok" : "");
  }

  async function loadAccount() {
    if (!F.cfg || !F.cfg.has_key) { note(ui.keyState, "Sin clave guardada."); return; }
    note(ui.keyState, "Comprobando tu cuenta…");
    const r = await api().fish_account();
    if (!r || !r.ok) { note(ui.keyState, (r && r.mensaje) || "No se pudo comprobar la clave.", "err"); return; }
    F.voices = r.voices || []; F.credit = r.credit;
    note(ui.keyState, `✓ Clave guardada ${F.cfg.key_hint || ""} · ${F.voices.length === 1 ? "1 voz propia" : F.voices.length + " voces propias"}`, "ok");
    paintVoices(); paintSummary();
  }

  async function save(changes) {
    const r = await api().fish_save_config(changes);
    if (r && r.ok) F.cfg = r.config;
    return r;
  }

  async function open() {
    ov.classList.remove("hidden");
    ui.msg.innerText = ""; ui.progText.innerText = "";
    F.cfg = await api().fish_get_config();
    ui.key.value = "";
    ui.key.placeholder = F.cfg.has_key ? "Clave guardada (escribe otra para cambiarla)" : "Pega aquí tu clave de API";
    ui.model.value = F.cfg.model || "s2.1-pro";
    ui.speed.value = String(F.cfg.speed || 1);
    if (!ui.speed.value) ui.speed.value = "1";
    paintVoices(); paintSummary();
    let tab = "";
    try { tab = localStorage.getItem("vnFishTab") || ""; } catch (e) {}
    showTab(tab === "api" || tab === "web" ? tab : (F.cfg.has_key ? "api" : "web"));
  }

  // ── Pestañas: cuenta gratis (web + Descargas) / clave de API ──
  let curTab = "web";
  function showTab(tab) {
    curTab = tab;
    try { localStorage.setItem("vnFishTab", tab); } catch (e) {}
    ov.querySelectorAll(".fish-tab").forEach(b => b.classList.toggle("active", b.dataset.tab === tab));
    $("fishWebPane").classList.toggle("hidden", tab !== "web");
    $("fishApiPane").classList.toggle("hidden", tab !== "api");
    if (tab === "web") W.enter(); else { W.stopWatch(); loadAccount(); }
  }
  ov.querySelectorAll(".fish-tab").forEach(b => b.addEventListener("click", () => showTab(b.dataset.tab)));

  const W = (function webMode() {
    const box = $("fishLines"), msg = $("fishWebMsg"), auto = $("fishAuto"), watchState = $("fishWatchState");
    const S = { current: null, folder: "", watching: false };
    const esc = (x) => String(x == null ? "" : x).replace(/[&<>"]/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[ch]));
    const base = (p) => String(p || "").split(/[\\/]/).pop();
    const audioOf = (cid) => (state.narratorAudios || {})[cid] || (state.narratorAudios || {})[String(cid)] || "";
    const say = (text, ok) => { msg.className = "auth-msg" + (ok ? " ok" : ""); msg.style.color = ok ? "#00F0FF" : ""; msg.innerText = text || ""; };

    function paint() {
      const lines = narratorLines();
      const done = lines.filter(l => audioOf(l.clip_id)).length;
      $("fishWebCount").innerText = lines.length ? `${done} de ${lines.length} con voz` : "";
      if (!lines.length) {
        box.innerHTML = '<div class="fish-empty">Primero pega tu guion: aquí aparecerán las líneas del narrador.</div>';
        $("fishImport").disabled = true;
        return;
      }
      $("fishImport").disabled = false;
      box.innerHTML = lines.map(l => {
        const a = audioOf(l.clip_id), cur = S.current === l.clip_id;
        const st = a ? `<span class="fl-ok" title="${esc(a)}">✓ ${esc(base(a))}</span>`
                 : cur ? `<span class="fl-wait">${S.watching ? "Esperando la descarga…" : "Copiada"}</span>`
                 : `<span class="fl-chars">${l.text.length} car.</span>`;
        return `<div class="fish-line${cur ? " current" : ""}${a ? " done" : ""}" data-cid="${l.clip_id}">
          <span class="fl-num">${l.clip_id}</span>
          <div class="fl-text">${esc(l.text)}</div>
          <div class="fl-side">${st}
            <div class="fl-btns"><button type="button" class="fl-copy">${cur ? "Copiar otra vez" : "Copiar"}</button>
            <button type="button" class="fl-pick" title="Elegir el audio de esta línea">Elegir audio</button></div></div>
        </div>`;
      }).join("");
      const curEl = box.querySelector(".fish-line.current");
      if (curEl && curEl.scrollIntoView) curEl.scrollIntoView({ block: "nearest" });
    }

    async function copyLine(cid, quiet) {
      const l = narratorLines().find(x => x.clip_id === cid);
      if (!l) return false;
      let ok = false;
      try { ok = !!(await api().fish_copy_text(l.text)).ok; } catch (e) {}
      if (!ok) {
        try { await navigator.clipboard.writeText(l.text); ok = true; } catch (e) {}
      }
      if (!ok) {
        const ta = document.createElement("textarea");
        ta.value = l.text; ta.style.position = "fixed"; ta.style.opacity = "0";
        document.body.appendChild(ta); ta.select();
        try { ok = document.execCommand("copy"); } catch (e) {}
        ta.remove();
      }
      S.current = cid;
      paint();
      if (!quiet) say(ok ? `Línea ${cid} copiada: pégala en Fish Audio (Ctrl+V), genera y descarga.` : "No se pudo copiar; selecciona el texto de la línea y cópialo a mano.", ok);
      return ok;
    }

    function nextMissing(after) {
      const lines = narratorLines();
      const start = after == null ? 0 : lines.findIndex(l => l.clip_id === after) + 1;
      return lines.slice(Math.max(0, start)).find(l => !audioOf(l.clip_id))
          || lines.find(l => !audioOf(l.clip_id) && l.clip_id !== after) || null;
    }

    async function assign(pairs) {
      const r = await api().fish_import(pairs, state.imagesFolder || "", state.audioPath || "");
      if (!r || !r.ok) { say((r && r.mensaje) || "No se pudo guardar el audio."); return null; }
      state.narratorAudios = state.narratorAudios || {};
      Object.entries(r.files || {}).forEach(([cid, path]) => { state.narratorAudios[cid] = path; });
      if (Object.keys(r.files || {}).length) triggerAnalyze();
      if (r.errors && r.errors.length) say(r.errors[0].error);
      return r;
    }

    async function startWatch() {
      if (!auto.checked) { stopWatch(); watchState.innerText = "Detección apagada: usa «Importar» o «Elegir audio»."; return; }
      const r = await api().fish_watch_start(S.folder || "");
      S.watching = !!(r && r.ok);
      if (S.watching) S.folder = r.folder;
      watchState.innerHTML = S.watching
        ? `Vigilando tus descargas en <b class="fish-path">${esc(S.folder)}</b> · <button type="button" class="upd-link" id="fishWatchChange">Cambiar carpeta</button>`
        : "No se pudo vigilar la carpeta de descargas.";
      const ch = $("fishWatchChange");
      if (ch) ch.addEventListener("click", async () => {
        const p = await api().fish_pick_folder();
        if (p && p.folder) { S.folder = p.folder; startWatch(); }
      });
      paint();
    }
    function stopWatch() {
      if (S.watching && api()) api().fish_watch_stop();
      S.watching = false;
    }

    // ── Emparejar por el texto: Fish nombra la descarga "Voz-AAAA-MM-DD-HH-MM-Primeras-palabras.mp3"
    const plain = (t) => String(t || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "");
    function slugOf(name) {
      const b = String(name || "").replace(/\.[^.]+$/, "").replace(/\s*\(\d+\)$/, "");
      const m = b.match(/\d{4}-\d{2}-\d{2}-\d{2}-\d{2}(?:-\d{2})?-(.+)$/);
      return plain(m ? m[1] : b);
    }
    function lev(a, b) {
      const v = Array.from({ length: b.length + 1 }, (_, i) => i);
      for (let i = 1; i <= a.length; i++) {
        let prev = v[0]; v[0] = i;
        for (let j = 1; j <= b.length; j++) {
          const tmp = v[j];
          v[j] = Math.min(v[j] + 1, v[j - 1] + 1, prev + (a[i - 1] === b[j - 1] ? 0 : 1));
          prev = tmp;
        }
      }
      return v[b.length];
    }
    function matchScore(slug, text) {
      if (slug.length < 6) return 0;
      const t = plain(text);
      let best = 0;
      for (const len of [slug.length - 3, slug.length, slug.length + 3]) {      // tolera letras perdidas (acentos)
        if (len < 1) continue;
        const pre = t.slice(0, len);
        best = Math.max(best, 1 - lev(slug, pre) / Math.max(slug.length, pre.length));
      }
      return best;
    }
    function lineForFile(name, lines, used) {
      const slug = slugOf(name);
      let best = null, bestScore = 0;
      lines.forEach(l => {
        if (used && used.has(l.clip_id)) return;
        const sc = matchScore(slug, l.text);
        if (sc > bestScore) { bestScore = sc; best = l; }
      });
      return bestScore >= 0.72 ? best : null;
    }

    S.queue = [];
    async function placeDownload(d) {
      const lines = narratorLines();
      if (!lines.length) { S.queue.push(d); return null; }
      let target = lineForFile(d.name, lines), how = "texto";
      if (!target) { target = lines.find(l => l.clip_id === S.current && !audioOf(l.clip_id)) || nextMissing(null); how = "orden"; }
      if (!target) return { none: true };
      const r = await assign([{ clip_id: target.clip_id, path: d.path }]);
      if (!r || !Object.keys(r.files || {}).length) return null;
      return { target, how };
    }

    async function afterPlaced(placed, name) {
      const nxt = nextMissing(placed.target.clip_id);
      if (nxt) {
        const ok = await copyLine(nxt.clip_id, true);
        say(`✓ Línea ${placed.target.clip_id} lista (${name}).` + (ok ? ` La línea ${nxt.clip_id} ya está copiada: pégala en Fish Audio.` : ""), true);
      } else {
        S.current = null; paint();
        say(`✓ Línea ${placed.target.clip_id} lista. ¡Todas las líneas del narrador tienen voz! Ya puedes cerrar esta ventana.`, true);
      }
    }

    window.onFishDownload = async function (d) {
      if (ov.classList.contains("hidden") || curTab !== "web" || !d || !d.path) return;
      const placed = await placeDownload(d);
      if (placed === null) {
        if (S.queue.length) { say(`Recibí ${S.queue.length} audio${S.queue.length === 1 ? "" : "s"}. En cuanto aparezca tu guion los pondré en sus líneas.`, true); paint(); }
        return;
      }
      if (placed.none) { say(`Llegó «${d.name}», pero no coincide con ninguna línea sin voz. Usa «Elegir audio» en la línea que quieras cambiar.`); return; }
      await afterPlaced(placed, d.name);
    };

    // Revisa el guion mientras la ventana está abierta (si lo pegas o cambias con la ventana abierta)
    let sig = "";
    async function tick() {
      if (ov.classList.contains("hidden") || curTab !== "web") return;
      const lines = narratorLines();
      const now = lines.map(l => l.clip_id + ":" + l.text.length + ":" + (audioOf(l.clip_id) ? 1 : 0)).join("|");
      if (now !== sig) { sig = now; paint(); }
      if (lines.length && S.queue.length) {
        const q = S.queue.splice(0);
        let n = 0, last = null;
        for (const d of q) { const p = await placeDownload(d); if (p && !p.none) { n++; last = p; } }
        if (last) await afterPlaced(last, `${n} audio${n === 1 ? "" : "s"} recibido${n === 1 ? "" : "s"}`);
      }
    }
    setInterval(tick, 1500);

    box.addEventListener("click", async (ev) => {
      const row = ev.target.closest(".fish-line");
      if (!row) return;
      const cid = parseInt(row.dataset.cid, 10);
      if (ev.target.closest(".fl-copy")) { copyLine(cid); return; }
      if (ev.target.closest(".fl-pick")) {
        const r = await api().fish_pick_downloads(S.folder || "");
        const f = r && r.files && r.files[r.files.length - 1];
        if (!f) return;
        const ok = await assign([{ clip_id: cid, path: f.path }]);
        if (ok) { if (S.current === cid) S.current = null; paint(); say(`✓ Línea ${cid}: ${f.name}`, true); }
      }
    });

    $("fishImport").addEventListener("click", async () => {
      const r = await api().fish_pick_downloads(S.folder || "");
      const files = (r && r.files) || [];
      if (!files.length) return;
      const lines = narratorLines();
      if (!lines.length) { say("Primero pega tu guion; luego importa los audios."); return; }
      const used = new Set(), pairs = [], rest = [];
      let byText = 0;
      files.forEach(f => {
        const l = lineForFile(f.name, lines, used);
        if (l) { used.add(l.clip_id); pairs.push({ clip_id: l.clip_id, path: f.path }); byText++; }
        else rest.push(f);
      });
      const free = lines.filter(l => !used.has(l.clip_id) && !audioOf(l.clip_id));
      rest.forEach(f => { const l = free.shift(); if (l) { used.add(l.clip_id); pairs.push({ clip_id: l.clip_id, path: f.path }); } });
      const extra = files.length - pairs.length;
      if (!pairs.length) { say("Esos audios no coinciden con ninguna línea sin voz."); return; }
      const res = await assign(pairs);
      if (!res) return;
      S.current = null;
      const nxt = nextMissing(null);
      if (nxt && auto.checked) await copyLine(nxt.clip_id, true); else paint();
      pairs.sort((x, y) => x.clip_id - y.clip_id);
      say(`✓ ${pairs.length} audio${pairs.length === 1 ? "" : "s"} puesto${pairs.length === 1 ? "" : "s"} en su línea`
        + (byText === pairs.length ? " (reconocidos por su texto)" : byText ? ` (${byText} por su texto, el resto por orden de descarga)` : " (por orden de descarga)")
        + "." + (extra > 0 ? ` ${extra} no coincidieron con ninguna línea sin voz.` : "")
        + (nxt ? ` Falta la línea ${nxt.clip_id}${auto.checked ? " (ya copiada)" : ""}.` : " ¡Todas las líneas tienen voz!"), true);
    });

    $("fishOpenSite").addEventListener("click", () => api().open_url("https://fish.audio/"));
    auto.addEventListener("change", startWatch);

    return {
      async enter() {
        say("");
        await startWatch();
        const first = narratorLines().find(l => !audioOf(l.clip_id));
        if (first && auto.checked && S.current == null) {
          const ok = await copyLine(first.clip_id, true);
          if (ok) say(`La línea ${first.clip_id} ya está copiada: abre Fish Audio, pégala (Ctrl+V), genera y descarga.`, true);
        } else paint();
      },
      stopWatch,
    };
  })();

  openBtn.addEventListener("click", () => { if (api()) open(); });
  function close() { ov.classList.add("hidden"); W.stopWatch(); }
  $("fishClose").addEventListener("click", close);
  ov.addEventListener("click", (ev) => { if (ev.target === ov && !F.running) close(); });
  $("fishKeyHelp").addEventListener("click", () => api().open_url("https://fish.audio/app/api-keys/"));
  $("fishKeySave").addEventListener("click", async () => {
    const k = ui.key.value.trim();
    if (k.length < 8) { note(ui.keyState, "Pega la clave completa.", "err"); return; }
    await save({ api_key: k });
    ui.key.value = "";
    ui.key.placeholder = "Clave guardada (escribe otra para cambiarla)";
    loadAccount();
  });
  ui.voice.addEventListener("change", async () => {
    const v = F.voices.find(x => x.id === ui.voice.value);
    await save({ voice_id: ui.voice.value, voice_name: v ? v.title : "" });
    paintVoices();
  });
  $("fishVoiceUse").addEventListener("click", async () => {
    note(ui.voiceState, "Buscando la voz…");
    const r = await api().fish_check_voice(ui.link.value);
    if (!r || !r.ok) { note(ui.voiceState, (r && r.mensaje) || "No se encontró la voz.", "err"); return; }
    await save({ voice_id: r.voice.id, voice_name: r.voice.title });
    ui.link.value = "";
    paintVoices();
  });
  ui.model.addEventListener("change", () => save({ model: ui.model.value }));
  ui.speed.addEventListener("change", () => save({ speed: parseFloat(ui.speed.value) || 1 }));

  ui.go.addEventListener("click", async () => {
    const lines = narratorLines();
    if (!lines.length) return;
    ui.msg.innerText = "";
    const r = await api().fish_generate(lines, state.imagesFolder || "", state.audioPath || "", ui.force.checked);
    if (!r || !r.ok) { ui.msg.innerText = (r && r.mensaje) || "No se pudo empezar."; return; }
    F.running = true;
    ui.go.disabled = true; ui.go.innerText = "Generando…";
    ui.cancel.classList.remove("hidden");
    ui.prog.classList.remove("hidden");
    ui.fill.style.width = "0%"; ui.pct.innerText = `0/${r.total}`;
  });
  ui.cancel.addEventListener("click", () => { api().fish_cancel(); ui.progText.innerText = "Cancelando al terminar la línea actual…"; });

  window.onFishProgress = function (p) {
    if (!p || !p.total) return;
    ui.fill.style.width = Math.round(p.done * 100 / p.total) + "%";
    ui.pct.innerText = `${p.done}/${p.total}`;
    ui.progText.innerText = p.clip_id != null ? `Línea ${p.clip_id}: «${p.text}${p.text && p.text.length >= 80 ? "…" : ""}»` : "";
  };

  window.onFishDone = function (r) {
    F.running = false;
    ui.go.disabled = false; ui.go.innerText = "Generar la voz";
    ui.cancel.classList.add("hidden");
    ui.progText.innerText = "";
    if (r && r.ok && !r.cancelled) { ui.fill.style.width = "100%"; const t = ui.pct.innerText.split("/")[1]; if (t) ui.pct.innerText = `${t}/${t}`; }
    if (!r || !r.ok) { ui.msg.className = "auth-msg"; ui.msg.innerText = (r && r.mensaje) || "Algo falló."; return; }
    const files = r.files || {};
    state.narratorAudios = state.narratorAudios || {};
    Object.entries(files).forEach(([cid, path]) => { state.narratorAudios[cid] = path; });
    const n = Object.keys(files).length;
    let text = n
      ? `✓ Listo: ${n} línea${n === 1 ? "" : "s"} con voz (${r.generated} nuevas, ${r.reused} reutilizadas). Ya están asignadas a sus escenas.\nCarpeta: ${r.folder}`
      : "No se creó ninguna línea.";
    if (r.cancelled) text += "\nSe canceló antes de terminar.";
    if (r.errors && r.errors.length) text += `\n⚠ ${r.errors.length} línea(s) con error: ${r.errors[0].error}`;
    ui.msg.className = "auth-msg" + (n && !(r.errors || []).length ? " ok" : "");
    ui.msg.style.color = n && !(r.errors || []).length ? "#00F0FF" : "";
    ui.msg.innerText = text;
    if (n) triggerAnalyze();
    loadAccount();
  };
})();
