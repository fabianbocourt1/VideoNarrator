/* VideoNarrator v8.5 — Conexión de respaldo.
   Si en esta PC pywebview no conecta la pantalla con el programa (window.pywebview.api no aparece),
   se usa un pequeño servidor local del propio VideoNarrator (127.0.0.1) con las mismas funciones. */
(function () {
  "use strict";
  const PORTS = Array.from({ length: 20 }, (_, i) => 47811 + i);
  const ready = () => { const a = window.pywebview && window.pywebview.api; return !!(a && typeof a.auth_login === "function"); };

  async function ping(port) {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), 900);
    try {
      const r = await fetch(`http://127.0.0.1:${port}/ping`, { cache: "no-store", signal: ctl.signal });
      const d = await r.json();
      return d && d.app === "VideoNarrator" && d.token ? { base: `http://127.0.0.1:${port}`, token: d.token } : null;
    } catch (e) { return null; } finally { clearTimeout(t); }
  }

  async function connect(tries) {
    if (ready()) return;
    let found = null;
    for (const p of PORTS) { found = await ping(p); if (found || ready()) break; }
    if (ready()) return;
    if (!found) { if (tries < 15) setTimeout(() => connect(tries + 1), 4000); return; }

    const { base, token } = found;
    const call = (name, args) => fetch(`${base}/call/${name}`, {
      method: "POST", cache: "no-store",
      headers: { "Content-Type": "application/json", "X-VN-Token": token },
      body: JSON.stringify(args)
    }).then(r => r.json()).then(d => {
      if (d && Object.prototype.hasOwnProperty.call(d, "result")) return d.result;
      throw new Error((d && d.error) || "Error en la conexión de respaldo");
    });
    const api = new Proxy({}, {
      get: (t, k) => (typeof k !== "string" || k === "then" || k === "toJSON") ? undefined : (...args) => call(k, args)
    });
    window.pywebview = window.pywebview || {};
    window.pywebview.api = api;
    window.vnBridgeBackup = true;
    try { console.log("[VideoNarrator] conexión de respaldo activa"); } catch (e) {}
    window.dispatchEvent(new Event("pywebviewready"));

    // Avisos de Python (progreso del render, descargas, etc.)
    (async function events() {
      for (;;) {
        try {
          const r = await fetch(`${base}/events`, { cache: "no-store", headers: { "X-VN-Token": token } });
          const d = await r.json();
          (d.js || []).forEach(code => { try { (0, eval)(code); } catch (e) {} });
        } catch (e) {
          await new Promise(res => setTimeout(res, 1500));
        }
      }
    })();
  }

  // Se espera primero a pywebview; solo si no llega se usa el respaldo
  setTimeout(() => connect(0), 5000);
})();
