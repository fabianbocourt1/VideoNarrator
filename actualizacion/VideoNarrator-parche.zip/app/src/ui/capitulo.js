// ============================================================
// v9.3 — Etiqueta de capítulo · v9.5 — ajuste a mano (mover, tamaño y rotación)
// "CAPÍTULO N" (+ título y "PARTE N") encima del primer clip, con letras gruesas sobre una franja
// de brocha. La imagen la dibuja Python (core/chapter_tag.py) y aquí se coloca con las mismas
// medidas que usará el video: lo que se ve en el reproductor es lo que sale.
// ============================================================
(function chapterTag() {
  const $ = (id) => document.getElementById(id);
  const el = {
    card: $("ctCard"), on: $("ctOn"), box: $("ctOptions"), num: $("ctChapter"), part: $("ctPart"), title: $("ctTitle"),
    pos: $("ctPos"), x: $("ctX"), y: $("ctY"), ent: $("ctEntrance"), dur: $("ctDur"), durVal: $("ctDurVal"), color: $("ctColor"),
    scale: $("ctScale"), scaleVal: $("ctScaleVal"), rot: $("ctRot"), rotVal: $("ctRotVal"), center: $("ctCenter"), reset: $("ctReset"),
    prev: $("ctPrevImg"), head: $("pvCtHead"), lane: $("pvCtTrack"), res: $("selectResolution")
  };
  if (!el.card || !el.on) return;
  const api = () => (window.pywebview && window.pywebview.api) || null;
  const ls = { get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }, set(k, v) { try { localStorage.setItem(k, v); } catch (e) {} } };
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const S = { png: "", key: "", timer: 0, shown: false, G: null, drag: null };

  const num = (inp, d) => { const v = parseFloat(inp.value); return isFinite(v) ? v : d; };
  function opts() {
    return {
      chapter_enabled: !!el.on.checked,
      chapter_number: Math.max(1, parseInt(el.num.value, 10) || 1),
      chapter_part: Math.max(0, parseInt(el.part.value, 10) || 0),
      chapter_title: (el.title.value || "").trim(),
      chapter_position: ["top", "center", "free"].includes(el.pos.value) ? el.pos.value : "top",
      chapter_entrance: el.ent.value === "suave" ? "suave" : "golpe",
      chapter_duration: clamp(num(el.dur, 2.5), 1, 5),
      chapter_color: ["rojo_azul", "rojo", "azul"].includes(el.color.value) ? el.color.value : "rojo_azul",
      chapter_x: clamp(num(el.x, 0.5), -0.5, 1.5),
      chapter_y: clamp(num(el.y, 0.15), -0.5, 1.5),
      chapter_scale: clamp(num(el.scale, 100), 30, 250) / 100,
      chapter_rot: clamp(num(el.rot, 0), -180, 180)
    };
  }
  window.vnChapter = { options: opts };

  // ── Medidas (iguales a core/chapter_tag.py) ──
  function presetY(o) {
    const G = S.G; if (!G) return 0.15;
    if (o.chapter_position === "center") return G.center_y;
    const f = G.base * o.chapter_scale;
    return (30 * f + G.h * f / 2) / G.H;
  }
  function center(o) {
    return o.chapter_position === "free" ? { x: o.chapter_x, y: o.chapter_y } : { x: 0.5, y: presetY(o) };
  }
  function frame() {               // dónde está el cuadro del video dentro del reproductor
    const pv = window.vnPreview, st = pv.stage, G = S.G;
    const sw = st.clientWidth, sh = st.clientHeight;
    const k = Math.min(sw / G.W, sh / G.H);
    return { k, ox: (sw - G.W * k) / 2, oy: (sh - G.H * k) / 2, fw: G.W * k, fh: G.H * k };
  }

  // ── Tarjeta ──
  function paintChoices() {
    el.card.querySelectorAll("[data-for]").forEach(g => {
      const v = $(g.dataset.for).value;
      g.querySelectorAll("[data-v]").forEach(b => b.classList.toggle("on", b.dataset.v === v));
    });
    const o = opts();
    el.durVal.innerText = String(o.chapter_duration).replace(".", ",") + " s";
    el.scaleVal.innerText = Math.round(o.chapter_scale * 100) + " %";
    el.rotVal.innerText = Math.round(o.chapter_rot) + "°";
    el.box.classList.toggle("hidden", !el.on.checked);
    paintMini();
  }
  function paintMini() {             // la miniatura de la tarjeta usa las mismas medidas
    const G = S.G, box = el.prev && el.prev.parentElement;
    if (!G || !box || !S.png) return;
    const o = opts(), c = center(o);
    const bw = box.clientWidth || 92, k = bw / G.W;
    const w = G.w * G.base * o.chapter_scale * k, h = G.h * G.base * o.chapter_scale * k;
    Object.assign(el.prev.style, { position: "absolute", width: w + "px", height: h + "px", left: (c.x * G.W * k - w / 2) + "px",
      top: (c.y * G.H * k - h / 2) + "px", transform: `rotate(${o.chapter_rot}deg)`, objectFit: "fill" });
    box.style.position = "relative";
    box.style.aspectRatio = `${G.W} / ${G.H}`;
  }
  function savePrefs() {
    const o = opts();
    ls.set("vn_chapter", JSON.stringify({ pos: o.chapter_position, ent: o.chapter_entrance, dur: o.chapter_duration, color: o.chapter_color,
      x: o.chapter_x, y: o.chapter_y, scale: Math.round(o.chapter_scale * 100), rot: o.chapter_rot }));
  }
  function loadPrefs() {
    try {
      const p = JSON.parse(ls.get("vn_chapter") || "null");
      if (!p) return;
      if (p.pos) el.pos.value = p.pos;
      if (p.ent) el.ent.value = p.ent;
      if (p.dur) el.dur.value = p.dur;
      if (p.color) el.color.value = p.color;
      if (p.x != null) el.x.value = p.x;
      if (p.y != null) el.y.value = p.y;
      if (p.scale) el.scale.value = p.scale;
      if (p.rot != null) el.rot.value = p.rot;
    } catch (e) {}
  }
  function set(id, v) { const inp = $(id); inp.value = String(v); inp.dispatchEvent(new Event("change", { bubbles: true })); }
  function toFree() {                // al tocar a mano, la posición pasa a "A mano" en el mismo sitio
    const o = opts();
    if (o.chapter_position === "free") return;
    const c = center(o);
    el.x.value = c.x.toFixed(4); el.y.value = c.y.toFixed(4);
    set("ctPos", "free");
  }
  function showOnPlayer() {         // para ajustar, el reproductor va al inicio, donde se ve la etiqueta
    const pv = window.vnPreview;
    if (!pv || !pv.seek || !el.on.checked) return;
    if (pv.playing()) pv.pause();
    if (pv.time() > opts().chapter_duration - 0.2) pv.seek(0.3);
  }

  // Imagen de la etiqueta (la dibuja Python; se pide de nuevo solo si algo cambió)
  function refresh() {
    clearTimeout(S.timer);
    S.timer = setTimeout(async () => {
      const a = api(); if (!a || !a.chapter_tag_preview) return;
      const o = opts();
      const res = el.res ? el.res.value : "vertical";
      const key = [o.chapter_number, o.chapter_part, o.chapter_title, o.chapter_color, res].join("|");
      if (key === S.key && S.png) return;
      let r; try { r = await a.chapter_tag_preview({ ...o, resolution: res }); } catch (e) { r = null; }
      if (r && r.png) {
        S.png = r.png; S.key = key;
        S.G = { w: r.w, h: r.h, W: r.W || 1080, H: r.H || 1920, base: r.base || 1, top_y: r.top_y, center_y: r.center_y || 0.4 };
        el.prev.src = r.png;
        const L = layer(); if (L) L.querySelector("img").src = r.png;
        paintMini();
      }
    }, 250);
  }

  el.card.addEventListener("click", (ev) => {
    const st = ev.target.closest("[data-step]");
    if (st) {
      const [id, d] = st.dataset.step.split(":");
      const inp = $(id);
      const min = parseInt(inp.min, 10) || 0, max = parseInt(inp.max, 10) || 999;
      set(id, Math.min(max, Math.max(min, (parseInt(inp.value, 10) || 0) + parseInt(d, 10))));
      return;
    }
    const b = ev.target.closest("[data-v]");
    const g = b && b.closest("[data-for]");
    if (g) {
      if (g.dataset.for === "ctPos" && b.dataset.v === "free") { toFree(); showOnPlayer(); return; }
      set(g.dataset.for, b.dataset.v);
      if (g.dataset.for === "ctPos") showOnPlayer();
    }
  });
  el.center.addEventListener("click", () => { toFree(); set("ctX", "0.5"); showOnPlayer(); });
  el.reset.addEventListener("click", () => { el.scale.value = "100"; el.rot.value = "0"; el.x.value = "0.5"; el.y.value = "0.15"; set("ctPos", "top"); showOnPlayer(); });
  [el.scale, el.rot].forEach(r => r.addEventListener("input", () => { showOnPlayer(); }));
  [el.on, el.num, el.part, el.title, el.pos, el.x, el.y, el.ent, el.dur, el.color, el.scale, el.rot].forEach(x => {
    ["input", "change"].forEach(t => x.addEventListener(t, () => {
      paintChoices(); refresh();
      if (x !== el.num && x !== el.part && x !== el.title && x !== el.on) savePrefs();
    }));
  });
  if (el.res) el.res.addEventListener("change", () => { S.key = ""; refresh(); });

  // ── Reproductor: la etiqueta, y en pausa su caja para moverla, escalarla y girarla ──
  // La imagen va dentro del reproductor (se recorta al cuadro del video); la caja de ajuste va
  // por encima, fuera del recorte, para que las esquinas y el círculo de girar siempre se alcancen.
  let lay = null, hnd = null;
  function layer() {
    const pv = window.vnPreview;
    if (!pv || !pv.stage) return null;
    if (lay && lay.parentNode === pv.stage && hnd && hnd.parentNode === pv.stage.parentElement) return lay;
    if (lay) lay.remove();
    if (hnd) hnd.remove();
    lay = document.createElement("div");
    lay.className = "ct-layer hidden";
    lay.innerHTML = '<div class="ct-wrap"><img alt=""></div>';
    if (S.png) lay.querySelector("img").src = S.png;
    pv.stage.appendChild(lay);
    hnd = document.createElement("div");
    hnd.className = "ct-handles hidden";
    hnd.innerHTML = '<div class="ct-wrap"><div class="ct-bx"><i data-c="nw"></i><i data-c="ne"></i><i data-c="sw"></i><i data-c="se"></i><span class="ct-rh" title="Girar (Shift: de 15 en 15°)">↻</span></div></div>';
    pv.stage.parentElement.appendChild(hnd);
    const wr = hnd.querySelector(".ct-wrap");
    wr.addEventListener("pointerdown", startDrag);
    ["mousedown", "click", "dblclick"].forEach(t => wr.addEventListener(t, (e) => { e.stopPropagation(); e.preventDefault(); }));   // no pausar/reproducir al ajustar
    return lay;
  }
  function place(L, o) {
    const G = S.G, F = frame(), c = center(o), st = window.vnPreview.stage;
    const w = G.w * G.base * o.chapter_scale * F.k, h = G.h * G.base * o.chapter_scale * F.k;
    const css = { width: w + "px", height: h + "px", left: (F.ox + c.x * F.fw - w / 2) + "px", top: (F.oy + c.y * F.fh - h / 2) + "px",
                  transform: `rotate(${o.chapter_rot}deg)` };
    Object.assign(L.querySelector(".ct-wrap").style, css);
    Object.assign(hnd.style, { left: st.offsetLeft + "px", top: st.offsetTop + "px", width: st.clientWidth + "px", height: st.clientHeight + "px" });
    Object.assign(hnd.querySelector(".ct-wrap").style, css);
  }
  function startDrag(ev) {
    if (!S.G) return;
    ev.preventDefault(); ev.stopPropagation();
    const pv = window.vnPreview; if (pv.playing()) pv.pause();
    toFree();
    const o = opts(), F = frame(), r = pv.stage.getBoundingClientRect();
    const cx = r.left + F.ox + o.chapter_x * F.fw, cy = r.top + F.oy + o.chapter_y * F.fh;
    const hd = ev.target.closest("[data-c]") ? "scale" : ev.target.closest(".ct-rh") ? "rot" : "move";
    const d0 = Math.hypot(ev.clientX - cx, ev.clientY - cy) || 1;
    S.drag = { hd, sx: ev.clientX, sy: ev.clientY, x0: o.chapter_x, y0: o.chapter_y, s0: o.chapter_scale, d0, cx, cy, F };
    const mv = (e) => {
      const D = S.drag; if (!D) return;
      if (D.hd === "move") {
        let x = D.x0 + (e.clientX - D.sx) / D.F.fw, y = D.y0 + (e.clientY - D.sy) / D.F.fh;
        if (Math.abs(x - 0.5) < 0.015) x = 0.5;                    // se queda centrada si pasas cerca del centro
        el.x.value = clamp(x, -0.5, 1.5).toFixed(4); el.y.value = clamp(y, -0.5, 1.5).toFixed(4);
      } else if (D.hd === "scale") {
        const d = Math.hypot(e.clientX - D.cx, e.clientY - D.cy);
        el.scale.value = String(Math.round(clamp(D.s0 * d / D.d0 * 100, 30, 250)));
      } else {
        let a = Math.atan2(e.clientY - D.cy, e.clientX - D.cx) * 180 / Math.PI + 90;
        if (a > 180) a -= 360;
        a = e.shiftKey ? Math.round(a / 15) * 15 : Math.round(a);
        if (Math.abs(a) <= 3) a = 0;                                 // se endereza sola cerca de 0°
        el.rot.value = String(clamp(a, -180, 180));
      }
      paintChoices();
    };
    const up = () => {
      document.removeEventListener("pointermove", mv); document.removeEventListener("pointerup", up);
      S.drag = null;
      [el.x, el.y, el.scale, el.rot].forEach(i => i.dispatchEvent(new Event("change", { bubbles: true })));
    };
    document.addEventListener("pointermove", mv); document.addEventListener("pointerup", up);
  }

  let laneKey = "";
  function tick() {
    const pv = window.vnPreview;
    const o = opts();
    const live = !!(pv && pv.stage && o.chapter_enabled && S.png && S.G && pv.total() > 0);
    if (live) {
      const L = layer();
      const vis = pv.time() <= o.chapter_duration || !!S.drag;
      if (vis && !S.shown) {
        L.classList.remove("hidden", "pop", "soft"); void L.offsetWidth;
        if (pv.playing()) L.classList.add(o.chapter_entrance === "suave" ? "soft" : "pop");
      }
      if (!vis) L.classList.add("hidden");
      S.shown = vis;
      if (vis) place(L, o);
      hnd.classList.toggle("hidden", !(vis && !pv.playing()));
      const pps = pv.pps() || 1, total = pv.total();
      const k = [total, pps, o.chapter_duration, o.chapter_number, o.chapter_part].join("|");
      el.lane.classList.remove("hidden"); el.head.classList.remove("hidden");
      if (k !== laneKey) {
        laneKey = k;
        el.lane.style.width = (total * pps) + "px";
        const w = Math.max(4, Math.min(total, o.chapter_duration) * pps - 2);
        el.lane.innerHTML = `<div class="ct-bar" style="width:${w}px" title="Etiqueta de capítulo · ${String(o.chapter_duration).replace(".", ",")} s"><span>CAP. ${o.chapter_number}${o.chapter_part ? " · P" + o.chapter_part : ""}</span></div>`;
      }
    } else {
      if (lay) lay.classList.add("hidden");
      if (hnd) hnd.classList.add("hidden");
      S.shown = false;
      el.lane.classList.add("hidden"); el.head.classList.add("hidden"); laneKey = "";
    }
    requestAnimationFrame(tick);
  }

  loadPrefs();
  paintChoices();
  setTimeout(refresh, 1200);
  requestAnimationFrame(tick);
})();
