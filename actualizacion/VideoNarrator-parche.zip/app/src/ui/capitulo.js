// ============================================================
// v9.3 — Etiqueta de capítulo
// "CAPÍTULO N" (+ título y "PARTE N") encima del primer clip, con letras gruesas sobre una franja
// de brocha. La imagen la dibuja Python (core/chapter_tag.py): lo que se ve aquí es lo que sale.
// ============================================================
(function chapterTag() {
  const $ = (id) => document.getElementById(id);
  const el = {
    card: $("ctCard"), on: $("ctOn"), box: $("ctOptions"), num: $("ctChapter"), part: $("ctPart"), title: $("ctTitle"),
    pos: $("ctPos"), ent: $("ctEntrance"), dur: $("ctDur"), durVal: $("ctDurVal"), color: $("ctColor"),
    prev: $("ctPrevImg"), head: $("pvCtHead"), lane: $("pvCtTrack")
  };
  if (!el.card || !el.on) return;
  const api = () => (window.pywebview && window.pywebview.api) || null;
  const ls = { get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }, set(k, v) { try { localStorage.setItem(k, v); } catch (e) {} } };
  const S = { png: "", key: "", timer: 0, shown: false };

  function opts() {
    return {
      chapter_enabled: !!el.on.checked,
      chapter_number: Math.max(1, parseInt(el.num.value, 10) || 1),
      chapter_part: Math.max(0, parseInt(el.part.value, 10) || 0),
      chapter_title: (el.title.value || "").trim(),
      chapter_position: el.pos.value === "center" ? "center" : "top",
      chapter_entrance: el.ent.value === "suave" ? "suave" : "golpe",
      chapter_duration: Math.min(5, Math.max(1, parseFloat(el.dur.value) || 2.5)),
      chapter_color: ["rojo_azul", "rojo", "azul"].includes(el.color.value) ? el.color.value : "rojo_azul"
    };
  }
  window.vnChapter = { options: opts };

  // Los botones de opción (posición, entrada, color) reflejan sus campos ocultos
  function paintChoices() {
    el.card.querySelectorAll("[data-for]").forEach(g => {
      const v = $(g.dataset.for).value;
      g.querySelectorAll("[data-v]").forEach(b => b.classList.toggle("on", b.dataset.v === v));
    });
    el.durVal.innerText = String(opts().chapter_duration).replace(".", ",") + " s";
    el.box.classList.toggle("hidden", !el.on.checked);
  }
  function savePrefs() {
    const o = opts();
    ls.set("vn_chapter", JSON.stringify({ pos: o.chapter_position, ent: o.chapter_entrance, dur: o.chapter_duration, color: o.chapter_color }));
  }
  function loadPrefs() {
    try {
      const p = JSON.parse(ls.get("vn_chapter") || "null");
      if (!p) return;
      if (p.pos) el.pos.value = p.pos;
      if (p.ent) el.ent.value = p.ent;
      if (p.dur) el.dur.value = p.dur;
      if (p.color) el.color.value = p.color;
    } catch (e) {}
  }

  // Imagen de la etiqueta (la dibuja Python; se pide de nuevo solo si algo cambió)
  function refresh() {
    clearTimeout(S.timer);
    S.timer = setTimeout(async () => {
      const a = api(); if (!a || !a.chapter_tag_preview) return;
      const o = opts();
      const key = [o.chapter_number, o.chapter_part, o.chapter_title, o.chapter_position, o.chapter_color].join("|");
      if (key === S.key && S.png) return;
      let r; try { r = await a.chapter_tag_preview(o); } catch (e) { r = null; }
      if (r && r.png) { S.png = r.png; S.key = key; el.prev.src = r.png; layer().querySelector("img").src = r.png; }
    }, 250);
  }

  el.card.addEventListener("click", (ev) => {
    const st = ev.target.closest("[data-step]");
    if (st) {
      const [id, d] = st.dataset.step.split(":");
      const inp = $(id);
      const min = parseInt(inp.min, 10) || 0, max = parseInt(inp.max, 10) || 999;
      inp.value = String(Math.min(max, Math.max(min, (parseInt(inp.value, 10) || 0) + parseInt(d, 10))));
      inp.dispatchEvent(new Event("change", { bubbles: true }));
      return;
    }
    const b = ev.target.closest("[data-v]");
    const g = b && b.closest("[data-for]");
    if (g) { const h = $(g.dataset.for); h.value = b.dataset.v; h.dispatchEvent(new Event("change", { bubbles: true })); }
  });
  [el.on, el.num, el.part, el.title, el.pos, el.ent, el.dur, el.color].forEach(x => {
    ["input", "change"].forEach(t => x.addEventListener(t, () => { paintChoices(); refresh(); if (x !== el.num && x !== el.part && x !== el.title) savePrefs(); }));
  });

  // ── Reproductor: la etiqueta aparece en los primeros segundos ──
  let lay = null;
  function layer() {
    const pv = window.vnPreview;
    if (lay && pv && pv.stage && lay.parentNode === pv.stage) return lay;
    lay = document.createElement("div");
    lay.className = "ct-layer hidden";
    lay.innerHTML = '<img alt="">';
    if (S.png) lay.querySelector("img").src = S.png;
    if (pv && pv.stage) pv.stage.appendChild(lay);
    return lay;
  }
  let laneKey = "";
  function tick() {
    const pv = window.vnPreview;
    const o = opts();
    const live = !!(pv && pv.stage && o.chapter_enabled && S.png && pv.total() > 0);
    if (live) {
      const L = layer();
      const vis = pv.time() <= o.chapter_duration;
      L.querySelector("img").style.transformOrigin = o.chapter_position === "center" ? "50% 40%" : "50% 12%";
      if (vis && !S.shown) { L.classList.remove("hidden", "pop", "soft"); void L.offsetWidth; L.classList.add(o.chapter_entrance === "suave" ? "soft" : "pop"); }
      if (!vis) L.classList.add("hidden");
      S.shown = vis;
      const pps = pv.pps() || 1, total = pv.total();
      const k = [total, pps, o.chapter_duration, o.chapter_number, o.chapter_part].join("|");
      el.lane.classList.remove("hidden"); el.head.classList.remove("hidden");
      if (k !== laneKey) {
        laneKey = k;
        el.lane.style.width = (total * pps) + "px";
        const w = Math.max(4, Math.min(total, o.chapter_duration) * pps - 2);
        el.lane.innerHTML = `<div class="ct-bar" style="width:${w}px" title="Etiqueta de capítulo · ${String(o.chapter_duration).replace(".", ",")} s"><span>CAP. ${o.chapter_number}${o.chapter_part ? " · P" + o.chapter_part : ""}</span></div>`;
      }
    } else {
      if (lay) lay.classList.add("hidden");
      S.shown = false;
      el.lane.classList.add("hidden"); el.head.classList.add("hidden"); laneKey = "";
    }
    requestAnimationFrame(tick);
  }

  loadPrefs();
  paintChoices();
  setTimeout(refresh, 1200);
  requestAnimationFrame(tick);
})();
