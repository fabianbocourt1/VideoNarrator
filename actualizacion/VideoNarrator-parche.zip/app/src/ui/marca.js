/* =====================================================================
   VideoNarrator v8.9 — Marca de agua
   Logo (imagen o video, con o sin fondo verde) encima de todo el video, quieto o moviéndose.
   - Tarjeta "Marca de agua" en Estilo (los valores van en campos con id: se guardan con la historia).
   - En el reproductor del editor: el logo en su sitio según el tiempo, y los puntos A y B arrastrables.
   - En la línea de tiempo: carril "Marca" con los rombos de inicio (A) y final (B).
   El video final lo hace core/watermark.py con las mismas reglas de movimiento.
   ===================================================================== */
(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const card = $("wmCard");
  if (!card) return;
  const el = {
    toggle: $("toggleWatermark"), body: $("fxWatermarkOptions"), path: $("wmPath"), thumb: $("wmThumb"),
    name: $("wmName"), info: $("wmInfo"), pick: $("btnWmPick"), chroma: $("wmChroma"), sim: $("wmSim"),
    before: $("wmBefore"), after: $("wmAfter"), cmp: $("wmCmp"), cap: $("wmCap"), when: $("wmWhen"), whenBox: $("wmWhenBox"),
    start: $("wmStart"), end: $("wmEnd"), size: $("wmSize"), sizeVal: $("wmSizeVal"), op: $("wmOpacity"), opVal: $("wmOpacityVal"),
    move: $("wmMove"), seg: $("wmSeg"), ax: $("wmAx"), ay: $("wmAy"), bx: $("wmBx"), by: $("wmBy"),
    atxt: $("wmAtxt"), btxt: $("wmBtxt"), pts: $("wmPts"), hint: $("wmHint"),
    head: $("pvWmHead"), lane: $("pvWmTrack")
  };
  const PINGPONG_HALF = 8, CORNER_STAY = 8, M = 0.03;
  const W = { preview: "", original: "", w: 0, h: 0, lastKey: "" };
  const api = () => window.pywebview && window.pywebview.api;
  const num = (x, d) => { const v = parseFloat(x); return isFinite(v) ? v : d; };
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  // ── Guardar como preferencia (para historias nuevas) ──
  const FIELDS = ["toggleWatermark", "wmPath", "wmChroma", "wmSim", "wmWhen", "wmStart", "wmEnd", "wmSize", "wmOpacity", "wmMove", "wmAx", "wmAy", "wmBx", "wmBy"];
  function savePrefs() {
    const o = {};
    FIELDS.forEach(id => { const e = $(id); if (e) o[id] = e.type === "checkbox" ? e.checked : e.value; });
    try { localStorage.setItem("vn_watermark", JSON.stringify(o)); } catch (e) {}
  }
  function loadPrefs() {
    let o = null;
    try { o = JSON.parse(localStorage.getItem("vn_watermark") || "null"); } catch (e) {}
    if (!o) return;
    FIELDS.forEach(id => { const e = $(id); if (!e || !(id in o)) return; if (e.type === "checkbox") e.checked = !!o[id]; else e.value = o[id]; });
  }

  function opts() {
    return {
      enabled: el.toggle.checked && !!el.path.value,
      path: el.path.value, chroma: el.chroma.checked, sim: el.sim.value,
      size: clamp(num(el.size.value, 18), 3, 90) / 100, opacity: clamp(num(el.op.value, 80), 5, 100) / 100,
      move: el.move.value || "ab",
      ax: clamp(num(el.ax.value, 0.04), 0, 1), ay: clamp(num(el.ay.value, 0.04), 0, 1),
      bx: clamp(num(el.bx.value, 0.96), 0, 1), by: clamp(num(el.by.value, 0.96), 0, 1),
      start: el.when.value === "range" ? Math.max(0, num(el.start.value, 0)) : 0,
      end: el.when.value === "range" ? Math.max(0, num(el.end.value, 0)) : 0
    };
  }
  window.vnWatermark = {
    options() {
      const o = opts();
      if (!o.enabled) return { wm_enabled: false };
      return { wm_enabled: true, wm_path: o.path, wm_chroma: o.chroma, wm_similarity: o.sim, wm_size: o.size, wm_opacity: o.opacity,
               wm_move: o.move, wm_ax: o.ax, wm_ay: o.ay, wm_bx: o.bx, wm_by: o.by, wm_start: o.start, wm_end: o.end };
    }
  };

  // ── Dónde está el logo en el segundo t (mismas reglas que el video final) ──
  function posAt(t, total) {
    const o = opts();
    const t0 = o.start, t1 = (o.end > t0 && o.end <= total) ? o.end : total;
    if (t < t0 - 1e-6 || t > t1 + 1e-6) return null;
    if (o.move === "fixed") return { x: o.ax, y: o.ay };
    if (o.move === "corners") {
      const k = Math.floor(((((t - t0) / CORNER_STAY) % 4) + 4) % 4);
      return { x: (k === 1 || k === 2) ? 1 - M : M, y: k >= 2 ? 1 - M : M };
    }
    let p;
    if (o.move === "pingpong") p = 1 - Math.abs((((t - t0) / PINGPONG_HALF) % 2) - 1);
    else p = clamp((t - t0) / Math.max(0.1, t1 - t0), 0, 1);
    return { x: o.ax + (o.bx - o.ax) * p, y: o.ay + (o.by - o.ay) * p };
  }

  const placeName = (x, y) => `${y < 0.34 ? "Arriba" : y > 0.66 ? "Abajo" : "Al centro"}${x < 0.34 ? " a la izquierda" : x > 0.66 ? " a la derecha" : (y >= 0.34 && y <= 0.66 ? "" : " al centro")}`;

  // ── Tarjeta ──
  function paintCard() {
    const o = opts();
    el.body.classList.toggle("hidden", !el.toggle.checked);
    el.sizeVal.innerText = `${Math.round(o.size * 100)} % del ancho`;
    el.opVal.innerText = `${Math.round(o.opacity * 100)} %`;
    el.whenBox.classList.toggle("hidden", el.when.value !== "range");
    el.seg.querySelectorAll("button").forEach(b => b.classList.toggle("on", b.dataset.move === o.move));
    el.pts.classList.toggle("hidden", o.move === "corners");
    el.pts.querySelectorAll("div")[1].classList.toggle("hidden", o.move === "fixed");
    el.atxt.innerText = o.move === "fixed" ? placeName(o.ax, o.ay) : `${placeName(o.ax, o.ay)} · al empezar`;
    el.btxt.innerText = `${placeName(o.bx, o.by)} · ${o.move === "pingpong" ? "y vuelve" : "al terminar"}`;
    el.hint.innerText = o.move === "corners" ? "Cambia de esquina cada 8 segundos: así es difícil recortarla para copiar tu video."
      : o.move === "pingpong" ? "Va de A a B en 8 segundos y vuelve, todo el tiempo. Arrastra A y B sobre el reproductor del editor."
      : o.move === "fixed" ? "Arrastra el punto A sobre el reproductor del editor para elegir dónde se queda."
      : "Recorre el camino de A a B durante todo el tiempo en que aparece. Arrastra A y B sobre el reproductor del editor.";
    const has = !!el.path.value;
    el.name.innerText = has ? (el.path.value.split(/[\\/]/).pop()) : "Ningún logo elegido";
    el.pick.innerText = has ? "Cambiar" : "Elegir logo";
    el.thumb.classList.toggle("hidden", !W.original);
    if (W.original) el.thumb.src = W.original;
    el.cmp.classList.toggle("hidden", !W.preview);
    el.cap.classList.toggle("hidden", !W.preview);
    if (W.preview) {
      el.before.style.backgroundImage = `url("${W.original}")`;
      el.after.style.setProperty("--img", `url("${W.preview}")`);
    }
  }

  async function refreshPreview() {
    const key = [el.path.value, el.chroma.checked, el.sim.value].join("|");
    if (key === W.lastKey) return;
    W.lastKey = key;
    if (!el.path.value || !api() || !api().watermark_preview) { W.preview = W.original = ""; paintCard(); return; }
    let r = null;
    try { r = await api().watermark_preview(el.path.value, el.chroma.checked, el.sim.value); } catch (e) { r = null; }
    if (key !== W.lastKey) return;
    if (r && !r.error) {
      W.preview = r.preview || ""; W.original = r.original || r.preview || ""; W.w = r.width || 0; W.h = r.height || 0;
      el.info.innerText = `${r.is_video ? "Video" : "Imagen"} · ${r.width}×${r.height}${el.chroma.checked ? " · fondo quitado" : ""}`;
    } else {
      W.preview = W.original = "";
      el.info.innerText = (r && r.error) || "No se pudo leer el archivo.";
    }
    paintCard();
  }

  function changed() { paintCard(); refreshPreview(); savePrefs(); }

  el.toggle.addEventListener("change", changed);
  [el.chroma, el.sim, el.when, el.start, el.end].forEach(x => x.addEventListener("change", changed));
  [el.size, el.op].forEach(x => x.addEventListener("input", changed));
  el.seg.addEventListener("click", (e) => { const b = e.target.closest("button[data-move]"); if (!b) return; el.move.value = b.dataset.move; changed(); });
  el.pick.addEventListener("click", async () => {
    if (!api() || !api().watermark_pick) return;
    let r;
    try { r = await api().watermark_pick(el.chroma.checked, el.sim.value); } catch (e) { r = { error: String(e) }; }
    if (!r || r.cancel) return;
    if (r.error) { alert(r.error); return; }
    el.path.value = r.path;
    W.lastKey = [r.path, el.chroma.checked, el.sim.value].join("|");
    W.preview = r.preview || ""; W.original = r.original || r.preview || ""; W.w = r.width || 0; W.h = r.height || 0;
    el.info.innerText = `${r.is_video ? "Video" : "Imagen"} · ${r.width}×${r.height}${el.chroma.checked ? " · fondo quitado" : ""}`;
    if (!el.toggle.checked) el.toggle.checked = true;
    changed();
  });

  // ── Reproductor del editor: logo + puntos A/B ──
  let layer = null;
  function buildLayer() {
    const pv = window.vnPreview; if (!pv || !pv.stage) return null;
    if (layer && layer.parentNode === pv.stage) return layer;
    layer = document.createElement("div");
    layer.className = "wm-layer";
    layer.innerHTML = `<svg class="wm-path"><line/></svg><img class="wm-img" alt=""><div class="wm-h a" data-h="a"><span>A</span></div><div class="wm-h b" data-h="b"><span>B</span></div>`;
    pv.stage.appendChild(layer);
    layer.querySelectorAll(".wm-h").forEach(h => h.addEventListener("pointerdown", startDrag));
    return layer;
  }
  function geom() {
    const pv = window.vnPreview; const st = pv.stage;
    const sw = st.clientWidth, sh = st.clientHeight;
    const o = opts();
    const ww = sw * o.size;
    const wh = W.w && W.h ? ww * W.h / W.w : ww * 0.35;
    return { sw, sh, ww, wh, fx: Math.max(1, sw - ww), fy: Math.max(1, sh - wh) };
  }
  function paintStage() {
    const pv = window.vnPreview;
    const o = opts();
    const show = !!(pv && pv.stage && o.enabled && W.preview && pv.total() > 0);
    if (!show) { if (layer) layer.classList.add("hidden"); paintLane(false); return; }
    const L = buildLayer(); if (!L) return;
    L.classList.remove("hidden");
    const g = geom();
    const img = L.querySelector(".wm-img");
    if (img.dataset.src !== W.preview) { img.src = W.preview; img.dataset.src = W.preview; }
    const p = posAt(pv.time(), pv.total());
    img.style.display = p ? "block" : "none";
    img.style.width = g.ww + "px";
    img.style.opacity = o.opacity;
    if (p) { img.style.left = (p.x * g.fx) + "px"; img.style.top = (p.y * g.fy) + "px"; }
    const editing = !pv.playing() && o.move !== "corners";
    const ha = L.querySelector(".wm-h.a"), hb = L.querySelector(".wm-h.b"), svg = L.querySelector(".wm-path"), ln = svg.querySelector("line");
    const cx = (x) => x * g.fx + g.ww / 2, cy = (y) => y * g.fy + g.wh / 2;
    ha.style.display = editing ? "grid" : "none";
    hb.style.display = editing && o.move !== "fixed" ? "grid" : "none";
    svg.style.display = editing && o.move !== "fixed" ? "block" : "none";
    ha.style.left = cx(o.ax) + "px"; ha.style.top = cy(o.ay) + "px";
    hb.style.left = cx(o.bx) + "px"; hb.style.top = cy(o.by) + "px";
    svg.setAttribute("width", g.sw); svg.setAttribute("height", g.sh);
    ln.setAttribute("x1", cx(o.ax)); ln.setAttribute("y1", cy(o.ay)); ln.setAttribute("x2", cx(o.bx)); ln.setAttribute("y2", cy(o.by));
    paintLane(true, o);
  }
  function startDrag(ev) {
    ev.preventDefault(); ev.stopPropagation();
    const which = ev.currentTarget.dataset.h;
    const st = window.vnPreview.stage, r = st.getBoundingClientRect();
    const mv = (e) => {
      const g = geom();
      const x = clamp((e.clientX - r.left - g.ww / 2) / g.fx, 0, 1), y = clamp((e.clientY - r.top - g.wh / 2) / g.fy, 0, 1);
      if (which === "a") { el.ax.value = x.toFixed(3); el.ay.value = y.toFixed(3); } else { el.bx.value = x.toFixed(3); el.by.value = y.toFixed(3); }
      paintCard(); paintStage();
    };
    const up = () => { document.removeEventListener("pointermove", mv); document.removeEventListener("pointerup", up); savePrefs(); };
    document.addEventListener("pointermove", mv); document.addEventListener("pointerup", up);
  }

  // ── Carril "Marca" en la línea de tiempo ──
  let laneKey = "";
  function paintLane(show, o) {
    if (!el.lane || !el.head) return;
    el.lane.classList.toggle("hidden", !show); el.head.classList.toggle("hidden", !show);
    if (!show) { laneKey = ""; return; }
    const pv = window.vnPreview, total = pv.total(), pps = pv.pps() || 1;
    const t0 = o.start, t1 = (o.end > t0 && o.end <= total) ? o.end : total;
    const k = [total, pps, t0, t1, o.move, W.preview.length].join("|");
    if (k === laneKey) return;
    laneKey = k;
    el.lane.style.width = (total * pps) + "px";
    const label = { fixed: "Fija", ab: "De A a B", pingpong: "Ida y vuelta", corners: "Esquinas" }[o.move] || "";
    el.lane.innerHTML = `<div class="wm-bar" style="left:${t0 * pps}px;width:${Math.max(4, (t1 - t0) * pps - 2)}px" title="Marca de agua · ${label}">
      ${W.preview ? `<img src="${W.preview}" alt="">` : ""}<span>Marca de agua · ${label}</span></div>
      <i class="wm-kf a" style="left:${t0 * pps}px" title="Punto A · inicio"></i>${o.move === "fixed" || o.move === "corners" ? "" : `<i class="wm-kf b" style="left:${t1 * pps}px" title="Punto B · final"></i>`}`;
  }

  // ── Bucle: sigue al reproductor y a los cambios hechos desde fuera (abrir otra historia) ──
  let lastPath = null, lastToggle = null;
  function tick() {
    if (el.path.value !== lastPath || el.toggle.checked !== lastToggle) {
      lastPath = el.path.value; lastToggle = el.toggle.checked;
      paintCard(); refreshPreview();
    }
    if (document.visibilityState === "visible") paintStage();
    requestAnimationFrame(tick);
  }
  loadPrefs();
  paintCard();
  setTimeout(refreshPreview, 1500);
  requestAnimationFrame(tick);
})();
